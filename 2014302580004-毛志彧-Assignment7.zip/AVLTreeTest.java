import javax.swing.*;

public class AVLTreeTest {
	public static void main(String[] args){
		AVLTree avl=new AVLTree();
		//����AVL��
		Node n1=new Node();
		n1.setId(2);
		n1.setData("AVLTree");
		Node n2=new Node();
		n2.setId(5);
		n2.setData();
		Node n3=new Node();
		n3.setId(7);
		n3.setData();
		Node n4=new Node();
		n4.setId(10);
		n4.setData();
		Node n5=new Node();
		n5.setId(6);
		n5.setData();
		Node n6=new Node();
		n6.setId(11);
		n6.setData();
		//�������
		System.out.print(avl.get(7));
		Node x=avl.root;
		avl.insert(x,n1);
		avl.insert��n2);
		avl.insert(n3);
		avl.insert(n4);
		avl.insert(n5);
		avl.insert(n6);
		//ɾ������
		JTree jt=avl.printTree();
		JFrame jf=new JFrame();
		jf.add(jt);
		jf.setVisible(true);
		jf.setSize(600, 600);
		jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		avl.delete(10);
		avl.printTree();
	}
	
	
}
