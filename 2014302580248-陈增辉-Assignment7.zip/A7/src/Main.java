import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;


public class Main {
	public static void main(String []args) throws FileNotFoundException{
		AVLTree tree=new AVLTree();
		File f=new File("tree_data.dat");
		Scanner s=new Scanner(f);
		while(s.hasNextLine()){
			String temp=s.nextLine();
			String [] data=temp.split("#");
			Node n=new Node();
			n.setData(data[0]);
			n.setId(Integer.valueOf(data[1]));
			tree.insert(n);
			//tree.printTree();
		}
		Node n = tree.get(3);
		//Object data = "art";
		//Node m = tree.Search(data);
		System.out.println(String.format("%s,%d", n.getData(),n.getId()));
		//System.out.println(String.format("%s,%d", m.getData(),m.getId()));
		tree.printTree();
		tree.delete(8);
		tree.printTree();
	}
}
