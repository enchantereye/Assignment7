import javax.swing.JFrame;
import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;


public class AVLTree {
	public Node root;
	public boolean unBalanced;  //�ж��Ƿ�ƽ��
	public boolean heightLower; //�жϸ߶��Ƿ񽵵�
	public AVLTree(){
		root = null;
		unBalanced = false;
	}
	
	public Node get(int id){
		Node m = root;
		while(m.getId()!=id){
			if(m.getId()>id){
				if(m.getLChild() == null){System.out.println("No such id");return null;}
				m = m.getLChild();
			}else{
				if(m.getRChild() == null){System.out.println("No such id");return null;}
				m = m.getRChild();
			}
		}
		return m;
	}
	//����
	public Node Search(Object data){
		return Search(root,data);
	}
	public Node Search(Node p,Object data){
		if(p == null){return null;}
		else if(p.getData() == data){return p;}
		else{
			if(Search(p.getLChild(),data) == null){return Search(p.getRChild(),data);}
			else{return Search(p.getLChild(),data);}
		}
	}
	//����
	public void insert(Node newNode){
		if(root == null){ root = newNode;return;}
		else{insert(newNode,root,null);}
	}
	public void insert(Node newNode,Node p,Node pparent){
		//IDС��ʱ����������
		if(newNode.getId() < p.getId()){
			if(p.getLChild() == null){
				p.setLChild(newNode);newNode.setParent(p);unBalanced = true;
				p.setBalanceFactor(p.getBalanceFactor()+1);return;
			}
			else{
				insert(newNode,p.getLChild(),p);
				if(unBalanced){
				switch(p.getBalanceFactor()){
				case -1:p.setBalanceFactor(0) ;unBalanced = false;break;
				case 0:p.setBalanceFactor(1);break;
				case 1:LRotation(p,pparent);
				}
				}
			}
		}
		//�������������
		else{
			if(p.getRChild() == null){
				p.setRChild(newNode);newNode.setParent(p);unBalanced = true;
				p.setBalanceFactor(p.getBalanceFactor()-1);
			}
			else{insert(newNode,p.getRChild(),p);
			    if(unBalanced){
				    switch(p.getBalanceFactor()){
				    case -1:RRotation(p,pparent);break;
				    case 0:p.setBalanceFactor(-1);break;
				    case 1:p.setBalanceFactor(0);unBalanced = false;
				    }
			    }
			}
			}
	}
	//����ת����
	public void LRotation(Node p,Node pparent){
		Node u,r = p.getLChild();
		Node l = p.getRChild();
		if(r.getBalanceFactor() == 1){  //LL��ת
			p.setLChild(r.getRChild()); r.setRChild(p);
			if(p == root) root = r;//r�������ĸ�
			else if( pparent.getLChild() == p){pparent.setLChild(r); }
			else{pparent.setRChild(r);}
			p.setBalanceFactor(0);
			r.setBalanceFactor(0);
		}
		else{              //LR��ת
			u = l.getRChild();r.setRChild(l.getLChild());
			u.setLChild(r);p.setLChild(u.getRChild());
			u.setRChild(p);
			
			if(p == root) root = u;//u�������ĸ�
			else if( pparent.getLChild() == p){pparent.setLChild(l.getLChild()); }
			else{pparent.setRChild(l.getLChild());}
			
			switch(u.getBalanceFactor()){
			case 1:p.setBalanceFactor(-1);r.setBalanceFactor(0);break;
			case 0:p.setBalanceFactor(0);r.setBalanceFactor(0);break;
			case -1:p.setBalanceFactor(0);r.setBalanceFactor(1);
			}
			l.getLChild().setBalanceFactor(0); 
		}
		
		unBalanced = false;  //����ƽ�����
	}
	//����ת����
	public void RRotation(Node p,Node pparent){
		Node u,r = p.getRChild();
		if(r.getBalanceFactor() == -1||r.getBalanceFactor() == 0){
			p.setRChild(r.getLChild()); r.setLChild(p);
			if(p == root) root = r;//r�������ĸ�
			else if( pparent.getLChild() == p){pparent.setLChild(r); }
			else{pparent.setRChild(r);}
			p.setBalanceFactor(0);
			r.setBalanceFactor(0);
		}
		else{
			u = r.getLChild();r.setLChild(u.getRChild());
			u.setRChild(r);p.setRChild(u.getLChild());
			u.setLChild(p);
			
			if(p == root) root = u;//u�������ĸ�
			else if( pparent.getLChild() == p){pparent.setLChild(r.getRChild()); }
			else{pparent.setRChild(r.getRChild());}
			
			switch(u.getBalanceFactor()){
			case 1:p.setBalanceFactor(0);r.setBalanceFactor(-1);break;
			case 0:p.setBalanceFactor(0);r.setBalanceFactor(0);break;
			case -1:p.setBalanceFactor(1);r.setBalanceFactor(0);
			}
			u.setBalanceFactor(0); //�ڵ�p��ƽ������Ϊ0
		}
		
		unBalanced = false;  //����ƽ�����
	}
	//ɾ��
	public void delete(int id){
		Node m = get(id);
		//m����Ҫɾ���ڵ�
		if(m == null){System.out.println("No such Id.");}
		else{
			//��ɾ�ڵ�����������Ϊ��
			if(m.getLChild() == null && m.getRChild() == null){
				Node p = getParent(m.getId());
				balance(p,m);
				}
			//������Ϊ��
			else if(m.getLChild() == null && m.getRChild() != null){
				m.setData(m.getLChild().getData());
				m.setId(m.getLChild().getId());
				balance(m,m.getLChild());
			}
			//������Ϊ��
			else if(m.getLChild() != null && m.getRChild() == null){
				m.setData(m.getRChild().getData());
				m.setId(m.getRChild().getId());
				balance(m,m.getRChild());
			}
			//���Ҷ���Ϊ��
			else if(m.getLChild() != null && m.getRChild() != null){
				Node change = m.getRChild();
				Node parent = m;
				while(change.getLChild() != null && change.getRChild() != null){
					parent = change;
					change = change.getLChild();
				}
				if(change.getLChild() == null && change.getLChild() == null){
					m.setData(change.getData());
					m.setId(change.getId());
					balance(parent,change);
				}else if(change.getLChild() == null){
					m.setData(change.getData());
					m.setId(change.getId());
					change.setData(change.getRChild().getData());
					change.setId(change.getRChild().getId());
					balance(change,change.getRChild());
				}else{
					m.setData(change.getData());
					m.setId(change.getId());
					change.setData(change.getLChild().getData());
					change.setId(change.getLChild().getId());
					balance(change,change.getLChild());
				}
			}
		}
	}
	public void balance(Node p,Node m){
		if(p.getBalanceFactor() == 0){
			if(p.getLChild() == m){p.setBalanceFactor(-1);}
			else if(p.getRChild() == m){p.setBalanceFactor(1);}
		}
		else {heightLower = true;}
		//���p����root��heightLowerΪ��
		if(p != root && heightLower){
			Node pparent = getParent(p.getId());
			while(heightLower){
				if((p.getBalanceFactor() == -1 && p.getRChild() == m)
						||(p.getBalanceFactor() == 1 && p.getLChild() == m)){
					p.setBalanceFactor(0);
					continue;
				}
				else if(p.getBalanceFactor() == 0){
					if(p.getLChild() == m){p.setBalanceFactor(-1);}
					else{p.setBalanceFactor(1);}
					heightLower = false;
				}
				else if(p.getBalanceFactor() == 1 && p.getRChild() == m){
					//��߽ϸ�ʱɾ������
					if(pparent != root){
						if(p.getLChild().getBalanceFactor() == 0){
							heightLower = false;
						}
						LRotation(pparent,getParent(pparent.getId()));
					}else{
						RRotation(pparent,null);
					}
				}
				else if(p.getBalanceFactor()==-1 && p.getLChild() == m){
					//�ұ߽ϸ�ʱɾ������
					if(pparent != root){
						if(p.getRChild().getBalanceFactor() == 0){
							heightLower = false;
						}
						RRotation(p,pparent);
					}else{
						RRotation(pparent,null);
					}
				}
				p = pparent;
				if(p == root){
					break;
				}else{
					pparent = getParent(p.getId());
				}
			}
		}
		else{
			heightLower = false;
		}
		heightLower = false;
	}
		
		
	
	public Node getParent(int id){
		Node m = root;
		Node p = null;
		while(m.getId()!=id){
			if(m.getId()>id){
				if(m.getLChild() == null){System.out.println("No such id");return null;}
				p = m;
				m = m.getLChild();
			}else{
				if(m.getRChild() == null){System.out.println("No such id");return null;}
				p = m;
				m = m.getRChild();
			}
		}
		return p;
	}
	
	
	public JTree printTree(){
		DefaultMutableTreeNode top=new DefaultMutableTreeNode(String.format("%s,%d", root.getData(),root.getId()));
		creatJTree(root,top);
		JTree tree=new JTree(top);
		JFrame f=new JFrame("��");
		f.add(tree);
		f.setSize(500, 500);
		f.setVisible(true);
		return tree;
	}

	public void creatJTree(Node p, DefaultMutableTreeNode top) {
		// TODO Auto-generated method stub
		if(p == null){
			return;
		}
		DefaultMutableTreeNode n=new DefaultMutableTreeNode(String.format("%s,%d", p.getData(),p.getId()));
		top.add(n);
		creatJTree(p.getLChild(), n);
		creatJTree(p.getRChild(), n);
	}
	
}




