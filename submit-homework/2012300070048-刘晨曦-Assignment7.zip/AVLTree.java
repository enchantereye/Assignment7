import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;

public class AVLTree implements IAVLTree {

	private Node root;

	public AVLTree() {
		root = null;
	}

	@Override
	public Node get(int id) {
		return get(this.root, id);
	}

	@Override
	public void insert(Node newNode) {
		if (root == null) {
			this.root = newNode;
			this.root.setHeight(1);
			return;
		}
		Node temp = root;
		Node insertPos = null;
		// �ҵ�������Ԫ�ص�λ��
		while (temp != null) {
			insertPos = temp;
			if (newNode.getId() < temp.getId()) {
				temp = temp.getChildren()[0];
			} else if (newNode.getId() > temp.getId()) {
				temp = temp.getChildren()[1];
			} else {
				return; // �����ظ�Ԫ��
			}
		}
		// ����Ԫ��
		if (newNode.getId() < insertPos.getId()) {
			newNode.setParent(insertPos);
			insertPos.setChild(newNode, 0);
		} else {
			newNode.setParent(insertPos);
			insertPos.setChild(newNode, 1);
		}
		// ����ƽ�����ӽ�����ת
		Node pointerS = newNode.getParent();
		while (pointerS != null) {
			pointerS.calBalanceFactor();
			int bf_S = pointerS.getBalanceFactor();
			if (bf_S == 2) {
				pointerS.getChildren()[0].calBalanceFactor();
				int bf_r = pointerS.getChildren()[0].getBalanceFactor();
				if (bf_r == 1) {
					LLrotation(pointerS);
				} else if (bf_r == -1) {
					LRrotation(pointerS);
				}
			} else if (bf_S == -2) {
				pointerS.getChildren()[1].calBalanceFactor();
				int bf_r = pointerS.getChildren()[1].getBalanceFactor();
				if (bf_r == -1) {
					RRrotation(pointerS);
				} else if (bf_r == 1) {
					RLrotation(pointerS);
				}

			}
			pointerS = pointerS.getParent();
		}
	}

	@Override
	public void delete(int id) {
		Node deleteL = get(id);    // Ҫ��ɾ���Ľ��
		Node s = new Node();
		if (deleteL == null) {
			// Ҫɾ����Ԫ�ز�����
			return;
		}
		// ����Ǳ�ɾ��������ҽ�㶼���ڵ�����£�����ת��Ϊ���ֻ����һ���������
		if (deleteL.getChildren()[0] != null && deleteL.getChildren()[1] != null) {
			s = deleteL.getChildren()[1];
			while (s.getChildren()[0] != null) {
				s = s.getChildren()[0];
			}
			deleteL.setData(s.getData());
			deleteL.setId(s.getId());
			deleteL = s;
		}
		// ��ɾ������Ƿ���˫�׽��
		if (deleteL.getParent() != null) {
			// ������������ۣ����߶�û�С�����У��ұ���
			if (deleteL.getChildren()[0] != null && deleteL.getChildren()[1] == null) {
				deleteL.getChildren()[0].setParent(deleteL.getParent());
				if (deleteL.getParent().getChildren()[0] == deleteL) {
					deleteL.getParent().setChild(deleteL.getChildren()[0], 0);
				} else if (deleteL.getParent().getChildren()[1] == deleteL) {
					deleteL.getParent().setChild(deleteL.getChildren()[0], 1);
				}
			} else if (deleteL.getChildren()[0] == null && deleteL.getChildren()[1] != null) {
				deleteL.getChildren()[1].setParent(deleteL.getParent());
				if (deleteL.getParent().getChildren()[0] == deleteL) {
					deleteL.getParent().setChild(deleteL.getChildren()[1], 0);
				} else if (deleteL.getParent().getChildren()[1] == deleteL) {
					deleteL.getParent().setChild(deleteL.getChildren()[1], 1);
				}
			} else {
				if (deleteL.getId() < deleteL.getParent().getId())
					deleteL.getParent().setChild(null, 0);
				else
					deleteL.getParent().setChild(null, 1);
			}
		} else {
			if (deleteL.getChildren()[0] != null && deleteL.getChildren()[1] == null) {
				deleteL.getChildren()[0].setParent(null);
				root = deleteL.getChildren()[0];
			} else if (deleteL.getChildren()[0] == null && deleteL.getChildren()[1] != null) {
				deleteL.getChildren()[1].setParent(null);
				root = deleteL.getChildren()[1];
			} else {
				root = null;
			}
		}

		// ����ƽ�����ӣ�ƽ��ö�����
		Node pointerS = deleteL.getParent();
		while (pointerS != null) {
			pointerS.calBalanceFactor();
			int bf_S = pointerS.getBalanceFactor();
			if (bf_S == 2) {
				pointerS.getChildren()[0].calBalanceFactor();
				int bf_r = pointerS.getChildren()[0].getBalanceFactor();
				if (bf_r == 1) {
					LLrotation(pointerS);
				} else if (bf_r == -1) {
					LRrotation(pointerS);
				}
			} else if (bf_S == -2) {
				pointerS.getChildren()[1].calBalanceFactor();
				int bf_r = pointerS.getChildren()[1].getBalanceFactor();
				if (bf_r == -1) {
					RRrotation(pointerS);
				} else if (bf_r == 1) {
					RLrotation(pointerS);
				}

			}
			pointerS = pointerS.getParent();
		}
	}

	@Override
	public JTree printTree() {
		JTree jTree = new JTree(printTree(this.root));
		return jTree;
	}

	private DefaultMutableTreeNode printTree(Node node) {
		if (node == null) {
			return null;
		}
		DefaultMutableTreeNode left = printTree(node.getChildren()[0]);
		DefaultMutableTreeNode right = printTree(node.getChildren()[1]);
		DefaultMutableTreeNode nodeNode = new DefaultMutableTreeNode(
				node.getData().toString() + "(" + node.getId() + ")");
		if (left != null) {
			nodeNode.add(left);
		}
		if (right != null) {
			nodeNode.add(right);
		}
		return nodeNode;
	}

	private Node get(Node node, int id) {
		if (node == null) {
			return null;
		}
		if (node.getId() == id) {
			return node;
		} else if (node.getId() > id) {
			return get(node.getChildren()[0], id);
		} else {
			return get(node.getChildren()[1], id);
		}
	}

	// RR��ת
	private void RRrotation(Node s) {
		Node pointer_r = s.getChildren()[1];
		if (s == root) {
			root = pointer_r;
		}

		s.setChild(pointer_r.getChildren()[0], 1);
		if (pointer_r.getChildren()[0] != null) {
			pointer_r.getChildren()[0].setParent(s);
		}

		pointer_r.setParent(s.getParent());
		if (s.getParent() != null) {
			if (s.getParent().getChildren()[0] == s) {
				s.getParent().setChild(pointer_r, 0);
			} else {
				s.getParent().setChild(pointer_r, 1);
			}
		}

		s.setParent(pointer_r);
		pointer_r.setChild(s, 0);
	}
	// LL��ת
	private void LLrotation(Node s) {
		Node pointer_r = s.getChildren()[0];
		if (s == root) {
			root = pointer_r;
		}

		s.setChild(pointer_r.getChildren()[1], 0);
		if (pointer_r.getChildren()[1] != null) {
			pointer_r.getChildren()[1].setParent(s);
		}

		pointer_r.setParent(s.getParent());
		if (s.getParent() != null) {
			if (s.getParent().getChildren()[0] == s) {
				s.getParent().setChild(pointer_r, 0);
			} else {
				s.getParent().setChild(pointer_r, 1);
			}
		}

		pointer_r.setChild(s, 1);
		s.setParent(pointer_r);
	}
	// LR��ת = RR + LL
	private void LRrotation(Node s) {
		RRrotation(s.getChildren()[0]);
		LLrotation(s);
	}

	// RL��ת = LL + RR
	private void RLrotation(Node s) {
		LLrotation(s.getChildren()[1]);
		RRrotation(s);
	}
}
