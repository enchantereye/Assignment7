public class Test{

	public static void main(String args[]) {
		Gui test = new Gui();
		test.run();
	}
}
