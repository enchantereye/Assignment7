
public class Node {
	private int id;
	private Object data;
	private Node parent;
	private Node[] children = new Node[2];
	private int height;
	private int lSubTreeHeight;
	private int rSubTreeHeight;
	private int balanceFactor;

	public void setId(int idL) {
		this.id = idL;
	}

	public int getId() {
		return id;
	}

	public Object getData() {
		return data;
	}

	public void setData(Object data) {
		this.data = data;
	}

	public Node getParent() {
		return parent;
	}

	public void setParent(Node parent) {
		this.parent = parent;
	}

	public Node[] getChildren() {
		return children;
	}

	public void setChildren(Node[] children) {
		this.children = children;
	}

	public void setChild(Node child, int id) {
		this.children[id] = child;
	}

	public int getlSubTreeHeight() {
		// TODO calculate the left sub tree height
		return lSubTreeHeight;
	}

	public void setlSubTreeHeight(int i) {
		lSubTreeHeight = i;
	}

	public int getrSubTreeHeight() {
		// TODO calculate the right sub tree height
		return rSubTreeHeight;
	}

	public void setrSubTreeHeight(int i) {
		rSubTreeHeight = i;
	}

	public int getBalanceFactor() {
		// TODO calculate the balance factor
		return balanceFactor;
	}

	public void setBalanceFactor(int bf) {
		balanceFactor = bf;
	}

	public void calBalanceFactor() {
		if (children[0] == null && children[1] == null) {
			balanceFactor = 0;
		} else if (children[0] != null && children[1] == null) {
			balanceFactor = children[0].getHeight();
		} else if (children[0] == null && children[1] != null) {
			balanceFactor = 0 - children[1].getHeight();
		} else {
			balanceFactor = children[0].getHeight() - children[1].getHeight();
		}
	}

	public void setHeight(int i) {
		height = i;
	}

	public int getHeight() {
		return getHeight(this);
	}

	private int getHeight(Node t) {
		int depthLeft = 1;
		int depthRight = 1;
		int depth = 0;

		if (t.children[0] != null) {
			depthLeft = getHeight(t.children[0]) + 1;
		}
		if (t.children[1] != null) {
			depthRight = getHeight(t.children[1]) + 1;
		}
		
		if (depthLeft >= depthRight) {
			depth = depthLeft;
		} 
		else {
			depth = depthRight;
		}
		return depth;
	}

}
