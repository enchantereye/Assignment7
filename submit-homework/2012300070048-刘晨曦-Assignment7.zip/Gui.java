
import java.awt.BorderLayout;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import javax.swing.*;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

@SuppressWarnings("serial")
public class Gui extends JFrame implements ActionListener{

	private AVLTree tree;
	private JScrollPane treePanel;
	private JPanel contentPane;
	private JTree avlTree;
	private JTextField searchField;
	private JTextField insertField_1;
	private JTextField insertField_2;
	private JTextField deleteField;
	private JButton searchButton;
	private JButton insertButton;
	private JButton deleteButton;
	
	public Gui() {
		super("AVLTree");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1012, 714);

		contentPane = new JPanel();
		contentPane.setLayout(null);
		this.add(contentPane, BorderLayout.CENTER);

		String str;
		String[] strArr;
		tree = new AVLTree();
		BufferedReader bre;
		try {
			String file = "tree_data.dat";
			bre = new BufferedReader(new FileReader(file));
			while ((str = bre.readLine()) != null) {
				Node temp = new Node();
				strArr = str.split("#");
				temp.setData(strArr[0]);
				temp.setId(Integer.parseInt(strArr[1]));
				tree.insert(temp);
			}
			bre.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		avlTree = new JTree();
		avlTree = tree.printTree();
		
		
		treePanel = new JScrollPane(avlTree);
		this.add(treePanel,BorderLayout.NORTH);
		
		searchField = new JTextField();
		searchField.setBounds(536, 34, 139, 43);
		contentPane.add(searchField);
		searchField.setColumns(10);
		
		searchButton = new JButton("\u67E5\u627Eid");
		searchButton.setFont(new Font("΢���ź�", Font.PLAIN, 20));
		searchButton.setBounds(694, 33, 139, 44);
		searchButton.addActionListener(this);
		contentPane.add(searchButton);
		
		JLabel lblId = new JLabel("ID");
		lblId.setHorizontalAlignment(SwingConstants.CENTER);
		lblId.setFont(new Font("΢���ź�", Font.PLAIN, 20));
		lblId.setBounds(420, 94, 112, 43);
		contentPane.add(lblId);
		
		insertField_1 = new JTextField();
		insertField_1.setColumns(10);
		insertField_1.setBounds(536, 94, 139, 43);
		contentPane.add(insertField_1);
		
		insertField_2 = new JTextField();
		insertField_2.setColumns(10);
		insertField_2.setBounds(536, 158, 139, 43);
		contentPane.add(insertField_2);
		
		insertButton = new JButton("\u6DFB\u52A0\u5143\u7D20");
		insertButton.setFont(new Font("΢���ź�", Font.PLAIN, 20));
		insertButton.setBounds(694, 154, 139, 44);
		insertButton.addActionListener(this);
		contentPane.add(insertButton);
		
		JLabel lblData = new JLabel("Data");
		lblData.setHorizontalAlignment(SwingConstants.CENTER);
		lblData.setFont(new Font("΢���ź�", Font.PLAIN, 20));
		lblData.setBounds(420, 158, 112, 43);
		contentPane.add(lblData);
		
		JLabel label = new JLabel("ID");
		label.setHorizontalAlignment(SwingConstants.CENTER);
		label.setFont(new Font("΢���ź�", Font.PLAIN, 20));
		label.setBounds(420, 221, 112, 43);
		contentPane.add(label);
		
		deleteField = new JTextField();
		deleteField.setColumns(10);
		deleteField.setBounds(536, 221, 139, 43);
		contentPane.add(deleteField);
		
		deleteButton = new JButton("\u5220\u9664\u5143\u7D20");
		deleteButton.setFont(new Font("΢���ź�", Font.PLAIN, 20));
		deleteButton.setBounds(694, 221, 139, 44);
		deleteButton.addActionListener(this);
		contentPane.add(deleteButton);
	}
	
	public void run() {
		this.setVisible(true);
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == searchButton) {
			int id = Integer.parseInt(searchField.getText());
			if (tree.get(id) != null) {
				JOptionPane.showMessageDialog(this, "Ԫ��Ϊ�� " + tree.get(id).getData(),"���ҳɹ�",JOptionPane.INFORMATION_MESSAGE);
			}
			else {
				JOptionPane.showMessageDialog(this, "����ʧ��","ERROR",JOptionPane.INFORMATION_MESSAGE);
			}
		}
		else if (e.getSource() == insertButton) {
			if (tree.get(Integer.parseInt(insertField_1.getText())) != null) {
				JOptionPane.showMessageDialog(this, "��id�Ѿ�����","ERROR",JOptionPane.INFORMATION_MESSAGE);
				return;
			}
			Node temp = new Node();
			temp.setId(Integer.parseInt(insertField_1.getText()));
			temp.setData(insertField_2.getText());
			tree.insert(temp);
			avlTree = tree.printTree();
			treePanel.setViewportView(avlTree);
		}
		else if (e.getSource() == deleteButton) {
			int id = Integer.parseInt(deleteField.getText());
			if (tree.get(id) == null) {
				JOptionPane.showMessageDialog(this, "��id������","ERROR",JOptionPane.INFORMATION_MESSAGE);
				return;
			}
			tree.delete(id);
			avlTree = tree.printTree();
			treePanel.setViewportView(avlTree);
		}
	}
}
