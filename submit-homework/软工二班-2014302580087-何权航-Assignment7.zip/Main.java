
public class Main {

	public static void main(String[] args) {
		    // TODO 自动生成的方法存根
		    AVLTree avlTree=new AVLTree();
			Node a=new Node(1, "ant");
			Node b=new Node(2, "apple");
			Node c=new Node(3, "art");
			Node d=new Node(4, "baby");
			Node e=new Node(5, "banan");
			Node f=new Node(6, "car");
			Node g=new Node(7, "door");
			Node h=new Node(8, "dress");
			Node i=new Node(9, "frog");
			Node j=new Node(10, "love");
			Node k=new Node(11, "mint");
			Node l=new Node(12, "rice");
			Node m=new Node(13, "show");
			Node n=new Node(14, "table");
			Node o=new Node(15, "tree");
			Node p=new Node(16, "trouble");
			Node q=new Node(17, "window");
			avlTree.insert(a);	
			avlTree.insert(b);
			avlTree.insert(c);
			avlTree.insert(d);
			avlTree.insert(e);
			avlTree.insert(f);
			avlTree.insert(g);
			avlTree.insert(h);
			avlTree.insert(i);
			avlTree.insert(j);
			avlTree.insert(k);
			avlTree.insert(l);
			avlTree.insert(m);
			avlTree.insert(n);
			avlTree.insert(o);
			avlTree.insert(p);
			avlTree.insert(q);
			avlTree.printTree(a);	
			avlTree.printTree(b);
			avlTree.printTree(c);
			avlTree.printTree(d);
			avlTree.printTree(e);
			avlTree.printTree(f);
			avlTree.printTree(g);
			avlTree.printTree(h);
			avlTree.printTree(i);
			avlTree.printTree(j);
			avlTree.printTree(k);
			avlTree.printTree(l);
			avlTree.printTree(m);
			avlTree.printTree(n);
			avlTree.printTree(o);
			avlTree.printTree(p);
			avlTree.printTree(q);
			

	}

}
