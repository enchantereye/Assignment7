
public class Node {
	private int id;
	private Object data;
	private Node parent;
	private Node[] children = new Node[2];
	private int lSubTreeHeight;
	private int rSubTreeHeight;
	private int balanceFactor;
	
    public Node(int id,Object data) {
		
		this.data=data;
		this.id=id;
		children[0]=null;
		children[1]=null;
		parent=null;
		lSubTreeHeight=0;
		rSubTreeHeight=0;
		balanceFactor=0;
		
	}
	public int getId() {
		return id;
	}
	public Object getData() {
		return data;
	}
	public void setData(Object data) {
		this.data = data;
	}
	public Node getParent() {
		return parent;
	}
	public void setParent(Node parent) {
		this.parent = parent;
	}
	public Node[] getChildren() {
		return children;
	}
	public void setChildren(Node[] children) {
		this.children = children;
	}
	public void setChild(Node child, int id){
		this.children[id] = child;
	}
	public int getlSubTreeHeight() {
		//TODO calculate the left sub tree height
		if(this.getChildren()[0]==null){
			lSubTreeHeight=0;
		}
		else{
			lSubTreeHeight=Math.max(this.children[0].lSubTreeHeight, this.children[0].rSubTreeHeight)+1;
		}
		return lSubTreeHeight;
	}
	public int getrSubTreeHeight() {
		//TODO calculate the right sub tree height
		if (this.children[1]==null) {
			rSubTreeHeight=0;
		}else {
			rSubTreeHeight=Math.max(this.children[1].lSubTreeHeight, this.children[1].rSubTreeHeight)+1;
		}
		return rSubTreeHeight;
	}
	public int getBalanceFactor() {
		//TODO calculate the balance factor
		balanceFactor=this.getlSubTreeHeight()-this.getrSubTreeHeight();
		return balanceFactor;
		
	}

	

}
