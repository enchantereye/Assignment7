import javax.swing.JTree;


public class AVLTree implements IAVLTree{

    private Node root;
	public AVLTree() {
		root=null;
	}
	public Node getRoot() {
		return root;
	}
	
	public Node get(int id) {
		// TODO 自动生成的方法存根
		return Search(root,id);
	}
	private Node Search(Node node, int id) {
		// TODO 自动生成的方法存根
        if (node!=null) {
			if (id==node.getId()) {
				return node;
			}
			if (id<node.getId()) {
				return Search(node.getChildren()[0], id);
			}
			if (id>node.getId()) {
				return Search(node.getChildren()[1], id);
			}
		}
		return node;
	}
	public void insert(Node newNode) {
		// TODO 自动生成的方法存根
		if(root==null){
			root=newNode;
			root.setParent(null);
		}
		else{
			root=Insert(root,newNode);
		}
	}
	private Node Insert(Node node, Node newNode) {
		// TODO 自动生成的方法存根
		//插入左子树
		if(node.getId()>newNode.getId()){
			if(node.getChildren()[0]==null){
				node.setChild(newNode,0);
				newNode.setParent(node);
			}
			else{
				Insert(node.getChildren()[0],newNode);
			}
		}
		if(node.getBalanceFactor()==2){
			node=LRotation(node);
		}
		//插入右子树
		if(node.getId()<newNode.getId()){
			if(node.getChildren()[1]==null){
				node.setChild(newNode,1);
				newNode.setParent(node);
			}
			else{
				Insert(node.getChildren()[1],newNode);
			}
		}
		if(node.getBalanceFactor()==-2){
			node=RRotation(node);
		}
		return node;
	}
	//右旋转
	private Node RRotation(Node node) {
		// TODO 自动生成的方法存根
		//RR旋转
		if(node.getChildren()[1].getBalanceFactor()==-1){
			Node s=node;
			Node r=node.getChildren()[1];
			s.setChild(r.getChildren()[0], 1);
			if (r.getChildren()[0]!=null) {
				r.getChildren()[0].setParent(s);
			}

			r.setChild(s, 0);
			if (s!=null) {
				s.setParent(r);
			}
			node=r;
		}
		//RL旋转
        if(node.getChildren()[1].getBalanceFactor()==1){
        	Node s=node;
    		Node r=s.getChildren()[1];
    		Node u=r.getChildren()[0];
    		s.setChild(u.getChildren()[0], 1);
    		if (u.getChildren()[0]!=null) {
    			u.getChildren()[0].setParent(s);
    		}
    		r.setChild(u.getChildren()[1], 0);
    		if (u.getChildren()[1]!=null) {
    			u.getChildren()[1].setParent(r);
    		}
    		u.setChild(s, 0);
    		if (s!=null) {
    			s.setParent(u);
    		}
    		u.setChild(r, 1);
    		if (r!=null) {
    			r.setParent(u);
    		}
    		node=u;
		}
		return node;
	}
	//左旋转
	private Node LRotation(Node node) {
		// TODO 自动生成的方法存根
		//LL旋转
		if(node.getChildren()[0].getBalanceFactor()==1){
			Node s=node;
			Node r=node.getChildren()[0];
			s.setChild(r.getChildren()[1], 0);
			if (r.getChildren()[1]!=null) {
				r.getChildren()[1].setParent(s);
			}
			
			r.setChild(s, 1);
			if (s!=null) {
				s.setParent(r);
			}
			node=r;
		}
		//LR旋转
		if(node.getChildren()[0].getBalanceFactor()==-1){
			Node s=node;
			Node r=node.getChildren()[0];
			Node u=r.getChildren()[1];
			
			r.setChild(u.getChildren()[0], 1);
			if (u.getChildren()[0]!=null) {
				u.getChildren()[0].setParent(r);
			}

			s.setChild(u.getChildren()[1], 0);
			if (u.getChildren()[1]!=null) {
				u.getChildren()[1].setParent(s);
			}
			
			u.setChild(r, 0);
			if (r!=null) {
				r.setParent(u);
			}

			u.setChild(s, 1);
			if (s!=null) {
				s.setParent(u);
			}
			node=u;
		}
		return node;
	}
	public void delete(int id) {
		// TODO 自动生成的方法存根		
	}
	public JTree printTree() {
		// TODO 自动生成的方法存根
		//printTree(root);
		return null;
	}
	void printTree(Node node) {
		// TODO 自动生成的方法存根
		if(node==null){
			return;
		}
		else{
		System.out.print("Root："+node.getData()+"\r\n");
		if(node.getChildren()[0]!=null){
			System.out.print("lchildren："+node.getChildren()[0].getData()+"\r\n");
		}
		else{
			System.out.print("lchildren:null"+"\r\n");
		}
		if(node.getChildren()[1]!=null){
			System.out.print("rchildren："+node.getChildren()[1].getData()+"\r\n");
		}
		else{
			System.out.print("rchildren:null"+"\r\n");
		}
	}
	}
	

}
