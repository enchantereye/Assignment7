package AVLTree;

public class Node {
	private int id;
	private Object data;
	private Node parent;
	private Node[] children = new Node[2];
	public Node left = children[0];
	public Node right = children[1];
	private int lSubTreeHeight;
	private int rSubTreeHeight;
	private int balanceFactor;
	

	public int getId() {
		return id;
	}
	public Object getData() {
		return data;
	}
	public void setData(Object data) {
		this.data = data;
	}
	public Node getParent() {
		return parent;
	}
	public void setParent(Node parent) {
		this.parent = parent;
	}
	public Node[] getChildren() {
		return children;
	}
	public void setChildren(Node[] children) {
		this.children = children;
	}
	public void setChild(Node child, int id){
		this.children[id] = child;
	}
	public int getlSubTreeHeight() {

		if(getChildren() == null) return 0;
		else
			lSubTreeHeight = Max(left.getlSubTreeHeight(),left.getrSubTreeHeight())+1;
		//TODO calculate the left sub tree height
		return lSubTreeHeight;
	}
	public int getrSubTreeHeight() {
		if(getChildren() == null) return 0;
		else
			rSubTreeHeight =  Max(right.getlSubTreeHeight(),right.getrSubTreeHeight())+1;
		//TODO calculate the right sub tree height
		return lSubTreeHeight;
	}
	public int getBalanceFactor() {
		 balanceFactor = lSubTreeHeight - rSubTreeHeight;
		//TODO calculate the balance factor
		return balanceFactor;
	}
	public int Max(int a,int b){
		if(a>b) return a;
		else return b;
	}
	

}
