import javax.swing.*;
import javax.swing.tree.DefaultMutableTreeNode;


public class AVLTree implements IAVLTree {
    private Node root;  //树的根
    private boolean unBalanced;     //是否平衡
    private Node tempParent;    //根的父亲，方便指向根
    private Node temp;  //必要时作为辅助

    public AVLTree() {
        root = null;
    }

    @Override
    public Node get(int id) {
        Node targetNode = getNodeByID(tempParent.getChildren()[0],id);
        if(targetNode!=null) {
            return targetNode;
        }else{
            throw new RuntimeException("id为"+id+"的结点不存在");
        }
    }

    @Override
    public void insert(Node newNode) {
        unBalanced = false;
        if(root == null) {
            root = newNode;
            tempParent = new Node();
            root.setParent(tempParent);
            tempParent.setChild(root,0);
            return;
        }
        insertnewNode(tempParent.getChildren()[0],newNode,unBalanced);
    }

    @Override
    public void delete(int id) {
        Node targetNode = get(id);
        if(targetNode==null) {
            throw new RuntimeException("id为"+id+"的结点不存在");
        }
        //若删除的结点左右子树都不为空，则用该结点的中序后继结点代替
        if(targetNode.getChildren()[0]!=null&&targetNode.getChildren()[1]!=null) {
            temp = targetNode.getChildren()[1];
            while(temp.getChildren()[0]!=null) {
                temp=temp.getChildren()[0];
            }
            targetNode.setId(temp.getId());
            targetNode.setData(temp.getData());
            targetNode = temp;
        }

        //最后对于真正要删除的结点，有如下情况：
        //左、右子树都为空
        if(targetNode.getChildren()[0]==null&&targetNode.getChildren()[1]==null) {
            //该结点父亲是tempParent,表明是树根
            if(targetNode.getParent()==tempParent) {
                root = null;
                tempParent.setChild(null,0);
                return;
            }
            //该结点是其父亲的左孩子
            else if(targetNode.getId()<targetNode.getParent().getId()) {
                targetNode.getParent().setChild(null,0);
                targetNode.getParent().setBalanceFactor(targetNode.getParent().getBalanceFactor()-1);
            }
            //该结点是其父亲的右孩子
            else{
                targetNode.getParent().setChild(null,1);
                targetNode.getParent().setBalanceFactor(targetNode.getParent().getBalanceFactor()+1);
            }
        }
        //左子树不为空，右子树为空
        else if(targetNode.getChildren()[0]!=null && targetNode.getChildren()[1]==null) {
            //该结点父亲是tempParent,表明是树根
            if(targetNode.getParent()==tempParent) {
                targetNode.getChildren()[0].setParent(tempParent);
                tempParent.setChild(targetNode.getChildren()[0],0);
            }
            //该结点是其父亲的左孩子
            else if(targetNode.getId()<targetNode.getParent().getId()) {
                targetNode.getChildren()[0].setParent(targetNode.getParent());
                targetNode.getParent().setChild(targetNode.getChildren()[0],0);
            }
            //该结点是其父亲的右孩子
            else{
                targetNode.getChildren()[0].setParent(targetNode.getParent());
                targetNode.getParent().setChild(targetNode.getChildren()[0],1);
            }
        }
        //右子树不为空，左子树为空
        else if(targetNode.getChildren()[0]==null&&targetNode.getChildren()[1]!=null) {
            //该结点父亲是tempParent,表明是树根
            if(targetNode.getParent()==tempParent) {
                targetNode.getChildren()[1].setParent(tempParent);
                tempParent.setChild(targetNode.getChildren()[1],0);
            }
            //该结点是其父亲的左孩子
            else if(targetNode.getId()<targetNode.getParent().getId()) {
                targetNode.getChildren()[1].setParent(targetNode.getParent());
                targetNode.getParent().setChild(targetNode.getChildren()[1],0);
            }
            //该结点是其父亲的右孩子
            else{
                targetNode.getChildren()[1].setParent(targetNode.getParent());
                targetNode.getParent().setChild(targetNode.getChildren()[0],1);
            }
        }
        //从要删除的结点开始，自下而上调整树
        down2up(targetNode);
    }

    @Override
    public JTree printTree() {
        DefaultMutableTreeNode treeRoot = new DefaultMutableTreeNode(tempParent.getChildren()[0].getData());
        JTree tree = new JTree(treeRoot);
        Node[] childrenNode = tempParent.getChildren()[0].getChildren();
        if(childrenNode[0] != null) {
            insertNode2Tree(childrenNode[0],treeRoot);
        }
        if(childrenNode[1] != null) {
            insertNode2Tree(childrenNode[1],treeRoot);
        }
        return tree;
    }

    //插入新结点
    private boolean insertnewNode(Node p,Node newNode,boolean unBalanced) {
        if(p == null) {     //插入新结点
            p = newNode;
            if(p.getId()<p.getParent().getId()) {
                p.getParent().setChild(p,0);
            }else if(p.getId()>p.getParent().getId()) {
                p.getParent().setChild(p,1);
            }
            unBalanced = true;
        }
        else if(newNode.getId()<p.getId()) {    //新结点插入左子树
            p.setBalanceFactor(p.getBalanceFactor()+1);
            newNode.setParent(p);
            unBalanced=insertnewNode(p.getChildren()[0], newNode, unBalanced);
            if(unBalanced) {
                switch (p.getBalanceFactor()) {
                    case 0:
                        //p.setBalanceFactor(0);
                        unBalanced = false;
                        break;
                    case 1:
                        //p.setBalanceFactor(1);
                        break;
                    case 2:
                        unBalanced=Rotation(p,unBalanced);
                        break;
                }
            }
        }
        else if(newNode.getId() == p.getId()) {     //相同关键字结点已经存在
            newNode.setParent(p);
            unBalanced = false;
            p = newNode;
        }
        else {    //新结点插入右子树
            p.setBalanceFactor(p.getBalanceFactor()-1);
            newNode.setParent(p);
            unBalanced = insertnewNode(p.getChildren()[1], newNode, unBalanced);
            if(unBalanced) {
                switch (p.getBalanceFactor()) {
                    case 0:
                        //p.setBalanceFactor(0);
                        unBalanced = false;
                        break;
                    case -1:
                        //p.setBalanceFactor(-1);
                        break;
                    case -2:
                        unBalanced=Rotation(p,unBalanced);
                        break;
                }
            }
        }
        return unBalanced;
    }

    //重组旋转
        private boolean Rotation(Node s,boolean unBalanced) {
        Node u,r;

        switch (s.getBalanceFactor()) {
            case 2:
                r = s.getChildren()[0];
                //左重组单旋转
                if(r.getBalanceFactor()==1) {
                    s.setChild(r.getChildren()[1],0);
                    if(r.getChildren()[1]!=null) {
                        r.getChildren()[1].setParent(s);
                    }
                    r.setChild(s,1);
                    r.setParent(s.getParent());
                    s.getParent().setChild(r,0);
                    //将s的祖先balancefactor都减1
                    temp = s;
                    while(temp!=tempParent) {
                        temp.getParent().setBalanceFactor((temp.getParent().getBalanceFactor()-1));
                        temp = temp.getParent();
                    }
                    //如果s是原树根，则将r置为新树根
                    if(tempParent.getChildren()[0]==s) {
                        tempParent.setChild(r,0);
                    }
                    s.setParent(r);
                    s.setBalanceFactor(0);
                    r.setBalanceFactor(0);
                }
                //左重组双旋转
                else if(r.getBalanceFactor()==-1){
                    u = r.getChildren()[1];
                    r.setChild(u.getChildren()[0],1);
                    if(u.getChildren()[0]!=null) {
                        u.getChildren()[0].setParent(r);
                    }
                    s.setChild(u.getChildren()[1],0);
                    if(u.getChildren()[1]!=null) {
                        u.getChildren()[1].setParent(s);
                    }
                    u.setChild(r,0);
                    u.setChild(s,1);
                    u.setParent(s.getParent());
                    //将s的祖先balancefactor都减1
                    temp = s;
                    while(temp!=tempParent) {
                        temp.getParent().setBalanceFactor((temp.getParent().getBalanceFactor()-1));
                        temp = temp.getParent();
                    }
                    r.setParent(u);
                    s.setParent(u);
                    //如果s是原树根，则将u置为新树根
                    if(tempParent.getChildren()[0]==s) {
                        tempParent.setChild(u,0);
                    }
                    switch (u.getBalanceFactor()) {
                        case -1:
                            r.setBalanceFactor(1);
                            s.setBalanceFactor(0);
                            break;
                        case 0:
                            r.setBalanceFactor(0);
                            s.setBalanceFactor(0);
                            break;
                        case 1:
                            r.setBalanceFactor(0);
                            s.setBalanceFactor(-1);
                            break;
                    }
                    u.setBalanceFactor(0);
                }
                unBalanced = false;
                break;
            case -2:
                r = s.getChildren()[1];
                //右重组单旋转
                if(r.getBalanceFactor()==-1) {
                    s.setChild(r.getChildren()[0], 1);
                    if(r.getChildren()[0] != null) {
                        r.getChildren()[0].setParent(s);
                    }
                    r.setChild(s,0);
                    r.setParent(s.getParent());
                    s.getParent().setChild(r,1);
                    //将s的祖先balancefactor都加1
                    temp = s;
                    while(temp!=tempParent) {
                        temp.getParent().setBalanceFactor((temp.getParent().getBalanceFactor()+1));
                        temp = temp.getParent();
                    }
                    //如果s是原树根，则将r置为新树根
                    if(tempParent.getChildren()[0]==s) {
                        tempParent.setChild(r,0);
                    }
                    s.setParent(r);
                    s.setBalanceFactor(0);
                    r.setBalanceFactor(0);
                }
                //右重组双旋转
                else if(r.getBalanceFactor()==1){
                    u = r.getChildren()[0];
                    s.setChild(u.getChildren()[0],1);
                    if(u.getChildren()[0]!=null) {
                        u.getChildren()[0].setParent(s);
                    }
                    r.setChild(u.getChildren()[1], 0);
                    if(u.getChildren()[1]!=null) {
                        u.getChildren()[1].setParent(r);
                    }
                    u.setChild(s, 0);
                    u.setChild(r,1);
                    u.setParent(s.getParent());
                    //将s的祖先balancefactor都加1
                    temp = s;
                    while(temp!=tempParent) {
                        temp.getParent().setBalanceFactor((temp.getParent().getBalanceFactor()+1));
                        temp = temp.getParent();
                    }
                    s.setParent(u);
                    r.setParent(u);
                    //如果s是原树根，则将u置为新树根
                    if(tempParent.getChildren()[0]==s) {
                        tempParent.setChild(u,0);
                    }
                    switch (u.getBalanceFactor()) {
                        case -1:
                            s.setBalanceFactor(1);
                            r.setBalanceFactor(0);
                            break;
                        case 0:
                            s.setBalanceFactor(0);
                            r.setBalanceFactor(0);
                            break;
                        case 1:
                            s.setBalanceFactor(0);
                            r.setBalanceFactor(-1);
                            break;
                    }
                    u.setBalanceFactor(0);
                }
                unBalanced = false;
                break;
        }
        return unBalanced;
    }

    //将结点加入JTree的树中
    private void insertNode2Tree(Node node,DefaultMutableTreeNode parentTreeNode) {
        DefaultMutableTreeNode treeNode = new DefaultMutableTreeNode(node.getData());
        parentTreeNode.add(treeNode);
        Node[] childrenNode = node.getChildren();
        if(childrenNode[0] != null) {
            insertNode2Tree(childrenNode[0],treeNode);
        }
        if(childrenNode[1] != null) {
            insertNode2Tree(childrenNode[1],treeNode);
        }
    }

    //通过ID获得结点
    private Node getNodeByID(Node node,int id) {
        if(node == null) {
            return null;
        }
        else if(node.getId()==id) {
            return node;
        }
        Node[] childrenNode = node.getChildren();
        if(id<node.getId()) {
            return getNodeByID(childrenNode[0],id);
        }else{
            return getNodeByID(childrenNode[1],id);
        }
    }

    //由下往上调整树
    private void down2up(Node initNode) {
        Node adjustNode = initNode.getParent();
        temp = adjustNode;
        while(temp.getParent()!=tempParent) {
            while(adjustNode.getParent()!=tempParent&&(adjustNode.getBalanceFactor()!=-2)&&(adjustNode.getBalanceFactor()!=2)) {
                adjustNode = adjustNode.getParent();
            }
            if(adjustNode.getParent()!=tempParent) {
                temp = adjustNode.getParent();
                unBalanced = true;
                Rotation(adjustNode,unBalanced);
                adjustNode=temp;
            }
            else{
                temp = adjustNode;
            }
        }
    }
}
