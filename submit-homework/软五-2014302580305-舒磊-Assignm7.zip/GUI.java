import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.JTree;
import javax.swing.JPanel;

public class GUI {

	
	private static JFrame frame2;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					GUI window = new GUI();
					
					frame2.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public GUI() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		AVLTree tree=new AVLTree("root",0);
		try {
	        File file=new File("F:/java/7/tree_data.dat");
	        if(file.isFile()&&file.exists()){                                 //�ж��ļ��Ƿ����          
	     	   InputStreamReader read = new InputStreamReader(new FileInputStream(file));
	     	   BufferedReader bufferedReader = new BufferedReader(read);
	     	   String line=null;
	     	 
	     	   while( ( line=bufferedReader.readLine())!=null){
	    			String[] temp=line.split("#");
	    			System.out.println(temp[0]);
	 		    Node node = new Node(temp[0],Integer.parseInt(temp[1]));
	             tree.insert(node);   //���ļ��еĽڵ����
	     	   }
	     	   
	     	   read.close();
	        }
	     	   else{
	     		   System.out.println("�Ҳ���ָ���ļ�");
	     	   }
	        }catch(Exception e){
	     	   System.out.println("��ȡ�ļ�����");
	     	   e.printStackTrace();
	        }
		
		JPanel pane2 = new JPanel();
		JPanel panel = new JPanel();
		frame2 = new JFrame();
		frame2.getContentPane().setBackground(new Color(240, 240, 240));
		frame2.getContentPane().setLayout(null);
		
		textField = new JTextField();
		textField.setBounds(328, 10, 66, 21);
		frame2.getContentPane().add(textField);
		textField.setColumns(10);
		
		JLabel lblId = new JLabel("id:");
		lblId.setBounds(289, 13, 24, 15);
		frame2.getContentPane().add(lblId);
		
		JButton btnSearch = new JButton("Search");
		btnSearch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				int i = Integer.parseInt(textField.getText());
				Node node = tree.get(i);
				if(node != null){
					textField_1.setText((String) node.getData());
				}
				else{
					textField_1.setText("�����ڣ�"); 
				}
			}
		});
		btnSearch.setBounds(208, 28, 75, 23);
		frame2.getContentPane().add(btnSearch);
		
		textField_1 = new JTextField();
		textField_1.setBounds(328, 41, 66, 21);
		frame2.getContentPane().add(textField_1);
		textField_1.setColumns(10);
		
		textField_2 = new JTextField();
		textField_2.setBounds(328, 86, 66, 21);
		frame2.getContentPane().add(textField_2);
		textField_2.setColumns(10);
		
		JLabel label = new JLabel("id:");
		label.setBounds(289, 89, 24, 15);
		frame2.getContentPane().add(label);
		
		textField_3 = new JTextField();
		textField_3.setBounds(328, 117, 66, 21);
		frame2.getContentPane().add(textField_3);
		textField_3.setColumns(10);
		
		JButton btnInsert = new JButton("Insert");
		btnInsert.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Node n1 = new Node((String)textField_3.getText(),Integer.parseInt(textField_2.getText()));
				tree.insert(n1);
				panel.setVisible(false);
				pane2.setVisible(true);
				pane2.add(tree.printTree());
				
			}
		});
		btnInsert.setBounds(208, 101, 75, 23);
		frame2.getContentPane().add(btnInsert);
		
		JLabel lblData = new JLabel("data:");
		lblData.setBounds(289, 44, 54, 15);
		frame2.getContentPane().add(lblData);
		
		JLabel lblData_1 = new JLabel("data:");
		lblData_1.setBounds(289, 120, 54, 15);
		frame2.getContentPane().add(lblData_1);
		
		JLabel label_1 = new JLabel("id:");
		label_1.setBounds(289, 166, 24, 15);
		frame2.getContentPane().add(label_1);
		
		textField_4 = new JTextField();
		textField_4.setColumns(10);
		textField_4.setBounds(328, 163, 66, 21);
		frame2.getContentPane().add(textField_4);
		
		JButton btnDelete = new JButton("Delete");
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int i = Integer.parseInt(textField_4.getText());
				tree.delete(i);
				panel.setVisible(false);
				pane2.setVisible(true);
				pane2.add(tree.printTree());
			}
		});
		btnDelete.setBounds(208, 162, 75, 23);
		frame2.getContentPane().add(btnDelete);
		
		
		pane2.setBounds(10, 10, 167, 245);
		pane2.setVisible(false);
		panel.add(tree.printTree());
		panel.setBounds(10, 10, 167, 245);
		frame2.getContentPane().add(panel);frame2.getContentPane().add(pane2);
		frame2.setBounds(100, 100, 420, 322);
		frame2.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}
