import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;

public  class AVLTree implements IAVLTree {
	
	private Node root;
	public AVLTree(Object x,int id){  
		root = new Node(x,id);   //Ϊ�����ָ���쳣
	}  
	@Override
	public Node get(int id) {
		// TODO Auto-generated method stub
		return root.contains(id, root);
	}

	public void insert(Node node) {
		// TODO Auto-generated method stub
		root = root.insert(node.getData(),node.getId(),root);
	}

	@Override
	public void delete(int id) {
		// TODO Auto-generated method stub
		root = root.delete(id,root);
	}
	@Override
	public JTree printTree() {
		// TODO Auto-generated method stub
		JTree tree=new JTree(showTree(this.root));
		return tree;
	}
	
	public DefaultMutableTreeNode showTree(Node node){                                   //
		if(node==null)
			return null;
		
		DefaultMutableTreeNode left=showTree((node.getleft()));      //DefaultMutableTreeNode��ͨ�ýڵ��������ݽṹ
		DefaultMutableTreeNode right=showTree((node.getright()));
		DefaultMutableTreeNode treeNode=new DefaultMutableTreeNode("("+node.getId()+")"+node.getData().toString());         //��ʾ���ṹ
		if(left!=null)
			treeNode.add(left);
		 if(right!=null)
			treeNode.add(right);
		
		return treeNode;

	}

	
}
