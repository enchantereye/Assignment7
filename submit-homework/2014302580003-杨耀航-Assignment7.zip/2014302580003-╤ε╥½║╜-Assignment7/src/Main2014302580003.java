import java.awt.GridLayout;
import java.awt.Toolkit;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.WindowConstants;


public class Main2014302580003 extends JFrame{
	private JFrame jf;
	private JPanel jp;
	private JButton[]jb = new JButton[3];
	private JTextField[]jt = new JTextField[3];
	private JTextArea jta;
	private JScrollPane jsp;
	
	public Main2014302580003(){
		jf = new JFrame();
		jp = new JPanel();
		jf.setContentPane(jp);
		jf.setTitle("AVLTree");
		//Set the window showed in the center of the screen
		double width = Toolkit.getDefaultToolkit().getScreenSize().getWidth();
		double height = Toolkit.getDefaultToolkit().getScreenSize().getHeight();
		int x = (int)(width-500)/2;
		int y = (int)(height-380)/2;
		jf.setBounds(x,y,660,380);
		jf.setLayout(null);
		jf.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		
		jb[0] = new JButton("Insert");
		jb[1] = new JButton("Delete");
		jb[2] = new JButton("GetNode");
		for(int i = 0;i < 3;i++){
			jt[i] = new JTextField();
			jp.add(jb[i]);
			jp.add(jt[i]);
		}
		jb[0].setBounds(10,10,75,25);
		jt[0].setBounds(90,10,75,25);
		jb[1].setBounds(200,10,75,25);
		jt[1].setBounds(280,10,75,25);
		jb[2].setBounds(390,10,85,25);
		jt[2].setBounds(495,10,75,25);
		jta = new JTextArea();
		jp.add(jta);
		jta.setBounds(390,50,250, 280);
		jta.setEditable(false);
		jsp = new JScrollPane();
		jp.add(jsp);
		jsp.setBounds(10,50,350,280);
		
		jf.setResizable(false);
		jf.setVisible(true);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new Main2014302580003();
	}

}
