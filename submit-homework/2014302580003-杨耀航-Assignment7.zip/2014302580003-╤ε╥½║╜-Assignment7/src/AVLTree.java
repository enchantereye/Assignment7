import javax.swing.JOptionPane;
import javax.swing.JTree;

public class AVLTree implements IAVLTree{

	private Node root;
	private Node search(Node node,int id){
		if(null == node) return null;
		else if(id == node.getId()) return node;
		else if(id < node.getId()) return search(node.getChildren()[0],id);
		else return search(node.getChildren()[1],id);
	}
	@Override
	public Node get(int id) {
		return search(root,id);
	}

	private Node LRotation(Node root,Node node){//��������
		if (root.getChildren()[0].getBalanceFactor()==1) {//����
			Node p = node;
			Node q = node.getChildren()[0];
			
			p.setChild(q.getChildren()[1], 0);
			if (q.getChildren()[1] != null) q.getChildren()[1].setParent(p);
	
			q.setChild(p, 1);
			if (p != null) p.setParent(q);
			
			node = q;
		}else if(root.getChildren()[0].getBalanceFactor()==-1){//��˫��
			Node p = node;
			Node q = node.getChildren()[0];
			Node r = q.getChildren()[1];
			
			q.setChild(r.getChildren()[0], 1);
			if (r.getChildren()[0] != null) r.getChildren()[0].setParent(q);
			
			p.setChild(r.getChildren()[1], 0);
			if (r.getChildren()[1] != null) r.getChildren()[1].setParent(p);
			
			r.setChild(q, 0);
			if (q != null) q.setParent(r);

			r.setChild(p, 1);
			if (p != null) p.setParent(r);
	
			node = r;
		}
		return node;
	}
	private Node RRotation(Node root,Node node){//��������
		if (root.getChildren()[1].getBalanceFactor() == -1) {//�ҵ���
			Node p = node;
			Node q = node.getChildren()[1];
			
			p.setChild(q.getChildren()[0], 1);
			if (q.getChildren()[0] != null) q.getChildren()[0].setParent(p);

			q.setChild(p, 0);
			if (p != null) p.setParent(q);
			
			node=q;
		}
		if (root.getChildren()[1].getBalanceFactor() == 1) {//��˫��
			Node p = node;
			Node q = p.getChildren()[1];
			Node r = q.getChildren()[0];

			p.setChild(r.getChildren()[0], 1);
			if (r.getChildren()[0] != null) 	r.getChildren()[0].setParent(p);
			
			q.setChild(r.getChildren()[1], 0);
			if (r.getChildren()[1] != null) r.getChildren()[1].setParent(q);
			
			r.setChild(p, 0);
			if (p != null) p.setParent(r);

			r.setChild(q, 1);
			if (q != null) q.setParent(r);
			
			node=r;
		}
		return node;
	}
	private Node insert(Node root,Node node){
		if(null == root) root = node;
		else if (node.getId() <= root.getId()) {//�������
			if (root.getChildren()[0] == null) {
				root.setChild(node, 0);
				node.setParent(root);
			}else {
				Node n = insert(root.getChildren()[0], node);
				root.setChild(n, 0);
				if (n!=null) 	n.setParent(root);				
			}
			if (root.getBalanceFactor()==2) //��������ת�ж�
				root = LRotation(root, node);
		}
		
		else if (node.getId() > root.getId()) {//���Ҳ���
			if (root.getChildren()[1]==null) {
				root.setChild(node, 1);
				node.setParent(root);
			}else {
				Node n=insert(root.getChildren()[1], node);
				root.setChild(n, 1);
				if (n!=null) 	n.setParent(root);
			}
			if (root.getBalanceFactor()==-2)//��������ת�ж�
				root = RRotation(root,node);
		}
		return node;
	}
	@Override
	public void insert(Node newNode) {
		// TODO Auto-generated method stub
		root = insert(root,newNode);
		root.setParent(null);
	}

	
	//���ڵ�ɾ��
	public Node delete(Node node,int id) {
		if (node!=null) {
			//�����Ѱ��
			if (id<node.getId()) {
				if (node.getChildren()[0]==null) {
					JOptionPane.showMessageDialog(null, "ɾ���Ľ�㲻���ڣ���������ȷ��ֵ��");
				}
			else if (id==node.getChildren()[0].getId()) {
				node.getChildren()[0]=delete(node.getChildren()[0]);
				node.getChildren()[0]=checkBlanceFactor(node.getChildren()[0]);
				if (node.getChildren()[0]!=null) {
					node.getChildren()[0].setParent(node);
				}
			}else {
				node.getChildren()[0]=delete(node.getChildren()[0], id);
				node.getChildren()[0]=checkBlanceFactor(node.getChildren()[0]);
				if (node.getChildren()[0]!=null) {
					node.getChildren()[0].setParent(node);
				}
			}
				
			}
			//���ұ�Ѱ��
			if (id>node.getId()) {
				if (node.getChildren()[1]==null) {
					JOptionPane.showMessageDialog(null, "ɾ���Ľ�㲻���ڣ���������ȷ��ֵ��");
				}
				else if (id==node.getChildren()[1].getId()) {
					node.getChildren()[1]=delete(node.getChildren()[1]);
					node.getChildren()[1]=checkBlanceFactor(node.getChildren()[1]);
					if (node.getChildren()[1]!=null) {
						node.getChildren()[1].setParent(node);
					}
					
				}else {
					node.getChildren()[1]=delete(node.getChildren()[1], id);
					node.getChildren()[1]=checkBlanceFactor(node.getChildren()[1]);
					if (node.getChildren()[1]!=null) {
						node.getChildren()[1].setParent(node);
					}
				}
			}

		}
		return node;
	}
	private Node operateLeftSubTreeRightNode(Node subTreeNode) {
		if (subTreeNode.getChildren()[1]==null) {
			subTreeNode=subTreeNode.getChildren()[0];
		}else {
			subTreeNode.getChildren()[1]=operateLeftSubTreeRightNode(subTreeNode.getChildren()[1]);
		}
		
		return subTreeNode;
	}
	@Override
	public void delete(int id) {
		if (root!=null) {
			if (root.getId()==id) {
				root=delete(root);
				root.setParent(null);
			}else {
				root=delete(root, id);
				
			}
			
		}
	}

	@Override
	public JTree printTree() {
		// TODO Auto-generated method stub
		return null;
	}
	
	

}
