/**
 * �ڵ��ࣺΪ�Ż�������ԭ�л���������getId(),getChild()���㷨
 */
public class Node {
	private int id;
	private Object data;
	private Node parent;
	private Node[] children = new Node[2];
	private int lSubTreeHeight;
	private int rSubTreeHeight;
	private int balanceFactor;
	
	public Node() {

	}
	
	public Node(int id,Object data) {
		this.id = id ;
		this.data = data;
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public Object getData() {
		return data;
	}
	public void setData(Object data) {
		this.data = data;
	}
	public Node getParent() {
		return parent;
	}
	public void setParent(Node parent) {
		this.parent = parent;
	}
	public Node[] getChildren() {
		return children;
	}
	public void setChildren(Node[] children) {
		this.children = children;
	}
	//��õ�������,id = 0��ʾ���ӣ�id=1��ʾ�Һ���
	public Node getChild(int id) {
		return this.children[id];
	}
	public void setChild(Node child, int id){
		this.children[id] = child;
	}
	

	//�����������߶ȸ߶��㷨
	public int getlSubTreeHeight() {
		lSubTreeHeight = getTreeHeight(this.getChild(0));
		return lSubTreeHeight;
	}
	
	//�����������߶��㷨
	public int getrSubTreeHeight() {
		rSubTreeHeight = getTreeHeight(this.getChild(1));
		return rSubTreeHeight;
	}
	
	//�������ĸ߶�
	private int getTreeHeight(Node child) {
		if(child == null)
			return 0;
		else {
			int h1 = getTreeHeight(child.getChild(0));
			int h2 = getTreeHeight(child.getChild(1));
			int h = h1 > h2 ? h1 : h2;
			return h+1;
		}
		
	}

	public int getBalanceFactor() {
		
		return balanceFactor;
	}
	public void setBalanceFactor(int BF) {
		this.balanceFactor = BF;
	}

}
