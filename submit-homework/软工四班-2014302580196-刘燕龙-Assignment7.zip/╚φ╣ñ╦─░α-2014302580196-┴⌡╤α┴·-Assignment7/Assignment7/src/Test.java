import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;


public class Test {
	
	public static void main(String[] args) throws IOException {
		
		//��ȡģ��������Ϣ
		List<Node> dataList = getTestData();
		
		//����AVLTree
		AVLTree tree = new AVLTree();
		
		//����insert�㷨
		for(int i = 0;i<17;i++) {
			tree.insert(dataList.get(i));
		}
		
		//����get�㷨��ͬʱ��ӡ��˫�׽ڵ�
		Node node = tree.get(5);
		System.out.println("id = "+node.getId()+" data = "+node.getData());
		Node node2 = tree.get(7);
		System.out.println("id = "+node2.getId()+" data = "+node2.getData());
		
		//����printTree�㷨��ͬʱ����insert�㷨
		tree.printTree();
		
		//����delete�㷨����printTree�㷨����
		
		
		tree.delete(9);
		tree.delete(11);
		tree.printTree();

		tree.delete(17);
		tree.delete(15);
		tree.delete(5);
		tree.delete(7);
		tree.delete(1);
		tree.delete(3);
		tree.delete(2);
		tree.delete(6);
		tree.printTree();
		
	}

	//��ȡģ��������Ϣ�����ص�list����
	private static List<Node> getTestData() throws IOException {
		
		File data = new File("tree_data.dat");
		BufferedReader br = null;
		List<Node> list = new ArrayList<Node>();
		
		try {
			
			br = new BufferedReader(new FileReader(data));
			
			String text = null;
			//��ȡ����
			while((text = br.readLine())!=null) {
				String strings[] = text.split("#");
				Node n = new Node();
				n.setData(strings[0]);
				n.setId(Integer.parseInt(strings[1]));
				list.add(n);

			}
			
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} finally {//�ر���
			
			if(br!=null) {
				
				try {
					br.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		return list;
	}

}
