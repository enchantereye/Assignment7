package treetest;



import java.awt.Container;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;

public class AVLTree extends JFrame implements IAVLTree {

	
	//public int a[]=new int[17];
	
   //���ڵ�
    private Node root=null;
    
    public void LL(Node s){
    	  
		  Node tm=s.getChild(1);
		
		  if(s.getParent()==null){
			  root=tm;
			  tm.setParent(null);
			 }else{
				 tm.setParent(s.getParent());
				 s.getParent().setChild(tm, 1);
			 }
		
		  Node tem=tm.getChild(0);
			 if(tm.getChild(0)==null){
			 tm.setChild(s, 0);
			 tem=null;
			 }else{
				
				 tem.setParent(s);
				 tm.setChild(s, 0);
				
			 }
			 s.setChild(tem,1);
			 s.setParent(tm);
		
		
		 
		 
    }
    
   
    //��������������ĵ���һ���ڵ�
    public Node getcenter(Node m){
    	Node temp=m.getChild(1);
    	 while(temp.getId()-m.getId()>1&&temp.getChild(0)!=null){
    		temp=temp.getChild(0);
    	 }
    	DeleteX(temp);
    	 
    	return temp;
    }
   
    
   public void fix(Node newNode){
	   Node t=root;
	// int[]temp=new int[17];
	  if(newNode.getParent()!=null){
	  int v=newNode.getParent().getBalanceFactor();
	  if(v==-1||v==1){
		  newNode=newNode.getParent();
		  
		  if(newNode.getParent()!=null){
			  
			 // int u=newNode.getParent().getBalanceFactor();
			  if(newNode.getParent().getBalanceFactor()==-2||newNode.getParent().getBalanceFactor()==2){
			  Node s=newNode.getParent();
			  LL(s);
			  }
			  
			  else if(newNode.getParent().getBalanceFactor()==-1){
				  if((t.getBalanceFactor()==-2&&t.getChild(1).getBalanceFactor()==-2)&&t.getChild(1).getChild(1).getBalanceFactor()!=-2){
				  Node s=t.getChild(1);
				  LL(s);
				  }else if((t.getBalanceFactor()==-2&&t.getChild(1).getBalanceFactor()==-2)&&t.getChild(1).getChild(1).getBalanceFactor()==-2){
					  Node s=t.getChild(1).getChild(1);
					  LL(s);
				  }
				  else if(t.getBalanceFactor()==-2&&t.getChild(1).getBalanceFactor()==-1){
					  Node s=t;
					  LL(s);
				  }else if(t.getBalanceFactor()!=-2&&t.getChild(1).getBalanceFactor()==-2){
					  Node s=t.getChild(1);
					  LL(s);
				  }
			  }
		  }
		 
	  }
	  }
	
	  
   }
   //���ýڵ�
	public Node setNode(int id,Object data,Node lchild,Node parent,Node rchild){
		 Node newNode = new Node();
		 newNode.setData(data);
         newNode.setId(id);
         newNode.setChild(lchild,0);
         newNode.setChild(rchild,1);
         newNode.setParent(parent);
		 return newNode;
	}

	@Override
	public Node get(int id) {
		// TODO �Զ����ɵķ������
		Node t=root;
		while(t.getId()!=id){
			if(id<t.getId()){
				t=t.getChild(0);
			}else{
				t=t.getChild(1);
			}
		}
		return t;
	}
	int i=0;

	@Override
	public void insert(Node newNode) {
		// TODO �Զ����ɵķ������
		boolean btn=false;
		Node t=root;
		
		if(t==null){
		   root=newNode;
		  
		}else{
		int wait=newNode.getId();
		do{
			
			if(wait<t.getId()){
				
				if(t.getChild(0)!=null){
					t=t.getChild(0);
				}else{
					
					t.setChild(newNode, 0);
					newNode.setParent(t);
					btn=true;
					//TODO ����Ҫ����
				}
				
			}else{
			
				if(t.getChild(1)!=null){
					t=t.getChild(1);
				}else{
					t.setChild(newNode, 1);
					newNode.setParent(t);
					btn=true;
					
					//TODO ����Ҫ����
				}
			}
			
		}while(!btn);
	
		}
	  fix(newNode);
	
	}
	 //ɾ������
    public void DeleteX(Node u){
    	if(u.getChild(0)==null&&u.getChild(1)==null){
			Node s=u.getParent();
			if(u.getId()>s.getId()){
				s.setChild(null, 1);
			}else{
				s.setChild(null, 0);
			}
			u.setParent(null);
		}else if(u.getChild(0)!=null&&u.getChild(1)==null){
			Node s=u.getParent();
			Node r=u.getChild(0);
			u.setParent(null);
			u.setChild(null, 0);
			int temp=u.getId()>s.getId()?1:0;
			s.setChild(r,temp);
			r.setParent(s);
		}else if(u.getChild(0)==null&&u.getChild(1)!=null){
			Node s=u.getParent();
			Node r=u.getChild(1);
			u.setParent(null);
			u.setChild(null, 1);
			int temp=u.getId()>s.getId()?1:0;
			s.setChild(r,temp);
			r.setParent(s);
		}
		else if(u.getChild(0)!=null&&u.getChild(1)!=null){
			if(u.getParent()!=null){
			Node s=u.getParent();
			Node r=u.getChild(1);
			Node l=u.getChild(0);
			Node center=getcenter(u);
				if(r.getId()!=center.getId()){
					//center.getParent().setChild(null, 0);
					int temp=center.getId()>s.getId()?1:0;
		
					s.setChild(center, temp);
					center.setParent(s);
				
		
					u.setParent(null);
					u.setChild(null, 0);
					u.setChild(null, 1);
			
					center.setChild(l, 0);
					l.setParent(center);
					center.setChild(r, 1);
					r.setParent(center);
				}else{
					//center.getParent().setChild(null, 0);
					int temp=center.getId()>s.getId()?1:0;
		
					s.setChild(center, temp);
					center.setParent(s);
				
		
					u.setParent(null);
					u.setChild(null, 0);
					u.setChild(null, 1);
			
					center.setChild(l, 0);
					l.setParent(center);
				
				}
			}else{
				Node r=u.getChild(1);
				Node l=u.getChild(0);
				Node center=getcenter(u);
				//center.getParent().setChild(null, 0);
				
				u.setParent(null);
				u.setChild(null, 0);
				u.setChild(null, 1);
				
				center.setChild(l, 0);
				l.setParent(center);
				center.setChild(r, 1);
				r.setParent(center);
				root=center;
			}
			
		}
    }

	@Override
	public void delete(int id) {
		// TODO �Զ����ɵķ������
		Node u=get(id);
		DeleteX(u);
		
	}
	public DefaultMutableTreeNode subTree(Node t){
		Object str=t.getData();
		DefaultMutableTreeNode root1 = new DefaultMutableTreeNode(str);
		if(t.getChild(0)!=null){
			
			subTree(t.getChild(0));
			root1.add(subTree(t.getChild(0)));
		
		}
		if(t.getChild(1)!=null){
			
			subTree(t.getChild(1));
			root1.add(subTree(t.getChild(1)));
		}
		return root1;
		
	}

	@Override
	public JTree printTree() {
		Node t=root;
		//System.out.println(t.getId());
		Object str=t.getData();
		
		DefaultMutableTreeNode root1 = new DefaultMutableTreeNode(str);
		if(t.getChild(0)!=null){
		
			Node subt=t;
			subt=subt.getChild(0);
			root1.add (subTree(subt));
			 
		}
		if(t.getChild(1)!=null){
			//System.out.println(t.getChild(1).getId());
			Object strl=t.getChild(1).getData();
			DefaultMutableTreeNode lchild = new DefaultMutableTreeNode(strl);
			 subTree(t.getChild(1));
			 root1.add( subTree(t.getChild(1)));
		}
        JTree tree = new JTree(root1);
		
		Container contentPane =getContentPane();
		contentPane.add(new JScrollPane(tree)); 
		pack();
		setVisible(true);
		return null;
		
	}
	/*public JTree printTree() {
		// TODO �Զ����ɵķ������
		Node t=root;
		Object str=t.getData();
		DefaultMutableTreeNode root1 = new DefaultMutableTreeNode(str);
		DefaultMutableTreeNode temp = new DefaultMutableTreeNode();
		temp=root1;
		while(t.getChild(0)!=null||t.getChild(1)!=null){
			
			if(t.getChild(0)!=null&&t.getChild(1)==null){
				
				t=t.getChild(0);
				Object strl=t.getData();
			DefaultMutableTreeNode lchild = new DefaultMutableTreeNode(strl);
			temp.add(lchild);
			temp=lchild;
			}else if(t.getChild(1)!=null&&t.getChild(0)==null){
				t=t.getChild(1);
				Object strr=t.getData();
				
				DefaultMutableTreeNode rchild = new DefaultMutableTreeNode(strr);
				temp.add(rchild);
				temp=rchild;
				}else{
					
				}
			
		}
		
		//DefaultMutableTreeNode root = new DefaultMutableTreeNode("World");
		//DefaultMutableTreeNode country = new DefaultMutableTreeNode("USA");
		//root.add(country);
		
		JTree tree = new JTree(root1);
		
		Container contentPane =getContentPane();
		contentPane.add(new JScrollPane(tree)); 
		pack();
		setVisible(true);
		return null;
	}*/
	
	

}
