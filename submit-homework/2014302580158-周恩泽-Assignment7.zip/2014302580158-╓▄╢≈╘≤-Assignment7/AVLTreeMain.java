package treetest;


public class AVLTreeMain {

	public static void main(String[] args) {
		// TODO �Զ����ɵķ������
         AVLTree tree=new AVLTree();
         Node Node3= tree.setNode(3, "art", null, null,null);
         Node Node4= tree.setNode(4, "baby", null, null,null);
         Node Node5=tree.setNode(5, "banan", null, null, null);
         Node Node6=tree.setNode(6, "car", null, null, null);
         Node Node7=tree.setNode(7, "door", null, null, null);
         Node Node8=tree.setNode(8, "dress", null, null, null);
         Node Node9=tree.setNode(9, "frog", null, null, null);
         Node Node10=tree.setNode(10, "love", null, null, null);
         Node Node11=tree.setNode(11, "mint", null, null, null);
         Node Node12=tree.setNode(12, "rice", null, null, null);
         Node Node13=tree.setNode(13, "show", null, null, null);
         Node Node14=tree.setNode(14, "table", null, null, null);
         Node Node15=tree.setNode(15, "tree", null, null, null);
         Node Node16=tree.setNode(16, "trouble", null, null, null);
         Node Node17=tree.setNode(17, "windows", null, null, null);
          Node newNode = new Node();
          newNode.setData("ant");
          newNode.setId(1);
         
         Node newNode1 = new Node();
          newNode1.setData("apple");
          newNode1.setId(2);
          tree.insert(newNode);
          tree.insert(newNode1);
          tree.insert(Node3);
       
          tree.insert(Node4);
          tree.insert(Node5);
          tree.insert(Node6);
          tree.insert(Node7);
          tree.insert(Node8);
          tree.insert(Node9);
          tree.insert(Node10);
          tree.insert(Node11);
          tree.insert(Node12);
          tree.insert(Node13);
          tree.insert(Node14);
          tree.insert(Node15);
          tree.insert(Node16);
          tree.insert(Node17);
          System.out.println("��ȡ�ڵ�5����Ϣ��");
         
         System.out.println( tree.get(5).getData());
         System.out.println( tree.get(5).getId());
          //tree.delete(15);
          tree.delete(8);
         //tree.getcenter(Node14);
          tree.printTree();
          
         // tree.test();
       
        
          
	}

}
