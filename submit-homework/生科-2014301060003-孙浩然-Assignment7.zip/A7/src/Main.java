import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTree;

public class Main {
	private int step = 0;
	private JTree jt;

	public static void main(String[] args) {
		Main main = new Main();
		AVLTree avl = new AVLTree();
		
		try {
			BufferedReader in=new BufferedReader(new FileReader("tree_data.dat"));
			Node nodes[] = new Node[17];
			for (int i = 0; i < 17; i++) {
				String str[] = in.readLine().split("#");
				nodes[i] = new Node();
				nodes[i].setId(1 + i);
				nodes[i].setData(str[0]);
				avl.insert(nodes[i]);
			}
			in.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		JTree jt = avl.printTree();
		JFrame jf = new JFrame("AVLTree");
		jf.setSize(380, 420);
		
		JPanel jp = new JPanel();
		jf.add(jp);
		
		JScrollPane js = new JScrollPane();
		js.setViewportView(jt);
		
		JButton jb = new JButton("����10");
		jb.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				switch(main.step++) {
					case 0:
						Node n = avl.get(10);
						jp.add(new JLabel(n.getData()+"#"+n.getId()));
						jb.setText("����yellow#18");
						break;
					case 1:
						Node node = new Node();
						node.setId(18);
						node.setData("yellow");
						avl.insert(node);
						jb.setText("ɾ��8");
						break;
					case 2:
						avl.delete(8);
						jb.setText("����");
						break;
					default:
						System.exit(0);
				}
				main.jt = avl.printTree();
				for(int i=0;i<main.jt.getRowCount();i++){
					main.jt.expandRow(i);
				}
				js.setViewportView(main.jt);
			}
		});
		
		jp.add(jb);
		jp.add(js);
		
		for(int i=0;i<jt.getRowCount();i++){
			jt.expandRow(i);
		}
		
		jf.setVisible(true);
	}
}
