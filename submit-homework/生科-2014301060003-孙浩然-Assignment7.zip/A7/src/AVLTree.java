import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;

public class AVLTree implements IAVLTree{
	private Node root;
	
	public Node get(int id) {
		return search(id,root);
	}

	public void insert(Node newnode) {
		if (root == null) root = newnode;
		else insert(root, newnode);
		balance(newnode);
	}
	
	public void delete(int id) {
		Node node = get(id);
		if(node == null)return;
		Node temp = node.getrChild();
		
		if (temp == null) {
			temp = node.getParent();
			if (temp == null) root = node.getlChild();
			else if (temp.getrChild() == node) temp.setrChild(node.getlChild());
			else temp.setlChild(node.getlChild());
		}
		
		else if (temp.getlChild() == null) {
			node.setData(temp.getData());
			node.setId(temp.getId());
			node.setrChild(temp.getrChild());
			temp = node;
		}
		
		else {
			while(temp.getlChild() != null) temp = temp.getlChild();
			node.setData(temp.getData());
			node.setId(temp.getId());
			temp.getParent().setlChild(temp.getrChild());
			temp = temp.getParent();
		}
		
		recover(root);
		balance(temp);
	}
	
	public JTree printTree() {
		return new JTree(buildJTree(root));
	}
	
	private DefaultMutableTreeNode buildJTree(Node node){
		if(node==null){
			return null;
		}
		DefaultMutableTreeNode left=buildJTree(node.getlChild());
		DefaultMutableTreeNode right=buildJTree(node.getrChild());
		//�Խڵ��id��data����JTree�ڵ㣬���磺data(id)
		DefaultMutableTreeNode treeNode=new DefaultMutableTreeNode(node.getData().toString()
				+"("+node.getId()+")");
		if(left!=null){
			treeNode.add(left);
		}
		if(right!=null){
			treeNode.add(right);
		}
		return treeNode;
	}
	
	private void recover(Node node) {
		if(node == root) {
			if (node == null) return;
			else node.setParent(null);
		}
		if(node.getlChild() != null) {
			node.getlChild().setParent(node);
			recover(node.getlChild());
		}
		if(node.getrChild() != null) {
			node.getrChild().setParent(node);
			recover(node.getrChild());
		}
	}
	
	private Node search(int id, Node node) {
		if (node == null) return null;
		else if (id > node.getId()) return search(id,node.getrChild());
		else if (id < node.getId()) return search(id,node.getlChild());
		else return node;
	}
	
	private void insert(Node node, Node newnode) {
		if (newnode.getId() > node.getId()) {
			if (node.getrChild() != null) insert(node.getrChild(), newnode);
			else {
				newnode.setParent(node);
				node.setrChild(newnode);
			}
		}
		else if (newnode.getId() < node.getId()) {
			if (node.getlChild() != null) insert(node.getlChild(), newnode);
			else {
				newnode.setParent(node);
				node.setlChild(newnode);
			}
		}
	}
	
	private int getHeight(Node node) {
		if (node == null) return 0;
		else return Math.max(getHeight(node.getlChild()),getHeight(node.getrChild())) + 1;
	}
	
	private int getBalanceFactor(Node node) {
		if (node == null) return 0;
		else return getHeight(node.getlChild()) - getHeight(node.getrChild());
	}
	
	private void balance(Node s) {
		if (s == null) return;
		if (Math.abs(getBalanceFactor(s)) < 2) balance(s.getParent());
		else if (getBalanceFactor(s) == 2) {
			Node u,r = s.getlChild();
			if (getBalanceFactor(r) == 1) {
				s.setlChild(r.getrChild());
				r.setrChild(s);
				if (root == s) root = r;
				else if (s.getParent().getlChild() == s) s.getParent().setlChild(r);
				else s.getParent().setrChild(r);
			}
			else {
				u = r.getrChild();
				r.setrChild(u.getlChild());
				u.setlChild(r);
				s.setlChild(u.getrChild());
				u.setrChild(s);
				if(root == s) root = u;
				else if (s.getParent().getlChild() == s) s.getParent().setlChild(u);
				else s.getParent().setrChild(u);
			}
		}
		else if (getBalanceFactor(s) == -2) {
			Node u,r = s.getrChild();
			if (getBalanceFactor(r) == -1) {
				s.setrChild(r.getlChild());
				r.setlChild(s);
				if(root == s) root = r;
				else if (s.getParent().getlChild() == s) s.getParent().setlChild(r);
				else s.getParent().setrChild(r);
			}
			else {
				u = r.getlChild();
				r.setlChild(u.getrChild());
				u.setrChild(r);
				s.setrChild(u.getlChild());
				u.setlChild(s);
				if(root == s) root = u;
				else if (s.getParent().getlChild() == s) s.getParent().setlChild(u);
				else s.getParent().setrChild(u);
			}
		}
		recover(root);
	}
}
