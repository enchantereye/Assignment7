
public class Node {
	private int id;
	private Object data;
	private Node parent, lChild, rChild;
	
	public int getId() {
		return id;
	}
	
	public Object getData() {
		return data;
	}
	
	public Node getParent() {
		return parent;
	}
	
	public Node getlChild() {
		return lChild;
	}
	
	public Node getrChild() {
		return rChild;
	}
	
	public void setId(int id) {
		this.id = id;
	}
	
	public void setData(Object data) {
		this.data = data;
	}
	
	public void setParent(Node parent) {
		this.parent = parent;
	}
	
	public void setlChild(Node lChild) {
		this.lChild = lChild;
	}
	
	public void setrChild(Node rChild) {
		this.rChild = rChild;
	}
	
}
