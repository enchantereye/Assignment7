import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ScrollPaneConstants;
import javax.swing.tree.DefaultMutableTreeNode;


public class Test {
	private static JTextArea output=new JTextArea();
	static JTextField temp=new JTextField();
	public static JScrollPane scrollPane;
	public static void treeInit(AVLTree tree) throws IOException{
		BufferedReader bufr=new BufferedReader(new InputStreamReader(new FileInputStream("tree_data.dat")));
		String line=null;
		while((line=bufr.readLine())!=null){
			
			String [] contents=line.split("#");
			Node node=new Node(Integer.valueOf(contents[1]));
			node.setData(contents[0]);
			tree.insert(node);
		}
		bufr.close();
	}
	public static void main(String[] args) throws IOException {
		final AVLTree aTree=new AVLTree();
		treeInit(aTree);
//		Node node=new Node(18);
//		node.setData("school");			
//		aTree.insert(node);
		JFrame f = new JFrame("AVLTree");
		f.setBounds(600, 200, 500, 600);
	    f.setLayout(null);	
		output.setBounds(20,60,330,35);
		temp.setBounds(20,20,100,35);
		JButton OKbutton=new JButton("����");
		OKbutton.setBounds(370, 20, 100, 35);
		JButton Dbutton=new JButton("ɾ��");
		Dbutton.setBounds(250, 20, 100, 35);
		
		scrollPane =new JScrollPane();
		scrollPane.setViewportView(aTree.printTree());
	    
	    scrollPane.setBounds(20, 135, 450, 355);
	    scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
	    f.add(output);
	    output.setEditable(false);
		f.add(OKbutton);
		f.add(Dbutton);
		f.add(temp);
		OKbutton.addActionListener(new ActionListener() {
	        
			public void actionPerformed(ActionEvent e) {
				int id=Integer.valueOf(temp.getText());
				Node searchNode=aTree.get(id);
				if(searchNode!=null){
					output.setText(String.valueOf(searchNode.getData()));
				}else{
					output.setText("û�иýڵ�");
				}
			}	
	     });
		Dbutton.addActionListener(new ActionListener() {
			        
					public void actionPerformed(ActionEvent e) {
						int id=Integer.valueOf(temp.getText());
						Node searchNode=aTree.get(id);
						if(searchNode!=null){
							aTree.delete(searchNode.getId());
							scrollPane.setViewportView(aTree.printTree());
							
						}else{
							output.setText("û�иýڵ�");
						}
					}	
			     });
		f.add(scrollPane);
	    f.setVisible(true);
	    f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);	
	}

}
