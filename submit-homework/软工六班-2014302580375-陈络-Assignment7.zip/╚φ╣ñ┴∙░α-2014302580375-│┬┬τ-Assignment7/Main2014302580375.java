
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTree;



public class Main2014302580375 {
	
	public static JScrollPane scrollPane;

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		
		final AVLTree tree = new AVLTree(null);
		ArrayList<Node> list=tree.readData();
		for(int i=0;i<list.size();i++){
			tree.insert(list.get(i).getId(),list.get(i));
		}
		
		tree.print();
		final JTree jtree = tree.printTree();
		
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					GUI frame = new GUI(jtree);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
		
        
        
	}
	
	
}