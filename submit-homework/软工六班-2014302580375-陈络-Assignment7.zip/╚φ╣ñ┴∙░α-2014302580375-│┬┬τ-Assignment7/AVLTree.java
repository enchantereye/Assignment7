import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;

public class AVLTree implements IAVLTree {
	private Node root=null;
	private ArrayList<Node> treeList=new ArrayList<Node>();
	public AVLTree(Node node)
	{
		root=node;
	}
	
	
	public boolean isEmpty(Node m_node){
		if(m_node==null)
			return true;
		else
			return false;
	}
	//��������
	//���޸�
	public int getHeight(Node node)
	{
		int lHeight=0;
	    int rHeight=0;
	    if(isEmpty(node))
	    	return max(0,0);
	    else{
	    	lHeight=getHeight(node.getChild(0))+1;
	        rHeight=getHeight(node.getChild(1))+1;
	        
	        return max(lHeight,rHeight);
	    }
	    
	   
	}
	
	//����ڵ�ƽ�ⳣ��
	//���޸�
	public int getBF(Node node)
	{
		Node left=node.getChild(0);
		Node right=node.getChild(1);
		int lHeight = 0;
		int rHeight = 0;
		if(!isEmpty(left))
			lHeight=getHeight(node.getChild(0));
		if(!isEmpty(right))
			rHeight=getHeight(node.getChild(1));
		return lHeight-rHeight;
	}
	
	//�Ը���㿪ʼ���µ������нڵ��ƽ�ⳣ��
	//���޸�
	public void refreshFactor()
	{
		for(int i=0;i<treeList.size();i++){
			treeList.get(i).setBalanceFactor(getBF(treeList.get(i)));
		}
	}
	public  int[] refreshBF(Node m_node){
		/*for(int i=0;i<treeList.size();i++){
			treeList.get(i).setlSubTreeHeight(0);
			treeList.get(i).setrSubTreeHeight(0);
		}
		for(int i=0;i<treeList.size();i++){
			if(treeList.get(i).getChildren()[0]==null&&treeList.get(i).getChildren()[1]==null){
				Node p=treeList.get(i);
				while(p!=null){
					if(p.getParent().getChildren()[0]==p){
						p.getParent().setlSubTreeHeight(p.getParent().getlSubTreeHeight()+1);
					}
					else if(p.getParent().getChildren()[1]==p){
						p.getParent().setrSubTreeHeight(p.getParent().getrSubTreeHeight()+1);
					}
				}
			}
		}	*/
		int[] lr = {0,0};
		if(m_node.getChild(0)!=null){
			lr[0]=max(refreshBF(m_node.getChild(0))[0],refreshBF(m_node.getChild(0))[1])+1;
			m_node.setLHeight(lr[0]);
		}else{
			m_node.setLHeight(0);
			lr[0]=0;
		}
		if(m_node.getChild(1)!=null){
			lr[1]=max(refreshBF(m_node.getChild(1))[0],refreshBF(m_node.getChild(1))[1])+1;
			m_node.setRHeight(lr[1]);
		}else{
			m_node.setRHeight(0);
			lr[1]=0;
		}
		return lr;
		
	}
	public int max(int a,int b){
		if(a>b)
			return a;
		else
			return b;
	}
	//������
	public void LRotation(Node node)
	{
		//System.out.println("����ת��");
		if(node.getId()==root.getId()){
			root=node.getChild(1);
			
		}
		if(node.getChild(0).getBalanceFactor()!=1) {
			
			
			Node r=node.getChild(0);
			Node u=r.getChild(1);
			if(!isEmpty(node.getParent())){
				boolean b1=node.getParent().getChild(0).getId()==node.getId();
				boolean b2=node.getParent().getChild(1).getId()==node.getId();
				if(b1){
					int i=node.getParent().getChild(0).getId();
					node.getParent().setChild(u, 0);
				}
			if(b2){
				node.getParent().setChild(u, 1);
				int b=max(node.getParent().getId(),node.getId());
			}
			}
			
			if(!isEmpty(node.getParent()))
				u.setParent(node.getParent());
			int sum=0;
			for(int i=0;i<treeList.size();i++){
				sum+=treeList.get(i).getId();
			}
			
			node.getChild(0).setParent(node.getChild(0).getChild(1));
			node.getChild(0).getChild(1).getChild(0).setParent(node.getChild(0));
			node.getChild(0).getChild(1).getChild(1).setParent(node);
			node.setParent(node.getChild(0).getChild(1));
			node.getChild(0).setChild(u.getChild(0), 1);
			node.setChild(u.getChild(1), 0);
			u.setChild(node.getChild(0), 0);
			node.getChild(0).getId();
			u.setChild(node, 1);
			refreshFactor();
		}
		Node nn=node.getChild(0);
		if(nn.getBalanceFactor()==1)
		{
			Node p=node.getChild(0);
			if(!isEmpty(node.getParent())){
			if(node.getParent().getChild(0)==node){
				node.getParent().setChild(node.getChild(0), 0);			
			}
			if(node.getParent().getChild(1)==node){
				node.getParent().setChild(node.getChild(0), 1);
			}
			}
			p.setParent(node.getParent());
			node.setParent(p);			
			refreshFactor();
		}
		
		//������˫��ת��u����node��u������Ϊr���Һ��ӣ�u���Һ���Ϊnode�����ӣ�rΪu�����ӣ�nodeΪu���Һ���
		
	}
	
	
	public void RRotation(Node node)
	{
		//System.out.println("����ת��");
		boolean b1=(node.getId()==root.getId());
		if(b1){
			Node node1=node.getChild(1);
			root=node1;
			
		}
		
		//�����鵥��ת
		if(node.getChild(1).getBalanceFactor()==-1)
		{
			if(node.getParent()!=null){
				boolean b2=node.getParent().getChild(0)==node;
				boolean b3=node.getParent().getChild(1)==node;
				if(b2){
				node.getParent().setChild(node.getChild(1), 0);
				}
				if(b3){
				node.getParent().setChild(node.getChild(1), 1);
			}
			}
			
			node.getChild(1).setParent(node.getParent());
			
			node.setParent(node.getChild(1));
			Node n2=node.getChild(1);
			boolean b4=(n2.getChild(0)!=null);
			if(b4)
				node.getChild(1).getChild(0).setParent(node);
			
			Node temp=n2.getChild(0);
			if(node.getChild(1)!=null&&node.getChild(1).getId()==-1)
				print();
			n2.setChild(node, 0);
			Node num=node.getChild(1);
			n2.setChild(num,0);
			n2.setChild(node,0);
			node.setChild(temp, 1);
			refreshFactor();
		}
		else if(node.getChild(1).getBalanceFactor()==1){
			
			Node u=node.getChild(1).getChild(0);	
			Node r=node.getChild(1);
			if(node.getParent()!=null){
				boolean b2=(node.getParent().getChild(0)==node);
				boolean b3=node.getParent().getChild(1)==node;
				if(b2){
				node.getParent().setChild(node.getChild(1).getChild(0), 0);
			}
			else if(b3){
				node.getParent().setChild(node.getChild(1).getChild(0), 1);
			}
			}
			Node nodenew=node.getParent();
			if(nodenew!=null)
				node.getChild(1).getChild(0).setParent(node.getParent());
			r.setParent(node.getChild(1).getChild(0));
			Node get1=node.getChild(1).getChild(0).getChild(1);
			get1.setParent(r);
			Node get2=u.getChild(0);
			get2.setParent(get2);
			get2.setParent(node);
			node.setParent(node.getChild(1).getChild(0));
			r.setChild(r,0);
			r.setChild(get1, 0);
			node.setChild(get2, 1);
			u.setChild(r, 1);
			u.setChild(r,0);
			u.setChild(node, 0);
			refreshFactor();
		}
	}

	//����id����ָ���ڵ�
	public Node get(int id) {
		// TODO Auto-generated method stub
		for(int i=0;i<treeList.size();i++){
			if(id==treeList.get(i).getId())
				return treeList.get(i);
		}
		return null;
	}
	
	//�����½ڵ�
	public void insert(int id,Node newNode) {
		// TODO Auto-generated method stub
		boolean bo1=root==null;
		if(bo1)
		{
			root=newNode;
			root.setBalanceFactor(0);
			treeList.add(root);
		}
		
		//����㲻Ϊ��
		else{
			//Ѱ�Ҳ���λ�ã���������ڵ�ĸ��ڵ�t��t��sʼ�ձ��ָ��ӹ�ϵ
			Node t = new Node(); 
			Node s =root;
			
			while(!isEmpty(s)){
				t=s;
				int i=(id<s.getId())?0:1;
				
				
				s=s.getChild(i);
			}
			
			//�����½ڵ㲢�޸���ؽڵ���Ϣ
			newNode.setParent(t);
			int b;
			boolean b4=id>t.getId();
		    if(b4)
			{
				b=1;
			}
		    else if(!b4)
			{
				b=0;
				
			}
		    else 
		    	b=0;
		    t.setChild(newNode, b);
			treeList.add(newNode);
		    
			while(!isEmpty(t)){
				t.setBalanceFactor((id<t.getId())?t.getBalanceFactor()+1:t.getBalanceFactor()-1);
				 int i=t.getBalanceFactor();
				if(i==0)break;
				
				else if(i==-2){
					RRotation(t);
					break;
				}
				
				else if(i==2){
					LRotation(t);
					break;
				}
				Node m_t=t.getParent();
				t=m_t;
			}
		}
	}

	public void print(){
		for(int i=0;i<treeList.size();i++){
			
			System.out.print(treeList.get(i).getId());
			if(treeList.get(i).getParent()!=null)
				System.out.print(" ����㣺"+treeList.get(i).getParent().getId());
			System.out.print(" �� ");
			if(treeList.get(i).getChild(0)!=null)
				System.out.print(treeList.get(i).getChild(0).getId());
			else
				System.out.print("null");
			System.out.print(" �ң� ");
			if(treeList.get(i).getChild(1)!=null)
				System.out.print(treeList.get(i).getChild(1).getId());
			else
				System.out.print("null");
			System.out.print(" �������߶ȣ�"+treeList.get(i).getLHeight()+" �������߶ȣ�"+treeList.get(i).getRHeight());
			System.out.print(" ƽ�����ӣ�"+treeList.get(i).getBalanceFactor());
			
			System.out.println("");
		}
	}
	
	public void delete(int id) {
		
		//Node temp = new Node();//���ڱ����ɾ���ڵ����Ϣ
		
		Node t = root;
		for(int i=0;i<treeList.size();i++){
			if(id==treeList.get(i).getId())
				t=treeList.get(i);
		}
		
		
		if(!isEmpty(root.getChild(0)) )
		{
			boolean pan2=t.getChild(1)!=null;
			if(t.getChild(1)!=null){
			Node p=t.getChild(1);
			boolean pan=true;
			while(pan){
				p=p.getChild(0);
				if(isEmpty(p.getChild(0)))
					pan=false;
			}
			t.setId(4);
			t.setId(p.getId());
			t=p;
			}
		}
		Node c=t.getChild(t.getChild(0)==null?1:0);
		Node temp = null;
		
		if(isEmpty(t.getChild(0)))
		{
			boolean boo=t.getChild(1)!=null;
			if(!boo){
			temp=t;
			t=null;
			temp.getParent().setChild(t, (temp.getParent().getChild(0)==temp)?0:1);
			
			}
		}
		
		
		
		
		if(!isEmpty(c)){
			t.getParent().setChild(c, (t.getParent().getChild(0)==t)?0:1);		
			c.setParent(t.getParent());
			temp=t;
			t=null;
			temp.getParent().setChild(t,(temp.getParent().getChild(0)==temp)?0:1);
			
		}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		//�޸Ĵ�ɾ���ڵ����Ƚڵ��ƽ�ⳣ��
		Node s = temp.getParent();
		while(s!=null){
			switch(getBF(s)){
			case 0:
				break;
			//�ҵ���ɾ��λ�������ƽ������Ϊ2�Ľڵ��������ת
			case 2:
				LRotation(s);
				System.out.print("��������ת");
				break;
			//�ҵ���ɾ��λ�������ƽ������Ϊ2�Ľڵ��������ת
			case -2:
				RRotation(s);
				System.out.print("��"+s.getId()+"��������ת    ");
				break;
			}
			s=s.getParent();
			
			}
			
	}

	public JTree printTree() {
		// TODO Auto-generated method 
		DefaultMutableTreeNode node = new DefaultMutableTreeNode("ID: "+this.root.getId()+" "+this.root.getData().toString());
		printTree(node,root);
		JTree tree = new JTree(node);
		return tree;
	}
	
	public JTree printTree(DefaultMutableTreeNode tree,Node node){
		if(!isEmpty(node)){
			//��������
			if(!isEmpty(node.getChild(0))){
				DefaultMutableTreeNode lchild = new DefaultMutableTreeNode("ID: "+node.getChild(0).getId()+" "+node.getChild(0).getData().toString());							
				printTree(lchild,node.getChild(0));
				tree.add(lchild);
			}
			//�����Һ���
			if(!isEmpty(node.getChild(1))){
				DefaultMutableTreeNode rchild = new DefaultMutableTreeNode("ID: "+node.getChild(1).getId()+" "+node.getChild(1).getData().toString());				
				tree.add(rchild);
				printTree(rchild,node.getChild(1));
			}
		}
		return null;		
	}
	public ArrayList<Node>  readData() throws IOException{
		
		String filePath= "src/tree_data.dat";
		File f1 = new File(filePath);
		 ArrayList<Node> list=new ArrayList<Node>();
		 BufferedReader br = new BufferedReader(new InputStreamReader(
			        new FileInputStream(filePath)));
			        for (String line = br.readLine(); line != null; line = br.readLine()) {
			                           System.out.println(line);    
			                           String[] str=line.split("#");
			                           Node m_node=new Node(Integer.parseInt(str[1]),str[0]);
			                           list.add(m_node);
			        }
			        br.close();
			        return list;
			    }
	

}
