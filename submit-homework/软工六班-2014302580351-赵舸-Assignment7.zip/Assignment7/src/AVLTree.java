import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JTree;
import javax.swing.ScrollPaneConstants;
import javax.swing.tree.DefaultMutableTreeNode;

public class AVLTree implements IAVLTree {
	private static JTextArea output = new JTextArea();
	static JTextField temp = new JTextField();
	public static JScrollPane scrollPane;
	private static ArrayList<Node> nodelist = new ArrayList<Node>();
	private static AVLTree aTree = new AVLTree();
	private static ArrayList<Integer> idlist = new ArrayList<Integer>();
	Node root;

	public static void treeInit(AVLTree tree) throws IOException {
		BufferedReader bufr = new BufferedReader(new InputStreamReader(new FileInputStream("tree_data.dat")));
		String line = null;
		while ((line = bufr.readLine()) != null) {
			String[] contents = line.split("#");
			Node node = new Node();
			node.setId(Integer.valueOf(contents[1]));
			node.setData(contents[0]);
			nodelist.add(node);
			// tree.insert(node);
		}
		for (Node node : nodelist) {
			tree.insert(node);
		}

		bufr.close();
	}

	public static void main(String args[]) throws IOException {

		treeInit(aTree);

		JFrame f = new JFrame("AVLTree");
		f.setBounds(600, 200, 500, 600);
		f.setLayout(null);
		output.setBounds(20, 60, 250, 35);
		temp.setBounds(20, 20, 100, 35);
		JButton OKbutton = new JButton("����");
		OKbutton.setBounds(300, 20, 100, 35);
		JButton Dbutton = new JButton("ɾ��");
		Dbutton.setBounds(300, 60, 100, 35);

		scrollPane = new JScrollPane();
		scrollPane.setViewportView(aTree.printTree());

		scrollPane.setBounds(20, 135, 450, 355);
		scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		f.add(output);
		output.setEditable(false);
		f.add(OKbutton);
		f.add(Dbutton);
		f.add(temp);
		OKbutton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int id = Integer.valueOf(temp.getText());
				Node searchNode = aTree.get(id);
				if (searchNode != null) {
					output.setText(String.valueOf(searchNode.getData()));
				} else {
					output.setText("û�иýڵ�");
				}
			}
		});
		Dbutton.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				int id = Integer.valueOf(temp.getText());
				Node searchNode = aTree.get(id);
				if (searchNode != null) {
					aTree.delete(searchNode.getId());
					scrollPane.setViewportView(aTree.printTree());
					output.setText("ɾ���ɹ�");
				} else {
					output.setText("û�иýڵ�");
				}
			}
		});
		f.add(scrollPane);
		f.setVisible(true);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

	}

	@Override
	public Node get(int id) {
		Node p = root;
		while (p != null) {
			if (id < p.getId()) {
				p = p.getChildren()[0];
			} else if (id > p.getId()) {
				p = p.getChildren()[1];
			} else {
				id = p.getId();
				return p;
			}
		}
		System.out.println("Sorry,there is no Node with this Id.");
		return null;
	}

	@Override
	public void insert(Node newNode) {
		if (root == null) {
			root = newNode;
			return;
		}
		Node p = root;
		Node q = p;
		int id = newNode.getId();
		System.out.println(id);
		while (p != null) {
			if (id < p.getId()) {
				q = p;
				p = p.getChildren()[0];
				if (p == null) {
					q.getChildren()[0] = newNode;
					q.balanceFactor += 1;
					newNode.setParent(q);
					System.out.println("left");
				}
			} else if (id > p.getId()) {
				q = p;
				p = p.getChildren()[1];
				if (p == null) {
					q.getChildren()[1] = newNode;
					q.balanceFactor -= 1;
					newNode.setParent(q);
					System.out.println("right");
				}
			} else {
				System.out.println("Sorry,there has been a Node with this Id.");
				break;
			}
		}

		boolean i = true;

		while (i) {
			if (q.balanceFactor == 0) {
				break;
			}

			else if (-2 < q.balanceFactor && q.balanceFactor < 2) {
				if (q == root)
					break;
				else if (id < q.getParent().getId()) {
					q.getParent().balanceFactor += 1;

				} else {
					q.getParent().balanceFactor -= 1;

				}
				q = q.getParent();
			} else if (1 < q.balanceFactor || q.balanceFactor < -1) {
	
				if (id < q.getId() && id < q.getChildren()[0].getId()) {
					R(q);
				} else if (id >= q.getId() && id >= q.getChildren()[1].getId()) {
					System.out.println("qis" + q.getId());
					System.out.println("llllll");
					L(q);
				} else if (id < q.getId() && id >= q.getChildren()[0].getId()) {
					L(q.getChildren()[0]);
					R(q);
				} else {
					R(q.getChildren()[1]);
					L(q);
				}

				if (q.getParent() == null || q.getParent().balanceFactor == 0) {
					break;
				} else {
					q = q.getParent().getParent();
				}

			}
		}

	}

	// ������
	private void L(Node node) {
		System.out.println("nodeis" + node.getId());
		System.out.println(node.getParent() != null);
		Node r = node.getChildren()[1];
		Node u = r.getChildren()[0];
		if (node.getParent() == null) {
			System.out.println("changeroot");
			root = r;
			root.setParent(null);
			System.out.println("rootis" + root.getId());
		} else {
			if (node.getId() < node.getParent().getId()) {
				node.getParent().setChild(r, 0);
				r.setParent(node.getParent());
			}
			if (node.getId() > node.getParent().getId()) {
				node.getParent().setChild(r, 1);
				r.setParent(node.getParent());
			}
		}

		if (u == null) {
			node.setParent(r);
			node.setChild(u, 1);
			r.setChild(node, 0);
			r.balanceFactor = 0;
			node.balanceFactor = 0;

		}
		if (u != null) {
			u.setParent(node);
			r.setChild(node, 0);
			node.setChild(u, 1);
			node.setParent(r);
			r.balanceFactor += 1;
			node.balanceFactor += 2;
		}


	}

	// ������
	private void R(Node node) {
		Node r = node.getChildren()[0];
		Node u = r.getChildren()[1];
		if (node.getParent() == null) {
			root = r;
			root.setParent(null);
		} else {
			if (node.getId() < node.getParent().getId()) {
				node.getParent().setChild(r, 0);
				r.setParent(node.getParent());

			}
			if (node.getId() > node.getParent().getId()) {
				node.getParent().setChild(r, 1);
				r.setParent(node.getParent());
			}
		}

		node.setParent(r);
		if (u == null) {
			node.setParent(r);
			r.setChild(node, 1);
			node.setChild(u, 0);
			r.balanceFactor = 0;
			node.balanceFactor = 0;

		}
		if (u != null) {
			u.setParent(node);
			r.setChild(node, 0);
			node.setChild(u, 0);
			node.setParent(r);
			r.balanceFactor -= 1;
			node.balanceFactor -= 2;
		}
		

	}

	@Override
	public void delete(int id) {
		BufferedReader bufr = null;
		ArrayList<Node> dnodelist = new ArrayList<Node>();
		ArrayList<Node> ddnodelist = new ArrayList<Node>();
		idlist.add(id);
		try {
			bufr = new BufferedReader(new InputStreamReader(new FileInputStream("tree_data.dat")));
		} catch (FileNotFoundException e1) {
			// TODO �Զ����ɵ� catch ��
			e1.printStackTrace();
		}
		String line = null;
		AVLTree Tree = new AVLTree();
		try {
			while ((line = bufr.readLine()) != null) {
				String[] contents = line.split("#");
				Node node = new Node();
				node.setId(Integer.valueOf(contents[1]));
				node.setData(contents[0]);
				dnodelist.add(node);

			}
		} catch (NumberFormatException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		} catch (IOException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}

		for (Node node : dnodelist) {
			for (int idd : idlist) {
				if (node.getId() == idd)
					ddnodelist.add(node);
			}
		}

		dnodelist.removeAll(ddnodelist);

		for (Node node : dnodelist) {
			Tree.insert(node);
		}
		aTree = Tree;
		try {
			bufr.close();
		} catch (IOException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}


	}

	@Override
	public JTree printTree() {
		return new JTree(printTree(this.root));
	}

	private DefaultMutableTreeNode printTree(Node node) {
		if (node == null) {
			return null;
		}

		DefaultMutableTreeNode left = printTree(node.getChildren()[0]);
		DefaultMutableTreeNode right = printTree(node.getChildren()[1]);
		DefaultMutableTreeNode treeNode = new DefaultMutableTreeNode(node.getId());
		if (left != null) {
			treeNode.add(left);
		}
		if (right != null) {
			treeNode.add(right);
		}
		return treeNode;
	}
}
