import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;

public class AVLTree2014302580390 implements IAVLTree{
	private Node root=null;
	public Node Root(){
		return root;
	}
	public Node getParent(Node p){
		int id=p.getId();
		Node p1=root;
		boolean a=true;
		while(a){
			if(id<p1.getId()){
				if(p1.getChild(0).getId()==id)
					a=false;
				else
					p1=p1.getChild(0);
			}
			else if(id>p1.getId()){
				if(p1.getChild(1).getId()==id)
					a=false;
				else
					p1=p1.getChild(1);
			}
			else
				a=false;
				
		}
		return p1;
		
	}

	@Override
	public Node get(int id) {
		
		return Get(id,root);
	}
	private Node Get(int i,Node n){
		if(n==null)
			return null;
		else{
			if(n.getId()==i)
				return n;
			else if(n.getId()<i)
				return Get(i,n.getChild(1));
			else
				return Get(i,n.getChild(0));
				
		}
	}


	private Node findMin(Node t){
		if(t==null)
			return null;
		else if(t.getChild(0)==null)
			return t;
		return findMin(t.getChild(0));
	}
	private Node delete(int id,Node t){
		if(t==null)
			return t;
		int compareResult=id-t.getId();
		if(compareResult<0)
			t.setChild(delete(id,t.getChild(0)), 0);
		else if(compareResult>0)
			t.setChild(delete(id,t.getChild(1)), 1);
		else if(t.getChild(0)!=null&&t.getChild(1)!=null){
			t.setId(findMin(t.getChild(1)).getId());
			t.setChild(delete(t.getId(),t.getChild(1)), 1);
		}
		else
			t=(t.getChild(0)!=null)?t.getChild(0):t.getChild(1);
		return t;
	}
	@Override
	public void delete(int id) {
		Node t=get(id);
		int compareResult=Height(getParent(t).getChild(0))-Height(getParent(t).getChild(1));
		if(compareResult==0)
			delete(id,t);
		if(compareResult<0&&t==getParent(t).getChild(1)){
			Node p1=getParent(t);
			delete(id,t);
			while(Height(p1.getChild(0))-Height(p1.getChild(1))>=-1&&
					Height(p1.getChild(0))-Height(p1.getChild(1))<=1){
				if(getParent(p1)!=null)
					p1=getParent(t);
				else
					break;
			}
			int compareResult1=Height(p1.getChild(0))-Height(p1.getChild(1));
			if(compareResult1==2){
			if(Height(p1.getChild(0).getChild(0))-Height(p1.getChild(0).getChild(1))==1)
				p1=rotateWithLeftChild(p1);
		    else
			    p1=doubleWithLeftChild(p1);
			}
			else if(compareResult1==-2){
				if(Height(p1.getChild(1).getChild(0))-Height(p1.getChild(1).getChild(1))==-1)
					p1=rotateWithLeftChild(p1);
			    else
				    p1=doubleWithLeftChild(p1);
				}
			}
		if(compareResult>0&&t==getParent(t).getChild(0)){
			Node p2=t.getParent();
			delete(id,t);
			while(Height(p2.getChild(0))-Height(p2.getChild(1))>=-1&&
					Height(p2.getChild(0))-Height(p2.getChild(1))<=1){
				if(getParent(p2)!=null)
					p2=getParent(p2);
				else
					break;
			}
			int compareResult2=Height(p2.getChild(0))-Height(p2.getChild(1));
			if(compareResult2==2){
				if(Height(p2.getChild(0).getChild(0))-Height(p2.getChild(0).getChild(1))==1)
					p2=rotateWithLeftChild(p2);
			    else
				    p2=doubleWithLeftChild(p2);
				}
				else if(compareResult2==-2){
					if(Height(p2.getChild(1).getChild(0))-Height(p2.getChild(1).getChild(1))==-1)
						p2=rotateWithLeftChild(p2);
				    else
					    p2=doubleWithLeftChild(p2);
					}
		}
		if(compareResult<0&&t==getParent(t).getChild(0)){
			Node p2=getParent(t);
			delete(id,t);
			while(Height(p2.getChild(0))-Height(p2.getChild(1))>=-1&&
					Height(p2.getChild(0))-Height(p2.getChild(1))<=1){
				if(getParent(p2)!=null)
					p2=getParent(p2);
				else
					break;
			}
			int compareResult2=Height(p2.getChild(0))-Height(p2.getChild(1));
			if(compareResult2==2){
				if(Height(p2.getChild(0).getChild(0))-Height(p2.getChild(0).getChild(1))==1)
					p2=rotateWithLeftChild(p2);
			    else
				    p2=doubleWithLeftChild(p2);
				}
				else if(compareResult2==-2){
					if(Height(p2.getChild(1).getChild(0))-Height(p2.getChild(1).getChild(1))==-1)
						p2=rotateWithLeftChild(p2);
				    else
				    	p2=doubleWithLeftChild(p2);
				}
		}
		if(compareResult>0&&t==getParent(t).getChild(1)){
			Node p2=t.getParent();
			delete(id,t);
			while(Height(p2.getChild(0))-Height(p2.getChild(1))>=-1&&
					Height(p2.getChild(0))-Height(p2.getChild(1))<=1){
				if(getParent(p2)!=null)
					p2=getParent(p2);
				else
					break;
			}
			int compareResult2=Height(p2.getChild(0))-Height(p2.getChild(1));
			if(compareResult2==2){
				if(Height(p2.getChild(0).getChild(0))-Height(p2.getChild(0).getChild(1))==1)
					p2=rotateWithLeftChild(p2);
			    else
				    p2=doubleWithLeftChild(p2);
				}
				else if(compareResult2==-2){
					if(Height(p2.getChild(1).getChild(0))-Height(p2.getChild(1).getChild(1))==-1)
						p2=rotateWithLeftChild(p2);
				    else
				    	p2=doubleWithLeftChild(p2);
				}
		}
		
}
		
		
	

	@Override
	public JTree printTree()
	{
		DefaultMutableTreeNode firstNode=new DefaultMutableTreeNode();
		printTree(firstNode,root);
		JTree temp=new JTree(firstNode);
		return temp;
	}
	
	private void printTree(DefaultMutableTreeNode defalutNode,Node node)
	{
		if(node!=null)
		{
			
			if(node.getChild(0)!=null)
			{
				DefaultMutableTreeNode secondNode=new DefaultMutableTreeNode(node.getChild(0));
				defalutNode.add(secondNode);
				printTree(secondNode,node.getChild(0));
			}
			defalutNode.add(new DefaultMutableTreeNode(node));
			if(node.getChild(1)!=null)
			{
				DefaultMutableTreeNode thirdNode=new DefaultMutableTreeNode(node.getChild(1));
				defalutNode.add(thirdNode);
				printTree(thirdNode,node.getChild(1));
			}
		}
	}
	@Override
	public void insert(Node newNode) {
		if(root==null){
			root=newNode;
		}
		else
			Insert(newNode,root);
	}
	private Node Insert(Node newNode,Node parent){
		if(parent==null){
			return new Node(newNode.getId());
		 }
		int compareResult=compare(newNode,parent);
		if(compareResult<0){
			parent.setChild(Insert(newNode,parent.getChild(0)), 0);
			if(Height(parent.getChild(0))-Height(parent.getChild(1))==2)
				if(compare(newNode,parent.getChild(0))<0)
					parent=rotateWithLeftChild(parent);
			    else
				    parent=doubleWithLeftChild(parent);
		}
		else if(compareResult>0){
			parent.setChild(Insert(newNode,parent.getChild(1)), 1);
			if(Height(parent.getChild(1))-Height(parent.getChild(0))==2)
				if(compare(newNode,parent.getChild(1))>0)
					parent=rotateWithRightChild(parent);
				else
					parent=doubleWithRightChild(parent);
		}
		else
			System.out.println("有重复的id");
		parent.setHeight(Math.max(Height(parent.getChild(0)), Height(parent.getChild(1)))+1);
		
		return parent;
		
	}
	private Node rotateWithLeftChild(Node k2){
		Node k1=k2.getChild(0);
		k2.setChild(k1.getChild(0), 0);
		k1.setChild(k2, 1);
		k2.setHeight(Math.max(Height(k2.getChild(0)), Height(k2.getChild(1)))+1);
		return k1;
	}
	private Node doubleWithLeftChild(Node k3){
		k3.setChild(rotateWithRightChild(k3.getChild(0)), 0);
		return rotateWithLeftChild(k3);
	}
	private Node rotateWithRightChild(Node k2){
		Node k1=k2.getChild(1);
		k2.setChild(k1.getChild(0), 1);
		k1.setChild(k2, 0);
		k2.setHeight(Math.max(Height(k2.getChild(0)), Height(k2.getChild(1)))+1);
		return k1;
	}
	private Node doubleWithRightChild(Node k3){
		k3.setChild(rotateWithLeftChild(k3.getChild(0)), 0);
		return rotateWithRightChild(k3);
	}

	
    public int compare(Node o1, Node o2) {
		if(o1.getId()>o2.getId())
			return 1;
		else if(o1.getId()<o2.getId())
		    return -1;
		else
			return 0;
		
	}
    public int Height(Node t){
	if(t!=null){
		return (Height(t.getChild(0))+1>Height(t.getChild(1))+1?Height(t.getChild(0))+1:Height(t.getChild(1))+1);
	} 
	return 0;
    }
    public void inOrder()
	{
		inOrder(root);
	}
	private void inOrder(Node node)
	{
		if(node!=null)
		{		
			inOrder(node.getChild(0));
			System.out.print(node.getId()+" ");
			inOrder(node.getChild(1));
		}
	}

}
