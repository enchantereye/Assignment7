import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTree;

public class Test2014302580390 extends JFrame{

	private JTree tree;
	private JTree newTree;
	public void setTree(JTree tree)
	{
		this.newTree=tree;
		this.add(this.newTree);
		this.tree.setVisible(false);
	}
	public Test2014302580390(JTree t)
	{
		this.tree=t;
		this.add(this.tree);
	}
	public static void main(String[] args)
	{
		AVLTree2014302580390 avltree=new AVLTree2014302580390();

		Node a=new Node(20);
		Node b=new Node(16);
		Node c=new Node(30);
		Node d=new Node(10);
		Node e=new Node(18);
		Node f=new Node(25);
		Node g=new Node(40);
		Node h=new Node(19);
	    Node i=new Node(27);
	    
		

		avltree.insert(a);
		avltree.insert(b);
		avltree.insert(c);
		avltree.insert(d);
		avltree.insert(e);
		avltree.insert(f);
		avltree.insert(g);
		avltree.insert(h);
		avltree.insert(i);
		System.out.println("get(25)");
		System.out.println(avltree.get(25));
		System.out.println("\n");
		System.out.println("中序遍历");
		avltree.inOrder();
		System.out.println("\n");
	   
	    
	    
		System.out.println("原本插入了16，现在删除后将其显示出来，结果没有16，删除成功");
        avltree.delete(16);
		avltree.inOrder();
		
		
		JTree treeDefalut=avltree.printTree();
		Test2014302580390 gui=new Test2014302580390(treeDefalut);
		gui.setTitle("AvlTree");
		gui.setVisible(true);
		gui.setSize(300, 500);
		gui.setBounds(300, 300, 300, 500);
		gui.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	
			
	}
}

