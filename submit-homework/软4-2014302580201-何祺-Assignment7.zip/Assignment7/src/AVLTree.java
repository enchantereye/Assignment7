import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;

public class AVLTree implements IAVLTree {
	private Node begin;

	public Node get(int id) {
		Node a = Search(begin, id);
		if (a.getId() != -1) {
			System.out.println(a.getId()+"#"+a.getData());
			return a;
		}
		try {
			throw new Exception();
		} catch (Exception e) {
			System.out.println("������idΪ" + id + "�Ľ�� ");
		}
		return null;
	}

	public void insert(Node newNode) {
		Node p = begin;
		Node q = null;
		while (p != null) {
			q = p;
			if (newNode.getId() < p.getId()) {
				p = p.getChildren()[0];
			} else if (newNode.getId() > p.getId()) {
				p = p.getChildren()[1];
			} else if (newNode.getId() == p.getId()) {
				try {
					throw new Exception();
				} catch (Exception e) {
					System.out.println("idΪ" + p.getId() + "�Ľ���Ѵ���");
					return;
				}
			}
		}
		if (begin == null) {
			begin = newNode;
		} else if (newNode.getId() < q.getId()) {
			q.setChild(newNode, 0);
			newNode.setParent(q);
		} else {
			q.setChild(newNode, 1);
			newNode.setParent(q);
		}
		adjustbf();
		while (balance() > 0) {
			rotate(newNode);
			adjustbf();
		}
		return;
	}

	public void delete(int id) {
		Node p = Search(begin, id);
		Node s;
		Node r;
		Node last = null;
		if (p.getId() == -1) {
			try {
				throw new Exception();
			} catch (Exception e) {
				System.out.println("������idΪ" + id + "�Ľ�� ");
			}
		} else if (p.getChildren()[0] == null && p.getChildren()[1] == null) {
			if (p == begin) {
				begin = null;
			} else {
				last = p.getParent();
				if (p.getId() < p.getParent().getId()) {
					p.getParent().setChild(null, 0);
				}
				if (p.getId() > p.getParent().getId()) {
					p.getParent().setChild(null, 1);
				}
			}
		}
		if (p.getChildren()[0] == null && p.getChildren()[1] != null) {
			if (p == begin) {
				p.getChildren()[1].setParent(null);
				begin = p.getChildren()[1];
			} else {
				last = p.getChildren()[1];
				if (p.getId() < p.getParent().getId()) {
					p.getParent().setChild(p.getChildren()[1], 0);
				}
				if (p.getId() < p.getParent().getId()) {
					p.getParent().setChild(p.getChildren()[1], 1);
				}
			}
		}
		if (p.getChildren()[0] != null && p.getChildren()[1] == null) {
			if (p == begin) {
				p.getChildren()[0].setParent(null);
				begin = p.getChildren()[0];
			} else {
				last = p.getChildren()[0];
				if (p.getId() < p.getParent().getId()) {
					p.getParent().setChild(p.getChildren()[0], 0);
				}
				if (p.getId() < p.getParent().getId()) {
					p.getParent().setChild(p.getChildren()[0], 1);
				}
			}
		}
		if (p.getChildren()[0] != null && p.getChildren()[1] != null) {
			s = p.getChildren()[1];
			while (s.getChildren()[0] != null) {
				s = s.getChildren()[0];
			}
			p.setId(s.getId());
			p.setData(s.getData());
			r = s.getParent();
			last = r;
			if (s.getChildren()[1] == null) {
				r.setChild(null, 0);
			} else {
				r.setChild(s.getChildren()[1], 0);
				s.getChildren()[1].setParent(r);
			}
		}
		adjustbf();
		while (balance() > 0) {
			rotate(last);
			adjustbf();
		}
	}

	public JTree printTree() {
		DefaultMutableTreeNode dt = new DefaultMutableTreeNode(begin.getId() + "#" + begin.getData());
		addTree(begin, dt);
		JTree jr = new JTree(dt);
		return jr;
	}

	public void addTree(Node p, DefaultMutableTreeNode dt) {
		if (p.getChildren()[0] != null) {
			DefaultMutableTreeNode a = new DefaultMutableTreeNode(
					p.getChildren()[0].getId() + "#" + p.getChildren()[0].getData());
			dt.add(a);
			addTree(p.getChildren()[0], a);
		}
		if (p.getChildren()[1] != null) {
			DefaultMutableTreeNode b = new DefaultMutableTreeNode(
					p.getChildren()[1].getId() + "#" + p.getChildren()[1].getData());
			dt.add(b);
			addTree(p.getChildren()[1], b);
		}
	}

	public Node Search(Node p, int id) {
		if (p == null) {
			Node a = new Node();
			a.setId(-1);
			return a;
		}
		Node[] child = p.getChildren();
		if (id < p.getId()) {
			return Search(child[0], id);
		} else if (id > p.getId()) {
			return Search(child[1], id);
		} else if (id == p.getId()) {
			return p;
		}
		return null;
	}

	public void adjustbf() {
		adjustbf(begin);
	}

	public int adjustbf(Node p) {
		if (p == null) {
			return 0;
		}
		p.setBalanceFactor(adjustbf(p.getChildren()[0]) - adjustbf(p.getChildren()[1]));
		if (adjustbf(p.getChildren()[0]) > adjustbf(p.getChildren()[1])) {
			return adjustbf(p.getChildren()[0]) + 1;
		} else if (adjustbf(p.getChildren()[0]) < adjustbf(p.getChildren()[1])) {
			return adjustbf(p.getChildren()[1]) + 1;
		} else if (adjustbf(p.getChildren()[0]) == adjustbf(p.getChildren()[1])) {
			return adjustbf(p.getChildren()[0]) + 1;
		}
		return -100;
	}

	public void LL(Node p) {
		Node r = p.getChildren()[0];
		if(r.getBalanceFactor()==0){
			if (p == begin) {
				begin = r;
				r.setParent(null);
				if (r.getChildren() != null) {
					p.setChild(r.getChildren()[1], 0);
				} else {
					p.setChild(null, 0);
				}
				p.setParent(r);
				r.setChild(p, 1);
			} else {
				r.setParent(p.getParent());
				if (p.getId() < p.getParent().getId()) {
					p.getParent().setChild(r, 0);
				} else {
					p.getParent().setChild(r, 1);
				}
				if (r.getChildren()[1] != null) {
					p.setChild(r.getChildren()[1], 0);
				} else {
					p.setChild(null, 0);
				}
				p.setParent(r);
				r.setChild(p, 1);
			}
		}
		if (r.getBalanceFactor() == 1) {
			if (p == begin) {
				begin = r;
				r.setParent(null);
				if (r.getChildren() != null) {
					p.setChild(r.getChildren()[1], 0);
				} else {
					p.setChild(null, 0);
				}
				p.setParent(r);
				r.setChild(p, 1);
			} else {
				r.setParent(p.getParent());
				if (p.getId() < p.getParent().getId()) {
					p.getParent().setChild(r, 0);
				} else {
					p.getParent().setChild(r, 1);
				}
				if (r.getChildren()[1] != null) {
					p.setChild(r.getChildren()[1], 0);
				} else {
					p.setChild(null, 0);
				}
				p.setParent(r);
				r.setChild(p, 1);
			}
		}
		if (r.getBalanceFactor() == -1) {
			if (p == begin) {
				Node u = r.getChildren()[1];
				if (u.getChildren()[0] != null) {
					r.setChild(u.getChildren()[0], 1);
				} else {
					r.setChild(null, 1);
				}
				if (u.getChildren()[1] != null) {
					p.setChild(u.getChildren()[1], 0);
				} else {
					p.setChild(null, 0);
				}
				u.setChild(r, 0);
				u.setChild(p, 1);
				r.setParent(u);
				p.setParent(u);
				u.setParent(null);
				begin = u;
			} else {
				Node u = r.getChildren()[1];
				if (u.getChildren()[0] != null) {
					r.setChild(u.getChildren()[0], 1);
				} else {
					r.setChild(null, 1);
				}
				if (u.getChildren()[1] != null) {
					p.setChild(u.getChildren()[1], 0);
				} else {
					p.setChild(null, 0);
				}
				u.setChild(r, 0);
				u.setChild(p, 1);
				u.setParent(p.getParent());
				if (p.getId() < p.getParent().getId()) {
					p.getParent().setChild(u, 0);
				} else {
					p.getParent().setChild(u, 1);
				}
				r.setParent(u);
				p.setParent(u);
			}
		}
	}

	public void RR(Node p) {
		Node r = p.getChildren()[1];
		if(r.getBalanceFactor()==0){
			if(p==begin){
				begin=r;
				r.setParent(null);
				if(r.getChildren()[0]!=null){
					p.setChild(r.getChildren()[0], 1);
				}else{
					p.setChild(null, 1);
				}
				p.setParent(r);
				r.setChild(p, 0);
			}else {
				r.setParent(p.getParent());
				if (p.getId() < p.getParent().getId()) {
					p.getParent().setChild(r, 0);
				} else {
					p.getParent().setChild(r, 1);
				}
				if (r.getChildren()[0] != null) {
					p.setChild(r.getChildren()[0], 1);
				} else {
					p.setChild(null, 1);
				}
				p.setParent(r);
				r.setChild(p, 0);
			}
		}
		if (r.getBalanceFactor() == -1) {
			if (p == begin) {
				begin = r;
				r.setParent(null);
				if (r.getChildren()[0] != null) {
					p.setChild(r.getChildren()[0], 1);
				} else {
					p.setChild(null, 1);
				}
				p.setParent(r);
				r.setChild(p, 0);
			} else {
				r.setParent(p.getParent());
				if (p.getId() < p.getParent().getId()) {
					p.getParent().setChild(r, 0);
				} else {
					p.getParent().setChild(r, 1);
				}
				if (r.getChildren()[0] != null) {
					p.setChild(r.getChildren()[0], 1);
				} else {
					p.setChild(null, 1);
				}
				p.setParent(r);
				r.setChild(p, 0);
			}

		}
		if (r.getBalanceFactor() == 1) {
			if (p == begin) {
				Node u = r.getChildren()[0];
				if (u.getChildren()[1] != null) {
					r.setChild(u.getChildren()[1], 0);
				} else {
					r.setChild(null, 0);
				}
				if (u.getChildren()[0] != null) {
					p.setChild(u.getChildren()[0], 1);
				} else {
					p.setChild(null, 1);
				}
				u.setChild(r, 1);
				u.setChild(p, 0);
				r.setParent(u);
				p.setParent(u);
				u.setParent(null);
				begin = u;
			} else {
				Node u = r.getChildren()[0];
				if (u.getChildren()[1] != null) {
					r.setChild(u.getChildren()[1], 0);
				} else {
					r.setChild(null, 0);
				}
				if (u.getChildren()[0] != null) {
					p.setChild(u.getChildren()[0], 1);
				} else {
					p.setChild(null, 1);
				}
				u.setChild(r, 1);
				u.setChild(p, 0);
				u.setParent(p.getParent());
				if (p.getId() < p.getParent().getId()) {
					p.getParent().setChild(u, 0);
				} else {
					p.getParent().setChild(u, 1);
				}
				r.setParent(u);
				p.setParent(u);
			}
		}
	}

	public int balance() {
		return balance(begin);
	}

	public int balance(Node p) {
		if (p == null) {
			return 0;
		}
		if (p.getBalanceFactor() == 2 || p.getBalanceFactor() == -2) {
			return 1;
		}
		return balance(p.getChildren()[0]) + balance(p.getChildren()[1]);
	}

	public void rotate(Node p) {
		if (p == null) {
			return;
		}
		if (p.getBalanceFactor() == 2) {
			LL(p);
			return;
		}
		if (p.getBalanceFactor() == -2) {
			RR(p);
			return;
		}
		if (p.getParent() == null) {
			return;
		}
		rotate(p.getParent());
	}
}
