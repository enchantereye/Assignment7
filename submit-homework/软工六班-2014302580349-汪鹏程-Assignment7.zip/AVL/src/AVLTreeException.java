
public class AVLTreeException extends Exception {
	private static final long serialVersionUID = 1L;
	
	public AVLTreeException(){}
	
	public AVLTreeException(String message){
		super(message);
	}
}
