public class Node {
	private int id;
	private Object data;
	private Node parent;
	private Node[] children = new Node[2];
	
	public Node(){
		
	}
	public Node(Object data){
		this.data=data;
	}
	public int getId() {
		return id;
	}
	public void setId(int i){
		this.id=i;
	}
	public Object getData() {
		return data;
	}
	public void setData(Object data) {
		this.data = data;
	}
	public Node getParent() {
		return parent;
	}
	public void setParent(Node parent) {
		this.parent = parent;
	}
	public int getChildId(Node parent) {
		// TODO ��õ�ǰ�ڵ���˫�׵����ӻ����Һ���
		if(parent==null){
			return 0;
		}
		if(parent.getChildren()[0]==this){
			return 0;
		}else{
			return 1;
		}
	}
	public int getChildrenCount(){
		// TODO ��ýڵ�ĺ������� ����ɾ��������Ҫ�õ���
		int account=0;
		if(this.getChildren()[0]!=null){
			account++;
		}
		if(this.getChildren()[1]!=null){
			account++;
		}
		return account;
	}
	public Node[] getChildren() {
		return children;
	}
	public void setChildren(Node[] children) {
		this.children = children;
		children[0].setParent(this);
		children[1].setParent(this);
	}
	public void setChild(Node child, int id){
		// TODO �޸ķ�����ʹ�ýڵ����Ӻ���ʱ�����ӻ��Զ����õ�ǰ�ڵ�Ϊ˫�׽ڵ�
		this.children[id] = child;
		if(child!=null){
			child.setParent(this);
		}
	}
	public int getlSubTreeHeight() {
		//TODO calculate the left sub tree height
		int lSubTreeHeight=0;
		if(getChildren()[0]!=null){
			lSubTreeHeight=getChildren()[0].getHeight();
		}else{
			lSubTreeHeight=0;
		}
		return lSubTreeHeight;
	}
	public int getrSubTreeHeight() {
		//TODO calculate the right sub tree height
		int rSubTreeHeight=0;
		if(getChildren()[1]!=null){
			rSubTreeHeight=getChildren()[1].getHeight();
		}else{
			rSubTreeHeight=0;
		}
		return rSubTreeHeight;
	}
	public int getBalanceFactor() {
		//TODO calculate the balance factor
		int balanceFactor=0;
		balanceFactor=getlSubTreeHeight()-getrSubTreeHeight();
		return balanceFactor;
	}
	public int getHeight(){
		//TODO ����Ե�ǰ�ڵ�Ϊ���ڵ�����ĸ߶ȡ�
		if(this.getChildren()[0]==null&&this.getChildren()[1]==null){
			return 1;
		}else if(this.getChildren()[0]==null){
			return this.getChildren()[1].getHeight()+1;
		} else if(this.getChildren()[1]==null){
			return this.getChildren()[0].getHeight()+1;
		} else {
			return max(this.getChildren()[0].getHeight(),this.getChildren()[1].getHeight())+1;
		}
	}
	private int max(int height, int height2) {
		// TODO ˽�з���������߶�ʱ��Ҫʹ�õ�
		if(height>height2){
			return height;
		}else{
			return height2;
		}
	}


}
