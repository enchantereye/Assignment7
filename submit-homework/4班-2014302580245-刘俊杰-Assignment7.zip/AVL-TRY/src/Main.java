import java.util.Random;

import javax.swing.JScrollPane;

public class Main {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String[] messages={"ant","apple","art","baby","banan",
				"car","door","dress","frog","love","mint","rice",
				"show","table","tree","troble","window"};
		AVLTree a=new AVLTree();
		for(int i=1;i<=messages.length;i++){
			a.insert(i,new Node(messages[i-1]));
		}
		a.delete(12);
		a.delete(8);
		a.showTree();
		Random r=new Random();
		int id=r.nextInt(16)+1;
		System.out.println("\n\n\n\nidΪ"+id+"�Ľڵ�����Ϊ�� "+a.get(id).getData());
		GUI g=new GUI("showTree");
		g.add(new JScrollPane(a.printTree()));
		g.setVisible(true);
	}

}
