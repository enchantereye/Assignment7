import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Toolkit;

import javax.swing.JFrame;

public class GUI extends JFrame{
	
	/**
	 * �򵥵�GUI
	 */
	private static final long serialVersionUID = 1L;
	public GUI(String name){
		super(name);
		init();
	}
	private void init(){
		setLayout(new GridLayout(1,1));
		setSize(500,350);
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		Dimension size = getSize();
		int x = (screenSize.width - size.width) / 2;
		int y = (screenSize.height - size.height) / 2;
		setLocation( x, y );
	}
}
