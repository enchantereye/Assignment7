import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class Data {

	private static String[][] arr;
	private static String[] details;
	private static File file;
	private static BufferedReader reader;

	public static void init() throws IOException {
		
		arr = new String[30][2];
		details = new String[2];
		file = new File("tree_data.dat");
		reader = new BufferedReader(new FileReader(file));

		String tempString = null;

		int line = 0;
		while ((tempString = reader.readLine()) != null) {

			details = tempString.split("\\#");
			arr[line] = details;
		//	System.out.println(arr[line][1] + "  " + arr[line][0]);
			line++;
		}

		reader.close();
	}
	public static int getID(int index)
	{
		return Integer.parseInt(arr[index][1]);
	}
	
	public static String getData(int index) {
		return arr[index][0];
	}
	
	public static void setID(int index,int ID)
	{
		arr[index][1]=Integer.toString(ID);
	}
	
	public static void setData(int index,String data)
	{
		arr[index][0]=data;
	}
	
	public static int getCurNotNullIndex()
	{
		for(int i=0;i<30;i++)
		{
			if(arr[i][0]==null||arr[i][1]==null)
			{
				return i;
			}
		}
		return 0;
	}
}
