import java.io.IOException;
import java.util.ArrayList;
import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;

class myBool {
	private boolean unbalanced;

	public myBool(boolean unbalanced) {
		// TODO Auto-generated constructor stub
		this.unbalanced = unbalanced;
	}

	public void setBool(boolean unbalanced) {
		this.unbalanced = unbalanced;
	}

	public boolean getBool() {
		return unbalanced;
	}
}

public class AVLTree implements IAVLTree {

	private Node root;

	private int nodeNum;

	private ArrayList<Integer> nodeIDs;

	private AVLTree myNewAVlTree;
	
	public AVLTree() throws IOException {
		// TODO Auto-generated constructor stub
		root = null;
		nodeNum = 0;
		nodeIDs = new ArrayList<Integer>();
		Data.init();
	}

	// �ж�AVL���Ƿ�Ϊ��
	public boolean isEmpty() {
		return root == null;
	}

	@Override
	public Node get(int id) {
		// TODO Auto-generated method stub
		Node findNode = root;
		while (findNode != null) {
			if (id == findNode.getId()) {
				break;
			} else if (id > findNode.getId()) {
				// findNode.setChild(findNode, 1);
				findNode = findNode.getRightChild();
			} else {
				// findNode.setChild(findNode, 0);
				findNode = findNode.getLeftChild();
			}
		}
		return findNode;
	}

	@Override
	public void insert(int id, Node newNode) {
	
		//System.out.println("��ʼ����ڵ�:" + id);
		newNode = root;

		boolean balanced = false;

		myBool unbalanced = new myBool(balanced);

		root = Insert(id, root, unbalanced);

		//System.out.println("����ɹ���");

		nodeNum++;
		nodeIDs.add(id);
	}

	private Node Insert(int id, Node p, myBool unBalanced) {

		if (p == null) {
			// System.out.println("���ڵ�Ϊ�գ�������ڵ㣡");
			p = new Node();
			p.setId(id);
			p.setData(Data.getData(id-1));
			unBalanced.setBool(true);
			// root=p;
		}

		else if (id < p.getId()) {
			// System.out.println("�����ӽڵ㣡");
			Node midNode = Insert(id, p.getLeftChild(), unBalanced);
			// unBalanced=true;
			p.setChild(midNode, 0);

			if (unBalanced.getBool()) {
				switch (p.getBalanceFactor()) {
				case -1:
					p.setBalanceFactor(0);
					unBalanced.setBool(false);
					break;
				case 0:
					p.setBalanceFactor(1);
					break;
				case 1:
					Node mNode = LRotation(p, unBalanced);
					p = mNode;

					// default:
					// System.err.println("ƽ��ʧ�ܣ�");
					// break;
				}
			}
		}

		else if (id == p.getId()) {
			unBalanced.setBool(false);
			id = p.getId();
			System.err.println("���ظ�Ԫ�أ�����ʧ�ܣ�");
		}

		else {
			// System.out.println("�����ӽڵ㣡");
			Node mdiNode = Insert(id, p.getRightChild(), unBalanced);
			// unBalanced=true;
			p.setChild(mdiNode, 1);

			// Insert(id, p.getRightChild, unBalanced);
			if (unBalanced.getBool()) {
				switch (p.getBalanceFactor()) {
				case 1:
					p.setBalanceFactor(0);
					unBalanced.setBool(false);
					break;
				case 0:
					p.setBalanceFactor(-1);
					break;
				case -1:
					Node mNode = RRotation(p, unBalanced);
					p = mNode;

					// default:
					// System.err.println("ƽ��ʧ�ܣ�");
					// break;
				}
			}
		}
		return p;
	}

	@Override
	public void delete(int id) {
		try {
			myNewAVlTree=deleteNode(id);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("ɾ���ɹ���");

	}

	private AVLTree deleteNode(int id) throws IOException {

		AVLTree newTree = new AVLTree();
		int index = -1;
		for (int j = 0; j < nodeNum; j++) {
			if (id == nodeIDs.get(j)) {
				index = j;
				break;
			}
		}

		nodeNum--;
		if (index >= 0) {
			nodeIDs.remove(index);
		} else {
			System.err.println("�����ڣ��޷�ɾ����");
			return null;
		}

		Node[] nodes = new Node[nodeNum];
		for (int i = 0; i < nodeNum; i++) {
			nodes[i] = new Node();
			nodes[i].setId(nodeIDs.get(i));
			//nodes[i].setData(Data.getData(nodes[i].getId()));
			newTree.insert(nodes[i].getId(), nodes[i]);
		}
		return newTree;
	}

	public void preOrder() {
		if (root == null) {
			System.out.println("����һ�ſն�������");
		} else {
			preOrder(root);
			System.out.println();
		}
	}

	private void preOrder(Node printNode) {
		if (printNode != null) {
			System.out.print(printNode.getId() + "-"+printNode.getData()+" ");
			preOrder(printNode.getLeftChild());
			
			preOrder(printNode.getRightChild());
		}
	}

	private Node LRotation(Node s, myBool unBalanced)// L��ת
	{
		Node u, r = s.getLeftChild();
		if (r.getBalanceFactor() == 1)// LL��ת
		{
			s.setChild(r.getRightChild(), 0);
			r.setChild(s, 1);
			s.setBalanceFactor(0);

			s = r;

		} else {// LR��ת
			u = r.getRightChild();
			r.setChild(u.getLeftChild(), 1);
			u.setChild(r, 0);
			s.setChild(u.getRightChild(), 0);
			u.setChild(s, 1);

			switch (u.getBalanceFactor()) {
			case 1:
				s.setBalanceFactor(-1);
				r.setBalanceFactor(0);
				break;
			case 0:
				s.setBalanceFactor(0);
				r.setBalanceFactor(0);
				break;
			case -1:
				s.setBalanceFactor(0);
				r.setBalanceFactor(1);
				break;

			// default:
			// System.err.println("ƽ�����Ӹ�ֵʧ�ܣ�");
			// break;
			}

			s = u;
		}
		s.setBalanceFactor(0);
		unBalanced.setBool(false);
		return s;
	}

	private Node RRotation(Node s, myBool unBalanced)// ����ת
	{
		Node u, r = s.getRightChild();
		if (r.getBalanceFactor() == -1)// RR��ת
		{
			s.setChild(r.getLeftChild(), 1);
			r.setChild(s, 0);
			s.setBalanceFactor(0);

			s = r;
		} else {// RL��ת
			u = r.getLeftChild();
			r.setChild(u.getRightChild(), 0);
			u.setChild(r, 1);
			s.setChild(u.getLeftChild(), 1);
			u.setChild(s, 0);

			switch (u.getBalanceFactor()) {
			case 1:
				s.setBalanceFactor(0);
				r.setBalanceFactor(-1);
				break;
			case 0:
				s.setBalanceFactor(0);
				r.setBalanceFactor(0);
				break;
			case -1:
				s.setBalanceFactor(1);
				r.setBalanceFactor(0);
				break;

			// default:
			// System.err.println("ƽ�����Ӹ�ֵʧ�ܣ�");
			// break;
			}
			s = u; // sָ����������
		}

		s.setBalanceFactor(0);
		unBalanced.setBool(false);

		return s;
	}

	@Override
	public JTree printTree() {
		// TODO Auto-generated method stub
		
		DefaultMutableTreeNode treeNode=insertMyJtreeNode(root);
		JTree tree = new JTree(treeNode);
		return tree;
	}
	
	private DefaultMutableTreeNode insertMyJtreeNode(Node insertNode)
	{
	
		DefaultMutableTreeNode jTreeNode=new DefaultMutableTreeNode(insertNode.getData()+"  "+insertNode.getId());
		
		if(insertNode.getRightChild()!=null)
		{
			jTreeNode.add(insertMyJtreeNode(insertNode.getRightChild()));
		}
		
		if(insertNode.getLeftChild()!=null)
		{
			jTreeNode.add(insertMyJtreeNode(insertNode.getLeftChild()));
		}
		
		return jTreeNode;
		
	}

	public AVLTree getMyNewAVlTree() {
		
		return myNewAVlTree;
	}

//	public void setMyNewAVlTree(AVLTree myNewAVlTree) {
//		this.myNewAVlTree = myNewAVlTree;
//	}

}
