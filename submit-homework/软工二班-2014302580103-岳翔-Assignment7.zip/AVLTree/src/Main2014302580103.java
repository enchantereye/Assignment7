import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JTree;

public class Main2014302580103 {
	
	private static AVLTree myAVLTree;
	private static JTree tree;

	public static void main(String[] args) throws IOException {

		myAVLTree = new AVLTree();
		//boolean flag = myAVLTree.isEmpty();
		//System.out.println("����ƽ�����Ƿ�Ϊ�գ�" + flag);

		Node node[] = new Node[17];

		for (int i = 0; i < 17; i++) {
			node[i] = new Node();
			node[i].setId(Data.getID(i));
			node[i].setData(Data.getData(i));
			myAVLTree.insert(node[i].getId(), node[i]);
			// Hint random = new Random().nextInt(50);
		}

		

		//flag = myAVLTree.isEmpty();
	//	System.out.println("����ƽ�����Ƿ�Ϊ�գ�" + flag);

		myAVLTree.preOrder();//ǰ�����
		
		Node getNode=myAVLTree.get(10);
		System.err.println("�ڵ���Ϣ:"+getNode.getId()+"  "+getNode.getData());
		
		Node getNode_2=myAVLTree.get(8);
		System.err.println("�ڵ���Ϣ:"+getNode_2.getId()+"  "+getNode_2.getData());

		JFrame frame = new JFrame();
	
		frame.setBounds(100, 100, 342, 445);
		frame.setLayout(null);

		JTextField deleteField = new JTextField();
		deleteField.setBounds(131, 370, 66, 21);
		frame.add(deleteField);
		deleteField.setVisible(true);
		deleteField.setColumns(10);
		
		JTextField insertIDField = new JTextField();
		insertIDField.setBounds(131, 340, 30, 21);
		frame.add(insertIDField);
		insertIDField.setVisible(true);
		insertIDField.setColumns(10);
		
		JTextField insertDataField = new JTextField();
		insertDataField.setBounds(170, 340, 66, 21);
		frame.add(insertDataField);
		insertDataField.setVisible(true);
		insertDataField.setColumns(10);
		
		

		JButton btn_insert = new JButton("����");
		btn_insert.setBounds(240, 340, 80, 23);
		frame.add(btn_insert);
		btn_insert.setVisible(true);
		
		btn_insert.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				tree.setVisible(false);
				
				Node newInsertNode= new Node();
				newInsertNode.setId(Integer.parseInt(insertIDField.getText()));
				newInsertNode.setData(insertDataField.getText());
				
				Data.setID(Data.getCurNotNullIndex(),Integer.parseInt(insertIDField.getText()) );
				Data.setData(Data.getCurNotNullIndex(), insertDataField.getText());
				
				myAVLTree.insert(newInsertNode.getId(), newInsertNode);
				
				tree=new JTree();
				tree=myAVLTree.printTree();
				tree.setBounds(0, 0, 326, 329);
				frame.add(tree);
				
				myAVLTree.preOrder();//ǰ�����
			}
		});
		
		JButton btn_delete = new JButton("ɾ��");
		btn_delete.setBounds(240, 370, 80, 23);
		frame.add(btn_delete);
		btn_delete.setVisible(true);
		
		
		btn_delete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				tree.setVisible(false);
				myAVLTree.delete(Integer.parseInt(deleteField.getText()));
				myAVLTree = myAVLTree.getMyNewAVlTree();
				
				tree=new JTree();
				tree=myAVLTree.printTree();
				tree.setBounds(0, 0, 326, 329);
				frame.add(tree);
				
				myAVLTree.preOrder();//ǰ�����
			}
		});
		
		JLabel label = new JLabel("������ɾ���Ľڵ㣺");
		label.setBounds(10, 373, 120, 15);
		frame.add(label);
		
		JLabel label_2 = new JLabel("���������Ľڵ㣺");
		label_2.setBounds(10, 343, 120, 15);
		frame.add(label_2);
		
		
		//this.setVisible(true);
	
		tree=new JTree();
		tree=myAVLTree.printTree();
		tree.setBounds(0, 0, 326, 329);
		frame.add(tree);
		
		frame.setVisible(true);

	}
}
