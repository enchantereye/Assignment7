
public class Node {
	private int id;//���
	private Object data;//����
	private Node parent;//��ĸ
	private Node[] children = new Node[2];//����
	//private Node leftChild=children[0];
	//private Node rightChild=children[1];
	private int lSubTreeHeight;//�������ĸ߶�
	private int rSubTreeHeight;//�������ĸ߶�
	private int balanceFactor;//ƽ������
	
	public Node()
	{
		children[0]=null;
		children[1]=null;
		id=0;
		data=null;
		parent=null;
		lSubTreeHeight=0;
		rSubTreeHeight=0;
		balanceFactor=0;
	}
	public void setId(int Id)
	{
		id=Id;
	}
	public int getId() {
		return id;
	}
	public Object getData() {
		return data;
	}
	public void setData(Object data) {
		this.data = data;
	}
	public Node getParent() {
		return parent;
	}
	public void setParent(Node parent) {
		this.parent = parent;
	}
	
	public Node getChild(int index){
		return children[index];
	}
	public Node[] getChildren() {
		return children;
	}
	public void setChildren(Node[] children) {
		this.children = children;
	}
	public void setChild(Node child, int id){
		this.children[id] = child;
	}
	public int getlSubTreeHeight() {
		//TODO calculate the left sub tree height
		return lSubTreeHeight;
	}
	public int getrSubTreeHeight() {
		//TODO calculate the right sub tree height
		return rSubTreeHeight;
	}
	public int getBalanceFactor() {
		//TODO calculate the balance factor
		return balanceFactor;
	}
	
	public void setBalanceFactor(int balanceFactor) {
		this.balanceFactor = balanceFactor;
	}
	
	public Node getLeftChild()
	{
		return children[0];
	}
	
	public Node getRightChild()
	{
		return children[1];
	}
	

}
