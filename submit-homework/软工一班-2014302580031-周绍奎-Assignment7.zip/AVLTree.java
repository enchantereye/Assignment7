import javax.swing.*;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.lang.*;
import java.awt.Rectangle;
import java.lang.Integer;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.lang.System;

public class AVLTree implements IAVLTree{
    private Node root;//avl树根

    public AVLTree() {
        root = null;
    }

    @Override
    public void insert(int id,Object data) {
        root = insert(id, root,data);
    }
    private Node insert(int id,Node t,Object data){
        if(t == null){
            t= new Node(id, null, null,data);
        }
        if(id<t.getId()) {
            Node m = insert(id, t.getChildren()[0],data);
            t.setChild(m, 0);//将id插入左子树中
            if( height( t.getChildren()[0] ) - height( t.getChildren()[1] ) == 2 )//打破平衡
                if( id< t.getChildren()[0].getId() )//LL型（左左型）
                    t = rotateLC(t);
                else   //LR型（左右型）
                    t = doubleLC(t);
        } else if( id>t.getId() ){

            Node m = insert(id, t.getChildren()[1],data);
            t.setChild( m,1);//将id插入右子树中
            if( height( t.getChildren()[1] ) - height( t.getChildren()[0] ) == 2 )//打破平衡
                if( id>t.getChildren()[1].getId() )//RR型（右右型）
                    t = rotateRC( t );
                else                           //RL型
                    t = doubleRC(t);
        }
        else {// 重复数据，什么也不做
        }
        t.height = Math.max( height( t.getChildren()[0] ), height( t.getChildren()[1] ) ) + 1;//更新高度
        return t;
    }


    //搜索（查找）
    @Override
    public Node get(int id) {
        Node t = root;
        while( t != null ) {
            if( id<t.getId() )
                t = t.getChildren()[0];
            else if( id<t.getId())
                t = t.getChildren()[1];
            else
                return t;
        }
        return null;
    }


    private int height( Node t ) {
        return t == null ? -1 : t.height;
    }
    public void delete(int id){

    }

    private Node rotateLC(Node t) {
        Node p = t.getChildren()[0];
        t.setChild(p.getChildren()[1],0);
        p.setChild(t,1);
        t.height = Math.max( height( t.getChildren()[0] ), height( t.getChildren()[1] ) ) + 1;
        p.height = Math.max( height( p.getChildren()[0] ), t.height ) + 1;
        return p;
    }

    private Node rotateRC(Node t) {
        Node p = t.getChildren()[1];
        t.setChild(p.getChildren()[0],1);
        p.setChild(t,0);
        t.height = Math.max( height( t.getChildren()[0] ), height( t.getChildren()[1] ) ) + 1;
        p.height = Math.max( height( p.getChildren()[1] ), t.height ) + 1;
        return p;
    }
    private Node doubleLC(Node t) {
        Node m = rotateRC(t.getChildren()[0]);
        t.setChild(m,0);
        return rotateLC(t);
    }
    private Node doubleRC(Node t) {
        Node m = rotateLC(t.getChildren()[1]);
        t.setChild(m,1);
        return rotateRC(t);
    }

    private DefaultMutableTreeNode printTree(Node t){
        if(t != null){
            DefaultMutableTreeNode DMTNode = new DefaultMutableTreeNode(t.getId());
            if(t.getChildren()[0]!=null){
                DMTNode.add(printTree(t.getChildren()[0]));
            }
            if(t.getChildren()[1]!=null){
                DMTNode.add(printTree(t.getChildren()[1]));
            }
            return DMTNode;
        }
        return null;
    }


    public JTree printTree() {
        DefaultMutableTreeNode RN = printTree(root);
        if(RN == null){
            RN = new DefaultMutableTreeNode("当前没有节点");
        }
        DefaultTreeModel DTM = new DefaultTreeModel(RN);
        return new JTree(DTM);
    }
    public static void main(String [] args)
    {
        final AVLTree tree = new AVLTree();
        tree.insert(1,"ant");
        tree.insert(2,"apple");
        tree.insert(3,"art");
        tree.insert(4,"baby");
        tree.insert(5,"banan");
        tree.insert(6,"car");
        tree.insert(7,"door");
        tree.insert(8,"dress");
        tree.insert(9,"frog");
        tree.insert(10, "love");
        tree.insert(11,"mint");
        tree.insert(12, "rice");
        tree.insert(13,"show");
        tree.insert(14, "table");
        tree.insert(15, "tree");
        tree.insert(16, "trouble");
        tree.insert(17, "window");
        JTree jt = tree.printTree();
        jt.setBounds(new Rectangle(0, 0, 400, 300));


        JButton getBtn;
        getBtn = new JButton("获取节点");
        getBtn.setBounds(new Rectangle(200, 20, 100, 30));
        final JTextArea inputArea = new JTextArea();
        inputArea.setBounds(20,20,150,30);
        final JTextField outField = new JTextField();
        outField.setBounds(20,60,280,60);
        JFrame frame = new JFrame();
        JScrollPane sp = new JScrollPane();
        sp.setBorder(null);
        sp.setBounds(new Rectangle(20, 150, 400, 300));
        sp.getViewport().add(jt);


        frame.setLayout(null);
        frame.setVisible(true);
        frame.setBounds(0, 0, 440, 500);
        frame.add(outField);
        frame.add(inputArea);
        frame.add(getBtn);
        frame.add(sp);

        getBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                String idstr = inputArea.getText();
                Node rs = tree.get(Integer.parseInt(idstr));
                outField.setText("Id: "+rs.getId()+" Data"+ rs.getData());
            }
        });

    }
}