import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.awt.event.ActionEvent;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.JSpinner;
import javax.swing.JTree;
import javax.swing.SwingConstants;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.DefaultMutableTreeNode;

public class Main extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
//					Main frame = new Main();
//					frame.setVisible(true);
				
//					tree.printTree();
					Main frame = new Main();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	

	/**
	 * Create the frame.
	 */
	public Main() {
		AVLTree tree=new AVLTree();
		Node node1=new Node();
		node1.setData("4");
		node1.setID(4);
		Node node2=new Node();
		node2.setData("2");
		node2.setID(2);

		Node node3=new Node();
		node3.setData("3");
		node3.setID(3);
		
		Node node5=new Node();
		node5.setData("5");
		node5.setID(5);
		
		Node node7=new Node();
		node7.setData("7");
		node7.setID(7);
		Node node8=new Node();
		node8.setData("8");
		node8.setID(8);
		Node node9=new Node();
		node9.setData("9");
		node9.setID(89);
		
		tree.insert(2, node2);
		tree.insert(4, node1);
		tree.insert(3, node3);
		tree.insert(5, node5);
		tree.insert(7, node7);
//		tree.insert(8, node8);
//		tree.insert(9, node9);
		tree.delete(4);
		Node node6=new Node();
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 365, 394);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(10, 10, 329, 272);
		contentPane.add(panel);
		panel.setLayout(null);

		JPanel panel2 = new JPanel();
//		contentPane.add(panel2);
//		AVLTree tree=new AVLTree();
		
		
		JPanel panel_1 = new JPanel();
		panel_1.setBounds(10, 292, 329, 54);
		contentPane.add(panel_1);
		panel_1.setLayout(null);
		
		JButton btnNewButton = new JButton("\u63D2\u5165\u65B0\u7ED3\u70B9");
		btnNewButton.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent arg0) {
				panel.setVisible(false);
				panel_1.setVisible(false);
				
				
				panel2.setVisible(true);
				panel2.setBounds(80, 58, 188, 196);
				contentPane.add(panel2);
				panel2.setLayout(null);
				
				JLabel lblNewLabel = new JLabel("ID:");
				lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
				lblNewLabel.setBounds(10, 51, 54, 26);
				panel2.add(lblNewLabel);
				
				//��ȡid
				JTextField textField = new JTextField();
				textField.setBounds(59, 54, 119, 21);
				panel2.add(textField);
				textField.setColumns(10);
				
				JLabel label = new JLabel("\u6570\u636E\uFF1A");
				label.setHorizontalAlignment(SwingConstants.CENTER);
				label.setBounds(10, 90, 54, 26);
				panel2.add(label);
				
				//��ȡ����
				JTextField textField_1 = new JTextField();
				textField_1.setColumns(10);
				textField_1.setBounds(59, 93, 119, 21);
				panel2.add(textField_1);
				
				JLabel lblNewLabel_1 = new JLabel("\u8BF7\u8F93\u5165\u8981\u63D2\u5165\u6811\u4E2D\u7684id\u548C\u6570\u636E");
				lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
				lblNewLabel_1.setBounds(10, 10, 168, 26);
				panel2.add(lblNewLabel_1);
				
				
				JButton btnNewButton = new JButton("\u786E\u8BA4");
				btnNewButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent arg0) {

						panel2.setVisible(false);
						panel.setVisible(true);
						panel_1.setVisible(true);
						int id=Integer.parseInt(textField.getText());
						Object data=textField_1.getText();
						node6.setID(id);
						node6.setData(data);
						tree.insert(id, node6);
						JTree t=tree.printTree();
						panel.add(t);
					}
				});
				btnNewButton.setBounds(54, 141, 85, 26);
				panel2.add(btnNewButton);

//				Insert point=new Insert();
//				point.setVisible(true);
//				Node newNode=new Node();
//				newNode.setData(point.getData());
//				tree.insert(point.getID(), newNode);

			}
		});
		btnNewButton.setBounds(0, 10, 99, 34);
		panel_1.add(btnNewButton);
		
		JButton button = new JButton("\u5220\u9664\u7ED3\u70B9");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				panel.setVisible(false);
				panel_1.setVisible(false);
				
				JPanel panel3 = new JPanel();
				panel3.setVisible(true);
				panel3.setLayout(null);
				panel3.setBounds(79, 64, 188, 196);
				contentPane.add(panel3);
				
				JLabel label = new JLabel("ID:");
				label.setHorizontalAlignment(SwingConstants.CENTER);
				label.setBounds(10, 81, 54, 26);
				panel3.add(label);
				
				JTextField textField = new JTextField();
				textField.setColumns(10);
				textField.setBounds(59, 84, 119, 21);
				panel3.add(textField);
				
				JLabel lblid = new JLabel("\u8BF7\u8F93\u5165\u8981\u5220\u9664\u6811\u4E2D\u7684id");
				lblid.setHorizontalAlignment(SwingConstants.CENTER);
				lblid.setBounds(10, 10, 168, 26);
				panel3.add(lblid);
				
				JButton button = new JButton("\u786E\u8BA4");
				button.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent arg0) {
						
						int id=Integer.parseInt(textField.getText());
						tree.delete(id);
						panel3.setVisible(false);
						Main frame=new Main();
						frame.setVisible(true);
					}
				});
				button.setBounds(54, 141, 85, 26);
				panel3.add(button);
			}
		});
		button.setBounds(115, 10, 99, 34);
		panel_1.add(button);
		
		JTree t=tree.printTree();
		panel.add(t);
		
		JButton button_1 = new JButton("\u6E05\u7A7A\u6811");
		button_1.setBounds(230, 10, 99, 34);
		panel_1.add(button_1);
	}


	


	
}
