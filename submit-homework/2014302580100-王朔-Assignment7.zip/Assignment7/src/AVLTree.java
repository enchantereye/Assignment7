import javax.swing.JTree;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;

public class AVLTree implements IAVLTree{
	public static  Node node;
	public  int id;
	public static  Node root;//���ڵ�
	public int size=0;
	public AVLTree()
	{
		root=null;
	}
	
	//���� ƽ������Ϊ-2
	public void rotateLeft(Node parent)
	{
		System.out.println("����"+parent.getData());
		if(parent!=null)
		{
			//ȡ���ڵ�ĸ��ڵ�
			Node p=parent.getParent();
			Node[] r=parent.getChildren();
			Node t=r[1];//�Һ���
			Node [] s=t.getChildren();
			r[1]=s[0];//�Һ��ӵ�������Ϊԭ���ڵ���Һ���
			//���parent���Һ��ӵ����Ӳ�Ϊ�� �Ͱ����ӵĸ��ڵ���Ϊparent
			if(s[0]!=null)
			{
				//parent�ĸ��ڵ���Ϊparent�Һ��ӵĸ��ڵ�
				r[1].setParent(parent);
			
			}
			//���parent�ĸ��ڵ�Ϊ�� �Ͱ��Һ��Ӹ�ֵ�����ڵ�
			if(parent.getParent()==null)
			{
				root=t;
				root.setParent(null);
			}else {
				Node [] pChild=p.getChildren();
				if(pChild[0]==parent)
				{
					pChild[0]=t;
				}else
				{
					pChild[1]=t;
				}
			}
		}
		parent.setBalanceFactor(0);
	}
	
	//����  ƽ������Ϊ+2
	public void rotateRight(Node parent)
	{
		System.out.println("����"+parent.getData());
		if(parent!=null)
		{
			//ȡ���ڵ�ĸ��ڵ�
			Node p=parent.getParent();
			Node[] r=parent.getChildren();
			Node t=r[0];//�Һ���
			Node [] s=t.getChildren();
			r[0]=s[1];//�Һ��ӵ�������Ϊԭ���ڵ���Һ���
			//���parent���Һ��ӵ����Ӳ�Ϊ�� �Ͱ����ӵĸ��ڵ���Ϊparent
			if(s[1]!=null)
			{
				//parent�ĸ��ڵ���Ϊparent�Һ��ӵĸ��ڵ�
				r[0].setParent(parent);
			}
			//���parent�ĸ��ڵ�Ϊ�� �Ͱ��Һ��Ӹ�ֵ�����ڵ�
			if(parent.getParent()==null)
			{
				root=t;
				root.setParent(null);
			}else {
				Node [] pChild=p.getChildren();
				if(pChild[0]==parent)
				{
					pChild[0]=t;
				}else
				{
					pChild[1]=t;
				}
			}
		}
	}
	
	/*��ȡ��������������Ϊ���ڵ� ��ԭ�������Ϊ�¸�������*/
	//������������  ƽ������Ϊ-2 ��һ��ƽ������Ϊ+1
	public void rotateLR(Node parent)
	{
		System.out.println("˫����������ң����ڵ��ǣ� "+parent.toString());
		Node p=parent.getParent();
//		Node [] pChild=p.getChildren();
		if(parent!=null)
		{
			Node par=parent;
			Node [] r=par.getChildren();
			Node t=r[1];//right
			
			Node[] s=t.getChildren();
			Node u=s[0];// parent right left
			Node [] sChild=u.getChildren();
			r[1]=sChild[0];//parent right left left
			sChild[0]=par;
			sChild[0].setParent(u);
//			System.out.println(sChild[0].toString());
			
			s[0]=sChild[1];//parent right left right
			sChild[1]=t;
			sChild[1].setParent(u);
//			u.setParent(p);

			if(p==null)
			{
				root=u;
				root.setParent(null);
			}else {
				Node [] pChild=p.getChildren();
				if(pChild[0]==parent)
				{
					pChild[0]=u;
					pChild[0].setParent(p);
				}else
				{
					pChild[1]=u;
					pChild[1].setParent(p);
				}
			}
			System.out.println("�����󸸽ڵ��ǣ�"+u.toString());
		}
//		System.out.println("�����󸸽ڵ��ǣ�"+u.toString());
	}
	public void rotateRL(Node parent)
	{
		System.out.println("˫�������Һ���");
		Node p=parent.getParent();
//		Node [] pChild=p.getChildren();
		if(parent!=null)
		{
			Node [] r=parent.getChildren();
			Node t=r[0];//left
			
			Node[] s=t.getChildren();
			Node u=s[1];// parent l r
			Node [] sChild=u.getChildren();
			r[1]=sChild[1];//parent l r r
			sChild[1]=parent;
//			r[1].setParent(u);
			s[1]=sChild[0];//parent l r l
			sChild[0]=t;
//			s[1].setParent(u);
//			u.setParent(p);

			if(parent.getParent()==null)
			{
				root=u;
				root.setParent(null);
			}else {
				Node [] pChild=p.getChildren();
				if(pChild[0]==parent)
				{
					pChild[0]=u;
					pChild[0].setParent(p);
				}else
				{
					pChild[1]=u;
					pChild[1].setParent(p);
				}
			}
		}
	}


	@Override
	public Node get(int id) {
		// TODO Auto-generated method stub
		Node parent=root;
		System.out.println("ɾ���Ľڵ��ǣ� "+id);
		while(id!=parent.getId()&&parent!=null)
		{
			Node[] child=parent.getChildren();
			if(id>parent.getId())
			{
				parent=child[1];
			}else
			{
				parent=child[0];
			}
		}
		return parent;

	}



	@Override
	public void insert(int id, Node newNode) {
		// TODO Auto-generated method stub
		System.out.println("insert��id�ǣ�"+id);
		//������ڵ��ǿ� ��ֱ�Ӳ�����ڵ�
		if(root==null)
		{
			root=newNode;
			size=1;
		}
		else{
		Node r=root;
		Node parent;
		//���ҿ��Բ����id
		do
		{
			parent=r;
			Node [] s=r.getChildren();
			if(id<r.getId())
			{
				r=s[0];
			}else if(id>r.getId()){
				r=s[1];
			}else
			{
				System.out.println("�����id�Ѿ����ڣ�");
			}
		}while(r!=null);
		Node [] child=parent.getChildren();
		if(id>parent.getId())
		{
//			Node [] child=parent.getChildren();
			child[1]=newNode;
			parent.setChild(newNode, 1);
			newNode.setParent(parent);
			parent.setBalanceFactor((parent.getBalanceFactor()-1));
			System.out.println(parent.getBalanceFactor());
		}else
		{
			child[0]=newNode;
			parent.setChild(newNode, 0);
			newNode.setParent(parent);
			parent.setBalanceFactor((parent.getBalanceFactor()+1));
			System.out.println(parent.getBalanceFactor());
		}
		while(parent!=null)
		{
			System.out.println(parent.toString()+"ƽ�������ǣ� "+parent.getBalanceFactor());
			Node p=parent.getParent();
			if(p!=null)
			{
				Node [] pChild=p.getChildren();
				if(pChild[0]==parent)
				{
					p.setBalanceFactor(p.getBalanceFactor()+1);
				}else
				{
					p.setBalanceFactor(p.getBalanceFactor()-1);
				}


				
				if(p.getBalanceFactor()==0)break;
				if(p.getBalanceFactor()==-2)
				{
					if(parent.getBalanceFactor()==-1)
					{
						rotateLeft(p);	
					}else
					{
						rotateLR(p);
					}
				}else if(p.getBalanceFactor()==2)
				{
					if(parent.getBalanceFactor()==1)
					{
						rotateRight(p);
					}
					else
					{
						rotateRL(p);
					}
				}
			}
			parent=parent.getParent();
		}
		size++;
		}
	}

	@Override
	public void delete(int id) {
		// TODO Auto-generated method stub
		Node parent=get(id);
		size--;
		
		Node [] pChild=parent.getChildren();
		Node p=parent.getParent();
//		Node [] child=p.getChildren();
		
		if(pChild[1]!=null)
		{
			Node [] pc=pChild[1].getChildren();
			Node replace=(pc[0]!=null?pc[0]:pChild[1]);
			if(replace==pc[0])
			{
				while(pc[0]!=null)
				{
					Node [] pcd=pc[0].getChildren();
					if(pcd[0]!=null)
					{
						pc[0]=pcd[0];
					}else
					{
						pc[0]=pcd[1];
						pc[0].setBalanceFactor(pc[0].getBalanceFactor()+1);
						fixAfterDeletion(pc[0]);
					}
				}
			}else
			{
				replace.setBalanceFactor(parent.getBalanceFactor()+1);
			}
			
			if(parent.getParent()==null)
			{
				root=replace;
				root.setParent(null);
				fixAfterDeletion(replace);
			}else
			{
				Node [] child=p.getChildren();
				if(child[0]==parent)
				{
					child[0]=replace;

				}else
				{
					child[1]=replace;
				}

				fixAfterDeletion(replace);
				pChild[0]=pChild[1]=parent=null;
			}
		}
		else if(pChild[0]!=null)
		{
			if(p!=null)
			{
				Node [] child=p.getChildren();
				
				pChild[0].setParent(parent.getParent());
				pChild[0].setBalanceFactor(parent.getBalanceFactor()-1);
				fixAfterDeletion(pChild[0]);
				if(child[0]==parent)
				{
					child[0]=pChild[0];
				}else
				{
					child[1]=pChild[0];
				}
			}else
			{
				root=pChild[0];
				root.setParent(null);
			}
			pChild[0]=pChild[1]=parent=null;
			
		}
		else
		{
			if(p!=null)
			{
				Node [] child=p.getChildren();
				
				pChild[0].setParent(parent.getParent());
				pChild[0].setBalanceFactor(parent.getBalanceFactor()-1);
				fixAfterDeletion(pChild[0]);
				if(child[0]==parent)
				{
					child[0]=pChild[0];
				}else
				{
					child[1]=pChild[0];
				}
			}else
			{
				root=pChild[0];
				root.setParent(null);
			}
			pChild[0]=pChild[1]=parent=null;
		}
		
	}

	private void fixAfterDeletion(Node parent) {
		// TODO Auto-generated method stub
		while(parent!=null)
		{
			Node p=parent.getParent();
//			if(parent.getBalanceFactor()==1||parent.getBalanceFactor()==-1)break;
//			else if(parent.getBalanceFactor()==-2)
//			{
//				
//			}
				
			if(p!=null)
			{
				Node [] pChild=p.getChildren();
				p.setBalanceFactor(p.getBalanceFactor()+(parent==pChild[1]?1:-1));
				if(p.getBalanceFactor()==-1)break;
				if(p.getBalanceFactor()==-2)
				{
					if(parent.getBalanceFactor()==0)
					{
						rotateLeft(p);	
					}else
					{
						rotateLR(p);
					}
				}else if(p.getBalanceFactor()==2)
				{
					if(parent.getBalanceFactor()==1)
					{
						rotateRight(p);
					}
					else
					{
						rotateRL(p);
					}
				}
			}
			parent=parent.getParent();
		}
	}

	@Override
	public JTree printTree() {
		// TODO Auto-generated method stub
//		JTree tree=new JTree();
		Node node=root;
		System.out.println("���ڵ��ǣ�"+node.toString());
		DefaultMutableTreeNode n=new DefaultMutableTreeNode(node);
		printTree(n,node);
	
		
		JTree tree=new JTree(n);
		tree.setToolTipText("");
		tree.setBounds(45, 0, 228, 262);
		 tree.addTreeSelectionListener(new TreeSelectionListener() {
			 
	            @Override
	            public void valueChanged(TreeSelectionEvent e) {
	                DefaultMutableTreeNode node = (DefaultMutableTreeNode) tree
	                        .getLastSelectedPathComponent();
	 
	                if (node == null)
	                    return;
	 
	            }
	        });
		return tree;
	}


	private void printTree(DefaultMutableTreeNode n, Node root) {
		// TODO Auto-generated method stub
		Node node=root;
		if(node!=null)
		{
		Node [] r=node.getChildren();


			if(r[0]!=null)
			{
				Node [] s=r[0].getChildren();
				DefaultMutableTreeNode node_1;
				node_1 = new DefaultMutableTreeNode(r[0]);
				n.add(node_1);
				printTree(node_1,r[0]);
//				if(s[0]!=null)
//				{
//					System.out.println(r[0].toString()+" ���ӽڵ���: "+s[0].toString());
//					r[0]=s[0];
//					node_1.add(new DefaultMutableTreeNode(s[0]));
//					
//				}else if(s[1]!=null)
//				{
//
//					System.out.println(r[1].toString()+" ���ӽڵ���: "+s[1].toString());
//					r[1]=s[1];
//					node_1.add(new DefaultMutableTreeNode(s[1]));
//				}
//				else
//				{
//					r[0]=null;
//				}
			}
			if(r[1]!=null)
			{
				Node [] t=r[1].getChildren();
				DefaultMutableTreeNode node_1;
				node_1 = new DefaultMutableTreeNode(r[1]);
				n.add(node_1);
//				if(t[0]!=null||t[1]!=null)
//				{
//				node_1 = new DefaultMutableTreeNode(r[1]);
//				n.add(node_1);
//				}
//				if(t[0]!=null)
//				{
//					System.out.println(r[1].toString()+" ���ӽڵ���: "+t[0].toString());
//					r[0]=t[0];
//					node_1.add(new DefaultMutableTreeNode(t[0]));
//					System.out.println(node_1.toString());
//				}else if(t[1]!=null)
//				{
//					System.out.println(r[1].toString()+" ���ӽڵ���: "+t[1].toString());
//					r[1]=t[1];
//					node_1.add(new DefaultMutableTreeNode(r[1]));
//					System.out.println(node_1.toString());
//				}
//				else
//				{
//					r[1]=null;
//				}
				printTree(node_1, r[1]);
			}
		
		}
	}

	 

}
