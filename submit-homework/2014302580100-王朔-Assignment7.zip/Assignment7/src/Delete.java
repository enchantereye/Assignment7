import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Delete extends JFrame {

	private JPanel contentPane;
	private JTextField textField;


	/**
	 * Create the frame.
	 */
	public Delete() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 365, 394);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setLayout(null);
		panel.setBounds(79, 64, 188, 196);
		contentPane.add(panel);
		
		JLabel label = new JLabel("ID:");
		label.setHorizontalAlignment(SwingConstants.CENTER);
		label.setBounds(10, 81, 54, 26);
		panel.add(label);
		
		textField = new JTextField();
		textField.setColumns(10);
		textField.setBounds(59, 84, 119, 21);
		panel.add(textField);
		
		JLabel lblid = new JLabel("\u8BF7\u8F93\u5165\u8981\u5220\u9664\u6811\u4E2D\u7684id");
		lblid.setHorizontalAlignment(SwingConstants.CENTER);
		lblid.setBounds(10, 10, 168, 26);
		panel.add(lblid);
		
		JButton button = new JButton("\u786E\u8BA4");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				int id=Integer.parseInt(textField.getText());
				AVLTree tree=new AVLTree();
				tree.delete(id);
				tree.printTree();
				dispose();
				Main frame=new Main();
				frame.setVisible(true);
			}
		});
		button.setBounds(54, 141, 85, 26);
		panel.add(button);
	}
}
