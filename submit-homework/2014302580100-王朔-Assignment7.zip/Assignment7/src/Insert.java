import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JTree;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Insert extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private int id;
	private Object data;


	/**
	 * Create the frame.
	 */
	public Insert() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 365, 394);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(80, 58, 188, 196);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("ID:");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(10, 51, 54, 26);
		panel.add(lblNewLabel);
		
		//��ȡid
		textField = new JTextField();
		textField.setBounds(59, 54, 119, 21);
		panel.add(textField);
		textField.setColumns(10);
		
		JLabel label = new JLabel("\u6570\u636E\uFF1A");
		label.setHorizontalAlignment(SwingConstants.CENTER);
		label.setBounds(10, 90, 54, 26);
		panel.add(label);
		
		//��ȡ����
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(59, 93, 119, 21);
		panel.add(textField_1);
		
		JLabel lblNewLabel_1 = new JLabel("\u8BF7\u8F93\u5165\u8981\u63D2\u5165\u6811\u4E2D\u7684id\u548C\u6570\u636E");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setBounds(10, 10, 168, 26);
		panel.add(lblNewLabel_1);
		
		
		JButton btnNewButton = new JButton("\u786E\u8BA4");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				dispose();
				Main mainframe=new Main();
				id=Integer.parseInt(textField.getText());
				data=textField_1.getText();
				mainframe.setVisible(true);
			}
		});
		btnNewButton.setBounds(54, 141, 85, 26);
		panel.add(btnNewButton);
	}


	public int getID() {
		// TODO Auto-generated method stub
		return Integer.parseInt(textField.getText());
	}

	public void setID(int id)
	{
		this.id=id;
	}


	public Object getData() {
		// TODO Auto-generated method stub
		return textField_1.getText();
	}
	public void setData(Object data)
	{
		this.data=data;
	}


}
