import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTree;
import javax.swing.event.CellEditorListener;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.tree.DefaultMutableTreeNode;

public class GetData {
	private static AVLTree at = new AVLTree();
	private static String selected;
	private static JTree tree;

	public static void main(String args[]) throws IOException{
		//���Ƚ����ݵ���AVLTree��
		inputData();
		System.out.println("�������ݲ���������ϣ�");
		JFrame frame = new JFrame();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		//����
		/**
		Node newNode = new Node();
		newNode.setId(19);
		newNode.setData("baozi");
		at.insert(newNode);
		*/
		
		//�õ�
		for(int i = 1; i<18;i++){
			Node getNode = at.get(i);
			if(getNode!=null)
				System.out.println("�õ���"+i+"��������Ϊ��"+getNode.getData());
		}
		
		//ɾ��
		System.out.println("ɾ��idΪ4�Ľڵ�");
		at.delete(4);
		
		tree = at.printTree();
		tree.setVisible(true);
		tree.setBounds(10,10,400,400);
		frame.getContentPane().add(tree);
		
		tree.addTreeSelectionListener(new TreeSelectionListener() {
			@Override
			public void valueChanged(TreeSelectionEvent e) {
				// TODO Auto-generated method stub
				DefaultMutableTreeNode node = (DefaultMutableTreeNode) tree.getLastSelectedPathComponent();
                if (node == null)
                    return;
 
                Object object = node.getUserObject();
                selected = (String) object;
                System.out.println("��ѡ���ˣ�" + selected);
			}
        });
	/**
		JButton delete = new JButton("ɾ��");
		delete.setBounds(300,20,70,30);
		delete.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				//System.out.println(selected);
				String[] id2 = selected.trim().split("[a-zA-Z_]+");
				//System.out.println(id2);
				int id = Integer.parseInt(id2[0]);
				System.out.println(id);
				at.delete(id);
				
				tree.setVisible(false);
				//frame.getContentPane().remove(tree);
				tree.updateUI();
				tree = at.printTree();
				tree.setVisible(true);
				//frame.getContentPane().add(tree);
				
			}
			
		});
		frame.getContentPane().add(delete);
	*/
		
		frame.setBounds(300,200,500,500);
		frame.setVisible(true);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		//insertʵ��
		/**
		Node newNode = new Node();
		newNode.setId(19);
		newNode.setData("baozi");
		*/
		

		
	}
	public static void inputData() throws IOException{
		File file = new File("tree_Data.dat");
		if(!file.exists()||file.isDirectory())
			throw new FileNotFoundException();
		BufferedReader br = new BufferedReader(new FileReader(file));
		StringBuffer sb = new StringBuffer();
		String dt = null;
		while((dt = br.readLine())!=null){
			at.insert(filter(dt));
		}
	}
	private static Node filter(String dt){
		//System.out.println(dt);
		String[] data = dt.split("[\\#]+");
		//System.out.println(data[1]);
		Node node = new Node();
		node.setData(data[0]);
		node.setId(Integer.parseInt(data[1]));
		return node;
	}
}
