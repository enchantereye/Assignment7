import java.util.ArrayList;

import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.TreeNode;


public class AVLTree implements IAVLTree{
	//������̬��
	private Node root;
	
	//�ҵ�idֵ�Ľ��
	public Node get(int id){
		Node a = root;
		while(a!= null && a.getId() != id){
			if(id<a.getId()) a = a.getChildren()[0];
			if(id>a.getId()) a = a.getChildren()[1];
		}
		if(a == null){
			System.out.println("�����������");
			return null;
		}
		else return a;
	}
	//����
	@Override
	public void insert(Node newNode) {
		// TODO Auto-generated method stub
		Node p = root; Node q = null;
		int id = newNode.getId();
		while(p != null){
			q = p;
			//System.out.println("�Ƚ�ID"+p.getId());
			if(id<p.getId()) p = p.getChildren()[0];
			else if(id>p.getId()) p = p.getChildren()[1];
			else return;
		}
		p = newNode;
		if(root == null){ 
			System.out.println("������ڵ�");
			root = p;
			return;
		}
		else if(p.getId()>q.getId()){
			System.out.println("����"+q.getData().toString()+"���ӽڵ�:" + p.getData());
			
			q.setChild(p, 1);
			p.setParent(q);
		}
		else {q.setChild(p, 0);p.setParent(q);}
		//System.out.println(p.getData().toString()+q.getData().toString());
		//System.out.println(q.getData());
		//if(q.getChildren()[1] !=null ) System.out.println("����ɹ�"+q.getChildren()[1].getData());
		while(p != null){
			//System.out.println(p.getData().toString());
			System.out.println(p.getData().toString()+"���������߶ȣ�"+p.getrSubTreeHeight());
			System.out.println(p.getData().toString()+"���������߶ȣ�"+p.getlSubTreeHeight());
			System.out.println(p.getData().toString()+"��ƽ������Ϊ��"+p.getBalanceFactor());
			if(p.getBalanceFactor() == 2){ 
				System.out.println("���ڽڵ�"+p.getData().toString()+"����");
				LRotation(p);
				break;
			}
			else if(p.getBalanceFactor() == -2){ 
				System.out.println("���ڽڵ�"+p.getData().toString()+"����");
				RRotation(p);
				break;
			}
			//System.out.println(p.getData());
			p = p.getParent();
			//System.out.println("����");
		}
	}
	//ɾ��
	@Override
	public void delete(int id) {
		// TODO Auto-generated method stub
		Node n = get(id);
		Node p;
		if(n == null) {System.out.println("no this node!"); return;}
		else{
			p = n.getParent();
			if(n.getChildren()[0]!=null&&n.getChildren()[1]!=null){
				Node s = n.getChildren()[1];
				Node r = n;
				while(s.getChildren()[0]!=null){
					r = s; s = s.getChildren()[0];
				}
				n.setData(s.getData());
				n.setId(s.getId());
				//System.out.println(n.getData().toString()+n.getId());
				r.setChild(s.getChildren()[1],0);
				
				if(r.getChildren()[0]!=null) System.out.println(r.getChildren()[0].getData().toString()+r.getChildren()[0].getId());
				if(s.getChildren()[1]!=null) s.getChildren()[1].setParent(r);
			}
			else if(n.getChildren()[0]!=null){
				n.getChildren()[0].setParent(p);
				if(n.getId()>p.getId())
					p.setChild(n.getChildren()[0], 1);
				else p.setChild(n.getChildren()[0],0);
			}
		   else if(n.getChildren()[1]!=null){
					n.getChildren()[1].setParent(p);
					if(n.getId()>p.getId())
						p.setChild(n.getChildren()[1], 1);
					else p.setChild(n.getChildren()[1],0);
			}
			else{
				if(n.getId()<p.getId()) p.setChild(null, 0);
				else p.setChild(null, 1);
			}
		}
		if(id<p.getId()&&p.getChildren()[0].getId()!= id) 	System.out.println("ɾ���ɹ�");
		else if(id>p.getId()&&p.getChildren()[1].getId()!= id)  System.out.println("ɾ���ɹ�");
		else System.out.println("ɾ��ʧ��");
		while(p != null){
			if(p.getBalanceFactor() == 2) LRotation(p);
			else if(p.getBalanceFactor() == -2) RRotation(p);
			p = p.getParent();
		}
	}

	private static DefaultMutableTreeNode top;
	public JTree printTree() {
		// TODO Auto-generated method stub
		top = new DefaultMutableTreeNode(this.root.getId() + this.root.getData().toString());
		Node node = root;
		helpPrintTree(node,top);
		JTree jt = new JTree(top);
		return jt;
	}
	private static void helpPrintTree(Node node,DefaultMutableTreeNode nod){
		if(node.getChildren() == null) return;
		else
		{
			if(node.getChildren()[0]!=null){
				DefaultMutableTreeNode nod1 = new DefaultMutableTreeNode(node.getChildren()[0].getId() + node.getChildren()[0].getData().toString());
				nod.add(nod1);
				helpPrintTree(node.getChildren()[0],nod1);
			}
			if(node.getChildren()[1]!=null){ 
				DefaultMutableTreeNode nod2 = new DefaultMutableTreeNode(node.getChildren()[1].getId() + node.getChildren()[1].getData().toString());
				nod.add(nod2);
				helpPrintTree(node.getChildren()[1],nod2);
			}
		}
	}
	//ƽ�����������
	private void LRotation(Node a){
		Node b = a.getChildren()[0];
		Node c,d,e;
		
		if(b.getBalanceFactor() == -1){
			a.setChild(b.getChildren()[1], 0);
			b.setChild(a, 1);
			
			b.setParent(a.getParent());
			if(a.getParent() == null) root = b;
			else a.getParent().setChild(b, 0);
			a.setParent(b);
			//if(a.getParent()!=null) b.setParent(a.getParent());
			//else{ root = b; System.out.println("������Ŷ");}
			//a.setParent(b);
			//System.out.println(b.getChildren()[0].getData().toString() + b.getChildren()[0].getId());
			//System.out.println(a.getParent().getData().toString()+a.getParent().getId());
			//System.out.println(b.getChildren()[1].getData().toString()+b.getChildren()[1].getId());
			System.out.println("�ɹ�");
		}
		else{
			c = b.getChildren()[1];
			d = c.getChildren()[0];
			e = c.getChildren()[1];
			
			b.setChild(d, 1);
			d.setParent(b);
			
			c.setParent(a.getParent());
			if(a.getParent() == null) root = c;
			else a.getParent().setChild(c, 0);
			b.setParent(c);
			a.setParent(c);
			e.setParent(a);
			
			c.setChild(b, 0);
			c.setChild(a, 1);
			
			a.setChild(e, 0);
		}
		System.out.println("���ڽڵ��ƽ������Ϊ��"+a.getBalanceFactor());
	}
	private void RRotation(Node a){
		Node b = a.getChildren()[1];
		Node c,d,e;
		
		if(b.getBalanceFactor() == -1){
			a.setChild(b.getChildren()[0], 1);
			b.setChild(a, 0);
			
			b.setParent(a.getParent());
			if(a.getParent() == null) root = b;
			else a.getParent().setChild(b, 1);
			a.setParent(b);
			//if(a.getParent()!=null) b.setParent(a.getParent());
			//else{ root = b; System.out.println("������Ŷ");}
			//a.setParent(b);
			//System.out.println(b.getChildren()[0].getData().toString() + b.getChildren()[0].getId());
			//System.out.println(a.getParent().getData().toString()+a.getParent().getId());
			//System.out.println(b.getChildren()[1].getData().toString()+b.getChildren()[1].getId());
			//if(b.getParent()!=null) System.out.println(b.getParent().getChildren()[1].getData().toString());
			System.out.println("�ɹ�");
		}
		else{
			c = b.getChildren()[0];
			d = c.getChildren()[1];
			e = c.getChildren()[0];
			
			b.setChild(d, 0);
			d.setParent(b);
			
			c.setParent(a.getParent());
			if(a.getParent() == null) root = c;
			else a.getParent().setChild(c, 1);			
			b.setParent(c);
			a.setParent(c);
			e.setParent(a);
			
			c.setChild(b, 1);
			c.setChild(a, 0);
			
			a.setChild(e, 1);
		}
		System.out.println("���ڽڵ��ƽ������Ϊ��"+a.getBalanceFactor());
	}
}
