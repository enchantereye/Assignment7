import java.lang.Math;
public class Node {
	private int id;
	private Object data;
	private Node parent;
	private Node[] children = new Node[2];
	private int lSubTreeHeight;					//�������߶�
	private int rSubTreeHeight;					//�������߶�
	private int balanceFactor;					//ƽ������
	//�õ�����ֵ
	public int getId() {
		return id;
	}
	public void setId(int id){
		this.id = id;
	}
	public Object getData() {
		return data;
	}
	public void setData(Object data) {
		this.data = data;
	}
	public Node getParent() {
		return parent;
	}
	public void setParent(Node parent) {
		this.parent = parent;
	}
	public Node[] getChildren() {
		return children;
	}
	public void setChildren(Node[] children) {
		this.children = children;
	}
	public void setChild(Node child, int id){
		this.children[id] = child; 
	}
	
	//�õ����ĸ߶�
	private static int helpGetSubTreeHeight(Node n) {
		if(n == null){
			return 0;
		}
		//System.out.println("�õ�����ʱ"+n.getData().toString());
		if(n.getChildren() == null) return 1;
		else {
			if(n.getChildren()[0] == null) return helpGetSubTreeHeight(n.getChildren()[1])+1;
			if(n.getChildren()[1] == null) return helpGetSubTreeHeight(n.getChildren()[0])+1;
			else return Math.max(helpGetSubTreeHeight(n.getChildren()[1])+1,helpGetSubTreeHeight(n.getChildren()[0])+1);
		}
	}
	public int getlSubTreeHeight() {
		//TODO calculate the left sub tree height
		this.setlSubTreeHeight();
		return lSubTreeHeight;
	}
	private void setlSubTreeHeight() {
		this.lSubTreeHeight = helpGetSubTreeHeight(this.getChildren()[0]);
	}
	public int getrSubTreeHeight() {
		//TODO calculate the right sub tree height
		this.setrSubTreeHeight();
		return rSubTreeHeight; 
	}	
	public void setrSubTreeHeight() {
		this.rSubTreeHeight = helpGetSubTreeHeight(this.getChildren()[1]);
	}
	//�õ�ƽ������
	public int getBalanceFactor() {
		//TODO calculate the balance factor
		balanceFactor = getlSubTreeHeight() - getrSubTreeHeight();
		return balanceFactor;
	}
}
