import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.JTree;
import javax.swing.event.CellEditorListener;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.tree.DefaultMutableTreeNode;

import java.lang.NumberFormatException;

public class GetData {
	private static AVLTree at = new AVLTree();
	private static String selected;
	private static JTree tree;
	
	private static Node filter(String dt){
		//System.out.println(dt);
		String[] data = dt.split("[\\#]+");
		//System.out.println(data[1]);
		Node node = new Node();
		node.setData(data[0]);
		node.setId(Integer.parseInt(data[1]));
		return node;
	}
	
	public static void inputData() throws IOException{
		File file = new File("tree_Data.dat");
		if(!file.exists()||file.isDirectory())
			throw new FileNotFoundException();
		BufferedReader br = new BufferedReader(new FileReader(file));
		StringBuffer sb = new StringBuffer();
		String dt = null;
		while((dt = br.readLine())!=null){
			at.insert(filter(dt));
		}
	}

	public static void main(String args[]) throws IOException{
		//���Ƚ����ݵ���AVLTree��
		inputData();
		System.out.println("�������ݲ���������ϣ�");
		JFrame frame = new JFrame();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		//����
		/**
		Node newNode = new Node();
		newNode.setId(19);
		newNode.setData("baozi");
		at.insert(newNode);
		*/
		/**
		//�õ�
		for(int i = 1; i<18;i++){
			Node getNode = at.get(i);
			if(getNode!=null)
				System.out.println("�õ���"+i+"��������Ϊ��"+getNode.getData());
		}
		
		//ɾ��
		System.out.println("ɾ��idΪ4�Ľڵ�");
		at.delete(4);
		**/
		tree = at.printTree();
		tree.setVisible(true);
		tree.setBounds(10,10,300,400);
		frame.getContentPane().add(tree);
		
		tree.addTreeSelectionListener(new TreeSelectionListener() {
			@Override
			public void valueChanged(TreeSelectionEvent e) {
				// TODO Auto-generated method stub
				DefaultMutableTreeNode node = (DefaultMutableTreeNode) tree.getLastSelectedPathComponent();
                if (node == null)
                    return;
 
                Object object = node.getUserObject();
                selected = (String) object;
                System.out.println("��ѡ���ˣ�" + selected);
			}
        });
		//��ʾ��ǩ
		JLabel label = new JLabel();
		label.setBounds(320,370,100,30);
		frame.getContentPane().add(label);
		
		JButton delete = new JButton("ɾ��");
		delete.setBounds(320,20,100,30);
		frame.getContentPane().add(delete);
		
		delete.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				//System.out.println(selected);
				String[] id2 = selected.trim().split("[a-zA-Z_]+");
				//System.out.println(id2);
				int id = Integer.parseInt(id2[0]);
				//System.out.println(id);
				boolean ifDelete = at.delete(id);
				
				if(ifDelete == true){
					tree.setVisible(false);
					frame.getContentPane().remove(tree);
				
					//tree.updateUI();
					tree = at.printTree();
					tree.setBounds(10,10,300,400);
					tree.setVisible(true);
					tree.addTreeSelectionListener(new TreeSelectionListener() {
						@Override
						public void valueChanged(TreeSelectionEvent e) {
							// TODO Auto-generated method stub
							DefaultMutableTreeNode node = (DefaultMutableTreeNode) tree.getLastSelectedPathComponent();
			                if (node == null)
			                    return;
			 
			                Object object = node.getUserObject();
			                selected = (String) object;
			                System.out.println("��ѡ���ˣ�" + selected);
						}
			        });
					
					frame.getContentPane().add(tree);
					label.setText("ɾ���ɹ�");
				}
				else label.setText("�����ڸõ㣡");
			}
			
		});
		
		JLabel idl = new JLabel("����ڵ�id:");
		idl.setBounds(320,50,100,30);
		frame.getContentPane().add(idl);
		
		JTextField id = new JTextField();
		id.setBounds(320,90,100,30);
		id.setVisible(true);
		id.setEditable(true);
		frame.getContentPane().add(id);
		
		JLabel datal = new JLabel("����ڵ�dataֵ:");
		datal.setBounds(320,130,100,30);
		frame.getContentPane().add(datal);
		
		JTextField data = new JTextField();
		data.setBounds(320,170,100,30);
		data.setVisible(true);
		data.setEditable(true);
		frame.getContentPane().add(data);
		
		JButton insert = new JButton("����");
		insert.setBounds(320,210,100,30);
		insert.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent e) {
				try{
					Node newNode = new Node();
					newNode.setData(data.getText());
					newNode.setId(Integer.parseInt(id.getText()));
					if(at.get(newNode.getId()) == null){
						at.insert(newNode);
				
						tree.setVisible(false);
						frame.getContentPane().remove(tree);
				
						//tree.updateUI();
						tree = at.printTree();
						tree.setBounds(10,10,300,400);
						tree.setVisible(true);
						frame.getContentPane().add(tree);
						label.setText("����ɹ���");
					}
					else label.setText("����ʧ�ܣ�");
				}catch(NumberFormatException e1){
					label.setText("��ֵ�������");
				}
			}
		});
		
		JLabel getl = new JLabel("�������õĽڵ��idֵ��");
		getl.setBounds(320,250,180,30);
		frame.getContentPane().add(getl);
		
		JTextField get = new JTextField();
		get.setBounds(320,290,100,30);
		frame.getContentPane().add(get);
		
		JButton getButton = new JButton("��ȡ");
		getButton.setBounds(320,330,100,30);
		getButton.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent e) {
				try{
					Node n = at.get(Integer.parseInt(get.getText()));
					if(n != null) label.setText(n.getData().toString());
					else label.setText("����������㣡");
				}catch(NumberFormatException e1){
					label.setText("��ֵ�������");
				}
			}
			
		});
		
		frame.getContentPane().add(getButton);
		
		frame.getContentPane().add(delete);
		frame.getContentPane().add(insert);
		
		frame.setBounds(300,200,500,500);
		frame.setVisible(true);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		//insertʵ��
		/**
		Node newNode = new Node();
		newNode.setId(19);
		newNode.setData("baozi");
		*/
		

		
	}
}
