import javax.swing.*;


public class main {
	public static void main(String[] args) {
	Object ob1 = new String("ant");
	Node a = new Node(1,ob1);
	Object ob2 = new String("apple");
	Node b = new Node(2,ob2);
	Object ob3 = new String("art");
	Node c = new Node(3,ob3);
	Object ob4 = new String("baby");
	Node d = new Node(4,ob4);
	Object ob5 = new String("banana");
	Node e = new Node(5,ob5);
	Object ob6 = new String("car");
	Node f = new Node(6,ob6);
	Object ob7 = new String("door");
	Node g = new Node(7,ob7);
	Object ob8 = new String("dress");
	Node h = new Node(8,ob8);
	Object ob9 = new String("frog");
	Node i = new Node(9,ob9);
	Object ob10 = new String("love");
	Node j = new Node(10,ob10);
	Object ob11 = new String("mint");
	Node k = new Node(11,ob11);
	Object ob12 = new String("rice");
	Node l = new Node(12,ob12);
	Object ob13 = new String("show");
	Node m = new Node(13,ob13);
	Object ob14 = new String("table");
	Node n = new Node(14,ob14);
	Object ob15 = new String("tree");
	Node o = new Node(15,ob15);
	Object ob16 = new String("trouble");
	Node p = new Node(16,ob16);
	Object ob17 = new String("window");
	Node q = new Node(17,ob17);
	
	AVLTree tree = new AVLTree();
	
	tree.insert(a);
	tree.insert(b);
	tree.insert(c);
	tree.insert(d);
	tree.insert(e);
	tree.insert(f);
	tree.insert(g);
	tree.insert(h);
	tree.insert(i);
	tree.insert(j);
	tree.insert(k);
	tree.insert(l);
	tree.insert(m);
	tree.insert(n);
	tree.insert(o);
	tree.insert(p);
	tree.insert(q);
	tree.delete(8);
	/*tree.insert(k);
	tree.insert(g);
	tree.insert(l);
	tree.insert(n);
	tree.insert(p);
	tree.insert(o);
	tree.insert(d);
	tree.insert(i);
	tree.insert(h);
	tree.insert(a);
	tree.insert(j);
	tree.insert(i);
	tree.insert(f);
	tree.insert(q);
	tree.insert(c);
	tree.insert(b);
	tree.insert(m);
	tree.insert(e);
	*/
	
	System.out.println("idΪ4�Ľڵ㣺"+tree.get(4).getId()+"#"+tree.get(4).getData());
	JFrame JF = new JFrame("ƽ�������");
	JTree Tr = tree.printTree();
	JF.add(Tr);
	JF.setSize(300, 500);
    JF.setVisible(true);
    JF.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}	
}
