import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import javax.swing.JFrame;

public class Main2014302580373 extends JFrame
{
		static Node root = new Node();
		static Node[] nodeAll = new Node[17];

	public static void main(String[] args) throws IOException {
		// TODO �Զ����ɵķ������
		//���ݵ���
		File file = new File(".\\tree_data.dat");
		if (!file.exists() || file.isDirectory()) 
		{
			throw new FileNotFoundException();
		}
		FileReader fr = new FileReader(file);
		BufferedReader br = new BufferedReader(fr);
		String temp = null;
		temp = br.readLine();
		StringBuffer sb = new StringBuffer();
		int _i = 0;
		while (temp != null) 
		{
			sb.append(temp);	
			nodeAll[_i] = new Node(_i+1);
			nodeAll[_i].setData(sb.toString());
			_i++;		
			sb.delete(0, temp.length());
			temp = br.readLine();
		}

		AVLTree avlTree = new AVLTree(nodeAll[0]);
		//�ɵ������ݴ���ƽ�����������֤insert()����
		for(int i=1;i<nodeAll.length;i++)
		{
			avlTree.insert(nodeAll[i]);
		}
		
		//Test
//		System.out.println("IdΪ5��Node��Ϣ��"+avlTree.get(5).getData());
//		avlTree.insert(new Node(18,"computer#18"));
		avlTree.delete(9);
		
		//����GUI
		JFrame jFrame = new JFrame();
		jFrame.add(avlTree.printTree());
		jFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		jFrame.setSize(300,500);
		jFrame.setVisible(true);

	}
}
