
public class Node {
	private int id;
	private Object data;
	private Node parent;
	private Node[] children = new Node[2];
//	private int lSubTreeHeight;
//	private int rSubTreeHeight;
//	private int balanceFactor;

	public Node(){		
	}
	
	public Node(int _id) {
		id = _id;
	}
	
	public Node(int _id, Object _data){
		id = _id;
		data = _data;
	}

	public int getId() {
		return id;
	}

	public Object getData() {
		return data;
	}

	public void setData(Object data) {
		this.data = data;
	}

	public Node getParent() {
		return parent;
	}

	public void setParent(Node parent) {
		this.parent = parent;
	}

	public Node[] getChildren() {
		return children;
	}

	public void setChildren(Node[] children) {
		this.children = children;
	}

	public void setChild(Node child, int id) {
		this.children[id] = child;
	}

	//������߶�
	public int getlSubTreeHeight() {
		// TODO calculate the left sub tree height
		return getHeight(this.getChildren()[0]);
	}

	//���ҽ��߶�
	public int getrSubTreeHeight() {
		// TODO calculate the right sub tree height

		return getHeight(this.getChildren()[1]);
	}

	public int getBalanceFactor() {
		// TODO calculate the balance factor
		return this.getlSubTreeHeight() - this.getrSubTreeHeight();
	}
	
	//������߶�
	public int getHeight(Node _node)
	{
		if(_node==null)
		{
			return 0;
		}
		else
		{
			int left = getHeight(_node.getChildren()[0]);
			int right = getHeight(_node.getChildren()[1]);
			return Math.max(left, right)+1;
		}
	}
}
