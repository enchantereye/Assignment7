import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;

public class AVLTree implements IAVLTree {
	Node root = new Node();
	DefaultMutableTreeNode t_root = new DefaultMutableTreeNode();
	DefaultMutableTreeNode[] t_nodeAll = new DefaultMutableTreeNode[100];
	
	public AVLTree(Node _root) {
		// TODO �Զ����ɵĹ��캯�����
		root = _root;
	}

	@Override
	public Node get(int id) {
		// TODO �Զ����ɵķ������
		Node r = root;
		while(true)
		{
			if(id == r.getId())
			{	
				break;
			}
			if(id < r.getId())
			{
				if(r.getChildren()[0]==null)
				{
					System.out.println("Error!No this ID node!");
					return null;
				}
				r = r.getChildren()[0];
				continue;
			}
			if(id > r.getId())
			{
				if(r.getChildren()[1]==null)
				{
					System.out.println("Error!No this ID node!");
					return null;
				}
				r = r.getChildren()[1];
				continue;
			}
		}
		return r;
	}

	@Override
	public void insert(Node newNode) {
		// TODO �Զ����ɵķ������
		Node r = root;
		while(true)
		{
			if(newNode.getId()==r.getId())
			{
				System.out.println("Error!Duplicate ID!");
				break;
			}
			if(newNode.getId()<r.getId())
			{
				if(r.getChildren()[0]==null)
				{
					r.setChild(newNode, 0);
					newNode.setParent(r);
					break;
				}
				else
				{
					r = r.getChildren()[0];
					continue;
				}
			}
			if(newNode.getId()>r.getId())
			{
				if(r.getChildren()[1]==null)
				{
					r.setChild(newNode, 1);
					newNode.setParent(r);
					break;
				}
				else
				{
					r = r.getChildren()[1];
					continue;
				}
			}
		}
		rotation(newNode);
		reRoot(newNode);
	}

	@Override
	public void delete(int id) {
		// TODO �Զ����ɵķ������
		Node d_node = this.get(id);
		Node p_node = d_node.getParent();
		if(d_node.getChildren()[0]==null && d_node.getChildren()[1]==null)
		{
			if(d_node==d_node.getParent().getChildren()[0])
			{
				d_node.getParent().setChild(null, 0);
			}
			else if(d_node==d_node.getParent().getChildren()[1])
			{
				d_node.getParent().setChild(null, 1);
			}
			d_node.setParent(null);
			d_node = null;
		}
		else if(d_node.getChildren()[0]==null && d_node.getChildren()[1]!=null)
		{
			if(d_node==d_node.getParent().getChildren()[0])
			{
				d_node.getParent().setChild(d_node.getChildren()[1], 0);
				d_node.getChildren()[1].setParent(d_node.getParent());
				d_node.setParent(null);
				d_node = null;
			}
			else if(d_node==d_node.getParent().getChildren()[1])
			{
				d_node.getParent().setChild(d_node.getChildren()[1], 1);
				d_node.getChildren()[1].setParent(d_node.getParent());
				d_node.setParent(null);
				d_node = null;
			}
		}
		else if(d_node.getChildren()[0]!=null && d_node.getChildren()[1]==null)
		{
			if(d_node==d_node.getParent().getChildren()[0])
			{
				d_node.getParent().setChild(d_node.getChildren()[0], 0);
				d_node.getChildren()[0].setParent(d_node.getParent());
				d_node.setParent(null);
				d_node = null;
			}
			else if(d_node==d_node.getParent().getChildren()[1])
			{
				d_node.getParent().setChild(d_node.getChildren()[0], 1);
				d_node.getChildren()[1].setParent(d_node.getParent());
				d_node.setParent(null);
				d_node = null;
			}
		}
		else if(d_node.getChildren()[0]!=null && d_node.getChildren()[1]!=null)
		{
			if(d_node.getChildren()[0].getChildren()!=null)
			{
				if(d_node==d_node.getParent().getChildren()[0])
				{
					d_node.getParent().setChild(d_node.getChildren()[0], 0);
					d_node.getChildren()[0].setParent(d_node.getParent());
					d_node.getChildren()[0].setChild(d_node.getChildren()[1], 1);
					d_node.getChildren()[1].setParent(d_node.getChildren()[0]);
					d_node.setParent(null);
					d_node = null;
				}
				else if(d_node==d_node.getParent().getChildren()[1])
				{
					d_node.getParent().setChild(d_node.getChildren()[0], 1);
					d_node.getChildren()[0].setParent(d_node.getParent());
					d_node.getChildren()[0].setChild(d_node.getChildren()[1], 1);
					d_node.getChildren()[1].setParent(d_node.getChildren()[0]);
					d_node.setParent(null);
					d_node = null;
				}
			}
			else if(d_node.getChildren()[0].getChildren()==null)
			{
				if(d_node==d_node.getParent().getChildren()[0])
				{
					d_node.getParent().setChild(d_node.getChildren()[1], 0);
					d_node.getChildren()[1].setParent(d_node.getParent());
					d_node.getChildren()[1].setChild(d_node.getChildren()[0], 1);
					d_node.getChildren()[0].setParent(d_node.getChildren()[1]);
					d_node.setParent(null);
					d_node = null;
				}
				else if(d_node==d_node.getParent().getChildren()[1])
				{
					d_node.getParent().setChild(d_node.getChildren()[1], 1);
					d_node.getChildren()[1].setParent(d_node.getParent());
					d_node.getChildren()[1].setChild(d_node.getChildren()[0], 1);
					d_node.getChildren()[0].setParent(d_node.getChildren()[1]);
					d_node.setParent(null);
					d_node = null;
				}
			}
		}
		rotation(p_node);
	}

	@Override
	public JTree printTree() {
		// TODO �Զ����ɵķ������
		t_root.setUserObject(root.getData());
		DLR(root, t_root);
		JTree jTree = new JTree(t_root);
		jTree.setSize(200, 400);
		return jTree;
	}
	
	@Override
	public void DLR(Node r, DefaultMutableTreeNode t_node) {
		// TODO �Զ����ɵķ������
		//�������
		if(r.getChildren()[0]!=null)
		{
			DefaultMutableTreeNode t_node0 = new DefaultMutableTreeNode(r.getChildren()[0].getData());
			t_node.add(t_node0);
			DLR(r.getChildren()[0], t_node0);
		}
		if(r.getChildren()[1]!=null)
		{
			DefaultMutableTreeNode t_node1 = new DefaultMutableTreeNode(r.getChildren()[1].getData());
			t_node.add(t_node1);
			DLR(r.getChildren()[1], t_node1);
		}	
	}

	@Override
	public void rotation(Node _node) {
		// TODO �Զ����ɵķ������
		Node s = new Node();
		Node r = new Node();
		Node u = new Node();
		//�ҳ�S���
		while(true)
		{
			if(_node == root)
			{
				break;
			}
			if(_node.getParent().getBalanceFactor()==2 || _node.getParent().getBalanceFactor()==-2)
			{
				s = _node.getParent();
				break;
			}
			else
			{
				_node = _node.getParent();
				continue;
			}
		}
		
		//����S����R����ƽ�����ӷ������ת
		if(s.getBalanceFactor()==2)
		{
			//S:2,R:1
			if(s.getChildren()[0].getBalanceFactor()==1)
			{
				r = s.getChildren()[0];
				if(r.getChildren()[1]!=null)
				{
					s.setChild(r.getChildren()[1], 0);
					r.getChildren()[1].setParent(s);
				}
				else
				{
					s.setChild(null, 0);
				}
				if(s.getParent()!=null)
				{
					s.getParent().setChild(r, 0);
					r.setParent(s.getParent());
				}
				else
				{
					r.setParent(null);
				}
				r.setChild(s, 1);
				s.setParent(r);
			}
			//S:2,R:-1
			else if(s.getChildren()[0].getBalanceFactor()==-1)
			{
				r = s.getChildren()[0];
				u = r.getChildren()[1];
				r.setChild(u.getChildren()[0], 1);
				s.setChild(u.getChildren()[1], 0);
				u.setChild(r, 0);
				u.setChild(s, 1);
			}
		}
		if(s.getBalanceFactor()==-2)
		{
			//S:-2,R:-1
			if(s.getChildren()[1].getBalanceFactor()==-1)
			{
				r = s.getChildren()[1];
				if(r.getChildren()[0]!=null)
				{
					s.setChild(r.getChildren()[0], 1);
					r.getChildren()[0].setParent(s);
				}
				else
				{
					s.setChild(null, 1);
				}
				if(s.getParent()!=null)
				{
					s.getParent().setChild(r, 1);
					r.setParent(s.getParent());
				}
				else
				{
					r.setParent(null);
				}
				r.setChild(s, 0);
				s.setParent(r);
			}
			//S:-2,R:1
			else if(s.getChildren()[1].getBalanceFactor()==1)
			{
				r = s.getChildren()[1];
				u = r.getChildren()[0];
				r.setChild(u.getChildren()[1], 0);
				s.setChild(u.getChildren()[0], 1);
				u.setChild(s, 0);
				u.setChild(r, 1);
			}
		}
	}

	@Override
	public void reRoot(Node _node) {
		// TODO �Զ����ɵķ������
		while(true)
		{
			if(_node.getParent()==null)
			{
				root = _node;
				break;
			}
			else
			{
				_node = _node.getParent();
				continue;
			}
		}
	}

}