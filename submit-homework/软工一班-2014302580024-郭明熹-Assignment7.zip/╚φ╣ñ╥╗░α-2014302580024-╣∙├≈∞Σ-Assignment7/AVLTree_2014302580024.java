package assignment7_2014302580024;

import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.JTree;

public class AVLTree_2014302580024 implements IAVLTree {
	private static final int LHigher = 1;    //���  
	private static final int EHigh = 0;    //�ȸ�  
	private static final int RHigher = -1;   //�Ҹ�  
	private Node root;
	private int TreeSize;
	
	public int size(){  
	    return TreeSize;  
	 }
	public AVLTree_2014302580024(){
		root=null;
	}
	public Node get (int id){
		Node s = root;    
	    while (s != null) {    
	      if (id == s.getId()) {    
	        return s;    
	    } else if (id<s.getId()) {    
	        s = s.getChildren()[0];    
	    } else {    
	       s= s.getChildren()[1];    
	    }    
	}    
	     return null;
	}
	private void LRotation(Node s){
		if(s!=null){
		Node r = s.getChildren()[1];
		s.setChild(r.getChildren()[0], 1);
		if(r.getChildren()[0]!=null)
			r.getChildren()[0].setParent(s);
		r.setParent(s.getParent());
		if(s.getParent()==null)
			root = r;
		else if(s.getParent().getChildren()[0]==s)
			s.getParent().setChild(r, 0);//p.parent.left=r
		else
			s.getParent().setChild(r,1);//p.parent.right=r
		r.setChild(s,0);//r.left=p
		s.setParent(r);//p.parent=r
		}
	}
	private void RRotation(Node s){
		if(s!=null){
		Node r = s.getChildren()[0];
		s.setChild(r.getChildren()[1],0);
		if(r.getChildren()[1]!=null){
			r.getChildren()[1].setParent(s);	// r.right.parent = s;  
			r.setParent(s.getParent());   //l.parent = p.parent;
		if(s.getParent()==null)
			root=r;
		else if(s.getParent().getChildren()[1]==s){
			s.getParent().setChild(r,1);
			}
			else{
				s.getParent().setChild(r,0);
				r.setChild(s,1);
				s.setParent(r);
			}	
		}
		}
		}

   private void adjustAfterInsertion(Node s){  
    if(s.getBalanceFactor() == 2){  
        leftBalance(s);  
    }  
    if(s.getBalanceFactor() == -2){  
        rightBalance(s);  
    }  
} 

	private boolean leftBalance(Node s) {
	// TODO �Զ����ɵķ������
    boolean heightLower = true;  
     Node first = s.getChildren()[0];  
     switch (first.getBalanceFactor()) {  
     case LHigher:            //t����������������  
         s.setBalanceFactor( EHigh);
         first.setBalanceFactor(EHigh);
         RRotation(s);  
         break;   
     case RHigher:            //t����������������                                            
        Node newChild = first.getChildren()[1];
        switch (newChild.getBalanceFactor()) {   //���������ڵ��BF  
        case LHigher:       
            s.setBalanceFactor(RHigher);  
             first.setBalanceFactor(EHigh);  
             break;  
           
         case RHigher:     
             s.setBalanceFactor (EHigh);  
             first.setBalanceFactor(LHigher);  
             break; 
         case EHigh:      
             s.setBalanceFactor (EHigh);
             first.setBalanceFactor (EHigh);
             break;
         }  
         newChild.setBalanceFactor (EHigh);
         LRotation(s.getChildren()[0]);  
         RRotation(s);   
         break;  
     case EHigh:       
         first.setBalanceFactor(RHigher);  
         s.setBalanceFactor(LHigher);  
         RRotation(s);   
         heightLower = false;  
         break;  
     }  
     return heightLower;  
 } 

	private boolean rightBalance(Node s) {
	// TODO �Զ����ɵķ������
		boolean hL = true;  
	    Node r = s.getChildren()[1];  
	    switch (r.getBalanceFactor()) {  
	    case LHigher:            //��ߣ����������  
	        Node ld = r.getChildren()[0];  
	        switch (ld.getBalanceFactor()) {   //���������ڵ��BF  
	        case LHigher:     
	            s.setBalanceFactor (EHigh);  
	            r.setBalanceFactor(RHigher);  
	            break;  
	        case EHigh:       
	            s.setBalanceFactor (EHigh);
	            r.setBalanceFactor(EHigh);  
	            break;  
	        case RHigher:      
	            s.setBalanceFactor(LHigher);  
	            r.setBalanceFactor(EHigh);  
	            break;  
	        }  
	        ld.setBalanceFactor(EHigh);
	        RRotation(s.getChildren()[1]);  
	        LRotation(s);
	        break;  
	    case RHigher:            //�Ҹߣ���������  
	        s.setBalanceFactor(EHigh);
	        r.setBalanceFactor(EHigh); 
	        LRotation(s); 
	        break;  
	    case EHigh:        
	        r.setBalanceFactor(LHigher);  
	        s.setBalanceFactor(RHigher);  
	        LRotation(s); 
	        hL = false;  
	        break;  
	   }  
	    return hL;  
}
	public void insert(int id, Node newNode) {
		 int i=0;
		 Node t = root;  
		        if(t == null){  
		            root = newNode;
		            newNode.setParent(null);
		            TreeSize = 1;  
		             
		        }  
		        else{
		        Node parent;  //����t�ĸ��ڵ�  
		       
		        //�Ӹ��ڵ������������ҵ�����λ��  
		        do {  
		            parent = t;       
		            if(id<parent.getId()){  
		                t = t.getChildren()[0];  
		            }else if(id>parent.getId()){  
		               t = t.getChildren()[1];  
		            }else{  
		                 System.out.println("idΪ"+id+"�Ľڵ��Ѿ����ڣ�����ʧ��"); 
		                 i=1;
		                 t=null;
		           }  
		       } while (t!=null);  
		   if(i==0) {      
		        Node child = newNode; 
		        newNode.setParent(parent);
		        if(id<parent.getId()){  
		            parent.setChild(child, 0);  
		             }else{  
		           parent.setChild(child, 1);     
		        }  
		         
		        while(parent!=null){  
		             if(id < parent.getId()){    //�½ڵ��Ϊ���������� 
		                int p=parent.getBalanceFactor()+1; 
		                parent.setBalanceFactor(p);
		                }else{           //�½ڵ��Ϊ�������Һ���
		                int q=parent.getBalanceFactor()-1;
		                	parent.setBalanceFactor(q);  
		           }  
		           if(parent.getBalanceFactor() == 0){    //�˽ڵ��balanceFactorΪ0���������ϵ���BFֵ���Ҳ���Ҫ��ת  
		               break;  
		           }  
		           if(parent.getBalanceFactor() == 2||parent.getBalanceFactor() == -2){  //�ҵ���ƽ��ĸ��ڵ㣬���е��� 
		               adjustAfterInsertion(parent);  
		                break;                  
		           }  
		           parent.setParent(parent.getParent());  
		       } 
		       
		        TreeSize ++;  
		   }
		        }// TODO Auto-generated method stub
		}
	public JTree printTree(){
		DefaultMutableTreeNode defaultNode=new DefaultMutableTreeNode(
				"data:"+this.root.getData());
		printTree(defaultNode,this.root);
		JTree temp=new JTree(defaultNode);
		return temp;	
	}
	private void printTree(DefaultMutableTreeNode defaultNode,Node node){
		//˽�еݹ��ӡ����
		if(node!=null){
			if(node.getChildren()[0]!=null){
				DefaultMutableTreeNode defaultNode1=new DefaultMutableTreeNode(
						"data:"+node.getChildren()[0].getData()
						);
				defaultNode.add(defaultNode1);
				printTree(defaultNode1,node.getChildren()[0]);
			}
			if(node.getChildren()[1]!=null){
				DefaultMutableTreeNode defaultNode2=new DefaultMutableTreeNode(
						"data:"+node.getChildren()[1].getData()
						);
				defaultNode.add(defaultNode2);
				printTree(defaultNode2,node.getChildren()[1]);
			}
		}
	}
	   
	public void delete(int id) {
		// TODO �Զ����ɵķ������
		
		// TODO Auto-generated method stub
		Node p=get(id);//�������Ҫ��ɾ���Ľڵ�
		if (p==null){
			System.out.println("û������ڵ�");
			return;
		}
		
		if(p.getChildren()[0]!=null&&p.getChildren()[0]!=null){
			Node s=p.getChildren()[1];//s��p��������
			while(s.getChildren()[0]!=null){
				s=s.getChildren()[0];
			}
			p.setData(s.getData());
			p.setId(s.getId());//��s�����ݸ��Ƶ�p����ȥ
			p=s;//��pָ�����s�ڵ�,�����Ѿ�ת��Ϊɾ�����ֻ��һ�������Ľڵ������
		}
		Node c=root;
		Node q=p.getParent();//q��p������
		if(p.getChildren()[0]!=null){
			c=p.getChildren()[0];
		}else{
			c=p.getChildren()[1];
		}//cָ��p�ĺ���,Ҳ������null�����pû�к��ӵĻ�
		if(p==root){
			root=c;
		}else if(p==q.getChildren()[0]){//p��q�����ӵĻ�
			q.setChild(c, 0);
		}else{
			q.setChild(c, 1);
		}
		p=q;//�ͷŽڵ�
		
		//��������ת�Ĳ���
		while(p!=null){
			Node pParent = p.getParent();// ����s�ĸ��ڵ㣬��ʱ������޸��˸��ڵ㣬��Ҫ�Ѹ��ڵ�ĸ��ױ仯һ�£�s�ڵ�����������ĸ�
			// s�ڵ�ĸ��ײ���null��ʱ�򣬼�s���Ǹ��ڵ��ʱ��
			int pIsLeftOrRight = 0;
			if (pParent != null) {
				pIsLeftOrRight = pParent.getChildren()[0] == p ? 0 : 1;// �ж�s�ڵ��Ǹ��׽ڵ��������������
			}
			
			if(p.getBalanceFactor()==0){
				if(c==p.getChildren()[0]){
					p.setBalanceFactor(-1);
				}else if(c==p.getChildren()[-1]){
					p.setBalanceFactor(1);
				}
				break;//����ѭ�����߶��Ѿ���Ӱ�����Ľڵ�
			}
			
			
			if(p.getBalanceFactor()==1){
				if(c==p.getChildren()[0]){
					p.setBalanceFactor(0);
					continue;//�ӽϸߵ�������ɾ���ڵ�
				}else if(c==p.getChildren()[1]){//�Ƚϰ�����������Ҫ��ת
					Node r=p.getChildren()[0];//r��p��������;
					if(r.getBalanceFactor()==0){
						p.setChild(r.getChildren()[1], 0);
						r.setChild(p, 1);
						r.setBalanceFactor(-1);
						if(pParent!=null){
							pParent.setChild(r,pIsLeftOrRight );
						}else{
							root=r;
						}
						p=r;
						break;//��ʱ��Ӱ�����ڵ�ĸ߶ȡ�
					}else if(r.getBalanceFactor()==1){
						p.setChild(r.getChildren()[1], 0);
						r.setChild(p, 1);
						r.setBalanceFactor(0);
						p.setBalanceFactor(0);
						if(pParent!=null){
							pParent.setChild(r,pIsLeftOrRight );
						}else{
							root=r;
						}
						p=r;
						continue;//��ʱ�߶ȼ�һ
					}else if(r.getBalanceFactor()==-1){
						Node u=r.getChildren()[1];//u��r������
						p.setChild(u.getChildren()[1], 0);
						r.setChild(u.getChildren()[0], 1);
						u.setChild(p, 1);
						u.setChild(u, 0);
						switch(u.getBalanceFactor()){
						case 0:
							p.setBalanceFactor(0);
							r.setBalanceFactor(0);
							u.setBalanceFactor(0);
							break;
						case -1:
							p.setBalanceFactor(0);
							r.setBalanceFactor(1);
							u.setBalanceFactor(0);
							break;
						case 1:
							p.setBalanceFactor(-1);
							r.setBalanceFactor(0);
							u.setBalanceFactor(0);
							break;
						}
						if(pParent!=null){
							pParent.setChild(r,pIsLeftOrRight );
						}else{
							root=r;
						}
						p=u;
						continue;
						
					}
				}
				
				
			}
			
			
			if(p.getBalanceFactor()==-1){
				if(c==p.getChildren()[1]){
					p.setBalanceFactor(1);
					continue;//�ӽϸߵ�������ɾ���ڵ�
				}else if(c==p.getChildren()[0]){//�Ƚϰ��� ��������Ҫ��ת
					Node r=p.getChildren()[1];//r��p��������;
					if(r.getBalanceFactor()==0){
						p.setChild(r.getChildren()[0], 1);
						r.setChild(p, 0);
						r.setBalanceFactor(1);
						if(pParent!=null){
							pParent.setChild(r,pIsLeftOrRight );
						}else{
							root=r;
						}
						p=r;
						break;//��ʱ��Ӱ�����ڵ�ĸ߶ȡ�
					}else if(r.getBalanceFactor()==-1){
						p.setChild(r.getChildren()[0], 1);
						r.setChild(p, 0);
						r.setBalanceFactor(0);
						p.setBalanceFactor(0);
						if(pParent!=null){
							pParent.setChild(r,pIsLeftOrRight );
						}else{
							root=r;
						}
						p=r;
						continue;
					}else if(r.getBalanceFactor()==1){
						Node u=r.getChildren()[0];//u��r������
						p.setChild(u.getChildren()[0], 1);
						r.setChild(u.getChildren()[1], 0);
						u.setChild(p, 0);
						u.setChild(u, 1);
						switch(u.getBalanceFactor()){
						case 0:
							p.setBalanceFactor(0);
							r.setBalanceFactor(0);
							u.setBalanceFactor(0);
							break;
						case 1:
							p.setBalanceFactor(0);
							r.setBalanceFactor(-1);
							u.setBalanceFactor(0);
							break;
						case -1:
							p.setBalanceFactor(1);
							r.setBalanceFactor(0);
							u.setBalanceFactor(0);
							break;
						}
						if(pParent!=null){
							pParent.setChild(r,pIsLeftOrRight );
						}else{
							root=r;
						}
						p=u;
						continue;
						
					}
				}
			}
			
		}
		
	}}