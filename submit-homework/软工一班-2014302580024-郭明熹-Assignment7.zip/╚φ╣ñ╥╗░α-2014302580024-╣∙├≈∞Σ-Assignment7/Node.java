package assignment7_2014302580024;

public class Node {
	private int id;
	private Object data;
	private Node parent;
	private Node[] children = new Node[2];
	private int lSubTreeHeight;
	private int rSubTreeHeight;
	private int balanceFactor;
	
	public Node(int id){
		this.id = id;
	}
	public Node (){
	}
	public Node(int id,Object data){
		this.id = id;
		this.data = data;
	}
	public Node(int id, Object data, Node parent){
		this.id = id;
		this.data = data;
		this.parent = parent;
	}
	public int getId() {
		return id;
	}
	public void setId(int id){
		this.id=id;
	}
	public Object getData() {
		return data;
	}
	public void setData(Object data) {
		this.data = data;
	}
	public Node getParent() {
		return parent;
	}
	public void setParent(Node parent) {
		this.parent = parent;
	}
	public Node[] getChildren() {
		return children;
	}
	public void setChildren(Node[] children) {
		this.children = children;
	}
	public void setChild(Node child, int id){
		if(id != 0 && id !=1){
			return;
		}
		this.children[id] = child;
	}
	public int getBalanceFactor() {
		//TODO calculate the balance factor
		return balanceFactor;
	}
	public void setBalanceFactor(int balanceFactor){
		this.balanceFactor=balanceFactor;
	}

}
