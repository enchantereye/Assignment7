package assignment7_2014302580024;

import java.util.Scanner;

import javax.swing.*;

public class Main_2014302580024 extends JFrame{

	 public static void main(String[] args) {
		 AVLTree_2014302580024 tree = new AVLTree_2014302580024();
		 
		 //���в��뺯���Ĳ���
		 Node n1 = new Node (1,"ant");
		 Node n2 = new Node (2,"ant");
		 Node n3 = new Node (3,"ant");
		 Node n4 = new Node (4,"ant");
		 Node n5 = new Node (5,"ant");
		 tree.insert(1, n1);
		 tree.insert(2, n2);
		 tree.insert(3, n3);
		 tree.insert(4, n4);
		 tree.insert(5, n5);
		 
		 //����get����
		 System.out.println("id="+tree.get(1).getId());
		 System.out.println("data="+tree.get(1).getData());
		 
		 //����ɾ�������Ĳ���
		 tree.delete(2);
		 
		 //���д�ӡ�����Ĳ���
		 JTree jtree = tree.printTree();
		 Main_2014302580024 m = new Main_2014302580024();
		 m.add(jtree);
		 m.setSize(600, 400);
		 m.setVisible(true);
		 m.setDefaultCloseOperation(EXIT_ON_CLOSE);
	 }
}
