import javax.swing.JFrame;
import javax.swing.JTree;

public class Main {
	public static void main(String[] args) {
		AVLTree avl=new AVLTree();
		Node[] nodes=new Node[]{
				new Node(1,"ant"),
				new Node(2,"apple"),
				new Node(3,"art"),
				new Node(4,"baby"),
				new Node(5,"banan"),
				new Node(6,"car"),
				new Node(7,"door"),
				new Node(8,"dress"),
				new Node(9,"frog"),
				new Node(10,"love"),
				new Node(11,"mint"),
				new Node(12,"rice"),
				new Node(13,"show"),
				new Node(14,"table"),
				new Node(15,"tree"),
				new Node(16,"trouble"),
				new Node(17,"window")
		};
		for(int i=0;i<17;i++){
			avl.insert(nodes[i]);
		}
		System.out.println("id:"+avl.get(1).getId()+"\n"+"data:"+avl.get(1).getData());
		JFrame f = new JFrame("��1");
        f.add(avl.printTree());
        f.setSize(300, 300);
        f.setVisible(true);
		avl.delete(2);
		JFrame f2 = new JFrame("��2");
        f2.add(avl.printTree());
        f2.setSize(300, 300);
        f2.setVisible(true);
	}
}
