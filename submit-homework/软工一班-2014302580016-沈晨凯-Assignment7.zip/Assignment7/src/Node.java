
/**
 * id默认是Int型，不使用泛型
 * @author Anjail
 *
 * 
 */

public class Node {
	private int id;		
	private Object data;
	private Node parent;		//父节点
	private Node lchild;	//左子树的节点
	private Node rchild; //右子树的节点
	private int lSubTreeHeight;		//左子树的高度
	private int rSubTreeHeight;		//右子树的高度
	private int balanceFactor;		//平衡因子
	
	public int getId() {
		return id;
	}
	public void setId(int id){
		this.id=id;
	}
	public Object getData() {
		return data;
	}
	public void setData(Object data) {
		this.data = data;
	}
	public Node getParent() {
		return parent;
	}
	public void setParent(Node parent) {
		this.parent = parent;
	}
	public Node getLChild() {
		return lchild;
	}
	
	public Node getRChild() {
		return rchild;
	}
	
	/**
	 * 设置左右子树
	 * @param children
	 */
	public void setLChild(Node lchild) {
		this.lchild = lchild;
	}
	
	public void setRChild(Node rchild) {
		this.rchild = rchild;
	}
	/**
	 * 根据id 设置左子树 或者右子树
	 * @param child
	 * @param id
	 */
//	public void setChild(Node<E> child, int id){
//		this.children[id] = child;
//	}
	public int getlSubTreeHeight() {
		//TODO calculate the left sub tree height
		if(this.getLChild()==null) lSubTreeHeight = 0;
		else 
			{
			int heightL;
			int heightR;
			heightL = this.getLChild().getlSubTreeHeight();
			heightR = this.getLChild().getrSubTreeHeight();
			if(heightL - heightR>0) lSubTreeHeight = heightL+1;
			else lSubTreeHeight = heightR+1;
			}
		return lSubTreeHeight;
	}
	public int getrSubTreeHeight() {
		//TODO calculate the right sub tree height
		if(this.getRChild()==null) rSubTreeHeight = 0;
		else 
			{
			int heightL;
			int heightR;
			heightL = this.getRChild().getlSubTreeHeight();
			heightR = this.getRChild().getrSubTreeHeight();
			if(heightL - heightR>0) rSubTreeHeight = heightL+1;
			else rSubTreeHeight = heightR+1;
			}
		return rSubTreeHeight;
	}
	public int getBalanceFactor() {
		//TODO calculate the balance factor
		if(this.getrSubTreeHeight()==0) balanceFactor=this.getlSubTreeHeight();
		else if(this.getlSubTreeHeight()==0) balanceFactor = -this.getrSubTreeHeight();
		else balanceFactor = this.getlSubTreeHeight() - this.getrSubTreeHeight();
		return balanceFactor;
	}
	public void setBanlanceFactor(int balanceFactor)
	{
		this.balanceFactor=balanceFactor;
	}
	
	public String toString()
	{
		String str = "id="+this.id+"";
		str+="  data="+this.data+"";
		return str;
		
	}
}
