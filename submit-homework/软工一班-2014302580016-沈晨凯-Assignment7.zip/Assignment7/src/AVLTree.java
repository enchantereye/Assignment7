import javax.swing.JOptionPane;
import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;




public class AVLTree implements IAVLTree {
	/**
	 * 根节点
	 */
	private Node root = null;
	
	/**
	 * 树中元素的个数
	 */
	private int number = 0;
	
	public int Number()
	{
		return number;
	}
	
	/**
	 * 根据节点的ID来获取节点
	 */
	public Node get(int id)
	{
		return get(root,id);
	}
	private Node get(Node node,int id)
	{
		if(node==null)
		{
			return null;
		}
		
		else
		{
			if(node.getId()==id)
			{
				return node;
			}
			else if(node.getId()>id)
			{
				return get(node.getLChild(),id);
			}
			else
			{
				return get(node.getRChild(),id);
			}
		}
		
		
	}
	
	/**
	 * 公共接口方法
	 */
	public void insert(Node newNode)
	{
		//如果二叉树为空
		if(root == null) root = newNode;
		//否则
		else 
			insert(root, newNode);
	}
	
	/**
	 * 具体实现方法
	 * @param p
	 * @param newNode
	 */
	private void insert(Node p, Node newNode) 
	{
		while (p!=null)
		{
			if(newNode.getId()<p.getId())
			{//插入左子树
				if(p.getLChild()==null)
				{//在左孩子为空时就插入
					p.setLChild(newNode);
					p.setBanlanceFactor(p.getBalanceFactor()+1);
					newNode.setParent(p);break;
				}
				else {
					p=p.getLChild();
				}
			}
			else if(newNode.getId()==p.getId())
			{
				JOptionPane.showMessageDialog(null, "提示消息.", "标题",JOptionPane.ERROR_MESSAGE);
				break;
			}
			else{
				if(p.getRChild()==null)
				{
					p.setRChild(newNode);
					p.setBanlanceFactor(p.getBalanceFactor()-1);
					newNode.setParent(p);break;
				}
				else 
					{
						p=p.getRChild();
					}
				
			}
		}
		//从最后的节点开始往上依次检查节点的平衡因子
		Node node = p;
		while(true)
		{//如果平衡因子=0，结束
			if(node.getBalanceFactor()==0)
			{
				return;
			}
			else if(node.getBalanceFactor()==1||node.getBalanceFactor()==-1)
			{
				if(node==root)
				{
					return;
				}
				//如果新节点是左孩子
				else if(newNode.getId()<node.getParent().getId())
				{
					node.getParent().setBanlanceFactor(node.getParent().getBalanceFactor()+1);
				}
				
				//如果新节点是右孩子
				else if(newNode.getId()>=node.getParent().getId())
				{
					node.getParent().setBanlanceFactor(node.getParent().getBalanceFactor()-1);

				}
				//继续往上检查
				node=node.getParent();
			}
			else if(node.getBalanceFactor()==2||node.getBalanceFactor()==-2)
			{
				//LL旋转
				if(newNode.getId()<node.getId()&&newNode.getId()<node.getLChild().getId())
				{
					balanceLR(node);
				}
				//RR旋转
				else if(newNode.getId()>=node.getId()&&newNode.getId()>=node.getRChild().getId())
				{
					balanceRR(node);
				}
				//LR旋转
				else if(newNode.getId()<node.getId()&&newNode.getId()>=node.getLChild().getId())
				{
					balanceRR(node.getLChild());
					balanceLR(node);
				}
				//RL旋转
				else 
				{
					balanceLR(node.getRChild());
					balanceRR(node);
				}
				//如果不能再往上了
				if(node.getParent()==root||node.getParent().getBalanceFactor()==0)
				{
					break;
				}
				else 
				{
					node = node.getParent().getParent();
				}
			}
		}
	}


	/**
	 * 删除平衡二叉树结点的算法：1、在中序遍历下找到要删除结点p直接后继(直接前驱)s，将s复制到p然后删除s
	 * 问题实际上是转化为了“被删除的结点最多只有一棵非空的子树”
	 */

	@Override
	public void delete(int id)  
	{  
		Node node = root;  
		while (node != null)  
		{  
			if (id < node.getId())  
			{  
				node = node.getLChild();  
			}  
			else if (id > node.getId())  
			{  
				node = node.getRChild();  
			}  
			else  
			{														// 找到该节点了，下面是找到实际的叶子节点与该节点交换  
				// 如果该节点的左子树不为空，则将左子树的最大节点与该节点交换  
				int temp = node.getId();  
				Node tempNode = null;  
				if (node.getLChild() != null)  
				{  
					tempNode = maxNode(node.getLChild());  
				}  
				else if (node.getRChild() != null)  
				{  
					tempNode = minNode(node.getRChild());  
				}  
				if (tempNode != null)  
				{  
					node.setId(tempNode.getId());
					tempNode.setId(temp);
					node = tempNode;  
				}  
				delete(node); 		//调用删除算法
				tempNode = node.getParent();								

				// 下面是删除操作的回朔算法 （往上依次判断） 
				while (true)  
				{  
					// 如果节点的balanceFactor为1或者-1，说明删除之前的balanceFactor为0（因为删除之前是平衡的，不可能为2或者-2情况），删除之后树的高度没有改变，不需要再回朔判断  
					if (tempNode.getBalanceFactor() == 1 || tempNode.getBalanceFactor() == -1)  
					{  
						return ;  
					}  
					else if (tempNode.getBalanceFactor() == 0)  
					{// 如果节点的balanceFactor为0，说明删除之前balanceFactor为1或者-1，删除之后高度减少了，那么需要首先判断当前节点是父节点的左子树还是右子树，再回朔父节点  
						// 判断是否需要继续往上
						if (tempNode == root)  
						{  
							return;  
						}  
						else if (tempNode == tempNode.getParent().getLChild())  
						{// 如果当前节点事左孩子，则父节点的左子树高度下降了  
							tempNode.getParent().setBanlanceFactor(tempNode.getParent().getBalanceFactor()-1);
						}  
						else  
						{  
							tempNode.getParent().setBanlanceFactor(tempNode.getParent().getBalanceFactor()+1);
						}  
					}  
					else  
					{// 如果节点的balanceFactor为2或者-2，则需要通过旋转保持平衡，首先确定旋转的类型，balanceFactor值大于等于0向左，小于0向右  
						if (tempNode.getBalanceFactor() >= 0 && tempNode.getLChild().getBalanceFactor() >= 0)  
						{// LL型旋转  
							balanceLR(tempNode);  
						}  
						else if (tempNode.getBalanceFactor() >= 0 && tempNode.getLChild().getBalanceFactor() < 0)  
						{// LR型旋转  
							balanceRR(tempNode.getLChild());  
							balanceLR(tempNode);  
						}  
						else if (tempNode.getBalanceFactor() < 0 && tempNode.getRChild().getBalanceFactor() >= 0)  
						{// RL型旋转  
							balanceLR(tempNode.getRChild());  
							balanceRR(tempNode);  
						}  
						else  
						{// RR型旋转  
							balanceRR(tempNode);  
						}  
					}  
					tempNode = tempNode.getParent();  
				}  
			}  
		}  

	}  
	
	
	private void delete(Node node)
	{
		// 具体的删除操作，删除叶子节点  
		if (node == root)  
		{  
			root = null;  

		}  
		else if (node == node.getParent().getLChild())  
		{														// 如果当前节点是其父节点的左子树  
			if (node.getLChild() != null)  
			{													// 如果当前节点的左子树不为空  
				node.getParent().setLChild( node.getLChild());
				node.getLChild().setParent(node.getParent());
			}  
			else if (node.getRChild() != null)  
			{  
				node.getParent().setLChild( node.getRChild());
				node.getRChild().setParent(node.getParent());
			}  
			else  
			{  
				node.getParent().setLChild(null);
			}  
			node.getParent().setBanlanceFactor(node.getParent().getBalanceFactor()-1);
		}  
		else  
		{															// 如果当前节点是其父节点的右子树  
			if (node.getLChild() != null)  
			{// 如果当前节点的左子树不为空，则将当前节点的左子树链接到当前节点的父节点  
				node.getParent().setRChild(node.getLChild());
				node.getLChild().setParent(node.getParent());
			}  
			else if (node.getRChild() != null)  
			{  
				node.getParent().setRChild(node.getRChild());  
				node.getRChild().setParent(node.getParent());  
			}  
			else  
			{  
				node.getParent().setRChild(null); 
			}  
			node.getParent().setBanlanceFactor(node.getParent().getBalanceFactor()+1);
		} 
	}
	
	/**
	 * 获取一个最大的结点
	 * @param root
	 * @return
	 */
	
	private Node maxNode(Node root)  
    {  
        Node n = root;  
        while (n != null)  
        {  //最大的结点肯定是某一结点 或者他的右子树
            if (n.getRChild() == null)  
            {  
                break;  
            }  
            else  
            {  
                n = n.getRChild();  
            }  
        }  
        return n;  
    }  
      
    /**
     * 获取一个最小的结点
     * @param root
     * @return
     */
    private Node minNode(Node root)  
    {  
        Node n = root;  
        while (n != null)  
        {  //最小的结点肯定是某一结点 或者他的左子树
            if (n.getLChild() == null)  
            {  
                break;  
            }  
            else  
            {  
                n = n.getLChild();  
            }  
        }  
        return n;  
    }  
	
	
	
	@Override
	public JTree printTree() {
		
		if(root==null)
		{
			return null;
		}
		else 
		{
			DefaultMutableTreeNode tNode = new DefaultMutableTreeNode(root);
			printTree(root,tNode);
			JTree tree = new JTree(tNode);
			return tree;
		}
		
		
	}

	private void printTree(Node n,DefaultMutableTreeNode d)
	{
		
		
		if((n.getLChild()!=null) && (n.getRChild()!=null))
		{
			DefaultMutableTreeNode lnode = new DefaultMutableTreeNode(n.getLChild());
			d.add(lnode);
			DefaultMutableTreeNode rnode = new DefaultMutableTreeNode(n.getRChild());
			d.add(lnode);
			d.add(rnode);
			printTree(n.getLChild(), lnode);
			printTree(n.getRChild(), rnode);
		}
		
		else if((n.getLChild()!=null)&&(n.getRChild()==null))
		{
			DefaultMutableTreeNode lnode = new DefaultMutableTreeNode(n.getLChild());
			d.add(lnode);
			printTree(n.getLChild(), lnode);
		}
		
		else if((n.getRChild()!=null)&&(n.getLChild()==null))
		{
			DefaultMutableTreeNode rnode = new DefaultMutableTreeNode(n.getRChild());
			d.add(rnode);
			printTree(n.getRChild(), rnode);
		}
	}
	/**
	 * 左重组
	 * @param s
	 */
	private void balanceLR(Node s)
	{
//		Node u;
//		Node r = s.getLChild();
//		if(r.getBalanceFactor()==1)
//		{						//LL旋转
//			s.setLChild(r.getRChild());  r.setRChild(s);
//			s.setBanlanceFactor(0);s=r;			//s指示新子树的根
//		}
//		else {				//LR旋转
//			u=r.getRChild();r.setRChild(u.getLChild());
//			u.setLChild(s);s.setLChild(u.getRChild());
//			u.setRChild(s);
//			switch(u.getBalanceFactor())
//			{
//			case 1:  s.setBanlanceFactor(-1);r.setBanlanceFactor(0);break;
//			case 0:  s.setBanlanceFactor(0);r.setBanlanceFactor(0);break;
//			case -1:  s.setBanlanceFactor(0); r.setBanlanceFactor(1);
//			}
//			s=u;				//s指示新子树的根
//		}
//		s.setBanlanceFactor(0);			//结点s的平衡因子为0
		if (s.getParent() == null)  
        {  
            root = s.getLChild();  
        }  
        else if (s == s.getParent().getLChild())
        {  //将s与s的左孩子交换位置
            s.getParent().setLChild(s.getLChild()); 
        }  
        else  
        {  //将s与s的左孩子交换位置
            s.getParent().setRChild(s.getLChild()); 
        }  
		
        // 将r的父节点设为s的父节点  r=s.getLChild()
        s.getLChild().setParent(s.getParent()); 
        // 如果r的右子树不为null，则将r的右子树的父节点设为s  
        if (s.getLChild().getRChild()!= null)  
        {  
            s.getLChild().getRChild().setParent(s); 
        }  
        // 将s的父节点设为r
        s.setParent(s.getLChild()); 
        // 将r的右子树接到s的左边  
        s.setLChild(s.getParent().getRChild()); 
        s.getParent().setRChild(s); 
      
        if (s.getParent().getBalanceFactor() >= 0)  
        {  
            s.setBanlanceFactor(s.getBalanceFactor()-s.getParent().getBalanceFactor()-1); 
        }  
        
        else  
        {  
            s.setBanlanceFactor(s.getBalanceFactor()-1); 
        }  
        if (s.getBalanceFactor() >= 0)  
        {  
            s.getParent().setBanlanceFactor(s.getParent().getBalanceFactor()-1); 
        }  
        else  
        {  
            s.getParent().setBanlanceFactor(s.getParent().getBalanceFactor()+s.getBalanceFactor()-1); 
        }  
    }  
	
	/**
	 * 右重组
	 * @param s
	 */
	private void balanceRR(Node s)
	{

	  
    if (s.getParent() == null)  
    {  
        root = s.getRChild();  
    }  
    else if (s == s.getParent().getLChild())  
    {  
       s.getParent().setLChild(s.getRChild());
    }  

    
    s.getRChild().setParent(s.getParent());
    
    
    if (s.getRChild().getLChild() != null)  
    {  
        s.getRChild().getLChild().setParent(s);
    }  
    
    s.setParent(s.getRChild());
    s.setRChild(s.getParent().getLChild()); 
    s.getParent().setLChild(s); 
    // 调整平衡因子  
    if (s.getParent().getBalanceFactor() < 0)//如果父节点的平衡因子小于0  
    {  
        s.setBanlanceFactor(s.getBalanceFactor()-s.getParent().getBalanceFactor()+1); 
    }  
    else  
    //如果父节点的平衡因子大于或等于0  
    {  
        s.setBanlanceFactor(s.getBalanceFactor()+1); 
    }  
    if (s.getBalanceFactor() < 0)  
    {  
        s.getParent().setBanlanceFactor(s.getParent().getBalanceFactor()+1);
    }  
    else  
    {  
        s.getParent().setBanlanceFactor(s.getParent().getBalanceFactor()+s.getBalanceFactor()+1);
    }  
	}
	
	//下面这两个是通过前序遍历将树展示在命名行中
		public void PreOrder()
		{
			PreOrder(root);
		}
		private void PreOrder(Node node)
		{
			if(node!=null)
			{		
				System.out.print(node.getId()+" ");
				PreOrder(node.getLChild());
				PreOrder(node.getRChild());
			}
			
		}
		
	}
