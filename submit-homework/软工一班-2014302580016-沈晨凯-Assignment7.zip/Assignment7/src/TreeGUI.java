import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;






import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;

import javax.swing.JLabel;



public class TreeGUI {

	private JFrame frame;
	
	
	JTree jt=new JTree() ;
	JTextField tf ;
	JButton button;
	AVLTree tree;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					 new TreeGUI();
					
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public TreeGUI() {
		initialize();
		frame.setVisible(true);
		
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		
		frame = new JFrame("JTree(左键选中右键删除)");
		frame.setBounds(100, 100, 650, 500);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		tf = new JTextField();
		tf.setSize(100, 50);
		tf.setLocation(300, 200);
		frame.getContentPane().add(tf);
		
		button = new JButton("插入");
		button.setSize(215, 57);
		button.setLocation(253, 290);
		frame.getContentPane().add(button);
		ButtonEvent();
		
		 tree=new AVLTree();
		//初始化节点
		Node n1=new Node();
		n1.setId(7);
		n1.setData("这是插入的第一个结点");
		Node n2=new Node();
		n2.setId(16);	
		Node n3=new Node();
		n3.setId(25);
		Node n4=new Node();
		n4.setId(14);
		Node n5=new Node();
		n5.setId(31);
		Node n6=new Node();
		n6.setId(2);
		Node n7=new Node();
		n7.setId(10);
		
		
		//插入操作
		tree.insert(n1);
		tree.insert(n2);
		tree.insert(n3);
		tree.insert(n4);
		tree.insert(n5);
		tree.insert(n6);
		tree.insert(n7);
		
		
		
		
		
		//get操作
		//System.out.print(tree.get(7).getId()+"");	
		//System.out.println(tree.get(7).getData());
		//System.out.println("前序遍历：");
		//tree.PreOrder();
		//System.out.println(" ");
		jt =  tree.printTree();
		//jt = new JTree();
		jt.setBounds(0, 0, 227, 212);
		//jt.setBounds(0,0,3,2);
		frame.getContentPane().add(jt);
		
		JLabel lblNewLabel = new JLabel("插入节点的id:");
		lblNewLabel.setBounds(304, 164, 109, 26);
		frame.getContentPane().add(lblNewLabel);
		
		MyEvent();
		//
		

	}
	

	
	
	
	private void MyEvent()
	{
		//int j=i+1;
		jt.addMouseListener(new MouseAdapter() {
			   public void mousePressed(MouseEvent e) {
			    if (e.getButton() == MouseEvent.BUTTON3) {  //BUTTON3是鼠标右键
			    	JTree treelist = (JTree)e.getSource();
			      DefaultMutableTreeNode nodeSelected =  (DefaultMutableTreeNode)treelist.getLastSelectedPathComponent();
			      
			      
			      int n = JOptionPane.showConfirmDialog(frame, "确定删除吗?", "标题",JOptionPane.YES_NO_OPTION);
			      if(n==JOptionPane.YES_OPTION)
			      {
			    	  
			    	  
			    	  Node node = (Node)nodeSelected.getUserObject();
			    	  tree.delete(node.getId());			//delete node by id
			    	  //System.out.println(node.getId());
			    	   jt.setVisible(false);
			    	  jt=tree.printTree(); 
			    	  jt.setBounds(0, 0, 227, 212);
			    	  frame.getContentPane().add(jt);
			    	  MyEvent();
			    	  //System.out.println("前序遍历：");
			    	  //tree.PreOrder(); //前序遍历对照
			    	  //System.out.println("");
			      }
 
			    }
			   }
			  });
		
	}
	
	
	private void ButtonEvent()
	{
		button.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				String s = tf.getText();
				int n = JOptionPane.showConfirmDialog(frame, "确定插入吗?", "标题",JOptionPane.YES_NO_OPTION);
				if(n==JOptionPane.YES_OPTION )
				{
					int id = Integer.parseInt(s);
						
						Node node=new Node();
					
					node.setId(id);	
					tree.insert(node);
					jt.setVisible(false);
					jt= tree.printTree();
					jt.setBounds(0, 0, 227, 212);
			    	 frame.getContentPane().add(jt);
			    	 MyEvent();
					}
				
			}
		});
	}
}
	

