import java.awt.BorderLayout;
import java.awt.Container;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;

public class AVLTree implements IAVLTree{
	 private Node root;
  
	    public AVLTree()
	    {
	        root = null;

	    }
	
	    public boolean isEmpty()
	    {
	        return root == null;
	    }
	
	    public Node get(int id)
	    {
	        Node current = root;
	        while (current != null)
	        {
	            if (id < current.getId())
	            {
	                if (current.getChildren()[0] == null)
	                {
	                    break;
	                }
	                else
	                {
	                    current = current.getChildren()[0];
	                }
	            }
	            else if(id > current.getId())
	            {
	                if (current.getChildren()[1] == null)
	                {
	                    break;
	                }
	                else
	                {
	                    current = current.getChildren()[1];
	                }
	            }
	            else
	            	break;
	        }
	        return current;
	    }
	  
	    public void insert(Node newNode)
	    {
	        if (root == null)
	        {
	            root = newNode;
	            return;
	        }
	        Node insertPos = root;
	        while (insertPos != null)
	        {
	            if (newNode.getId() < insertPos.getId())
	            {
	                if (insertPos.getChildren()[0] == null)
	                {
	                    insertPos.setChild(newNode, 0); 
	                    insertPos.bf+= 1;
	                    newNode.setParent(insertPos); 
	                    break;
	                }
	                else
	                {
	                    insertPos = insertPos.getChildren()[0];
	                }
	            }
	            else
	            {
	                if (insertPos.getChildren()[1] == null)
	                {
	                    insertPos.setChild(newNode, 1); 
	                    insertPos.bf -= 1;
	                    newNode.setParent(insertPos);
	                    break;
	                }
	                else
	                {
	                    insertPos = insertPos.getChildren()[1];
	                }
	            }
	        }
	        Node current = insertPos;
	        while (true)
	        {
	            if (current.bf == 0)
	            {
	                return;
	            }
	            else if (current.bf == 1 || current.bf == -1)
	            {
	                if (current == root)
	                {
	                    return;
	                }
	                else if (newNode.getId() < current.getParent().getId())
	                {
	                    current.getParent().bf += 1;
	                }
	                else
	                {
	                    current.getParent().bf -= 1;
	                }
	                current = current.getParent();
	            }
	            else if (current.bf == 2 || current.bf == -2)
	            {
	                if (newNode.getId() < current.getId() && newNode.getId() < current.getChildren()[0].getId())
	                {
	                    rightRotate(current);
	                }
	                else if ( newNode.getId()>= current.getId() && newNode.getId() >= current.getChildren()[1].getId())
	                {
	                    
	                    leftRotate(current);
	                }
	              
	                else if (newNode.getId() < current.getId() && newNode.getId() >= current.getChildren()[0].getId())
	                {
	                    leftRotate(current.getChildren()[0]);
	                    rightRotate(current);
	                }
	                else
	                {
	                    rightRotate(current.getChildren()[1]);
	                    leftRotate(current);
	                }
	               
	                if (current.getParent() == root || current.getParent().bf == 0)
	                {
	                    break;
	                }
	               
	                else
	                {
	                    current = current.getParent().getParent();
	                }
	            }
	        }
	    }
	    
	   
	    public Node delete(int id)
	    {
	        Node current = root;
	        while (current != null)
	        {
	            if (id < current.getId())
	            {
	                current = current.getChildren()[0];
	            }
	            else if (id > current.getId())
	            {
	                current = current.getChildren()[1];
	            }
	            else
	            {
	                int temp = current.getId();
	                Node tempNode = null;
	                if (current.getChildren()[0] != null)
	                {
	                    tempNode = maxNode(current.getChildren()[0]);
	                }
	                else if (current.getChildren()[1] != null)
	                {
	                    tempNode = minNode(current.getChildren()[1]);
	                }
	                if (tempNode != null)
	                {
	                    current.setId(tempNode.getId());
	                    tempNode.setId(temp);
	                    current = tempNode;
	                }
	                if (current == root)
	                {
	                    root = null;
	                   return current;
	                }
	                else if (current == current.getParent().getChildren()[0])
	                {
	                    if (current.getChildren()[0] != null)
	                    {
	                        current.getParent().setChild(current.getChildren()[0], 0);
	                        current.getChildren()[0].setParent(current.getParent());
	                    }
	                    else if (current.getChildren()[1] != null)
	                    {
	                        current.getParent().setChild(current.getChildren()[1], 0);
	                        current.getChildren()[1].setParent(current.getParent());
	                    }
	                    else
	                    {
	                        current.getParent().setChild(null, 0);
	                    }
	                    current.getParent().bf -= 1;
	                }
	                else
	                {
	                    if (current.getChildren()[0] != null)
	                    {
	                        current.getParent().setChild(current.getChildren()[0], 1);
	                        current.getChildren()[0].setParent(current.getParent());
	                    }
	                    else if (current.getChildren()[1] != null)
	                    {
	                        current.getParent().setChild(current.getChildren()[1], 1);
	                        current.getChildren()[1].setParent(current.getParent());
	                    }
	                    else
	                    {
	                        current.getParent().setChild(null, 1);
	                    }
	                    current.getParent().bf += 1;
	                }
	                tempNode = current.getParent();
	                while (true)
	                {
	                    if (tempNode.bf == 1 || tempNode.bf == -1)
	                    {
	                        return current;
	                   }
	                    if (tempNode.bf == 0)
	                    {
	                        if (tempNode == root)
	                        {
	                            return current;
	                        }
	                        else if (tempNode == tempNode.getParent().getChildren()[0])
	                        {
	                            tempNode.getParent().bf -= 1;
	                        }
	                        else
	                        {
	                            tempNode.getParent().bf += 1;
	                        }
	                    }
	                    else
	                    {
	                        if (tempNode.bf >= 0 && tempNode.getChildren()[0].bf >= 0)
	                        {// LL����ת
	                            rightRotate(tempNode);
	                        }
	                        else if (tempNode.bf >= 0 && tempNode.getChildren()[0].bf < 0)
	                        {// LR����ת
	                            leftRotate(tempNode.getChildren()[0]);
	                            rightRotate(tempNode);
	                        }
	                        else if (tempNode.bf < 0 && tempNode.getChildren()[1].bf >= 0)
	                        {// RL����ת
	                            rightRotate(tempNode.getChildren()[1]);
	                            leftRotate(tempNode);
	                        }
	                        else
	                        {// RR����ת
	                            leftRotate(tempNode);
	                        }
	                    }
	                    tempNode = tempNode.getParent();
	                }
	            }
	        }
	        return current;
	    }
	    
	   
	    private Node maxNode(Node root)
	    {
	        Node current = root;
	        while (current != null)
	        {
	            if (current.getChildren()[1] == null)
	            {
	                break;
	            }
	            else
	            {
	                current = current.getChildren()[1];
	            }
	        }
	        return current;
	    }
	    
	 
	    private Node minNode(Node root)
	    {
	        Node current = root;
	        while (current != null)
	        {
	            if (current.getChildren()[0] == null)
	            {
	                break;
	            }
	            else
	            {
	                current = current.getChildren()[0];
	            }
	        }
	        return current;
	    }
	    
	   
	    private void leftRotate(Node node)
	    {
	        // ��ת����
	        if (node.getParent() == null)
	        {
	            root = node.getChildren()[1];
	        }
	        else if (node == node.getParent().getChildren()[0])
	        {
	            node.getParent().setChild(node.getChildren()[1], 0);
	        }
	        else
	        {
	            node.getParent().setChild(node.getChildren()[1], 1);
	        }
	        node.getChildren()[1].setParent(node.getParent());
	        if (node.getChildren()[1].getChildren()[0] != null)
	        {
	            node.getChildren()[1].getChildren()[0].setParent(node);
	        }
	        node.setParent(node.getChildren()[1]);
	        node.setChild(node.getParent().getChildren()[0], 1);
	        node.getParent().setChild(node, 0);
	        if (node.getParent().bf < 0)
	        {
	            node.bf = node.bf - node.getParent().bf + 1;
	        }
	        else
	        {
	            node.bf += 1;
	        }
	        if (node.bf < 0)
	        {
	            node.getParent().bf += 1;
	        }
	        else
	        {
	            node.getParent().bf = node.getParent().bf + node.bf + 1;
	        }
	    }
	    
	    private void rightRotate(Node node)
	    {
	        if (node.getParent() == null)
	        {
	            root = node.getChildren()[0];
	        }
	        else if (node == node.getParent().getChildren()[0])
	        {
	            node.getParent().setChild(node.getChildren()[0], 0);
	        }
	        else
	        {
	            node.getParent().setChild(node.getChildren()[0], 1);
	        }
	        node.getChildren()[0].setParent(node.getParent());
	        if (node.getChildren()[0].getChildren()[1] != null)
	        {
	            node.getChildren()[0].getChildren()[1].setParent(node);
	        }
	        node.setParent(node.getChildren()[0]);
	        node.setChild(node.getParent().getChildren()[1], 0);
	        node.getParent().setChild(node, 1);
	        if (node.getParent().bf >= 0)
	        {
	            node.bf = node.bf - node.getParent().bf - 1;
	        }
	        else
	        {
	            node.bf -= 1;
	        }
	        if (node.bf >= 0)
	        {
	            node.getParent().bf -= 1;
	        }
	        else
	        {
	            node.getParent().bf = node.getParent().bf + node.bf - 1;
	        }
	    }
	  
	    public void middleDisplay()
	    {
	        middleDisplay(root);
	    }
	   
	    private void middleDisplay(Node root)
	    {
	        if (root != null)
	        {
	            middleDisplay(root.getChildren()[0]);
	            root.displayNode();
	            middleDisplay(root.getChildren()[1]);
	        }
	    }
		


		@Override
		public JTree printTree() {
			// TODO �Զ����ɵķ�����
			/*
			JFrame frame = new JFrame();
			   Container contentPane = frame.getContentPane();
			   JPanel panel = new JPanel(new BorderLayout());
			   DefaultMutableTreeNode  root1 = new DefaultMutableTreeNode(get(1).getData());
			   DefaultMutableTreeNode chosen=null;
			   JTree tree = new JTree(root1);
			   panel.add(new JScrollPane(tree),BorderLayout.CENTER);
			   DefaultTreeModel model = (DefaultTreeModel)tree.getModel();
			   DefaultMutableTreeNode child = new DefaultMutableTreeNode(get(1).getData());
				for(int i=0;i<m;i++)
				{
					 child.add(new DefaultMutableTreeNode(get(i).getData()));
					if(chosen == null)
						 chosen = root1;
							 
					 model.insertNodeInto(child, chosen, 0);
				}
			   JPanel panel2 = new JPanel();
			   panel.add(panel2,BorderLayout.SOUTH);
			   contentPane.add(panel);
			   frame.setVisible(true);
			   frame.setSize(300,500);
			   frame.setLocation(400,100);
			   return tree;
			   */
			return null;

		}

}
