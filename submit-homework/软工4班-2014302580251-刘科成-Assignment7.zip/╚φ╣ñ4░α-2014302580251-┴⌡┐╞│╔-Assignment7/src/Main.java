
public class Main {
	public static void main(String[] args){
		Node myNode1=new Node(1,"ant");
		Node myNode2=new Node(2,"apple");
		Node myNode3=new Node(3,"art");
		Node myNode4=new Node(4,"baby");
		Node myNode5=new Node(5,"banana");
		Node myNode6=new Node(6,"car");
		Node myNode7=new Node(7,"door");
		Node myNode8=new Node(8,"dress");
		Node myNode9=new Node(9,"frog");
		Node myNode10=new Node(10,"love");
		Node myNode11=new Node(11,"mint");
		Node myNode12=new Node(12,"rice");
		Node myNode13=new Node(13,"show");
		Node myNode14=new Node(14,"table");
		Node myNode15=new Node(15,"tree");
		Node myNode16=new Node(16,"trouble");
		Node myNode17=new Node(17,"window");
		AVLTree myTree=new AVLTree();
		myTree.insert(myNode1);
		myTree.insert(myNode2);
		myTree.insert(myNode3);
		myTree.insert(myNode4);
		myTree.insert(myNode5);
		myTree.insert(myNode6);
		myTree.insert(myNode7);
		myTree.insert(myNode8);
		myTree.insert(myNode9);
		myTree.insert(myNode10);
		myTree.insert(myNode11);
		myTree.insert(myNode12);
		myTree.insert(myNode13);
		myTree.insert(myNode14);
		myTree.insert(myNode15);
		myTree.insert(myNode16);
		myTree.insert(myNode17);
		
		System.out.println("����ȫ��17���ڵ����������Ľ����");
		myTree.middleDisplay();
		System.out.println();
		
		System.out.println("��ѯ�ڶ����ڵ�����ݣ�");
		System.out.print(myTree.get(2).getId());
		System.out.print(myTree.get(2).getData());
		System.out.println();
		
		myTree.delete(6);
		myTree.delete(4);
		myTree.delete(13);
		System.out.println("ɾ��6,4,13�Žڵ����������Ľ��:");
		myTree.middleDisplay();
		
		//myTree.printTree();
	}

}
