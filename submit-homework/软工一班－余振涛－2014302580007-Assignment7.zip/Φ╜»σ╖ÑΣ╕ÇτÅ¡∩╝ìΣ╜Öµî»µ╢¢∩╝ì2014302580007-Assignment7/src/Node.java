
public class Node {
	private int id;
	private Object data;
	private Node parent;
	private Node lchild;
	private Node rchild;
	private int lSubTreeHeight;
	private int rSubTreeHeight;
	private int balanceFactor;
	
	public Node(){
	}

	public Node(int i,Object data){
		id = i;
		this.data = data;
	}
	
	public int getId() {
		return id;
	}
	public Object getData() {
		return data;
	}
	public void setData(Object data) {
		this.data = data;
	}
	public Node getParent() {
		return parent;
	}
	public void setParent(Node parent) {
		this.parent = parent;
	}
	public int getlSubTreeHeight() {
		//TODO calculate the left sub tree height
		return lSubTreeHeight;
	}
	public int getrSubTreeHeight() {
		//TODO calculate the right sub tree height
		return rSubTreeHeight;
	}
	public int getBalanceFactor() {
		//TODO calculate the balance factor
		return balanceFactor;
	}
	public Node getLchild() {
		return lchild;
	}
	public void setLchild(Node lchild) {
		this.lchild = lchild;
	}
	public Node getRchild() {
		return rchild;
	}
	public void setRchild(Node rchild) {
		this.rchild = rchild;
	}
	public void setId(int id) {
		this.id = id;
	}
	public void setlSubTreeHeight(int lSubTreeHeight) {
		this.lSubTreeHeight = lSubTreeHeight;
	}
	public void setrSubTreeHeight(int rSubTreeHeight) {
		this.rSubTreeHeight = rSubTreeHeight;
	}
	public void setBalanceFactor(int balanceFactor) {
		this.balanceFactor = balanceFactor;
	}
	

}
