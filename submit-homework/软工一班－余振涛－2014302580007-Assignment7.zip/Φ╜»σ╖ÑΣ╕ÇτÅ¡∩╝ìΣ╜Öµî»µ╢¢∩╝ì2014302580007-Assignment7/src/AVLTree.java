import javax.swing.JFrame;
import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;

public class AVLTree implements IAVLTree {

	private Node root = null;
	private boolean unbalanced;

	@Override
	public Node get(int id) {
		// TODO Auto-generated method stub
		Node p = new Node();
		p = root;
		while (p != null) {
			if (id < p.getId())
				p = p.getLchild();
			else if (id > p.getId())
				p = p.getRchild();
			else {
				id = p.getId();
				System.out.println("Found it");
				return p;
			}
		}
		System.out.println("Not found!");
		return null;
	}

	@Override
	public void insert(Node newNode) {
		// TODO Auto-generated method stub
		if (root == null) {
			root = newNode;
		} else
			insert(root, newNode);

	}

	private Node insert(Node p, Node newNode) {

		if (p == null) {
			p = newNode;
			unbalanced = true;
		} else if (newNode.getId() == p.getId())
			System.out.println("Existed");
		else if (newNode.getId() < p.getId()) {
			if (p.getLchild() == null) {
				p.setLchild(newNode);
				newNode.setParent(p);
			} else {
				insert(p.getLchild(), newNode);
			}
			if (unbalanced)
				switch (p.getBalanceFactor()) {
				case -1:
					p.setBalanceFactor(0);
					unbalanced = false;
					break;
				case 0:
					p.setBalanceFactor(1);
					break;
				case 1:
					LRotation(p, unbalanced);
				}
		} else {
			if (p.getRchild() == null) {
				p.setRchild(newNode);
				newNode.setParent(p);
			} else {
				insert(p.getRchild(), newNode);
			}
			if (unbalanced)
				switch (p.getBalanceFactor()) {
				case 1:
					p.setBalanceFactor(0);
					unbalanced = false;
					break;
				case 0:
					p.setBalanceFactor(-1);
					break;
				case -1:
					RRotation(p, unbalanced);
				}
		}
		return p;
	}

	@Override
	public void delete(int id) {
		// TODO Auto-generated method stub	
		Node p = new Node();
		p = get(id);
		if (p != null) {
			if (p.getLchild() != null && p.getRchild() != null) {
				Node s = new Node();
				s = null;
				int i = id + 1;
				while (s==null&&i<99) {
					s = get(i);
					i++;
				}
				p.setId(s.getId());
				p.setData(s.getData());
				id = i;
				p = s;
			}
			if (p == root){
				if (root.getLchild() != null) {
					root.getLchild().setParent(null);
					root = root.getLchild();
				} else if (root.getRchild() != null) {
					root.getRchild().setParent(null);
					root = root.getRchild();
				} else {
					if (p.getParent().getBalanceFactor()==1&& p.getParent().getLchild() == p)
					{
						delete(p);		
						while(p.getParent().getBalanceFactor()<=1&&p.getParent().getBalanceFactor()>=-1){
							p=p.getParent();
							if(p.getParent()==null) break;
						}
						if(p.getParent()!=null){
							if(p.getParent().getBalanceFactor()==-2) RRotation(p.getParent(),true);
							else if(p.getParent().getBalanceFactor()==2) LRotation(p.getParent(),true);
						}
					}else if(p.getParent().getBalanceFactor()==-1&&p.getParent().getRchild()==p){
						delete(p);
						while(p.getParent().getBalanceFactor()<=1&&p.getParent().getBalanceFactor()>=-1){
							p=p.getParent();
							if(p.getParent()==null) break;
						}
						if(p.getParent()!=null){
							if(p.getParent().getBalanceFactor()==-2){
								RRotation(p.getParent(),true);
							}else if(p.getParent().getBalanceFactor()==2){
								LRotation(p.getParent(),true);
							}
						}
						}else if(p.getParent().getBalanceFactor()==0){
							delete(p);
					}else if(p.getParent().getBalanceFactor()==1&&p.getParent().getRchild()==p){
						delete(p);
						while(p.getParent().getBalanceFactor()<=1&&p.getParent().getBalanceFactor()>=-1){
							p=p.getParent();
							if(p.getParent()==null) break;
						}
						if(p.getParent()!=null){
							if(p.getParent().getBalanceFactor()==-2) RRotation(p.getParent(),true);
							else if(p.getParent().getBalanceFactor()==2) LRotation(p.getParent(),true);
						}
					}else if(p.getParent().getBalanceFactor()==-1&&p.getParent().getLchild()==p){
						delete(p);
						while(p.getParent().getBalanceFactor()<=1&&p.getParent().getBalanceFactor()>=-1){
							p=p.getParent();
							if(p.getParent()==null) break;
						}
						if(p.getParent()!=null){}
						if(p.getParent().getBalanceFactor()==-2) RRotation(p.getParent(),true);
						else if(p.getParent().getBalanceFactor()==2) LRotation(p.getParent(),true);
					}
				}
			}
		}
	}

	void delete(Node n) {
		if(n.getId()<n.getParent().getId()){
			if(n.getLchild()!=null){
				n.getLchild().setParent(n.getParent());
				n.getParent().setLchild(n.getLchild());
				n= n.getLchild();	
			}else if(n.getRchild()!=null){
				n.getRchild().setParent(n.getParent());
				n.getParent().setRchild(n.getRchild());
				n= n.getRchild();
			}else{
				n = n.getParent();
				n.setLchild(null);
			}
		}
		else if (n.getId()>n.getParent().getId()){
			if(n.getLchild()!=null){
				n.getLchild().setParent(n.getParent());
				n.getParent().setRchild(n.getLchild());
				n=n.getLchild();
			}else if(n.getRchild()!=null){
				n.getRchild().setParent(n.getParent());
				n.getParent().setRchild(n.getRchild());
				n=n.getRchild();
			}else{
				n= n.getParent();
				n.setRchild(null);
			}
		}
	}

	@Override
	public JTree printTree() {
		// TODO Auto-generated method stub
		JTree tree = new JTree(make(root));
		JFrame frame = new JFrame("AVLTREE");
		frame.add(tree);
		frame.setSize(400, 400);
		frame.setVisible(true);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		return null;
	}
	private DefaultMutableTreeNode make(Node p){
		DefaultMutableTreeNode node = new DefaultMutableTreeNode(p.getData());
		if(p.getLchild()!=null)
			node.add(make(p.getLchild()));
		if(p.getRchild()!=null)
			node.add(make(p.getRchild()));
		
		return node;
		
	}
	
	public void RRotation(Node s,boolean ub) {
		System.out.println("绕" + s + "右旋");

		Node u = new Node();
		Node r = new Node();
		r = s.getRchild();
		if (r.getBalanceFactor() == -1) {
			s.setRchild(r.getLchild());
			r.setLchild(s);
			s.setBalanceFactor(0);
			s = r;
		} else {
			u = r.getLchild();
			r.setLchild(u.getRchild());
			s.setRchild(u.getLchild());
			u.setRchild(r);
			u.setLchild(s);
			switch (u.getBalanceFactor()) {
			case 1:
				s.setBalanceFactor(0);
				r.setBalanceFactor(-1);
				break;
			case 0:
				s.setBalanceFactor(0);
				r.setBalanceFactor(0);
				break;
			case -1:
				s.setBalanceFactor(1);
				r.setBalanceFactor(0);
			}
			s = u;
		}
		s.setBalanceFactor(0);
		ub = false;
	}
	
	public void LRotation(Node s,boolean ub){
		System.out.println("绕"+s+"左旋");
		Node u = new Node();
		Node r = new Node();
		r=s.getLchild();
		if(r.getBalanceFactor()==1){
			s.setLchild(r.getRchild());
			r.setRchild(s);
			s.setBalanceFactor(0);
			s=r;
		}else{
			u=r.getRchild();
			r.setRchild(u.getLchild());
			s.setLchild(u.getRchild());
			u.setLchild(r);
			u.setRchild(s);
			switch(u.getBalanceFactor()){
			case 1:
				s.setBalanceFactor(-1);
				r.setBalanceFactor(0);
				break;
			case 0:
				s.setBalanceFactor(0);
				r.setBalanceFactor(0);
				break;
			case -1:
				s.setBalanceFactor(0);
				r.setBalanceFactor(1);
			}
			s=u;
		}
		s.setBalanceFactor(0);
		ub = false ;
	}
}
