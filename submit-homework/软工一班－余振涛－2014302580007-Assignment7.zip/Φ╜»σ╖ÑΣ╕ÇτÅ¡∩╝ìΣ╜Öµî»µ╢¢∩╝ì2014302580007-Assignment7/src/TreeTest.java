
public class TreeTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AVLTree myTree = new AVLTree();
		Node node0 = new Node(1,"a");
		Node node1 = new Node(0,"b");
		Node node2 = new Node(7,"c");
		Node node3 = new Node(8,"d");
		Node node4 = new Node(-2,"e");
		Node node5 = new Node(3,"f");
		Node node6 = new Node(9,"g");
		
		myTree.insert(node0);
		myTree.insert(node1);
		myTree.insert(node2);
		myTree.insert(node3);
		myTree.insert(node4);
		myTree.insert(node5);
		myTree.insert(node6);
		myTree.printTree();
		//get操作
		Node temp = new Node();
		temp=myTree.get(1);
		System.out.println("The ID is:"+temp.getId());
		System.out.println("The data is:"+temp.getData());
		
		//insert操作
		Node a = new Node(4,"h");
		Node b = new Node(-8,"i");
		Node c = new Node(52,"j");
		Node d = new Node(5,"k");
		myTree.insert(a);
		myTree.insert(b);
		myTree.insert(c);
		myTree.insert(d);
		myTree.printTree();
	
		//delete操作
		myTree.delete(a);
		myTree.delete(b);
		myTree.delete(c);
		myTree.printTree();
		
	}

}
