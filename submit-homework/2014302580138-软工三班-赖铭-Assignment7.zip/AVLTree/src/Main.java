import javax.swing.*;
import java.io.*;

/**
 * Created by lai on 12/18/15.
 */

public class Main {

    public static void printTree(JTree tree){
        JFrame f = new JFrame("AVLTree");
        f.add(tree);
        f.setSize(300, 300);
        f.setVisible(true);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    public static void readTree(AVLTree tree, String url){
        File file = new File(url);

        Reader reader;
        String s;
        try{
            reader = new InputStreamReader(new FileInputStream(file));
            BufferedReader bufferedReader = new BufferedReader(reader);

            while ((s = bufferedReader.readLine()) != null){
                String[] ch = s.split("#");
                Node node = new Node(ch[0],Integer.parseInt(ch[1]));
                tree.insert(node);
            }
        }
        catch (Exception e){
        }
    }

    public static void main(String args[]){
        BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("文件所在路径: ");
        String url = "";
        try {
            url = in.readLine();
        } catch (IOException e) {
            e.printStackTrace();
        }

        AVLTree tree = new AVLTree();
        readTree(tree, url);

        printTree(tree.printTree());
        tree.delete(8);
        printTree(tree.printTree());
    }
}
