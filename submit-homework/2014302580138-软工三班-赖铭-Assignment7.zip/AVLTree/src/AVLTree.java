import javax.swing.JTree;


public class AVLTree implements IAVLTree{
	private Node root = new Node();
	
	public Node get(int id){
		return getNode(root, id);
	}
	
	public Node getNode(Node n, int id){
		Node lChild = n.getLChild();
		Node
		Node lNode = null, rNode = null;
		if (children[0].getId() == id){
			return children[0];
		}
		if (children[1].getId() == id){
			return children[1];
		}
		if (children[0] != null){
			lNode = getNode(children[0], id);
		}
		if (children[1] != null){
			rNode =  getNode(children[1], id);
		}
		if (lNode != null) return lNode;
		if (rNode != null) return rNode;
		return null;
	}
	
	public void insert(Node newNode){
		
	}
	
	public void delete(int id){
		
	}
	
	public JTree printTree(){
		return new JTree();
	}

}
