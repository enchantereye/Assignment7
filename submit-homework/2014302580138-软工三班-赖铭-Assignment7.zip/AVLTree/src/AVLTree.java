import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.TreeNode;
import javax.swing.tree.TreePath;
import java.util.Enumeration;

public class AVLTree implements IAVLTree{
    private Node root = null;

    public Node get(int id){
        return getNode(root, id);
    }

    public Node getNode(Node n, int id){
        if (n.getId() == id) return n;

        Node lChild = n.getLChild();
        Node rChild = n.getRChild();
        Node lNode = null, rNode = null;

        if (lChild != null){
            if (lChild.getId() == id) return lChild;
            lNode = getNode(lChild, id);
        }
        if (rChild != null){
            if (rChild.getId() == id) return rChild;
            rNode =  getNode(rChild, id);
        }

        if (lNode != null) return lNode;
        if (rNode != null) return rNode;

        return null;
    }

    public void insert(Node newNode){
        if (root == null)
            root = newNode;
        else
            insertNode(newNode, root);
    }

    public int insertNode(Node newNode, Node r){
        if (newNode.getId() == r.getId()) return max(r.getlSubTreeHeight(), r.getrSubTreeHeight());

        if (newNode.getId() > r.getId()){
            if (r.getRChild() == null){
                r.setRChild(newNode);

            }
            else{
                r.setrSubTreeHeight(insertNode(newNode, r.getRChild())+1);
            }
        }
        else{
            if (r.getLChild() == null){
                r.setLChild(newNode);
            }
            else{
                r.setlSubTreeHeight(insertNode(newNode, r.getLChild())+1);
            }
        }
        if (r.getBalanceFactor() > 1 || r.getBalanceFactor() < -1) toBalance(r);
        return max(r.getlSubTreeHeight(), r.getrSubTreeHeight());
    }

    public void delete(int id){
        System.out.println(id);
        Node node = get(id);
        if (node != null){
            if (node.getLChild() != null && node.getRChild() != null){
                boolean flag = false;
                Node n = node.getRChild();
                while (n.getLChild() != null){
                    n = n.getLChild();
                    flag = true;
                }

                Object d = n.getData();
                n.setData(node.getData());
                node.setData(d);

                int x = n.getId();
                n.setId(node.getId());
                node.setId(x);

                if (flag){
                    n.getParent().setLChild(null);
                }
                else{
                    n.getParent().setRChild(null);
                }
                return;
            }

            Node parent = node.getParent();
            if (node.getLChild() != null && node.getRChild() == null){

                if (parent.getLChild() != null && node.getId() == parent.getLChild().getId()) parent.setLChild(node.getLChild());
                if (parent.getRChild() != null && node.getId() == parent.getRChild().getId()) parent.setRChild(node.getLChild());
            }

            if (node.getRChild() != null && node.getLChild() == null){
                if (parent.getLChild() != null && node.getId() == parent.getLChild().getId()) parent.setLChild(node.getRChild());
                if (parent.getRChild() != null && node.getId() == parent.getRChild().getId()) parent.setRChild(node.getRChild());
            }

            if (node.getLChild() == null && node.getRChild() == null){
                if (parent.getLChild() != null && node.getId() == parent.getLChild().getId()) parent.setLChild(null);
                if (parent.getRChild() != null && node.getId() == parent.getRChild().getId()) parent.setRChild(null);
            }

            while (parent != null){
                node = parent.getLChild();
                if (node != null)
                    parent.setlSubTreeHeight(node.getTreeHeight());
                else
                    parent.setlSubTreeHeight(0);

                node = parent.getRChild();
                if (node != null)
                    parent.setrSubTreeHeight(node.getTreeHeight());
                else
                    parent.setrSubTreeHeight(0);
                if (parent.getBalanceFactor() > 1 || parent.getBalanceFactor() < -1) toBalance(parent);
                parent = parent.getParent();
            }
        }

    }

    public JTree printTree(){
        if (root == null) return new JTree();
        DefaultMutableTreeNode rootNode = new DefaultMutableTreeNode(root.getData()+" "+Integer.toString(root.getId()));
        createTree(rootNode, root);
        JTree tree = new JTree(rootNode);
        expandTree(tree);
        return tree;
    }

    public void createTree(DefaultMutableTreeNode node, Node r){
        if (r == null) return ;

        if (r.getRChild() != null){
            DefaultMutableTreeNode rNode = new DefaultMutableTreeNode(r.getRChild().getData()+" "+Integer.toString(r.getRChild().getId()));
            createTree(rNode, r.getRChild());
            node.add(rNode);
        }
        else{
            DefaultMutableTreeNode lNode = new DefaultMutableTreeNode(null);
            node.add(lNode);
        }
        if (r.getLChild() != null){
            DefaultMutableTreeNode lNode = new DefaultMutableTreeNode(r.getLChild().getData()+" "+Integer.toString(r.getLChild().getId()));
            createTree(lNode, r.getLChild());
            node.add(lNode);
        }
        else{
            DefaultMutableTreeNode lNode = new DefaultMutableTreeNode(null);
            node.add(lNode);
        }
    }

    public int max(int a, int b){
        if (a > b) return a;
        return b;
    }

    public void toBalance(Node r){
        Node parent = r.getParent();
        Boolean flag = true;
        if (parent != null) {
            if (parent.getRChild() == r) flag = false;
        }

        Node a, b, c;
        if (r.getBalanceFactor() == 2){
            a = r.getLChild();

            if (a.getBalanceFactor() == 1){
                c = a.getRChild();
                a.setParent(null);
                r.setLChild(c);
                a.setRChild(r);
                if (parent != null){
                    if (flag){
                        parent.setLChild(a);
                    }
                    else{
                        parent.setRChild(a);
                    }
                }
                else{
                    root = a;
                }
            }
            else {
                b = a.getRChild();
                b.setParent(null);

                c = b.getRChild();
                r.setLChild(c);
                b.setRChild(r);


                c = b.getLChild();
                a.setRChild(c);
                b.setLChild(a);

                if (parent != null){
                    if (flag){
                        parent.setLChild(b);
                    }
                    else{
                        parent.setRChild(b);
                    }
                }
                else{
                    root = b;
                }
            }
        }
        else {
            a = r.getRChild();
            if (a.getBalanceFactor() == -1){
                c = a.getLChild();
                a.setParent(null);
                r.setRChild(c);
                a.setLChild(r);

                if (parent != null){
                    if (flag){
                        parent.setLChild(a);
                    }
                    else{
                        parent.setRChild(a);
                    }
                }
                else{
                    root = a;
                }
            }
            else {

                b = a.getLChild();
                b.setParent(null);

                c = b.getRChild();
                a.setLChild(c);
                b.setRChild(a);

                c = b.getLChild();
                r.setRChild(c);
                b.setLChild(r);

                if (parent != null){
                    if (flag){
                        parent.setLChild(b);
                    }
                    else{
                        parent.setRChild(b);
                    }
                }
                else{
                    root = b;
                }
            }
        }
    }

    public static void expandTree(JTree tree) {
        TreeNode root = (TreeNode) tree.getModel().getRoot();
        expandAll(tree, new TreePath(root), true);
    }

    private static void expandAll(JTree tree, TreePath parent, boolean expand) {
        // Traverse children
        TreeNode node = (TreeNode) parent.getLastPathComponent();
        if (node.getChildCount() >= 0) {
            for (Enumeration e = node.children(); e.hasMoreElements(); ) {
                TreeNode n = (TreeNode) e.nextElement();
                TreePath path = parent.pathByAddingChild(n);
                expandAll(tree, path, expand);
            }
        }

        // Expansion or collapse must be done bottom-up
        if (expand) {
            tree.expandPath(parent);
        } else {
            tree.collapsePath(parent);
        }
    }
}
