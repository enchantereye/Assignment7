
public class Node {
    private int id = -100000;
    private Object data = null;
    private Node parent = null;
    private Node lChild = null;
    private Node rChild = null;
    private int lSubTreeHeight = 0;
    private int rSubTreeHeight = 0;
    private int balanceFactor = 0;

    public Node(Object data, int id){
        this.data = data;
        this.id = id;
    }

    public int getTreeHeight() {
        if (lSubTreeHeight > rSubTreeHeight){
            return lSubTreeHeight + 1;
        }
        else{
            return rSubTreeHeight + 1;
        }
    }
    public int getId(){ return this.id; }
    public void setId(int id){ this.id = id; }
    public Object getData() {
        return data;
    }
    public void setData(Object data) {
        this.data = data;
    }
    public Node getParent() {
        return parent;
    }
    public void setParent(Node parent) {
        this.parent = parent;
    }
    public Node getLChild() {
        return lChild;
    }
    public Node getRChild() {
        return rChild;
    }
    public void setLChild(Node child){
        this.lChild = child;
        if (child == null) {
            setlSubTreeHeight(0);
            return;
        }
        setlSubTreeHeight(child.getTreeHeight());
        child.setParent(this);
    }
    public void setRChild(Node child){
        this.rChild = child;
        if (child == null){
            setrSubTreeHeight(0);
            return;
        }
        setrSubTreeHeight(child.getTreeHeight());
        child.setParent(this);
    }
    public int getlSubTreeHeight() {
        //TODO calculate the left sub tree height
        return lSubTreeHeight;
    }
    public int getrSubTreeHeight() {
        //TODO calculate the right sub tree height
        return rSubTreeHeight;
    }
    public void setlSubTreeHeight(int height) {
        //TODO calculate the left sub tree height
        lSubTreeHeight = height;
        balanceFactor = lSubTreeHeight - rSubTreeHeight;
    }
    public void setrSubTreeHeight(int height) {
        //TODO calculate the right sub tree height
        rSubTreeHeight = height;
        balanceFactor = lSubTreeHeight - rSubTreeHeight;
    }
    public int getBalanceFactor() {
        //TODO calculate the balance factor
        return balanceFactor;
    }

}