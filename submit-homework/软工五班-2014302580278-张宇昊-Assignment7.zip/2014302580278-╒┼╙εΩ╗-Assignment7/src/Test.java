import javax.swing.JTree;
import javax.swing.tree.TreeNode;
import javax.swing.tree.TreePath;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.Enumeration;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class Test {
		static JFrame mainJF;
		static JTextField text;
		static AVLTree tree = new AVLTree();
		static JPanel panel;
		static JPanel panel2;
		static JButton insert;
		static JButton delete;
		static JButton find;
		static JScrollPane pane; 

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*Node temp = new Node(1,getDataById(1));
    	Node temp2 = new Node(2,getDataById(2));
    	Node temp7 = new Node(7,getDataById(7));
		tree.insert(7, temp7);
		tree.insert(1, temp);
		tree.insert(2, temp2);*/
		//tree.delete(1);
		//tree.insert(2, temp2);
		
		mainJF = new JFrame("AVLTree");
		
		mainJF.setBounds(300, 100, 700, 600);
		mainJF.setLayout(new GridLayout(1,2));
		mainJF.setResizable(false);
		mainJF.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		mainJF.setVisible(true);
		
		JOptionPane.showMessageDialog(mainJF.getContentPane(),
				"输入id编号后点击插入、删除或查询", "提示", JOptionPane.INFORMATION_MESSAGE);
		panel = new JPanel(new GridLayout());
        mainJF.add(panel);
        panel.setBounds(0, 0, 350, 600);
		panel.setVisible(true);
		
		pane = new JScrollPane();
        panel.add(pane);
        pane.setBounds(0, 0, 350, 600);
		//pane.getViewport().add(tree.printTree());
		
		
        
		panel2 = new JPanel();
		mainJF.add(panel2);
		panel2.setBounds(350, 0, 350, 600);
		
        text = new JTextField();
		panel2.add(text);
		text.setVisible(true);
		text.setBounds(130, 200, 200, 20);
		text.requestFocusInWindow();
		text.setText("");

		insert = new JButton("insert");
		panel2.add(insert);
		insert.setVisible(true);
		insert.setBounds(170, 300, 100, 40);
		insert.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent actionEvent)
            {
            	int id = Integer.parseInt(text.getText());
            	Node temp = new Node(id, getDataById(id));
            	tree.insert(id, temp);
            	
        		panel = new JPanel();
                mainJF.add(panel);
        		panel.setBounds(0, 0, 350, 600);
        		panel.setVisible(true);
        		
        		pane = new JScrollPane();
                panel.add(pane);
                pane.setBounds(0, 0, 350, 600);
            	pane.getViewport().removeAll();
        		pane.getViewport().add(tree.printTree());
            	text.setText("");
        		text.requestFocusInWindow();
            }
        });

		delete = new JButton("delete");
		panel2.add(delete);
		delete.setVisible(true);
		delete.setBounds(170, 380, 100, 40);
		delete.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent actionEvent)
            {
            	int id = Integer.parseInt(text.getText());
            	tree.delete(id);

        		panel = new JPanel();
                mainJF.add(panel);
        		panel.setBounds(0, 0, 350, 600);
        		panel.setVisible(true);
        		
        		pane = new JScrollPane();
                panel.add(pane);
                pane.setBounds(0, 0, 350, 600);
            	pane.getViewport().removeAll();
        		pane.getViewport().add(tree.printTree());
            	text.setText("");
        		text.requestFocusInWindow();            	
            }
        });
		
		find = new JButton("find");
		panel2.add(find);
		find.setVisible(true);
		find.setBounds(170, 460, 100, 40);
		find.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent actionEvent)
            {
            	int id = Integer.parseInt(text.getText());
            	Node n = tree.get(id); 
            	System.out.print(tree.root == null);
            	if(n == null)
            		JOptionPane.showMessageDialog(mainJF.getContentPane(),
            				"未在现有树中查询到", "提示", JOptionPane.INFORMATION_MESSAGE);
            	else
            		JOptionPane.showMessageDialog(mainJF.getContentPane(),
            				"编号为"+id +"的结点存在于树中，具体数据为"+n.data, "提示", JOptionPane.INFORMATION_MESSAGE);
            	text.setText("");
        		text.requestFocusInWindow();
            }
        });
	}
	
    
	//范例中由id获得data
	public static String getDataById(int id){
		String a = "";
		switch(id){
		case 1:
			a = "ant";
			break;
		case 2:
			a = "apple";
			break;
		case 3:
			a = "art";
			break;
		case 4:
			a = "baby";
			break;
		case 5:
			a = "banana";
			break;
		case 6:
			a = "car";
			break;
		case 7:
			a = "door";
			break;
		case 8:
			a = "dress";
			break;
		case 9:
			a = "frog";
			break;
		case 10:
			a = "love";
			break;
		case 11:
			a = "mint";
			break;
		case 12:
			a = "rice";
			break;
		case 13:
			a = "show";
			break;
		case 14:
			a = "table";
			break;
		case 15:
			a = "tree";
			break;
		case 16:
			a = "trouble";
			break;
		case 17:
			a = "window";
			break;
		}
		return a;
	}

}
