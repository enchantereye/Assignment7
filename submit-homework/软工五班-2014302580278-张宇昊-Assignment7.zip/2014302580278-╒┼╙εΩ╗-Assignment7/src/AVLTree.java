import java.util.Enumeration;

import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.TreeNode;
import javax.swing.tree.TreePath;

public class AVLTree implements IAVLTree {
	private JTree tree;
	DefaultMutableTreeNode jRoot;
	protected Node root;

	@Override
	public Node get(int id) {
		// TODO Auto-generated method stub
		/*if (root == null)
			return null;
		else{
			if(root.key == id) return root;
			else{
				if(root.left != null){
					AVLTree tempLTree = new AVLTree();
					tempLTree.root = root.left;
					return tempLTree.get(id);
				}
				if(root.right != null){
					AVLTree tempRTree = new AVLTree();
					tempRTree.root = root.right;
					return tempRTree.get(id);
				}
			}
		}*/ 

        Node t = root;
        int difference;

        while (t != null) {
            difference = id - t.key;
            if (difference < 0) {
                t = t.left;
            } else if (difference > 0) {
                t = t.right;
            } else {
                return t;
            }
        }

        return null;
	}

	@Override
	public void insert(int id, Node newNode) {
		// TODO Auto-generated method stub
		Node n = new Node(id, newNode.data);
		insertAVL(this.root, n);
	}

	public void insertAVL(Node p, Node q) {
		if (p == null) {
			this.root = q;
		} else {
			if (q.key < p.key) {
				if (p.left == null) {
					p.left = q;
					q.parent = p;

					recursiveBalance(p);
				} else {
					insertAVL(p.left, q);
				}

			} else if (q.key > p.key) {
				if (p.right == null) {
					p.right = q;
					q.parent = p;

					recursiveBalance(p);
				} else {
					insertAVL(p.right, q);
				}
			} else {
			}
		}
	}

	public void recursiveBalance(Node cur) {
		setBalance(cur);
		int balance = cur.balance;

		if (balance == -2) {
			if (height(cur.left.left) >= height(cur.left.right)) {
				cur = rotateRight(cur);
			} else {
				cur = doubleRotateLeftRight(cur);
			}
		} else if (balance == 2) {
			if (height(cur.right.right) >= height(cur.right.left)) {
				cur = rotateLeft(cur);
			} else {
				cur = doubleRotateRightLeft(cur);
			}
		}

		if (cur.parent != null) {
			recursiveBalance(cur.parent);
		} else {
			this.root = cur;
		}
	}

	@Override
	public void delete(int id) {
		// TODO Auto-generated method stub
		removeAVL(this.root, id);
	}

	public void removeAVL(Node p, int q) {
		if (p == null) {
			return;
		} else {
			if (p.key > q) {
				removeAVL(p.left, q);
			} else if (p.key < q) {
				removeAVL(p.right, q);
			} else if (p.key == q) {
				removeFoundNode(p);
			}
		}
	}

	public void removeFoundNode(Node q) {
		Node r;
		if (q.left == null || q.right == null) {
			// the root is deleted
			if (q.parent == null) {
				this.root = null;
				q = null;
				return;
			}
			r = q;
		} else {
			r = successor(q);
			q.key = r.key;
		}

		Node p;
		if (r.left != null) {
			p = r.left;
		} else {
			p = r.right;
		}

		if (p != null) {
			p.parent = r.parent;
		}

		if (r.parent == null) {
			this.root = p;
		} else {
			if (r == r.parent.left) {
				r.parent.left = p;
			} else {
				r.parent.right = p;
			}
			recursiveBalance(r.parent);
		}
		r = null;
	}

	public Node rotateLeft(Node n) {

		Node v = n.right;
		v.parent = n.parent;

		n.right = v.left;

		if (n.right != null) {
			n.right.parent = n;
		}

		v.left = n;
		n.parent = v;

		if (v.parent != null) {
			if (v.parent.right == n) {
				v.parent.right = v;
			} else if (v.parent.left == n) {
				v.parent.left = v;
			}
		}

		setBalance(n);
		setBalance(v);

		return v;
	}

	public Node rotateRight(Node n) {

		Node v = n.left;
		v.parent = n.parent;

		n.left = v.right;

		if (n.left != null) {
			n.left.parent = n;
		}

		v.right = n;
		n.parent = v;

		if (v.parent != null) {
			if (v.parent.right == n) {
				v.parent.right = v;
			} else if (v.parent.left == n) {
				v.parent.left = v;
			}
		}

		setBalance(n);
		setBalance(v);

		return v;
	}

	public Node doubleRotateLeftRight(Node u) {
		u.left = rotateLeft(u.left);
		return rotateRight(u);
	}

	public Node doubleRotateRightLeft(Node u) {
		u.right = rotateRight(u.right);
		return rotateLeft(u);
	}

	public Node successor(Node q) {
		if (q.right != null) {
			Node r = q.right;
			while (r.left != null) {
				r = r.left;
			}
			return r;
		} else {
			Node p = q.parent;
			while (p != null && q == p.right) {
				q = p;
				p = q.parent;
			}
			return p;
		}
	}

	private int height(Node cur) {
		if (cur == null) {
			return -1;
		}
		if (cur.left == null && cur.right == null) {
			return 0;
		} else if (cur.left == null) {
			return 1 + height(cur.right);
		} else if (cur.right == null) {
			return 1 + height(cur.left);
		} else {
			return 1 + maximum(height(cur.left), height(cur.right));
		}
	}

	private int maximum(int a, int b) {
		if (a >= b) {
			return a;
		} else {
			return b;
		}
	}

	private void setBalance(Node cur) {
		cur.balance = height(cur.right) - height(cur.left);
	}

	@Override
	public JTree printTree() {
		// TODO Auto-generated method stub
		tree = new JTree(turnIntoJTree(root));
		if(root != null)
			expandTree(tree);
		return tree;
	}

	// 将平衡二叉树转变为JTree以便图像输出
	private DefaultMutableTreeNode turnIntoJTree(Node node) {
		DefaultMutableTreeNode jTreeRoot = new DefaultMutableTreeNode();
		if (node == null)
			return null;
		jTreeRoot.setUserObject(node.key + ":" + node.data);

		DefaultMutableTreeNode leftSub = turnIntoJTree(node.left);
		DefaultMutableTreeNode rightSub = turnIntoJTree(node.right);
		if (leftSub != null)
			jTreeRoot.add(leftSub);
		if (rightSub != null)
			jTreeRoot.add(rightSub);

		return jTreeRoot;
	}

    public static void expandTree(JTree tree)
    {
        TreeNode root = (TreeNode) tree.getModel().getRoot();
        expandAll(tree, new TreePath(root), true);
    }

    private static void expandAll(JTree tree, TreePath parent, boolean expand)
    {
        TreeNode node = (TreeNode) parent.getLastPathComponent();
        if (node.getChildCount() >= 0) {
            for (Enumeration e = node.children(); e.hasMoreElements(); )
            {
                TreeNode n = (TreeNode) e.nextElement();
                TreePath path = parent.pathByAddingChild(n);
                expandAll(tree, path, expand);
            }
        }
        if (expand)
        {
            tree.expandPath(parent);
        }
        else
        {
            tree.collapsePath(parent);
        }
    }
}
