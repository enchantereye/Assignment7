
public class Node {
		 public Node left;
		 public Node right;
		 public Node parent;
		 public int key;
		 public int balance;
		 public String data;

		 public Node(int k, String dat) {
		  left = right = parent = null;
		  balance = 0;
		  key = k;
		  data = dat;
		 }
		 public String toString() {
		  return "" + key;
		 }

		
	/*private int id;
	private Object data;
	private Node parent;
	private Node[] children = new Node[2];
	private int lSubTreeHeight;
	private int rSubTreeHeight;
	private int balanceFactor;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public Object getData() {
		return data;
	}
	public void setData(Object data) {
		this.data = data;
	}
	public Node getParent() {
		return parent;
	}
	public void setParent(Node parent) {
		this.parent = parent;
	}
	public Node[] getChildren() {
		return children;
	}
	public void setChildren(Node[] children) {
		this.children = children;
	}
	public void setChild(Node child, int id){
		this.children[id] = child;
	}
	public int getlSubTreeHeight() {
		//TODO calculate the left sub tree height
		lSubTreeHeight = 0;
		if(this.children[0] != null)
			lSubTreeHeight = getSubTreeHeight(this.children[0]);
		return lSubTreeHeight;
	}
	public int getrSubTreeHeight() {
		rSubTreeHeight = 0;
		//TODO calculate the right sub tree height
		if(this.children[1] != null)
			rSubTreeHeight = getSubTreeHeight(this.children[1]);
		return rSubTreeHeight;
	}
	
	//计算以结点为根的子树高度
	private int getSubTreeHeight(Node n) {
		if (n == null)
			return 0;
		else
		{
			//计算子树高度
			int lheight = getSubTreeHeight(n.children[0]);
			int rheight = getSubTreeHeight(n.children[1]);

			//选取较大者
			if (lheight > rheight)
				return(lheight + 1);
			else return(rheight + 1);
		}
	}
	
	public int getBalanceFactor() {
		//TODO calculate the balance factor
		balanceFactor = getlSubTreeHeight() - getrSubTreeHeight();
		return balanceFactor;
	}*/
}
