package avl.imple;

import javax.swing.*;
import javax.swing.tree.DefaultMutableTreeNode;

import avl.inter.IAVLTree;


public class AVLTree implements IAVLTree {
    private Node root;  //树的根
   
    public AVLTree() {
        root = null;
    }
        @Override
    public Node get(int id) {
        	Node a = root;
        	while (a != null && id != a.getId()) {
				if(id < a.getId()){
					a = a.getChild(0);
				}
				if (id > a.getId()) {
					a = a.getChild(1);
				}
								
			}
        	if (a == null) {
				
				return null;
			}

    		else {
				return a;
			}
       
    }


    //插入新节点
    @Override
    public void insert(Node newNode) {
    		int id = newNode.getId();
    	//插入节点
    		if (root == null) {
				root = newNode;
				return;
			}
    		
    		
    		Node nodeToInsert = root;
    		while(nodeToInsert != null) {
    			if (id < nodeToInsert.getId()) {
    				if (nodeToInsert.getChild(0) == null) {
    					nodeToInsert.setChild(newNode, 0);
    					nodeToInsert.setBalanceFactor(nodeToInsert.getBalanceFactor()+1); 
    					newNode.setParent(nodeToInsert);
    					break;
    				}
    				else {
    					nodeToInsert = nodeToInsert.getChild(0);
    				}
    			}
    			else {
    				if (nodeToInsert.getChild(1) == null) {
    					nodeToInsert.setChild(newNode, 1);
    					nodeToInsert.setBalanceFactor(nodeToInsert.getBalanceFactor()-1);
    					newNode.setParent(nodeToInsert);
    					break;
    				}
    				else {
    					nodeToInsert = nodeToInsert.getChild(1);
    				}
    			}
    		}
       //回溯算法，插入完成后修改平衡因子
    		Node currentNode = nodeToInsert;
    		while (true) {
			//插入之后平衡因子为0不需要重新修改平衡因子	
    			if (currentNode.getBalanceFactor() == 0) {
					return;
				}
			else if(currentNode.getBalanceFactor() == 1 || currentNode.getBalanceFactor() == -1)	{
				if (currentNode == root) {
					return;
				}
				else if(id < currentNode.getParent().getId()) {
					currentNode.getParent().setBalanceFactor(currentNode.getParent().getBalanceFactor() + 1);
				}
				else {
					currentNode.getParent().setBalanceFactor(currentNode.getParent().getBalanceFactor() - 1);
				}
				
				currentNode = currentNode.getParent();
				
			}
			else if (currentNode.getBalanceFactor() == 2 || currentNode.getBalanceFactor() == -2) {
				if (newNode.getId() < currentNode.getId() && newNode.getId() < currentNode.getChild(0).getId()) {
					rightRotate(currentNode);
				}
				else if (newNode.getId() >=  currentNode.getId() && newNode.getId() >= currentNode.getChild(1).getId()) {
					leftRotate(currentNode);
				}
				else if (newNode.getId() < currentNode.getId() && newNode.getId() >= currentNode.getChild(0).getId()) {
					leftRotate(currentNode.getChild(0));
					rightRotate(currentNode);
				}
				else {
					rightRotate(currentNode.getChild(1));
					leftRotate(currentNode);
					
				}
				if (currentNode.getParent() == root || currentNode.getParent().getBalanceFactor() == 0) {
					break;
				}
				else {
					currentNode = currentNode.getParent().getParent();
				}
			}
				
			}
    		
    }

    @Override
    public void delete(int id) {
    	Node currentNode = root;  
        while (currentNode != null)  
        {  
            if (id < currentNode.getId())  
            {  
                currentNode = currentNode.getChild(0);  
            }  
            else if (id > currentNode.getId())  
            {  
                currentNode = currentNode.getChild(1);  
            }  
            else  
            {
            		// 找到该节点了，下面是找到实际的叶子节点与该节点交换  
                // 如果该节点的左子树不为空，则将左子树的最大节点与该节点交换  
                int tempID = currentNode.getId();  
                Object tempData = currentNode.getData();
                Node tempNode = null;  
                if (currentNode.getChild(0) != null)  
                {  
                    tempNode = maxNode(currentNode.getChild(0));  
                }  
                else if (currentNode.getChild(1)!= null)  
                {  
                    tempNode = minNode(currentNode.getChild(1));  
                }  
                if (tempNode != null)  
                {  
                    currentNode.setId(tempNode.getId()); 
                    currentNode.setData(tempNode.getData());
                    tempNode.setId(tempID);
                    tempNode.setData(tempData);
                    currentNode = tempNode;  
                }  
                // 下面是具体的删除操作，就是删除叶子节点  
                if (currentNode == root)  
                {  
                    root = null;  
                    return ;  
                }  
                else if (currentNode == currentNode.getParent().getChild(0))  
                {
                		// 如果当前节点是其父节点的左子树  
                    if (currentNode.getChild(0) != null)  
                    {
                    	// 如果当前节点的左子树不为空  
                        currentNode.getParent().setChild(currentNode.getChild(0), 0);;  
                        currentNode.getChild(0).setParent(currentNode.getParent());;  
                    }  
                    else if (currentNode.getChild(1) != null)  
                    {  
                        currentNode.getParent().setChild(currentNode.getChild(0), 0);  
                        currentNode.getChild(1).setParent(currentNode.getParent());;  
                    }  
                    else  
                    {  
                        currentNode.getParent().setChild(null, 0);  
                    }  
                    currentNode.getParent().setBalanceFactor(currentNode.getParent().getBalanceFactor() - 1);  
                }  
                else  
                {
                		// 如果当前节点是其父节点的右子树  
                    if (currentNode.getChild(0) != null)  
                    {// 如果当前节点的左子树不为空，则将当前节点的左子树链接到当前节点的父节点  
                        currentNode.getParent().setChild(currentNode.getChild(0), 1);  
                        currentNode.getChild(0).setParent(currentNode.getParent());  
                    }  
                    else if (currentNode.getChild(1) != null)  
                    {  
                        currentNode.getParent().setChild(currentNode.getChild(1), 1);
                        
                        currentNode.getChild(1).setParent(currentNode.getParent()); 
                    }  
                    else  
                    {  
                        currentNode.getParent().setChild(null, 1); 
                    }  
                    currentNode.getParent().setBalanceFactor(currentNode.getParent().getBalanceFactor() + 1);;  
                }  
                tempNode = currentNode.getParent();
                  
                // 下面是删除操作的回朔算法  
                while (true)  
                {  
                    // 如果节点的bf为1或者-1，说明删除之前的bf为0（因为删除之前是平衡的，不可能为2或者-2情况），删除之后树的高度没有改变，不需要再回朔判断  
                    if (tempNode.getBalanceFactor() == 1 || tempNode.getBalanceFactor() == -1)  
                    {  
                        return ;  
                    }  
                    else if (tempNode.getBalanceFactor() == 0)  
                    {// 如果节点的bf为0，说明删除之前bf为1或者-1，删除之后高度减少了，那么需要首先判断当前节点是父节点的左子树还是右子树，再回朔父节点  
                        // 首先需要判断是否已经回朔到了根节点  
                        if (tempNode == root)  
                        {  
                            return ;  
                        }  
                        else if (tempNode == tempNode.getParent().getChild(0))  
                        {// 如果当前节点是父节点的左子树，说明父节点的左子树高度下降了  
                            tempNode.getParent().setBalanceFactor(tempNode.getParent().getBalanceFactor() - 1);  
                        }  
                        else  
                        {  
                        	   tempNode.getParent().setBalanceFactor(tempNode.getParent().getBalanceFactor() + 1);  
                        }  
                    }  
                    else  
                    {
                    		// 如果节点的bf为2或者-2，则需要通过旋转保持平衡，首先确定旋转的类型，bf值大于等于0向左，小于0向右  
                        if (tempNode.getBalanceFactor() >= 0 && tempNode.getChild(0).getBalanceFactor() >= 0)  
                        {// LL型旋转  
                            rightRotate(tempNode);  
                        }  
                        else if (tempNode.getBalanceFactor() >= 0 && tempNode.getChild(1).getBalanceFactor() < 0)  
                        {// LR型旋转  
                            leftRotate(tempNode.getChild(1));  
                            rightRotate(tempNode);  
                        }  
                        else if (tempNode.getBalanceFactor() < 0 && tempNode.getChild(1).getBalanceFactor() >= 0)  
                        {// RL型旋转  
                            rightRotate(tempNode.getChild(1));  
                            leftRotate(tempNode);  
                        }  
                        else  
                        {// RR型旋转  
                            leftRotate(tempNode);  
                        }  
                    }  
                    tempNode = tempNode.getParent();  
                }  
            }  
        }  
        return ;  
       
    }
    
    private Node maxNode(Node root)  
    {  
        Node current = root;  
        while (current != null)  
        {  
            if (current.getChild(1) == null)  
            {  
                break;  
            }  
            else  
            {  
                current = current.getChild(1);  
            }  
        }  
        return current;  
    }  
      
        private Node minNode(Node root)  
    {  
        Node current = root;  
        while (current != null)  
        {  
            if (current.getChild(0) == null)  
            {  
                break;  
            }  
            else  
            {  
                current = current.getChild(0);  
            }  
        }  
        return current;  
    }  

    @Override
    public JTree printTree() {
       
        JTree tree = new JTree(drawTree(root));
        
       
      
        return tree;
    }
    //递归法画树
    private DefaultMutableTreeNode drawTree(Node node) {
    		if (node == null ) {
				return null;
			}
    		DefaultMutableTreeNode leftChild = drawTree(node.getChild(0));
    		DefaultMutableTreeNode rightChild = drawTree(node.getChild(1));
    		DefaultMutableTreeNode root = new DefaultMutableTreeNode("("+node.getId()+")" + node.getData().toString());
    		if (leftChild != null) {
				root.add(leftChild);
			}
    		if (rightChild != null) {
				root.add(rightChild);
			}
		return root;
	}
   //左旋转
    private void leftRotate(Node node) {
    	if (node.getParent() == null)  
        {  
            root = node.getChild(1);  
        }  
        else if (node == node.getParent().getChild(0))  
        {  
            node.getParent().setChild(node.getChild(1), 0); ;  
        }  
        else  
        {  
            node.getParent().setChild(node.getChild(1), 1);  
        }  
        node.getChild(1).setParent(node.getParent());;  
        if (node.getChild(1).getChild(0) != null)  
        {  
            node.getChild(1).getChild(0).setParent(node);  
        }  
        node.setParent(node.getChild(1));  
        node.setChild(node.getParent().getChild(0), 1); 
        node.getParent().setChild(node, 0); 
        // 调整平衡因子  
        if (node.getParent().getBalanceFactor() < 0)//如果父节点的平衡因子小于0  
        {  
            node.setBalanceFactor(node.getBalanceFactor() - node.getParent().getBalanceFactor() + 1); 
        }  
        else  
        //如果父节点的平衡因子大于或等于0  
        {  
            node.setBalanceFactor(node.getBalanceFactor() + 1);  
        }  
        if (node.getBalanceFactor() < 0)  
        {  
            node.getParent().setBalanceFactor(node.getParent().getBalanceFactor() + 1); 
        }  
        else  
        {  
            node.getParent().setBalanceFactor(node.getParent().getBalanceFactor() + node.getBalanceFactor() + 1); 
        }  
	}
   //右旋转
    private void rightRotate(Node node) {
    	if (node.getParent() == null)  
        {  
            root = node.getChild(0);  
        }  
        else if (node == node.getParent().getChild(0))  
        {  
            node.getParent().setChild(node.getChild(0), 0);
        }  
        else  
        {  
            node.getParent().setChild(node.getChild(0), 1);
        }  
        // 将B的父节点设为A的父节点  
        node.getChild(0).setParent(node.getParent());;  
        // 如果B的右子树不为null，则将B的右子树的父节点设为A  
        if (node.getChild(0).getChild(1) != null)  
        {  
            node.getChild(0).getChild(1).setParent(node);
        }  
        // 将A的父节点设为B  
        node.setParent(node.getChild(0)); 
        // 将B的右子树接到A的左边  
        node.setChild(node.getParent().getChild(1), 0); 
        node.getParent().setChild(node, 1);;  
       
        if (node.getParent().getBalanceFactor() >= 0)  
        {  
            node.setBalanceFactor(node.getBalanceFactor() - node.getParent().getBalanceFactor() - 1);
        }
        else  
        {  
            node.setBalanceFactor(node.getBalanceFactor() - 1);  
        }  
        if (node.getBalanceFactor() >= 0)  
        {  
            node.getParent().setBalanceFactor(node.getParent().getBalanceFactor() - 1);  
        }  
        else  
        {  
            node.getParent().setBalanceFactor(node.getParent().getBalanceFactor() + node.getBalanceFactor() - 1); 
        }  
	}


}
