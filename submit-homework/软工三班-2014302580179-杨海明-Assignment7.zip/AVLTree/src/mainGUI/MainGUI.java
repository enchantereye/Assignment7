package mainGUI;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import avl.imple.AVLTree;
import avl.imple.Node;

import javax.swing.JTree;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.awt.event.ActionEvent;


public class MainGUI extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField txt_insert;
	private JTextField txt_delete;
	private JTextField txt_get;
	private JTree tree;
	private JTextField txtOutput;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					
					MainGUI frame = new MainGUI();
					frame.setVisible(true);
					
					
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 * @throws Exception 
	 */
	public MainGUI() throws Exception {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 352, 579);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		AVLTree avltree = new AVLTree();
		initTree(avltree);
		tree = avltree.printTree();
		tree.setBounds(23, 6, 298, 384);
	
		contentPane.add(tree);
		contentPane.setLayout(null);
		
		txtOutput = new JTextField();
		txtOutput.setText("output");
		txtOutput.setBounds(23, 390, 298, 28);
		contentPane.add(txtOutput);
		txtOutput.setColumns(10);
		txtOutput.setEditable(false);
		
		txt_insert = new JTextField();
		txt_insert.setBounds(23, 422, 134, 28);
		txt_insert.setText("格式为id#data(1#a)");
		contentPane.add(txt_insert);
		txt_insert.setColumns(10);
		
		txt_delete = new JTextField();
		txt_delete.setBounds(23, 462, 134, 28);
		txt_delete.setText("输入id");
		contentPane.add(txt_delete);
		txt_delete.setColumns(10);
		
		txt_get = new JTextField();
		txt_get.setBounds(23, 502, 134, 28);
		txt_get.setText("输入id");
		contentPane.add(txt_get);
		txt_get.setColumns(10);
		
		JButton btn_insert = new JButton("Insert");
		btn_insert.setBounds(204, 423, 117, 29);
		btn_insert.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String[] info = txt_insert.getText().split("#");
				if(info.length == 2){
				Node flagNode = avltree.get(Integer.parseInt(info[0]));
				
				if(flagNode == null){
					tree.setVisible(false);
					remove(tree);
				Node node = new Node();
	            node.setData(info[1]);
	            node.setId(Integer.valueOf(info[0]));
	            avltree.insert(node);
	           
	            tree = avltree.printTree();
	            tree.setBounds(23, 6, 298, 384);
	            tree.setVisible(true);
	            getContentPane().add(tree);
	            txtOutput.setText("("+info[0]+")"+info[1]+"插入成功。");
				}
				else {
					txtOutput.setText("id为"+info[0]+"已经存在。");
					JOptionPane.showMessageDialog(null, "id为"+info[0]+"已经存在。", "错误", JOptionPane.ERROR_MESSAGE);
				}
				}
				else {
					txtOutput.setText("格式错误，请输入id#data。");
					JOptionPane.showMessageDialog(null, "格式错误，请输入id#data。", "错误", JOptionPane.ERROR_MESSAGE);
				}
	           
				
			}
		});
		contentPane.add(btn_insert);
		
		JButton btn_delete = new JButton("Delete");
		btn_delete.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				try{
				Node flagNode = avltree.get(Integer.parseInt(txt_delete.getText()));
				if (flagNode != null) {
					
				
				tree.setVisible(false);
				remove(tree);
				int id = Integer.parseInt(txt_delete.getText());
				txtOutput.setText("("+flagNode.getId()+")"+flagNode.getData().toString()+"删除成功。");
				avltree.delete(id);
				remove(tree);
				tree = avltree.printTree();
				
				tree.setBounds(23, 6, 298, 384);
				tree.setVisible(true);
				getContentPane().add(tree);
				
				
				}
				
				else {
					JOptionPane.showMessageDialog(null, "id为"+txt_delete.getText()+"不存在。", "错误", JOptionPane.ERROR_MESSAGE);
				}
				}
				
				catch(NumberFormatException e2){
					txtOutput.setText( "请输入数字。"); 
					JOptionPane.showMessageDialog(null, "请输入数字。", "错误", JOptionPane.ERROR_MESSAGE);
	                  e2.printStackTrace();
				}
			}
		});
		btn_delete.setBounds(204, 463, 117, 29);
		contentPane.add(btn_delete);
		
		JButton btn_get = new JButton("Get");
		btn_get.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
				try{
				Node nodeToGet = avltree.get(Integer.parseInt(txt_get.getText()));
				if (nodeToGet != null) {
					txtOutput.setText("获取成功:"+"        ("+nodeToGet.getId()+")"+nodeToGet.getData().toString());
				}
				else {
					txtOutput.setText("获取失败，节点不存在。");
					JOptionPane.showMessageDialog(null, "id为"+txt_get.getText()+"不存在。", "错误", JOptionPane.ERROR_MESSAGE);
				}
				}
				catch(NumberFormatException e2){
					JOptionPane.showMessageDialog(null, "请输入数字", "错误", JOptionPane.ERROR_MESSAGE);
	                  e2.printStackTrace();

				}
				}
				
				
				
			
		});
		btn_get.setBounds(204, 503, 117, 29);
		contentPane.add(btn_get);
		
		
		
		
		
		
		
		
	}
	
	public static void initTree(AVLTree tree) throws Exception {
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(new FileInputStream("tree_data.dat")));
        for(String info = bufferedReader.readLine();info!=null;info = bufferedReader.readLine()) {
            String[] dataAndId = info.split("#");
            Node node = new Node();
            node.setData(dataAndId[0]);
            node.setId(Integer.parseInt(dataAndId[1]));
            tree.insert(node);
        }
        bufferedReader.close();
    }
}
