import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.nio.Buffer;


/**
 * Created by inksmallfrog on 2015/12/15.
 */
public class AVLTreeGui extends JFrame {
    static final int WINDOW_WIDTH = 800;
    static final int WINDOW_HEIGHT = 600;
    static final String WINDOW_NAME = "Assignment7";

    AVLTree tree;

    JScrollPane scrollPane;
    JTree treeView;

    JPanel rightPanel;
    JPanel inputPanel;

    JPanel idPanel;
    JLabel idLabel;
    JTextField idField;

    JPanel dataPanel;
    JLabel dataLabel;
    JTextField dataField;

    JPanel buttonPanel;
    JButton searchButton;
    JButton addButton;
    JButton deleteButton;

    JPanel errorPanel;
    JLabel errorLabel;


    public AVLTreeGui(){
        setSize(WINDOW_WIDTH, WINDOW_HEIGHT);
        setTitle(WINDOW_NAME);
        setVisible(true);

        setLayout(new GridLayout(1, 2));

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        addTreeView();
        addInputView();

        addListener();

        initTree("tree_data.dat");
    }

    private void addTreeView(){
        tree = new AVLTree();

        treeView = tree.printTree();
        scrollPane = new JScrollPane(treeView);

        add(scrollPane);
    }

    private void initTree(String fileName){
        File treeData = new File(fileName);
        InputStreamReader fileIn = null;
        try {
            fileIn = new InputStreamReader(new FileInputStream(treeData));
        }
        catch (FileNotFoundException e){
            errorLabel.setText("读取文件" + fileName + "数据失败！");
            return;
        }

        BufferedReader reader = new BufferedReader(fileIn);

        String fileData = null;
        try {
            fileData = reader.readLine();
        }
        catch (IOException e){
            errorLabel.setText("读取文件" + fileName + "数据失败！");
            return;
        }
        while(fileData != null){
            String[] nodeData = fileData.split("#");
            Node node = new Node();
            node.setData(nodeData[0]);
            node.setId(Integer.parseInt(nodeData[1]));
            tree.insert(node);
            try {
                fileData = reader.readLine();
            }
            catch (IOException e){
                errorLabel.setText("读取文件" + fileName + "数据失败！");
                return;
            }
        }
        treeView.updateUI();
        return;
    }

    private void addInputView(){
        rightPanel = new JPanel();
        rightPanel.setLayout(new BorderLayout());

        inputPanel = new JPanel();
        inputPanel.setLayout(new GridLayout(12, 1, 500, 20));

        inputPanel.add(new JPanel());
        inputPanel.add(new JPanel());

        InitInputPanel();
        addInputPanel(idPanel, idLabel, idField);
        addInputPanel(dataPanel, dataLabel, dataField);
        addButtonPanel();
        addErrorPanel();

        rightPanel.add(inputPanel, BorderLayout.CENTER);
        add(rightPanel);
    }

    private void InitInputPanel(){
        idPanel = new JPanel();
        dataPanel = new JPanel();

        idLabel = new JLabel("    id: ");
        dataLabel = new JLabel("data: ");

        idField = new JTextField("");
        dataField = new JTextField("");
    }

    private void addInputPanel(JPanel panel, JLabel label, JTextField textField){
        panel.setLayout(new BoxLayout(panel, BoxLayout.X_AXIS));

        label.setFont(new Font("微软雅黑", Font.PLAIN, 20));

        panel.add(Box.createHorizontalStrut(20));
        panel.add(label);
        panel.add(Box.createHorizontalStrut(20));
        panel.add(textField);
        panel.add(Box.createHorizontalStrut(20));

        inputPanel.add(panel);
    }

    private void addButtonPanel(){
        buttonPanel = new JPanel();
        buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.X_AXIS));

        searchButton = new JButton("搜索");
        addButton = new JButton("添加");
        deleteButton = new JButton("删除");

        buttonPanel.add(Box.createHorizontalStrut(40));
        buttonPanel.add(searchButton);
        buttonPanel.add(Box.createHorizontalStrut(40));
        buttonPanel.add(addButton);
        buttonPanel.add(Box.createHorizontalStrut(40));
        buttonPanel.add(deleteButton);
        buttonPanel.add(Box.createHorizontalStrut(40));

        inputPanel.add(buttonPanel);
    }

    private void addErrorPanel(){
        errorPanel = new JPanel();
        errorPanel.setLayout((new BoxLayout(errorPanel, BoxLayout.X_AXIS)));

        errorLabel = new JLabel();
        errorLabel.setFont(new Font("微软雅黑", Font.BOLD, 25));
        errorLabel.setForeground(Color.RED);

        errorPanel.add(errorLabel);

        inputPanel.add(errorPanel);
    }

    private void addListener(){
        searchButton.addActionListener(e -> {
            int item = 0;
            try {
                item = Integer.parseInt(idField.getText());
            }
            catch (NumberFormatException exc){
                errorLabel.setText("请输入整数id！");
                return;
            }
            Node node = tree.get(item);
            if(null == node){
                errorLabel.setText("搜索的id不存在！");
            }
            else{
                dataField.setText(node.getData().toString());
            }
        });

        addButton.addActionListener(e -> {
            int item = 0;
            try {
                item = Integer.parseInt(idField.getText());
            }
            catch (NumberFormatException exc){
                errorLabel.setText("请输入整数id！");
                return;
            }
            Node newNode = new Node();
            String data = dataField.getText();
            if(null == data || "".equals(data)){
                errorLabel.setText("请输入data！");
                return;
            }
            else{
                newNode.setData(dataField.getText());
                newNode.setId(item);
                tree.insert(newNode);
                CheckInput();
            }
        });

        deleteButton.addActionListener(e->{
            int id = 0;
            try {
                id = Integer.parseInt(idField.getText());
            }
            catch (NumberFormatException exc){
                errorLabel.setText("请输入整数id！");
                return;
            }
            tree.delete(id);
            CheckInput();
        });
    }

    private void CheckInput(){
        String error = tree.getError();
        if(!error.equals("")){
            errorLabel.setText(tree.getError());
        }
        else{
            idField.setText("");
            dataField.setText("");
            errorLabel.setText("");
            treeView.updateUI();
        }
    }
}
