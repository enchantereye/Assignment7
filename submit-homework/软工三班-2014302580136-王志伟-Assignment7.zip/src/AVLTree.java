import javax.swing.*;
import javax.swing.event.TreeModelListener;
import javax.swing.tree.TreeModel;
import javax.swing.tree.TreePath;

/**
 * Created by inksmallfrog on 2015/12/15.
 */
//实现AVL树
public class AVLTree implements IAVLTree {
    private Node root = null;                   //树根节点
    private String error = new String("");      //执行错误信息

    //根据索引获得节点
    @Override
    public Node get(int id) {
        Node currentNode = root;
        while(currentNode != null && currentNode.getId() != id){
            if(id < currentNode.getId()){
                currentNode = currentNode.getChildren()[0];
            }
            else{
                currentNode = currentNode.getChildren()[1];
            }
        }
        return currentNode;
    }

    //插入新节点
    @Override
    public void insert(Node newNode) {
        //空树
        if(null == root){
            newNode.setParent(null);
            newNode.setChild(null, 0);
            newNode.setChild(null, 1);
            root = newNode;
        }
        else {
            Node currentNode = root;
            Node parentNode = null;
            while (currentNode != null) {
                parentNode = currentNode;
                //索引已存在
                if(newNode.getId() == currentNode.getId()){
                    error = "id已存在";
                    return;
                }
                else{
                    error = "";
                    if (newNode.getId() < currentNode.getId()) {
                        currentNode = currentNode.getChildren()[0];
                    } else {
                        currentNode = currentNode.getChildren()[1];
                    }
                }
            }
            //判断节点插入位置
            int childId = (newNode.getId() < parentNode.getId()) ? 0 : 1;
            parentNode.setChild(newNode, childId);
            //平衡二叉树
            AVLCalculate(newNode);
        }
    }

    //删除节点
    @Override
    public void delete(int id) {
        //搜索待删节点
        Node currentNode = get(id);
        //节点不存在
        if(null == currentNode){
            error = "id不存在";
            return;
        }
        else {
            error = "";
            deleteNode(currentNode);    //删除节点
            AVLCalculate(currentNode);  //平衡二叉树
        }
    }

    //将二叉树组织为JTree用于显示
    @Override
    public JTree printTree() {
        JTree treeView = new JTree();
        treeView.setModel(new AVLTreeModel(this));

        return treeView;
    }

    //获得根节点
    public Node getRoot(){
        return root;
    }

    //获得错误信息
    public String getError() { return error; }

    //删除节点
    private void deleteNode(Node targetNode){
        Node parent = targetNode.getParent();
        //单节点删除
        if(targetNode.getChildren()[0] == null && targetNode.getChildren()[1] == null){
            if(null == parent){
                root = null;
            }
            else{
                parent.setChild(null, getIdAsChild(targetNode));
            }
        }
        //同时有左右孩子的节点删除
        else if(targetNode.getChildren()[0] != null && targetNode.getChildren()[1] != null){
            Node rSmallest = targetNode.getChildren()[1];
            for(;rSmallest.getChildren()[0] != null; rSmallest = rSmallest.getChildren()[0]);
            rSmallest.setChild(targetNode.getChildren()[0], 0);
            if(rSmallest.getParent() != targetNode){
                rSmallest.getParent().setChild(rSmallest.getChildren()[1], 0);
                rSmallest.setChild(targetNode.getChildren()[1], 1);
            }

            if(null == parent){
                root = rSmallest;
                rSmallest.setParent(null);
            }
            else{
                parent.setChild(rSmallest, getIdAsChild(targetNode));
            }
        }
        //只拥有单个孩子节点删除
        else{
            int childPosition = (targetNode.getChildren()[0] != null) ? 0 : 1;
            if(null == parent){
                root = targetNode.getChildren()[childPosition];
            }
            else{
                parent.setChild(targetNode.getChildren()[childPosition], getIdAsChild(targetNode));
            }
        }

    }

    //平衡二叉树
    private void AVLCalculate(Node newNode) {
        Node centerNode;
        Node rotateNode = newNode;
        //寻找不平衡的节点
        for(; rotateNode != null && Math.abs(rotateNode.getBalanceFactor()) < 2; rotateNode = rotateNode.getParent())
            ;
        //无不平衡节点
        if(null == rotateNode){
            return;
        }
        else{
            //旋转中心
            if(rotateNode.getBalanceFactor() < 0){
                centerNode = rotateNode.getChildren()[0];
            }
            else{
                centerNode = rotateNode.getChildren()[1];
            }

            //LL旋转条件
            if(rotateNode.getBalanceFactor() < 0 && centerNode.getBalanceFactor() < 0){
                rotateLL(rotateNode, centerNode);
            }
            //LR旋转条件
            else if(rotateNode.getBalanceFactor() < 0 && centerNode.getBalanceFactor() > 0){
                rotateLR(rotateNode, centerNode);
            }
            //RL旋转条件
            else if(rotateNode.getBalanceFactor() > 0 && centerNode.getBalanceFactor() < 0){
                rotateRL(rotateNode, centerNode);
            }
            //RR旋转条件
            else if(rotateNode.getBalanceFactor() > 0 && centerNode.getBalanceFactor() > 0){
                rotateRR(rotateNode, centerNode);
            }
        }
    }

    private void rotateLL(Node rotateNode, Node centerNode){
        Node parent = rotateNode.getParent();
        //处理根节点
        if(null == parent){
            centerNode.setParent(null);
            root = centerNode;
        }
        else{
            parent.setChild(centerNode, getIdAsChild(rotateNode));
        }
        rotateNode.setChild(centerNode.getChildren()[1], 0);
        centerNode.setChild(rotateNode, 1);
    }

    private void rotateLR(Node rotateNode, Node centerNode){
        Node rChild = centerNode.getChildren()[1];
        Node parent = rotateNode.getParent();
        if(null == parent){
            rChild.setParent(null);
            root = rChild;
        }
        else{
            parent.setChild(rChild, getIdAsChild(rotateNode));
        }
        centerNode.setChild(rChild.getChildren()[0], 1);
        rotateNode.setChild(rChild.getChildren()[1], 0);
        rChild.setChild(centerNode, 0);
        rChild.setChild(rotateNode, 1);
    }

    private void rotateRL(Node rotateNode, Node centerNode){
        Node lChild = centerNode.getChildren()[0];
        Node parent = rotateNode.getParent();
        if(null == parent){
            lChild.setParent(null);
            root = lChild;
        }
        else{
            parent.setChild(lChild, getIdAsChild(rotateNode));
        }
        rotateNode.setChild(lChild.getChildren()[0], 1);
        centerNode.setChild(lChild.getChildren()[1], 0);
        lChild.setChild(centerNode, 1);
        lChild.setChild(rotateNode, 0);
    }

    private void rotateRR(Node rotateNode, Node centerNode){
        Node parent = rotateNode.getParent();
        if(null == parent){
            centerNode.setParent(null);
            root = centerNode;
        }
        else{
            rotateNode.getParent().setChild(centerNode, getIdAsChild(rotateNode));
        }
        rotateNode.setChild(centerNode.getChildren()[0], 1);
        centerNode.setChild(rotateNode, 0);
    }

    //获得孩子的Id序号
    public final int getIdAsChild(Node childNode){
        Node parent = childNode.getParent();
        if(parent == null){
            return -1;
        }
        else{
            if(parent.getId() < childNode.getId()){
                return 1;
            }
            else{
                return 0;
            }
        }
    }
}

//JTree模型
class AVLTreeModel implements TreeModel{
    private AVLTree tree;   //存储数据

    AVLTreeModel(AVLTree tree){
        this.tree = tree;
    }

    @Override
    public Object getRoot() {
        return tree.getRoot();
    }

    @Override
    public Object getChild(Object parent, int index) {
        if(((Node)parent).getChildren()[index] == null){
            return ((Node)parent).getChildren()[index + 1];
        }
        return ((Node)parent).getChildren()[index];
    }

    @Override
    public int getChildCount(Object parent) {
        int count = 0;
        for(Node node : ((Node)parent).getChildren()){
            if(node != null){
                ++count;
            }
        }
        return count;
    }

    @Override
    public boolean isLeaf(Object node) {
        return (null == ((Node)node).getChildren()[0] && null == ((Node)node).getChildren()[1]);
    }

    @Override
    public void valueForPathChanged(TreePath path, Object newValue) {

    }

    @Override
    public int getIndexOfChild(Object parent, Object child) {
        if(parent == null || child == null)
            return -1;
        return tree.getIdAsChild((Node)child);
    }

    @Override
    public void addTreeModelListener(TreeModelListener l) {

    }

    @Override
    public void removeTreeModelListener(TreeModelListener l) {

    }
}