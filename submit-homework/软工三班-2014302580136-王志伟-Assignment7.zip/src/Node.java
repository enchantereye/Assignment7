
public class Node {
	private int id;
	private Object data;
	private Node parent;
	private Node[] children = new Node[2];
	private int lSubTreeHeight;
	private int rSubTreeHeight;
	private int balanceFactor;
	
	public int getId() {
		return id;
	}
	public Object getData() {
		return data;
	}
	public void setData(Object data) {
		this.data = data;
	}
	public Node getParent() {
		return parent;
	}
	public Node[] getChildren() {
		return children;
	}
	public void setChildren(Node[] children) {
		children[0].setParent(this);
		children[1].setParent(this);
		this.children = children;
	}
	//在设置孩子的同时设置孩子的祖先，以减少代码量降低出错率
	public void setChild(Node child, int id){
		if(child != null){
			child.setParent(this);
		}
		this.children[id] = child;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getlSubTreeHeight() {
		//TODO calculate the left sub tree height
		Node lChild = getChildren()[0];
		if(null == lChild){
			return 0;
		}

		lSubTreeHeight = Math.max(lChild.getlSubTreeHeight(), lChild.getrSubTreeHeight()) + 1;

		return lSubTreeHeight;
	}
	public int getrSubTreeHeight() {
		//TODO calculate the right sub tree height
		Node rChild = getChildren()[1];
		if(null == rChild){
			return 0;
		}

		rSubTreeHeight = Math.max(rChild.getlSubTreeHeight(), rChild.getrSubTreeHeight()) + 1;
		return rSubTreeHeight;
	}
	public int getBalanceFactor() {
		//TODO calculate the balance factor
		balanceFactor = getrSubTreeHeight() - getlSubTreeHeight();
		return balanceFactor;
	}

	public void setParent(Node parent) {
		this.parent = parent;
	}

	//显示Node信息
	public String toString() {
		if (data == null) {
			return "";
		} else {
			return data.toString();
		}
	}
}
