import java.awt.*;

/**
 * Created by inksmallfrog on 2015/12/15.
 */
public class MainGui {
    public static void main(String[] args){
        EventQueue.invokeLater(()-> new AVLTreeGui());
    }
}
