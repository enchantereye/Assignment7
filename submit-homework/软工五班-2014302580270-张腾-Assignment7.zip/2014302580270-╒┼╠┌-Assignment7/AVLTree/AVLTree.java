package AVLTree;

import java.awt.Component;
import java.util.LinkedList;
import java.util.Queue;

import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;

public class AVLTree implements IAVLTree{

	private Node root = null;
	private Component comp;
	
	public AVLTree(Component comp) {
		this.comp = comp;
		root = null;
	}

	public AVLTree(Component comp,Object n, int id) {
		this.comp = comp;
		root = new Node(id, n);
	}
	
	public AVLTree() {
		// TODO �Զ����ɵĹ��캯�����
	}

	@Override
	public Node get(int id) {
		// TODO �Զ����ɵķ������
		return get(root,id);
	}

	private Node get(Node n,int id){
		if(n==null)return null;
		if(n.getId()>id)return get(n.getLChild(),id);
		if(n.getId()<id)return get(n.getLChild(),id);
		return n;
	}
	
	//L������������
	private void rotateLeft(Node p)
	{
		if (p != null)
		{
			Node r = p.getRChild();
	        p.setRChild(r.getLChild());
	        if (r.getLChild() != null)
	            r.getLChild().setParent(p);
	        r.setParent(p.getParent());
	        if (p.getParent() == null)
	            root = r;
	        else if (p.getParent().getLChild() == p)
	            p.getParent().setLChild(r);
	        else
	            p.getParent().setRChild(r);
	        r.setLChild(p);
	        p.setParent(r);
	    }
	}	
	
	//R������������
	private void rotateRight(Node p)
    {
        if (p != null)
        {
            Node l = p.getLChild();
            p.setLChild(l.getRChild());
            if (l.getRChild() != null)
                l.getRChild().setParent(p);
            l.setParent(p.getParent());
            if (p.getParent() == null)
                root = l;
            else if (p.getParent().getRChild() == p)
                p.getParent().setRChild(l);
            else
                p.getParent().setLChild(l);
            l.setRChild(p);
            p.setParent(l);
        }
    }
	
	@Override
	public void insert(Node newNode) {
		// TODO �Զ����ɵķ������
		 Node t1 = root;
	        if (t1 == null)
	        {
	            root = newNode;
	            return;
	        }
	        Node parent;
	        do
	        {
	            parent = t1;
	            if (newNode.getId() < t1.getId())
	            {
	                t1 = t1.getLChild();
	            }
	            else if (newNode.getId() > t1.getId())
	            {
	                t1 = t1.getRChild();
	            }
	            else
	            {
	                return;
	            }
	        } while (t1 != null);

	        newNode.setParent(parent);
	        if (newNode.getId() < parent.getId())
	        {
	            parent.setLChild(newNode);
	        }
	        else
	        {
	            parent.setRChild(newNode);
	        }
	        while (parent != null)
	        {
	            if (newNode.getId() < parent.getId())
	            {
	                parent.setBalance(parent.getBalance() + 1);
	            }
	            else
	            {
	                parent.setBalance(parent.getBalance() - 1);
	            }
	            if (parent.getBalance() == 0)
	            {
	                break;
	            }
	            if (Math.abs(parent.getBalance()) == 2)
	            {
	            	 boolean heightLower = true;
	                 Node t2 = parent.getParent();
	                 while (t2 != null && heightLower)
	                 {
	                     if (t2.getId() > parent.getId())
	                     {
	                         t2.setBalance(t2.getBalance() + 1);
	                     }else
	                     {
	                         t2.setBalance(t2.getBalance() - 1);
	                     }
	                     if (Math.abs(t2.getBalance()) == 1)
	                     {
	                         break;
	                     }
	                     Node r = t2;
	                     if (t2.getBalance() == 2)
	                     {
	                         boolean heightLower1 = true;
	                         Node l = t2.getLChild();
	                         switch (l.getBalance())
	                         {
	                             case 1:
	                                 t2.setBalance(0);
	                                 l.setBalance(0);
	                                 rotateRight(t2);
	                                 break;
	                             case -1:
	                                 Node rd = l.getRChild();
	                                 switch (rd.getBalance())
	                                 {
	                                     case 1:
	                                         t2.setBalance(-1);
	                                         l.setBalance(0);
	                                         break;
	                                     case 0:
	                                         t2.setBalance(0);
	                                         l.setBalance(0);
	                                         break;
	                                     case -1:
	                                         t2.setBalance(0);
	                                         l.setBalance(1);
	                                         break;
	                                 }
	                                 rd.setBalance(0);
	                                 rotateLeft(t2.getLChild());
	                                 rotateRight(t2);
	                                 break;
	                             case 0:
	                                 l.setBalance(0);
	                                 t2.setBalance(1);
	                                 rotateRight(t2);
	                                 heightLower1 = false;
	                                 break;
	                         }
	                     }
	                     else if(t2.getBalance() == -2)
	                     {
	                    	 boolean heightLower1 = true;
	                         Node l = t2.getLChild();
	                         switch (l.getBalance())
	                         {
	                             case 1:
	                                 t2.setBalance(0);
	                                 l.setBalance(0);
	                                 rotateRight(t2);
	                                 break;
	                             case -1:
	                                 Node rd = l.getRChild();
	                                 switch (rd.getBalance())
	                                 {
	                                     case 1:
	                                         t2.setBalance(-1);
	                                         l.setBalance(0);
	                                         break;
	                                     case 0:
	                                         t2.setBalance(0);
	                                         l.setBalance(0);
	                                         break;
	                                     case -1:
	                                         t2.setBalance(0);
	                                         l.setBalance(1);
	                                         break;
	                                 }
	                                 rd.setBalance(0);
	                                 rotateLeft(t2.getLChild());
	                                 rotateRight(t2);
	                                 break;
	                             case 0:
	                                 l.setBalance(0);
	                                 t2.setBalance(1);
	                                 rotateRight(t2);
	                                 heightLower1 = false;
	                                 break;
	                         }
	                     }
	                     t2 = t2.getParent();
	                 }
	                break;
	            }
	            parent = parent.getParent();
	        }
	}

	@Override
	public void delete(int id) {
		// TODO �Զ����ɵķ������
		delete(id,root);
	}
	
	private Node LSingleRotation(Node n){
		Node r=n.getLChild();
			n.setLChild(r.getRChild());
			r.setRChild(n);
			return r;
	}

	private Node RSingleRotation(Node n){
		Node r=n.getRChild();
		n.setRChild(r.getLChild());
		r.setLChild(n);
		return r;
	}
	
	private void delete(int id,Node n){
		Node d=get(n,id);
		if(d==null)return;
		if(d.getLChild()==null&&d.getRChild()==null){
			if(d.getParent()==null){
				root=null;return;
			}
			else if(d==d.getParent().getLChild())
				d.getParent().setLChild(null);
			else
				d.getParent().setRChild(null);
			Node s=d.getParent();
			while((s!=null)&&s.getBalance()<2&&s.getBalance()>-2){
				s=s.getParent();
			}
			if(s==null)return;
			//��ƽ��ʱ����ת����
			else if(s.getBalance()==2)
				if(id>s.getLChild().getId())
					rotateLeft(s);
				else{
					n.setLChild(RSingleRotation(n.getLChild()));
					LSingleRotation(n);
				}
					
			else
				if(id<s.getRChild().getId())
					rotateRight(s);
				else{
					n.setRChild(LSingleRotation(n.getRChild()));
					RSingleRotation(n);
				}
		}
		else if(d.getLChild()==null){
			if(d==root){
				root=d.getRChild();return;
			}
			else if(d.getParent().getLChild()==d)
				d.getParent().setLChild(d.getRChild());
			else
				d.getParent().setRChild(d.getRChild());
			Node s=d.getParent();
			while((s!=null)&&s.getBalance()<2&&s.getBalance()>-2){
				s=s.getParent();
			}
			if(s==null)return;
			else if(s.getBalance()==2)
				if(id>s.getLChild().getId())
					rotateLeft(s);
				else{
					n.setLChild(RSingleRotation(n.getLChild()));
					LSingleRotation(n);
				}
			else
				if(id<s.getRChild().getId())
					rotateRight(s);
				else{
					n.setRChild(LSingleRotation(n.getRChild()));
					RSingleRotation(n);
				}
		}
		else if(d.getRChild()==null){
			if(d==root){
				root=d.getLChild();return;
			}
			else if(d.getParent().getLChild()==d)
				d.getParent().setLChild(d.getLChild());
			else
				d.getParent().setRChild(d.getLChild());
			Node s=d.getParent();
			while((s!=null)&&s.getBalance()<2&&s.getBalance()>-2){
				s=s.getParent();
			}
			if(s==null)return;
			else if(s.getBalance()==2)
				if(id>s.getLChild().getId())
					rotateLeft(s);
				else{
					n.setLChild(RSingleRotation(n.getLChild()));
					LSingleRotation(n);
				}
			else
				if(id<s.getRChild().getId())
					rotateRight(s);
				else{
					n.setRChild(LSingleRotation(n.getRChild()));
					RSingleRotation(n);
				}
		}
		else{
			Node u=d.getRChild();
			while(u.getLChild()!=null){
				u=u.getLChild();
			}
			d.setId(u.getId());
			d.setData(u.getData());
			delete(u.getId(),d.getRChild());
		}
	}

	@Override
	public JTree printTree()
	{
		// TODO �Զ����ɵķ������
		DefaultMutableTreeNode defalutNode=new DefaultMutableTreeNode();
		printTree(defalutNode,root);
		JTree temp=new JTree(defalutNode);
		return temp;
	}
	
	private void printTree(DefaultMutableTreeNode defalutNode,Node node)
	{
		//ͨ���ݹ����JTree
		if(node!=null)
		{
			
			if(node.getLChild()!=null)
			{
				DefaultMutableTreeNode defalutNode1=new DefaultMutableTreeNode(node.getLChild());
				defalutNode.add(defalutNode1);
				printTree(defalutNode1,node.getLChild());
			}
			defalutNode.add(new DefaultMutableTreeNode(node));
			if(node.getRChild()!=null)
			{
				DefaultMutableTreeNode defalutNode2=new DefaultMutableTreeNode(node.getRChild());
				defalutNode.add(defalutNode2);
				printTree(defalutNode2,node.getRChild());
			}
		}
	}
}
