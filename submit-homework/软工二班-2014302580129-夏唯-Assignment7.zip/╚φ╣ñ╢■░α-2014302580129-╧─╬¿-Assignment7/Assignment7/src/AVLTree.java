import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;

public class AVLTree implements IAVLTree{

private Node root;
private Boolean unBalanced=true;
private Boolean shorter=true;



	@Override
	public Node get(int id) {
		// TODO Auto-generated method stub
	return	get(id,root);
	}
	private Node get(int id,Node t)
	{
		if(t==null)
			return null;
			if(id<t.getId())
			{
				t=t.getChildren()[0];
				return get(id,t);
			}
			
			else if(id>t.getId())
				{
				t=t.getChildren()[1];
				return get(id,t);
				}
			else
			  return t;
	}

	@Override
	public void insert( Node newNode) {
		// TODO Auto-generated method stub
		
		     root=insert(newNode,root);
		     root.setParent(null);
		
	}
private Node insert(Node newNode,Node t){
	int bf;
	if(t==null)
	{   unBalanced=true;
		return newNode;
	}
	
	if(newNode.getId()<t.getId())
	{
		bf=t.getBalanceFactor();
		newNode.setParent(t);
		t.setChild(insert(newNode,t.getChildren()[0]),0);
		
		
		if(unBalanced)
			switch(bf){
			case -1:unBalanced=false;break;
			case 0:break;
			case 1:t=LRotation(t,unBalanced);
			}
		
	}
	
	else if(newNode.getId()>t.getId())
	{
		bf=t.getBalanceFactor();
         newNode.setParent(t);
		
		  t.setChild(insert(newNode,t.getChildren()[1]),1);
		
		
		if(unBalanced)
			switch(bf){
			case 1:unBalanced=false;break;
			case 0:break;
			case -1:t=RRotation(t,unBalanced);
			}
	
		 
	}
	
		return t;

  
	
	
}
	private Node RRotation(Node t, Boolean unBalanced2) {
	
	// TODO Auto-generated method stub
		  Node s=t;
			Node u;
			Node r=s.getChildren()[1];
			if(r.getBalanceFactor()==-1)//RR��ת
			{
				
				if(r.getChildren()[0]!=null)
				{
					s.setChild(r.getChildren()[0], 1);//��r�����Ӻ��Ӹ�ֵ��s���Һ���
					r.getChildren()[0].setParent(s);
					
				}
				else
					{
					s.setChild(null, 0);
					s.setChild(null, 1);
					}
				
			    r.setChild(s, 0);//��s��ֵ��r���Һ���
			    r.setParent(null);
			    if(s.getParent()!=null)
			    {
			       if(s==s.getParent().getChildren()[0])
			       s.getParent().setChild(r, 0);
			       if(s==s.getParent().getChildren()[1])
			    	s.getParent().setChild(r, 1);
			       r.setParent(s.getParent());
			      
			     }
			    else
			    	root=r;
			    s.setParent(r);
			    t=r;//ƽ������������ĸ�Ϊr
			   
			}
			else{//RL��ת
				u=r.getChildren()[0];
				if(u.getChildren()[1]!=null)
				{
					r.setChild(u.getChildren()[1], 0);//��u�����Ӹ�ֵ��r���Һ���
					u.getChildren()[1].setParent(r);
				}
				else
					r.setChild(null, 0);
				
				u.setChild(r, 1);
				r.setParent(u);
				if(u.getChildren()[0]!=null)
				
					{
					s.setChild(u.getChildren()[0], 1);
					u.getChildren()[0].setParent(s);
					}
				else
					s.setChild(null, 1);
				u.setChild(s, 0);
				u.setParent(null);
				 if(s.getParent()!=null)
				    {
				       if(s==s.getParent().getChildren()[0])
				       s.getParent().setChild(u, 0);
				       if(s==s.getParent().getChildren()[1])
				    	s.getParent().setChild(u, 1);
				       u.setParent(s.getParent());
				       
				       
				    }
				 else
					 root=u;
					
				 s.setParent(u);
				
				
				t=u;
				
			}
			
			
			
			
			unBalanced=false;
			return t;
	
			
		

}

	private Node LRotation(Node t, Boolean unBalanced2) {
	// TODO Auto-generated method stub
	    Node s=t;
		Node u;
		Node r=s.getChildren()[0];
		if(r.getBalanceFactor()==1)//LL��ת
		{
			if(r.getChildren()[1]!=null)
			{
			s.setChild(r.getChildren()[1], 0);//��r���Һ��Ӹ�ֵ��s������
			r.getChildren()[1].setParent(s);
			}
			else
			{
				s.setChild(null, 0);
				s.setChild(null, 1);
			}
		
		    r.setChild(s, 1);//��s��ֵ��r���Һ���
		    r.setParent(null);
		 if(s.getParent()!=null)
		 {
			 if(s==s.getParent().getChildren()[0])
		    s.getParent().setChild(r, 0);
		    if(s==s.getParent().getChildren()[1])
		    	s.getParent().setChild(r, 1);
		    r.setParent(s.getParent());
		 }
		 else
			 root=r;
		 s.setParent(r);
		   t=r;//ƽ������������ĸ�Ϊr
		   
		}
		else{//LR��ת
			u=r.getChildren()[1];
			if(u.getChildren()[0]!=null)
			{
				r.setChild(u.getChildren()[0], 1);//��u�����Ӹ�ֵ��r���Һ���
			u.getChildren()[0].setParent(r);
			}
			else
				r.setChild(null, 1);
			
			u.setChild(r, 0);
			r.setParent(u);
			if(u.getChildren()[1]!=null)
			{
			s.setChild(u.getChildren()[1], 0);
			u.getChildren()[1].setParent(s);
			
			}
			else
				s.setChild(null, 0);
			
			u.setChild(s, 1);
			u.setParent(null);
			 if(s.getParent()!=null)
			    {
			       if(s==s.getParent().getChildren()[0])
			       s.getParent().setChild(u, 0);
			       if(s==s.getParent().getChildren()[1])
			    	s.getParent().setChild(u, 1);
			       
			       u.setParent(s.getParent());
			    }
			 else
				 root=u;
			 
			 s.setParent(u);
			
			
			t=u;//ƽ�����������ĸ�Ϊu
			
		}
		
		
		
		unBalanced=false;
		return t;
		
		
	
}

	
	public void delete(int id) {
		// TODO Auto-generated method stub
		Node s,r,c;
		Node d=get(id);
		s=d;
		if(d==null)
			return ;
		
		 if((d.getChildren()[0]!=null)&&(d.getChildren()[1]!=null))//d����������������
		{
			r=d;//dΪr��˫��
			s=d.getChildren()[1];//rΪd���������ĸ����
			while(s.getChildren()[0]!=null)
			{
				r=s;s=s.getChildren()[0];
			}
		d.setId(s.getId());
		d.setData(s.getData());
		}
	
		shorter=true;
		if(s.getParent()!=null&&s==s.getParent().getChildren()[1])
		{
			switch(s.getParent().getBalanceFactor()){
				case -1:
					if(s.getChildren()[1]!=null)
						
				      {
				      s.getParent().setChild(s.getChildren()[1], 1);
				      s.getChildren()[1].setParent(s.getParent());
				      }
					else if(s.getChildren()[0]!=null)
					{
						  s.getParent().setChild(s.getChildren()[0], 1);
					      s.getChildren()[0].setParent(s.getParent());
					}
				    else 
				    	s.getParent().setChild(null, 1);
					if(s.getParent()!=null)
					{
						if(s.getParent().getBalanceFactor()==2)
						LRotation(s.getParent(),shorter);
						s=s.getParent();
					}
					while(s.getParent()!=null){
						if(s==s.getParent().getChildren()[0]&&s.getParent().getBalanceFactor()==-2)
							RRotation(s.getParent(),shorter);
							if(s==s.getParent().getChildren()[1]&&s.getParent().getBalanceFactor()==2)
								LRotation(s.getParent(),shorter);
							s=s.getParent();
							
					}

					break;
				case 0:
					shorter=false;
					if(s.getChildren()[1]!=null)
						
				      {
				      s.getParent().setChild(s.getChildren()[1], 1);
				      s.getChildren()[1].setParent(s.getParent());
				      }
					else if(s.getChildren()[0]!=null)
					{
						  s.getParent().setChild(s.getChildren()[0], 1);
					      s.getChildren()[0].setParent(s.getParent());
					}
				    else 
				    	s.getParent().setChild(null, 1);
					break;
				case 1:
					if(s.getChildren()[1]!=null)
						
				      {
				      s.getParent().setChild(s.getChildren()[1], 1);
				      s.getChildren()[1].setParent(s.getParent());
				      }
					else if(s.getChildren()[0]!=null)
					{
						  s.getParent().setChild(s.getChildren()[0], 1);
					      s.getChildren()[0].setParent(s.getParent());
					}
				    else 
				    	s.getParent().setChild(null, 1);
					if(s.getParent()!=null)
					{
						if(s.getParent().getBalanceFactor()==2)
						LRotation(s.getParent(),shorter);
						s=s.getParent();
					}
					while(s.getParent()!=null){
						if(s==s.getParent().getChildren()[0]&&s.getParent().getBalanceFactor()==-2)
							RRotation(s.getParent(),shorter);
							if(s==s.getParent().getChildren()[1]&&s.getParent().getBalanceFactor()==2)
								LRotation(s.getParent(),shorter);
							s=s.getParent();
							
					}
					
				
				    break;
					
					
					
			}
			
		}
		
		else if(shorter&&s.getParent()!=null)//sλ��s��ĸ�ڵ��������
				switch(s.getParent().getBalanceFactor()){
				case -1:
					
					
						if(s.getChildren()[1]!=null)
					
					      {
					      s.getParent().setChild(s.getChildren()[1], 0);
					      s.getChildren()[1].setParent(s.getParent());
					      }
					    else 
					    	s.getParent().setChild(null, 0);
						if(s.getParent()!=null)
						{
							if(s.getParent().getBalanceFactor()==-2)
							RRotation(s.getParent(),shorter);
							s=s.getParent();
						}
						while(s.getParent()!=null){
							if(s==s.getParent().getChildren()[0]&&s.getParent().getBalanceFactor()==-2)
								RRotation(s.getParent(),shorter);
								if(s==s.getParent().getChildren()[1]&&s.getParent().getBalanceFactor()==2)
									LRotation(s.getParent(),shorter);
								s=s.getParent();
								
						}
						
					
			
					    break;
				case 0:shorter=false;
				
					if(s.getChildren()[1]!=null)
				
				      {
				      s.getParent().setChild(s.getChildren()[1], 0);
				      s.getChildren()[1].setParent(s.getParent());
				      }
				      else if(s.getChildren()[0]!=null)
						{
							  s.getParent().setChild(s.getChildren()[0], 0);
						      s.getChildren()[0].setParent(s.getParent());
						}
				      
				    else 
				    	s.getParent().setChild(null, 0);
				
				
				      break;
				case 1:
				      
				
						if(s.getChildren()[1]!=null)
					
					      {
					      s.getParent().setChild(s.getChildren()[1], 0);
					      s.getChildren()[1].setParent(s.getParent());
					      }
						else if(s.getChildren()[0]!=null)
						{
							  s.getParent().setChild(s.getChildren()[0], 0);
						      s.getChildren()[0].setParent(s.getParent());
						}
					
					    else 
					    	s.getParent().setChild(null, 0);
						if(s.getParent()!=null)
						{
							if(s.getParent().getBalanceFactor()==-2)
							RRotation(s.getParent(),shorter);
							s=s.getParent();
						}
						while(s.getParent()!=null){
							if(s==s.getParent().getChildren()[0]&&s.getParent().getBalanceFactor()==-2)
								RRotation(s.getParent(),shorter);
								if(s==s.getParent().getChildren()[1]&&s.getParent().getBalanceFactor()==2)
									LRotation(s.getParent(),shorter);
								s=s.getParent();
								
						}
						
							
					
			break;
				
}
			else{
				if(d.getChildren()[0]!=null)
					{
					root=d.getChildren()[0];
					d.getChildren()[0].setParent(null);
					}
				else if(d.getChildren()[1]!=null)
					{
					root=d.getChildren()[1];
					d.getChildren()[1].setParent(null);
					}
				else
					root=null;
			}
		
		
}	
	  
		
		
	

	

	public JTree printTree() {
		// TODO Auto-generated method stub
		JTree tree;
		if(root!=null)
		   tree=new JTree( printTree(root));
		else
			tree = new JTree(new DefaultMutableTreeNode("��") );
	   return tree;
		
		
	}
	private DefaultMutableTreeNode printTree(Node t){
		if((t.getChildren()[0]==null)&&(t.getChildren()[1]==null))
		{
		
			return new DefaultMutableTreeNode(t);
			
			}
		
		if((t.getChildren()[0]!=null)&&t.getChildren()[1]==null)
			{
				DefaultMutableTreeNode n = new DefaultMutableTreeNode(t);
			
			 n.add(printTree(t.getChildren()[0]));
			
			 return n;
			}
		if((t.getChildren()[1]!=null)&&t.getChildren()[0]==null)
		{
			DefaultMutableTreeNode n = new DefaultMutableTreeNode(t);
			
			 n.add(printTree(t.getChildren()[1]));
			 return n;
		}
		else
		{
			DefaultMutableTreeNode n = new DefaultMutableTreeNode(t);
			 n.add(printTree(t.getChildren()[0]));
			 n.add(printTree(t.getChildren()[1]));
			 return n;
		}
		
	}

	
}
