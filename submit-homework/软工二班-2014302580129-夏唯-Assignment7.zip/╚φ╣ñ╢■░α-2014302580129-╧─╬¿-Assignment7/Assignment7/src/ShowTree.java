import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import javax.swing.*;
public class ShowTree {
	
	static AVLTree a=new AVLTree();
	  static ShowTree b=new ShowTree();
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		JFrame f=new JFrame("ƽ�������");
		
        BufferedReader reader=new BufferedReader(new InputStreamReader(new FileInputStream("tree_data.dat")));
		String line=null;
		while((line=reader.readLine())!=null){
			
			String [] one=line.split("#");
			Node n=new Node(Integer.valueOf(one[1]),one[0]);
			
			a.insert(n);
		}
		reader.close();
		f.add(a.printTree(),BorderLayout.CENTER);
		
		b.showf(f);
	}
	public void showf(JFrame f1){
		JFrame f=new JFrame("ƽ�������");
		 JButton delete=new JButton("ɾ��");
		  delete.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
			
			int id=Integer.valueOf(JOptionPane.showInputDialog("��Ҫɾ����id��Ϊ��"));
			a.delete(id);
			f.add(a.printTree(),BorderLayout.CENTER);
			
			 showf(f);
					
				
			}
			  
		  });
		 
		  JButton insert=new JButton("����");
		  insert.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
			
			int id=Integer.valueOf(JOptionPane.showInputDialog("��Ҫ�������ݵ�id��Ϊ��"));
			String data=JOptionPane.showInputDialog("��Ҫ������Ϊ��");
			a.insert(new Node(id,data));
			f.add(a.printTree(),BorderLayout.CENTER);
			
			 showf(f);
					
				
			}
			  
		  });
		  JButton get=new JButton("����");
		  get.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
			
			int id=Integer.valueOf(JOptionPane.showInputDialog("��Ҫ���������ݵ�id��Ϊ��"));
			 JOptionPane.showMessageDialog(null,a.get(id));
		
			
					
				
			}
			  
		  });
		 
		
		  JPanel p2=new JPanel(new GridLayout(1,3,0,0));
		  p2.add(insert);
		  p2.add(delete);
		  p2.add(get);
		 f1.add(p2,BorderLayout.SOUTH);
		 f1.setBounds(100,100,400,500);
	      f1.setVisible(true);
	      f1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

}
