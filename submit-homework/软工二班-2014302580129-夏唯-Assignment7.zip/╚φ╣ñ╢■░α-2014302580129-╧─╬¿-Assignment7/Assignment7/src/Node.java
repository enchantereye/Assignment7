
public class Node {
	private int id;
	private Object data;
	private Node parent;
	private Node[] children = new Node[2];
	private int lSubTreeHeight;
	private int rSubTreeHeight;
	private int balanceFactor;
	Node(int id,Object data){
		this.id=id;
		this.data=data;
		this.parent=null;
		this.children[0]=null;
		this.children[1]=null;
		this.lSubTreeHeight=0;
		this.rSubTreeHeight=0;
		this.balanceFactor=0;
		
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id){
		this.id=id;
	}
	public Object getData() {
		return data;
	}
	public void setData(Object data) {
		this.data = data;
	}
	public Node getParent() {
		return parent;
	}
	public void setParent(Node parent) {
		this.parent = parent;
	}
	public Node[] getChildren() {
		return children;
	}
	public void setChildren(Node[] children) {
		this.children = children;
	}
	public void setChild(Node child, int id){
		this.children[id] = child;
	}
	public int getlSubTreeHeight() {
		//TODO calculate the left sub tree height
		lSubTreeHeight=getHeight(this.getChildren()[0]);
		return lSubTreeHeight;
	}
	
	public int getrSubTreeHeight() {
		//TODO calculate the right sub tree height
		rSubTreeHeight=getHeight(this.getChildren()[1]);
		return rSubTreeHeight;
	}
private int getHeight(Node t) {
	
		if(t==null)
			return 0;
		else if(t.getHeight(t.getChildren()[0])>t.getHeight(t.getChildren()[1]))
			return t.getHeight(t.getChildren()[0])+1;
		else 
			return t.getHeight(t.getChildren()[1])+1;
	}
	public int getBalanceFactor() {
		//TODO calculate the balance factor
		balanceFactor=this.getlSubTreeHeight()-this.getrSubTreeHeight();
		return balanceFactor;
}

public String toString(){
	return id+":"+data;
}








}
