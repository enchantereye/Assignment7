
public class MainAVL {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     AVLTree a=new AVLTree();
     
	}

}
