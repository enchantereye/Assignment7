
public class Node {
	private int id;
	private String data;
	private Node parent;
	private Node[] children = new Node[2];
	private int lSubTreeHeight;
	private int rSubTreeHeight;
	private int balanceFactor;
	
	public int getId() {
		return id;
	}
	public String getData() {
		return data;
	}
	public void setId(int id){
		this.id = id;
	}
	public void setData(String data) {
		this.data = data;
	}
	public Node getParent() {
		return parent;
	}
	public void setParent(Node parent) {
		this.parent = parent;
	}
	public Node[] getChildren() {
		return children;
	}
	public void setChildren(Node[] children) {
		this.children = children;
	}
	public void setChild(Node child, int id){
		this.children[id] = child;
	}

	public  int getHeight(Node t)
	{
		if (t==null) return 0;
		else
			return Math.max(getHeight(t.getChildren()[0]),getHeight(t.getChildren()[1])) + 1;
	}
	
	public int getlSubTreeHeight() {
		Node temp = getChildren()[0];
		if(temp == null){
			lSubTreeHeight = 0;
			return 0;
		}
		lSubTreeHeight = getHeight(temp);
		return lSubTreeHeight;
	}
	public int getrSubTreeHeight() {
		Node temp = getChildren()[1];
		if(temp == null) {
			rSubTreeHeight = 0;
			return 0;
		}
		rSubTreeHeight = getHeight(temp);
		return rSubTreeHeight;
	}
	

	public int getBalanceFactor() {
		balanceFactor=this.getlSubTreeHeight()-this.getrSubTreeHeight();
		return balanceFactor;
	}
	

}
