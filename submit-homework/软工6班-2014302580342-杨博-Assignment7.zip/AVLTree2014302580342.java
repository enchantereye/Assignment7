import java.util.ArrayList;

import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;

public class AVLTree2014302580342 implements IAVLTree {
	private Node root;


	public Node get(int id){
		Node node;
		node = root;
		while(node != null){
			if(id < node.getId()){ 
				node = node.getChildren()[0];
			}
			else if(id>node.getId()){
				node = node.getChildren()[1];
			}
			else if(id == node.getId()){
				System.out.println("�����ɹ�");
				return node;
			}
		}
		return null;
	}
	/**
	 * LL��ת
	 */
	private void LLRotation(Node s){
		Node r = s.getChildren()[0];
	
			s.setChild(r.getChildren()[1], 0);
			if(r.getChildren()[1] != null){
				r.getChildren()[1].setParent(s);
			}
			r.setParent(null);
			r.setChild(null, 1);
			r.setChild(s, 1);
		
			if(s.getParent() == null){
				root = r;
			}
			else{
				r.setParent(s.getParent());
				
				if(s.getParent().getChildren()[0] == s){
					s.getParent().setChild(r, 0);
				}
				else s.getParent().setChild(r, 1);
			}
			
			s.setParent(r);
		}
	
	/**
	 * LR��ת
	 */
	private void LRRotation(Node s){
		Node r = s.getChildren()[0];
	
			
			Node u = r.getChildren()[1];
			r.setChild(u.getChildren()[0], 1);
			s.setChild(u.getChildren()[1], 0);
			if(u.getChildren()[0]!=null){
				u.getChildren()[0].setParent(r);
			}
			if(u.getChildren()[1]!=null){
				u.getChildren()[1].setParent(s);
			}
			u.setChild(null, 0);
			u.setChild(null, 1);
			u.setParent(null);
			r.setParent(null);
			
			u.setChild(r, 0);
			u.setChild(s, 1);
			
			if(s.getParent() == null){
				root = u;
			}
			else {
				u.setParent(s.getParent());
				if(s.getParent().getChildren()[0] == s){
					s.getParent().setChild(u, 0);
				}
				else s.getParent().setChild(u, 1);
			}
			s.setParent(u);
			r.setParent(u);
	}
	/**
	 * RR��ת
	 */
	private void RRRotation(Node s){
		Node r = s.getChildren()[1];
		
			s.setChild(r.getChildren()[0], 1);
			if(r.getChildren()[0] != null){
				r.getChildren()[0].setParent(s);
			}
			r.setParent(null);
			r.setChild(null, 0);
			
			r.setChild(s, 0);
		
			if(s.getParent() == null){
				root = r;
			}
			else{
				r.setParent(s.getParent());
				
				if(s.getParent().getChildren()[0] == s){
					s.getParent().setChild(r, 0);
				}
				else s.getParent().setChild(r, 1);
			}
			
			s.setParent(r);
		
	}
	/**
	 * RL��ת
	 */
	private void RLRotation(Node s){
		Node r = s.getChildren()[1];
		Node u = r.getChildren()[0];
	
			
			r.setChild(u.getChildren()[1], 0);
			s.setChild(u.getChildren()[0], 1);
			if(u.getChildren()[1]!=null){
				u.getChildren()[1].setParent(r);
			}
			if(u.getChildren()[0]!=null){
				u.getChildren()[0].setParent(s);
			}
			u.setChild(null, 0);
			u.setChild(null, 1);
			u.setParent(null);
			r.setParent(null);
			
			u.setChild(r, 1);
			u.setChild(s, 0);
			
			if(s.getParent() == null){
				root = u;
			}
			else {
				u.setParent(s.getParent());
				if(s.getParent().getChildren()[0] == s){
					s.getParent().setChild(u, 0);
				}
				else s.getParent().setChild(u, 1);
			}
			
			s.setParent(u);
			r.setParent(u);
	}
	public void LRotation(Node s){
		Node r = s.getChildren()[0];
		if(r.getBalanceFactor() == -1){
			LRRotation(s);
		}
		else if(r.getBalanceFactor() == 1){
			LLRotation(s);
		}
	}
	public void RRotation(Node s){
		Node r = s.getChildren()[1];
		if(r.getBalanceFactor() == -1){
			RRRotation(s);
		}
		else if(r.getBalanceFactor() == 1){
			RLRotation(s);
		}
	}

	/**
	 * @override
	 * insert the node by id
	 *  the parent node id to insert
	 */
	public  void insert(Node node){
		//�ж����Ƿ�Ϊ��
		if(root == null)
			root = node;
		//��ʽ��ʼ����
		else{
			insert(root,node);
		}
	}
	public void insert(Node temp,Node node){
		//�����
		boolean idCompare = node.getId()<temp.getId();
		if(idCompare){
			if(temp.getChildren()[0] !=null){
				insert(temp.getChildren()[0],node);
			}
			else {
				temp.setChild(node, 0);
				node.setParent(temp);
			}
			if(temp.getParent() != null){
			//��ת�ж�
				if(temp.getBalanceFactor() ==1){
					int leftFlag = temp.getParent().getBalanceFactor();
					if((leftFlag>1)||(leftFlag<-1)){
						LRotation(temp.getParent());
					}
						
						
					
				}
			}
		}
		//��ͻ
		else if(node.getId() == temp.getId()){
			System.out.println("�ڵ��Ѵ���");
		}
		//�Ҳ���
		else if(node.getId()> temp.getId()){
			if(temp.getChildren()[1] != null){
				insert(temp.getChildren()[1], node);
			}
			else{
				temp.setChild(node, 1);
				node.setParent(temp);
			}
			
			if(temp.getParent() != null){
			//��ת�ж�
				if(temp.getBalanceFactor() == -1){
					int rightFlag = temp.getParent().getBalanceFactor();
					boolean rFlag = (rightFlag>1)||(rightFlag<-1);
					if(rFlag)
						RRotation(temp.getParent());
					
					}
				}
			}
		}
		
	
	//�������
	public ArrayList<Node> InOrder(){
		ArrayList<Node>  nodes = new ArrayList<Node>();
		InOrder(nodes,root);
		return nodes;
	}
	private void InOrder(ArrayList<Node> nodes,Node node){
		if(node != null){
			InOrder(nodes,node.getChildren()[0]);
			nodes.add(node);
			InOrder(nodes,node.getChildren()[1]);
		}
	}
	/**
	 * the node id to delete
	 * @param id
	 */
	
	public void delete(int id){
		int index = 0;
		Node temp = new Node(); 
		temp=	get(id);
		//���������ýڵ�λ��
		ArrayList<Node> nodes = InOrder();
		for(Node n : nodes){
			if(n == temp){
				index = nodes.indexOf(n);
			}
		}
		//ת��Ϊɾ�����ֻ��һ�����ӽڵ������
		if((temp.getChildren()[0]!=null)&&(temp.getChildren()[1]!=null)){
			if(nodes.get(index +1) != null){
				temp.setData(nodes.get(index +1).getData());
				temp.setId(nodes.get(index +1).getId());
				temp = nodes.get(index +1);
			}
			else{
				temp.setData(nodes.get(index -1).getData());
				temp.setId(nodes.get(index -1).getId());
				temp = nodes.get(index -1);
			}
		}
		//ɾ�����ڵ�
		if(temp == root){
			if(root.getChildren()[0] != null){
				root.getChildren()[0].setParent(null);
				root.getChildren()[0].setChild(root.getChildren()[1], 1);
				root = root.getChildren()[0];
			}
			else if(root.getChildren()[1] != null){
				root.getChildren()[1].setParent(null);
				root.getChildren()[1].setChild(root.getChildren()[0], 0);
				root = root.getChildren()[1];
			}
		}
		//��������
		else {
			if(temp.getParent().getBalanceFactor() == 0){
				delete(temp);
			}
			else if((temp.getParent().getBalanceFactor() == 1&&temp.getParent().getChildren()[0] == temp)
					||(temp.getParent().getBalanceFactor() == -1&&temp.getParent().getChildren()[1] == temp)){
				delete(temp);
				DeleteRotation(temp);
			}
			else if((temp.getParent().getChildren()[1]==temp&&temp.getParent().getBalanceFactor()==1)
					||(temp.getParent().getChildren()[0]==temp&&temp.getParent().getBalanceFactor()==-1))
			{
				delete(temp);
				DeleteRotation(temp);
			}
			
		}
		
	}
	//ɾ��ʱ����ת
	private void DeleteRotation(Node node){
		while(node.getBalanceFactor()<2&&node.getBalanceFactor()>-2)
		{
			node=node.getParent();	
			if(node==null)
				break;									
		}
		
		if(node!=null)
		{
			if(node.getParent().getBalanceFactor()==-2){
				RRotation(node);
			}
			else if(node.getParent().getBalanceFactor()==2){
				LRotation(node);
			}
		}	
	}
	//ɾ�������ڵ�
	private void delete(Node temp){
		//ɾ����Ϊ������
		if(temp.getParent().getChildren()[0] == temp)
		{					
			if(temp.getChildren()[0]!=null)
			{
				temp.getChildren()[0].setParent(temp.getParent());
				temp.getParent().setChild(temp.getChildren()[0], 0);
				temp=temp.getChildren()[0];
			}
			else if(temp.getChildren()[1]!=null)
			{
				temp.getChildren()[1].setParent(temp.getParent());
				temp.getParent().setChild(temp.getChildren()[1], 0);
				temp=temp.getChildren()[1];
			}
			else
			{
				temp=temp.getParent();
				temp.setChild(null, 0);
			}	
		}
		//ɾ����Ϊ������
		else if(temp.getParent().getChildren()[1]==temp)
		{
			if(temp.getChildren()[0]!=null)
			{
				temp.getChildren()[0].setParent(temp.getParent());
				temp.getParent().setChild(temp.getChildren()[0], 1);
				temp=temp.getChildren()[0];
			}
			else if(temp.getChildren()[1]!=null)
			{
				temp.getChildren()[1].setParent(temp.getParent());
				temp.getParent().setChild(temp.getChildren()[1], 1);
				temp=temp.getChildren()[1];
			}
			else
			{
				temp=temp.getParent();
				temp.setChild(null, 1);
			}
		}
	}
	/**
	 * print the whole tree
	 * @return a java swing Object JTree
	 */
	public JTree printTree()
	{
		DefaultMutableTreeNode defalutNode=new DefaultMutableTreeNode();
		printTree(defalutNode,root);
		JTree temp=new JTree(defalutNode);
		return temp;
	}
	
	private void printTree(DefaultMutableTreeNode defalutNode,Node node)
	{
		if(node!=null)
		{
			
			if(node.getChildren()[0]!=null)
			{
				DefaultMutableTreeNode a=new DefaultMutableTreeNode(node.getChildren()[0].getId());
				defalutNode.add(a);
				printTree(a,node.getChildren()[0]);
			}

			if(node.getChildren()[1]!=null)
			{
				DefaultMutableTreeNode b=new DefaultMutableTreeNode(node.getChildren()[1].getId());
				defalutNode.add(b);
				printTree(b,node.getChildren()[1]);
			}
		}
	}
	public void visit(){
		ArrayList<Node> a =InOrder();
		for(Node b:a){
			System.out.println(b.getId() + " ");
		}
	}
}

