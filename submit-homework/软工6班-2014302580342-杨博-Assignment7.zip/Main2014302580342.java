import javax.swing.*;
import java.awt.*;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class Main2014302580342 {
	public static  void main(String[] args) {
		String file = "d:\\tree_data.dat";
		String str;
        String[] strArr;
        final AVLTree2014302580342 tree = new AVLTree2014302580342();
        BufferedReader bre;
        try {
            
            bre = new BufferedReader(new FileReader(file));
            while ((str = bre.readLine())!= null) {
                Node temp = new Node();
                strArr = str.split("#");
                temp.setData(strArr[0]);
                temp.setId(Integer.parseInt(strArr[1]));
                tree.insert(temp);
            }
            tree.delete(6);
            tree.delete(11);
            System.out.println(tree.get(10).getId()+" : " + tree.get(10).getData());
            bre.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
       JTree test = tree.printTree();

        final JFrame frame = new JFrame("JTree");
        frame.setSize(600, 600);
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setResizable(false);
        Container gui = frame.getContentPane();
        gui.add(test);
	}
}
