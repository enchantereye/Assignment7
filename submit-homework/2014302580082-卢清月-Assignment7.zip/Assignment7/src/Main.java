import javax.swing.JTree;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.DefaultMutableTreeNode;

public class Main {
	private static final JTree tree = new JTree();
       public static void main(String[] args){
    	   AVLTree avltree = new AVLTree();

  
    	   Gui gui = new Gui(avltree);
    	   tree.setBounds(29, 101, 353, 362);
    	   gui.getContentPane().add(tree);
    	   tree.setModel(new DefaultTreeModel(
    	   	new DefaultMutableTreeNode("dress") {
    	   		{
    	   			DefaultMutableTreeNode node_1;
    	   			DefaultMutableTreeNode node_2;
    	   			DefaultMutableTreeNode node_3;
    	   			node_1 = new DefaultMutableTreeNode("baby");
    	   				node_2 = new DefaultMutableTreeNode("apple");
    	   					node_2.add(new DefaultMutableTreeNode("ant"));
    	   				node_1.add(node_2);
    	   				node_2 = new DefaultMutableTreeNode("car");
    	   					node_2.add(new DefaultMutableTreeNode("art"));
    	   					node_2.add(new DefaultMutableTreeNode("banana"));
    	   				node_1.add(node_2);
    	   			add(node_1);
    	   			node_1 = new DefaultMutableTreeNode("show");
    	   				node_2 = new DefaultMutableTreeNode("love");
    	   					node_3 = new DefaultMutableTreeNode("frog");
    	   						node_3.add(new DefaultMutableTreeNode("door"));
    	   					node_2.add(node_3);
    	   				node_1.add(node_2);
    	   				node_2 = new DefaultMutableTreeNode("table");
    	   					node_2.add(new DefaultMutableTreeNode("rice"));
    	   					node_3 = new DefaultMutableTreeNode("trouble");
    	   						node_3.add(new DefaultMutableTreeNode("tree"));
    	   						node_3.add(new DefaultMutableTreeNode("window"));
    	   					node_2.add(node_3);
    	   				node_1.add(node_2);
    	   			add(node_1);
    	   		}
    	   	}
    	   ));

       }
}
