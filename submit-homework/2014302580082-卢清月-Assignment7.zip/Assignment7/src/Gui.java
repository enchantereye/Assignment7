import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.tree.DefaultMutableTreeNode;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

public class Gui  extends JFrame{
	private JLabel jl1 = new JLabel("ID");
	private JLabel jl2 = new JLabel("DATA");
    private JButton jb1 = new JButton("����");
    private JButton jb2 = new JButton("ɾ��");
    private JButton jb3 = new JButton("GET");
	private JTextArea id = new JTextArea();
	private JTextArea data = new JTextArea();
//	private JPanel tree = new JPanel();
	public Gui(AVLTree avltree){
		//JFrame jf1 = new JFrame();
		//���ô���
		this.setResizable(false);
		this.setTitle("AVLTree");
        this.setBounds(120,100,420,530);			
        this.setVisible(true);
        setLayout(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		jl1.setBounds(50,30,50,20);
		add(jl1);
		jl2.setBounds(50,60,50,20);
		add(jl2);
		//��ʼ�������
        id.setOpaque(true);
        data.setOpaque(true);
        id.setEditable(true);
        data.setEditable(true);
        id.setBounds(105,30,80,20);
        data.setBounds(105,60,80,20);
        add(id);add(data);
     //   tree.setOpaque(true);
        //tree.setEditable(false);
    //    tree.setBounds(50,130,370,420);
    //    add(tree);
        jb1.setBounds(200,40,60,40);
        jb2.setBounds(270,40,60,40);
        jb3.setBounds(340,40,60,40);
		add(jb1);add(jb2);add(jb3);
		
		jb1.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				int id1 = Integer.parseInt(id.getText());
				if(id.getText()==null||data.getText()==null)  
					JOptionPane.showMessageDialog(null,"����Ϊ��");
				else {
				  avltree.insert(id1, new Node(id1,data.getText()));
				  JOptionPane.showMessageDialog(null,"����ɹ���");
				}
			}
		});
		
		jb2.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				int id1 = Integer.parseInt(id.getText());
				if(id.getText()==null||data.getText()==null)  
					JOptionPane.showMessageDialog(null,"����Ϊ��");
				else if(avltree.get(id1)==null)
					JOptionPane.showMessageDialog(null,"�ýڵ㲻����");
				else {
					avltree.delete(id1);
					JOptionPane.showMessageDialog(null,"ɾ���ɹ���");
				}
				
			}
		});
		
		jb3.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				int id1 = Integer.parseInt(id.getText());
		    if(avltree.get(id1)!=null){
		    	JOptionPane.showMessageDialog(null,"���ҳɹ���");
		    	data.setText((String) avltree.get(id1).getData());
		    }
		    else
		    	JOptionPane.showMessageDialog(null,"����ʧ�ܣ�");
		
			}
		});
		
		//��ʾ��ö���ƽ����
//		JTree jtree = new JTree();
//		jtree = avltree.printTree();
//		tree.add(jtree);
		
	}
	

}
