import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTree;
public class Test extends AVLTree2014302580818{

	public static void main(String[] args)throws NullPointerException {
		// TODO Auto-generated method stub
		
			AVLTree2014302580818 avltree=new AVLTree2014302580818();
			Node a=new Node();
	        Node b=new Node();
	        Node c=new Node();
	        Node d=new Node();
	        Node e=new Node();
	        Node f=new Node();
	        Node g=new Node();
	        Node h=new Node();
	        Node i=new Node();
	        Node j=new Node();
	        a.setData(31);
	        b.setData(10);
	        c.setData(50);
	        d.setData(8);
	        e.setData(20);
	        f.setData(60);
	        g.setData(5);
	        h.setData(9);
	        i.setData(15);
	        j.setData(26);
	        avltree.insert(a);
	        avltree.insert(b);
	        avltree.insert(c);
	        avltree.insert(d);
	        avltree.insert(e);
	        avltree.insert(f);
	        avltree.insert(g);
	        avltree.insert(h);
	        avltree.insert(i);
	        avltree.insert(j);
	        
			JTree tree=avltree.printTree();		
			JFrame frame1 = new JFrame("AVLTree");
			frame1.add(tree);
		    frame1.setSize(500, 500);
		    frame1.setVisible(true);
		    frame1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		    
		    JFrame frame2=new JFrame("get(4)�����ֵ");
		    String data=avltree.get(4).getData().toString();
		    JLabel label2 =new JLabel(data);	
		    frame2.add(label2);
		    frame2.setSize(500, 500);
		    frame2.setVisible(true);
		    frame2.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
						
			JFrame frame3=new JFrame("����21");
			Node k=new Node();
			k.setData(21);
			avltree.insert(k);
			JTree tree1=avltree.printTree();
			frame3.add(tree1);
		    frame3.setSize(500, 500);
		    frame3.setVisible(true);
		    frame3.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);		   
			
		    JFrame frame4=new JFrame("ɾ��id=2");	
		    avltree.delete(2);
			JTree tree2=avltree.printTree();
			frame4.add(tree2);
		    frame4.setSize(500, 500);
		    frame4.setVisible(true);
		    frame4.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
	}

}
