import java.util.Stack;

import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;

public class AVLTree2014302580818 extends Node implements IAVLTree2014302580181{
	public Node[] inorder=null;
	public Node[] levelorder=null;
	public Node root=null;
	private int lSubTreeHeight;
	private int rSubTreeHeight;
	private int balanceFactor;
	
	private int getTreeHeight(Node n){
		if (n == null)
			return 0;
		else {
			int left = getTreeHeight(n.getChildren()[0]);
			int right = getTreeHeight(n.getChildren()[1]);
			return 1 + Math.max(left, right);
			}
	}
	
	private int getlSubTreeHeight(Node n){
		if(n==null)
			return 0;
		else{
			Node x=n.getChildren()[0];
			return getTreeHeight(x);
		}
	}
	
	private int getrSubTreeHeight(Node n){
		if(n==null)
			return 0;
		else{
			Node x=n.getChildren()[1];
			return getTreeHeight(x);
		}
	}
	
	private int CheckBalance(Node n){
		lSubTreeHeight=getlSubTreeHeight(n);
		rSubTreeHeight=getrSubTreeHeight(n);
		balanceFactor=lSubTreeHeight-rSubTreeHeight;
		return balanceFactor;
	}
	
	private boolean small(Object x,Object y) {
		double a=Double.parseDouble(x.toString());
		double b=Double.parseDouble(y.toString());
		if(a<b){
			return true;
		}
		else
			return false;
	}

	private boolean large(Object x,Object y) {
		double a=Double.parseDouble(x.toString());
		double b=Double.parseDouble(y.toString());
		if(a>b){
			return true;
		}
		else
			return false;
	}
			
	private void KeepBalance(Node n){
		if(CheckBalance(n)==2){
			Node son=n.getChildren()[0];
			if(CheckBalance(son)==-1){
				Node son1=son.getChildren()[1];
				son.setChild(son1.getChildren()[0], 1);
				son1.getChildren()[0].setParent(son);
				n.setChild(son1.getChildren()[1], 0);
				son1.getChildren()[1].setParent(n);
				Node p=n.getParent();
		    	if(p!=null){
		    		if(p.getChildren()[0]==n){
						p.setChild(son1, 0);
					}
					else{
						p.setChild(son1, 1);
					}
		    		son1.setParent(p);
		    	}
		    	son1.setChild(son, 0);
		    	son.setParent(son1);
		    	son1.setChild(n, 1);
		    	n.setParent(son1);
			}	
			else{
				n.setChild(son.getChildren()[1], 0);
				Node p=n.getParent();
				if(p!=null){
		    		if(p.getChildren()[0]==n){
						p.setChild(son, 0);
					}
					else{
						p.setChild(son, 1);
					}
		    		son.setParent(p);
		    	}
		    	son.setChild(n, 1);
		    	n.setParent(son);
			}
		}
		else if(CheckBalance(n)==-2){
			Node son=n.getChildren()[1];
			if(CheckBalance(son)==1){
				Node son1=son.getChildren()[0];
				son.setChild(son1.getChildren()[1], 0);
				son1.getChildren()[1].setParent(son);
				n.setChild(son1.getChildren()[0], 1);
				son1.getChildren()[0].setParent(n);
				Node p=n.getParent();
		    	if(p!=null){
		    		if(p.getChildren()[0]==n){
						p.setChild(son1, 0);
					}
					else{
						p.setChild(son1, 1);
					}
		    		son1.setParent(p);
		    	}
		    	son1.setChild(son, 1);
		    	son.setParent(son1);
		    	son1.setChild(n, 0);
		    	n.setParent(son1);
			}	
			else{
				n.setChild(son.getChildren()[0], 1);
				Node p=n.getParent();
				if(p!=null){
		    		if(p.getChildren()[0]==n){
						p.setChild(son, 0);
					}
					else{
						p.setChild(son, 1);
					}
		    		son.setParent(p);
		    	}
		    	son.setChild(n, 0);
		    	n.setParent(son);
			}
		}
	}
	
	private Node getRoot(Node x) {
		while(x.getParent()!=null){
			x=x.getParent();
		}
		return x;
	}
	
	
   public Node[] inorder(Node root){
		int x=0;
	    Stack<Node> stack = new Stack<Node>();
		stack.push(root);
		Node node =root;
		while(node.getChildren()[0]!=null){
			stack.push(node.getChildren()[0]);
			node  = node.getChildren()[0];
		}
		while(!stack.empty()){
			inorder[x]=stack.peek();
			x++;
			Node popNode = stack.pop();
			if(popNode.getChildren()[1]!=null){
				Node node1 = popNode.getChildren()[1];
				stack.push(node1);
				while(node.getChildren()[0]!=null){
					stack.push(node.getChildren()[0]);
					node1  = node.getChildren()[0];
				}
			}
		}
		return inorder;
	}
	
   private Node[] levelOrder(Node root){
	   int height=getTreeHeight(root);
	   Node[] in=inorder(root);
	   int length=in.length;
	   Node nn[][]=null;
	   Node[] levelNode = null;
	   int x=0;
	   int y=0;
	   for(int i=0;i<length;i++){
		   int j=height-getTreeHeight(in[i]);
		   nn[j][x]=in[i];
		   x++;
	   }
	   for(int f=0;f<height;f++){
		   for(int k=0;nn[f][k]!=null;k++){
			   levelNode[y]=nn[f][k];
			   y++;
		   }
	   }
	   return levelNode;
   }
   
	@Override
	public Node get(int id) {
		// TODO Auto-generated method stub
        if(root==null){
        	return null;
        }
        else{
        	Node[] list=levelOrder(root);
        	if(list.length<id){
        		return null;
        	}
        	return list[id];
        }
	}	

	@Override
	public void insert(Node newNode) {
		if(root!=null){
			Object data=newNode.getData();
			Node[] node=inorder(root);;
			Node lowNode=newNode;
			Node highNode=newNode;
			for(int i=0;i<node.length;i++){
				if(large(lowNode.getData(),inorder[i].getData())
						&&small(inorder[i].getData(),data)){
					lowNode=inorder[i];
				}
				else if(small(highNode.getData(),inorder[i].getData())
						&&large(inorder[i].getData(),data)){
					highNode=inorder[i];
				}
			}
			if(lowNode.getChildren()[1]==null){
				lowNode.setChild(newNode, 1);
				newNode.setParent(lowNode);
				Node p=lowNode;
				while(p!=null){
					KeepBalance(p);
					p=p.getParent();
				}
			}
			else{
				highNode.setChild(newNode, 0);
				newNode.setParent(highNode);
				Node p=highNode;
				while(p!=null){
					KeepBalance(p);
					p=p.getParent();
				}
			}
			root=getRoot(newNode);
		}
		else{
			root=newNode;
		}	
	}
    
	@Override
	public void delete(int id) {
		// TODO Auto-generated method stub
		if(root!=null){
			Node[] ind=inorder(root);
			Node deleteNode=get(id);
			Node afterNode=null;
			for(int q=0;q<ind.length;q++){
				if(ind[q]==deleteNode){
					afterNode=ind[q+1];
					break;
				}
			}
		    if(afterNode!=null){
		    	 Node pafterNode=afterNode.getParent();
				 Node pdeleteNode=deleteNode.getParent();
				 Node safterNode=afterNode.getChildren()[1];
				 pafterNode.setChild(safterNode, 0);
				 safterNode.setParent(pafterNode);
				 afterNode.setChildren(deleteNode.getChildren());
				 deleteNode.getChildren()[0].setParent(afterNode);
				 deleteNode.getChildren()[1].setParent(afterNode);
				 if(pdeleteNode!=null){
		    		 if(pdeleteNode.getChildren()[0]==deleteNode){
		    		    pdeleteNode.setChild(afterNode, 0);				
					 }
		    		 else{
						pdeleteNode.setChild(afterNode, 1);
					 }
		    		 afterNode.setParent(pdeleteNode);
		    	 }
				 deleteNode=null;
				 Node x=safterNode;
				 while(x!=null){
					 KeepBalance(x);
				     x=x.getParent();
				 }
				 root=getRoot(afterNode);
		    }
		    else {
		    	 Node predeleteNode=get(id-1);
		    	 if(predeleteNode!=null){
		    		 Node pdeleteNode=deleteNode.getParent();
		    		 pdeleteNode.setChild(predeleteNode, 1);
		    		 predeleteNode.setParent(pdeleteNode);
		    		 Node x=predeleteNode;
					 while(x!=null){
						 KeepBalance(x);
					     x=x.getParent();
					 }
					 root=getRoot(predeleteNode);
		    	 }
		    	 else
		    	 {
		    		 deleteNode=null;
		    		 root=null;
		    	 }
		    }
		}
	}
	
	private void print(Node parent){
        if(parent.getChildren()[0]!=null&&parent.getChildren()[1]!=null){        	
    		Node lchild=parent.getChildren()[0];
    		Node rchild=parent.getChildren()[1];
    		DefaultMutableTreeNode TreeParent = new DefaultMutableTreeNode(parent);
    		DefaultMutableTreeNode TreeLChild = new DefaultMutableTreeNode(lchild);
    		DefaultMutableTreeNode TreeRChild = new DefaultMutableTreeNode(rchild);
    		TreeParent.add(TreeLChild);
    		TreeParent.add(TreeRChild);
    		print(lchild);
    		print(rchild);
        }
        else if(parent.getChildren()[0]!=null){
            Node rchild=parent.getChildren()[1];
    		DefaultMutableTreeNode TreeParent = new DefaultMutableTreeNode(parent.getData().toString());
    		DefaultMutableTreeNode TreeRChild = new DefaultMutableTreeNode(rchild.getData().toString());
    		TreeParent.add(TreeRChild);
        }
        else{
        	Node lchild=parent.getChildren()[0];
    		DefaultMutableTreeNode TreeParent = new DefaultMutableTreeNode(parent.getData().toString());
    		DefaultMutableTreeNode TreeLChild = new DefaultMutableTreeNode(lchild.getData().toString());
    		TreeParent.add(TreeLChild);
        }
	}
	
	@Override
	public JTree printTree() {
		// TODO Auto-generated method stub
		DefaultMutableTreeNode TreeRoot = new DefaultMutableTreeNode(root.getData().toString());
		JTree tree=new JTree(TreeRoot);
	    print(root);
        return tree;       
	}

}
