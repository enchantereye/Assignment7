import javax.swing.JTree;

	public interface IAVLTree {
	
		Node get(int id);
	
		void insert(Node newNode);
	
		void delete(int id);
	
		JTree printTree();

	}
	


