import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;

import javax.swing.JFrame;
import javax.swing.JTree;
import javax.swing.WindowConstants;

public class Assignment7 {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		AVLTree tree=new AVLTree();
		treeInit(tree);
		tree.delete(16);
		showTree(tree);
	}
	
	public static void treeInit(AVLTree tree) throws IOException{
		BufferedReader bufr=new BufferedReader(new InputStreamReader(new FileInputStream(".\\tree_data.dat")));
		String line=null;
		while((line=bufr.readLine())!=null){
			Node node=new Node();
			String [] contents=line.split("#");
			node.setId(Integer.valueOf(contents[1]));
			node.setData(contents[0]);
			tree.insert(node);
		}
		bufr.close();
	}
	
	public static void showTree(AVLTree tree){
		JFrame jf=new JFrame("AVLTree");
		jf.setBounds(400,200,500,400);
		jf.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		JTree treeGUI=tree.printTree();
		jf.add(treeGUI);
		jf.setVisible(true);
	}
}
