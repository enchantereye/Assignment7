import javax.swing.JFrame;
import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;

public class AVLTree implements IAVLTree {
	static int number = 0;
	private Node root;// ���ø�

	@Override
	public Node get(int id) {
		// TODO Auto-generated method stub
		return visit(root,id);
	}
        //ǰ�����������������Ѱ����Ҫ�ҵĽڵ�
	private Node visit(Node stemp, int id) {
		if (stemp != null) {
			if (stemp.getId() == id)
				return stemp;
			else {
				if (stemp.getChildren()[0] != null&&id<stemp.getId())
					return visit(stemp.getChildren()[0], id);
				if (stemp.getChildren()[1] != null&&id>stemp.getId())
					return visit(stemp.getChildren()[1], id);
			}
		}
		return null;
	}

	@Override
	public void insert(Node newNode) {
		// TODO Auto-generated method stub
		newNode.setParent(null);
		newNode.setChild(null, 1);
		newNode.setChild(null, 0);
		if(number==0){
			root=newNode;
			number++;
		}
		else{
			compareId(newNode,root);
			//���������ɺ���е���ת����
			Node s=newNode;
			Node r=null;
			Node u=null;
			while(s.getBalanceFactor()!=2&&s.getParent()!=null){
				if(s.getBalanceFactor()==-2)
					break;
				s=s.getParent();
			}
			/*if(s==null)
				return;*/
			//LL��LR��ת
			if(s.getBalanceFactor()==2)
			{
				r=s.getChildren()[0];
				if(r.getBalanceFactor()==1){
					s.setChild(r.getChildren()[1], 0);
					//�ж�s�Ǹ�������ӻ����Һ���
					if (s.getParent() == null)
						r.setParent(null);
					else {
						if (s.getParent().getChildren()[0]!=null&&s.getParent().getChildren()[0].getId() == s.getId())
							s.getParent().setChild(r, 0);
						if (s.getParent().getChildren()[1]!=null&&s.getParent().getChildren()[1].getId() == s.getId())
							s.getParent().setChild(r, 1);
					}
					r.setChild(s, 1);
					if(r.getParent()==null)
						root=r;
					return;
				}
				if(r.getBalanceFactor()==-1){
					u=r.getChildren()[1];
					//u.setParent(s.getParent());
					if (s.getParent() == null)
						r.setParent(null);
					else {
						if (s.getParent().getChildren()[0]!=null&&s.getParent().getChildren()[0].getId() == s.getId())
							s.getParent().setChild(u, 0);
						if (s.getParent().getChildren()[1]!=null&&s.getParent().getChildren()[1].getId() == s.getId())
							s.getParent().setChild(u, 1);
					}
					r.setChild(u.getChildren()[0], 1);
					u.setChild(r, 0);
					s.setChild(u.getChildren()[1], 0);
					u.setChild(s, 1);
					if(u.getParent()==null)
						root=u;
					return;
				}
				
			}
			//RR��RL��ת
			if(s.getBalanceFactor()==-2){
				r=s.getChildren()[1];
				if(r.getBalanceFactor()==-1){
					s.setChild(r.getChildren()[0], 1);
					//r.setParent(s.getParent());
					if (s.getParent() == null)
						r.setParent(null);
					else {
						if (s.getParent().getChildren()[0]!=null&&s.getParent().getChildren()[0].getId() == s.getId())
							s.getParent().setChild(r, 0);
						if (s.getParent().getChildren()[1]!=null&&s.getParent().getChildren()[1].getId() == s.getId())
							s.getParent().setChild(r, 1);
					}
					r.setChild(s, 0);
					if(r.getParent()==null)
						root=r;
					return;
				}
				if(r.getBalanceFactor()==1){
					u=r.getChildren()[0];
					//u.setParent(s.getParent());
					if (s.getParent() == null)
						r.setParent(null);
					else {
						if (s.getParent().getChildren()[0]!=null&&s.getParent().getChildren()[0].getId() == s.getId())
							s.getParent().setChild(u, 0);
						if (s.getParent().getChildren()[1]!=null&&s.getParent().getChildren()[1].getId() == s.getId())
							s.getParent().setChild(u, 1);
					}
					r.setChild(u.getChildren()[1], 0);
					u.setChild(r, 1);
					s.setChild(u.getChildren()[0], 1);
					u.setChild(s, 0);
					if(u.getParent()==null)
						root=u;
					return;
				}
			}
		}
		number++;
	}
	private void compareId(Node tree_node,Node sroot){
		//������������˶����������Ĳ������
		if(tree_node.getId()==sroot.getId()){
			System.out.println("�ڵ�Ĺؼ���ֵ������ͬ");
		}
		if(tree_node.getId()<sroot.getId()){
			if(sroot.getChildren()[0]!=null){
			compareId(tree_node,sroot.getChildren()[0]);
			return;
			}
			sroot.setChild(tree_node, 0);
		}
		if(tree_node.getId()>sroot.getId()){
			if(sroot.getChildren()[1]!=null){
			compareId(tree_node,sroot.getChildren()[1]);
			return;
			}
			sroot.setChild(tree_node, 1);
		}
	}
	@Override
	public void delete(int id) {
		// TODO Auto-generated method stub
		Node  toDelete=visit(root,id);
		if(toDelete==null){
			System.out.println("�����޸ýڵ�");
			return;
		}
		//��������º�̽ڵ㲻����ʱ
		if(toDelete.getChildren()[1]==null){
			if(toDelete.getParent()==null&&toDelete.getChildren()[0]==null){
				root=null;
				return;
			}
			if(toDelete.getParent()==null&&toDelete.getChildren()[0]!=null){
				root=toDelete.getChildren()[0];
				return;
			}
			if(toDelete.getParent()!=null&&toDelete.getChildren()[0]==null){
				if(toDelete.getParent().getChildren()[0]!=null&&toDelete.getParent().getChildren()[0].getId()==toDelete.getId())
					toDelete.getParent().setChild(null, 0);
				if(toDelete.getParent().getChildren()[1]!=null&&toDelete.getParent().getChildren()[1].getId()==toDelete.getId())
					toDelete.getParent().setChild(null, 1);
				 if(toDelete.getParent().getBalanceFactor()==2){
					 Node s=toDelete.getParent();
					 Node  r=s.getChildren()[0];
					 Node u=null;
					 if(r.getBalanceFactor()==1){
							s.setChild(r.getChildren()[1], 0);
							//�ж�s�Ǹ�������ӻ����Һ���
							if (s.getParent() == null)
								r.setParent(null);
							else {
								if (s.getParent().getChildren()[0]!=null&&s.getParent().getChildren()[0].getId() == s.getId())
									s.getParent().setChild(r, 0);
								if (s.getParent().getChildren()[1]!=null&&s.getParent().getChildren()[1].getId() == s.getId())
									s.getParent().setChild(r, 1);
							}
							r.setChild(s, 1);
							if(r.getParent()==null)
								root=r;
							return;
						}
						if(r.getBalanceFactor()==-1){
							u=r.getChildren()[1];
							//u.setParent(s.getParent());
							if (s.getParent() == null)
								r.setParent(null);
							else {
								if (s.getParent().getChildren()[0]!=null&&s.getParent().getChildren()[0].getId() == s.getId())
									s.getParent().setChild(u, 0);
								if (s.getParent().getChildren()[1]!=null&&s.getParent().getChildren()[1].getId() == s.getId())
									s.getParent().setChild(u, 1);
							}
							r.setChild(u.getChildren()[0], 1);
							u.setChild(r, 0);
							s.setChild(u.getChildren()[1], 0);
							u.setChild(s, 1);
							if(u.getParent()==null)
								root=u;
							return;
						}
				 }
				return;
			}
			if(toDelete.getParent()!=null&&toDelete.getChildren()[0]!=null){
				if(toDelete.getParent().getChildren()[0]!=null&&toDelete.getParent().getChildren()[0].getId()==toDelete.getId())
					toDelete.getParent().setChild(toDelete.getChildren()[0], 0);
				if(toDelete.getParent().getChildren()[1]!=null&&toDelete.getParent().getChildren()[1].getId()==toDelete.getId())
					toDelete.getParent().setChild(toDelete.getChildren()[0], 1);
				
				 if(toDelete.getParent().getBalanceFactor()==2){
					 Node s=toDelete.getParent();
					 Node  r=s.getChildren()[0];
					 Node u=null;
					 if(r.getBalanceFactor()==1){
							s.setChild(r.getChildren()[1], 0);
							//�ж�s�Ǹ�������ӻ����Һ���
							if (s.getParent() == null)
								r.setParent(null);
							else {
								if (s.getParent().getChildren()[0]!=null&&s.getParent().getChildren()[0].getId() == s.getId())
									s.getParent().setChild(r, 0);
								if (s.getParent().getChildren()[1]!=null&&s.getParent().getChildren()[1].getId() == s.getId())
									s.getParent().setChild(r, 1);
							}
							r.setChild(s, 1);
							if(r.getParent()==null)
								root=r;
							return;
						}
						if(r.getBalanceFactor()==-1){
							u=r.getChildren()[1];
							//u.setParent(s.getParent());
							if (s.getParent() == null)
								r.setParent(null);
							else {
								if (s.getParent().getChildren()[0]!=null&&s.getParent().getChildren()[0].getId() == s.getId())
									s.getParent().setChild(u, 0);
								if (s.getParent().getChildren()[1]!=null&&s.getParent().getChildren()[1].getId() == s.getId())
									s.getParent().setChild(u, 1);
							}
							r.setChild(u.getChildren()[0], 1);
							u.setChild(r, 0);
							s.setChild(u.getChildren()[1], 0);
							u.setChild(s, 1);
							if(u.getParent()==null)
								root=u;
							return;
						}
				 }
				return;
			}
				
		}
		Node  p=toDelete.getChildren()[1];
		//qΪҪɾ���ڵ����������µ�ֱ�Ӻ�̽��
		Node  q=toDelete.getChildren()[1];
		while(q.getChildren()[0]!=null){
			q=q.getChildren()[0];
		}
		if(p.getBalanceFactor()==0){
			toDelete.setData(q.getData());
			toDelete.setId(q.getId());
			q.getParent().setChild(q.getChildren()[1], 1);
			q.setChild(null,0);
			q.setChild(null,1);
			q.setParent(null);
		}
		
		if(p.getBalanceFactor()>0){
			toDelete.setData(q.getData());
			toDelete.setId(q.getId());
			q.getParent().setChild(q.getChildren()[1], 0);
			q.setChild(null,0);
			q.setChild(null,1);
			q.setParent(null);
			if(toDelete.getBalanceFactor()==2){
				    Node s=toDelete;
					Node r=s.getChildren()[0];
					s.setChild(r.getChildren()[1], 0);
					//r.setParent(s.getParent());
					if (s.getParent() == null){
						r.setParent(null);
						root=r;
					}
					else {
						if (s.getParent().getChildren()[0]!=null&&s.getParent().getChildren()[0].getId() == s.getId())
							s.getParent().setChild(r, 0);
						if (s.getParent().getChildren()[1]!=null&&s.getParent().getChildren()[1].getId() == s.getId())
							s.getParent().setChild(r, 1);
					}
					r.setChild(s, 1);
			}
		}
		if(p.getBalanceFactor()<0){
			if(p==q){
				toDelete.setData(q.getData());
				toDelete.setId(q.getId());
				q.getParent().setChild(q.getChildren()[1], 0);
				q.setChild(null,0);
				q.setChild(null,1);
				q.setParent(null);
				return;
			}
			Node t=p.getChildren()[1];
			//ɾ���ڵ�
			toDelete.setData(q.getData());
			toDelete.setId(q.getId());
			q.getParent().setChild(q.getChildren()[1], 0);
			q.setChild(null,0);
			q.setChild(null,1);
			q.setParent(null);
			
			//�ж�
			if(t.getBalanceFactor()<=0){
				p.setChild(t.getChildren()[0], 1);
				//t.setParent(p.getParent());
				if (p.getParent() == null){
					t.setParent(null);
					root=t;
				}
				else {
					if (p.getParent().getChildren()[0]!=null&&p.getParent().getChildren()[0].getId() == p.getId())
						p.getParent().setChild(t, 0);
					if (p.getParent().getChildren()[1]!=null&&p.getParent().getChildren()[1].getId() == p.getId())
						p.getParent().setChild(t, 1);
				}
				t.setChild(p, 0);
			}
			if(t.getBalanceFactor()>0){
				Node u=null;
				if(t.getlSubTreeHeight()>t.getrSubTreeHeight())
					u=t.getChildren()[0];
				else
					u=t.getChildren()[1];
				p.setChild(u.getChildren()[0], 1);
				t.setChild(u.getChildren()[1], 0);
				//u.setParent(p.getParent());
				if (p.getParent() == null){
					u.setParent(null);
					root=u;
				}
				else {
					if (p.getParent().getChildren()[0]!=null&&p.getParent().getChildren()[0].getId() == p.getId())
						p.getParent().setChild(u, 0);
					if (p.getParent().getChildren()[1]!=null&&p.getParent().getChildren()[1].getId() == p.getId())
						p.getParent().setChild(u, 1);
				}
				u.setChild(p, 0);
				u.setChild(t, 1);
			}
		}
	}

	@Override
	public JTree printTree() {
		// TODO Auto-generated method stub

		DefaultMutableTreeNode top=new DefaultMutableTreeNode(String.valueOf(root.getId())+"ƽ������:"+root.getBalanceFactor());
		addNode(root,top);
		final JTree tree = new JTree(top);
		return tree;
	}

	private void addNode(Node node,DefaultMutableTreeNode jnode){//ǰ��Ĳ���Ҫ����ĳ���ڵ㣬��������Ƕ�Ӧ�Ľڵ�
		if(node.getChildren()[0] != null){
			DefaultMutableTreeNode l=new DefaultMutableTreeNode("��"+node.getChildren()[0].getId()+"ƽ������:"+node.getChildren()[0].getBalanceFactor());
			jnode.add(l);
			addNode(node.getChildren()[0],l);
		}
		if(node.getChildren()[1] != null){
			DefaultMutableTreeNode r=new DefaultMutableTreeNode("��"+node.getChildren()[1].getId()+"ƽ������:"+node.getChildren()[1].getBalanceFactor());
			jnode.add(r);
			addNode(node.getChildren()[1],r);
		}
	}
	public static void main(String [] arg){
		
		Node one=new Node(20);
		Node two=new Node(16);
		Node three=new Node(30);
		Node four=new Node(10);
		Node five=new Node(18);
		Node six=new Node(19);
		Node e=new Node(25);
		Node s=new Node(40);
		Node n=new Node(27);
		AVLTree tree=new AVLTree();
		
	
		tree.insert(one);
		tree.insert(two);
		tree.insert(three);
		tree.insert(four);
		tree.insert(five);
		tree.insert(e);
		tree.insert(s);
		tree.insert(six);
		tree.insert(n);
		Node fe=tree.get(18);
		System.out.println("id=18��ƽ������Ϊ"+fe.getBalanceFactor());
		System.out.println("id=18����������Ϊ"+fe.getlSubTreeHeight());
		System.out.println("id=18����������Ϊ"+fe.getrSubTreeHeight());
		System.out.println("id=18��idΪ"+fe.getId());
		tree.delete(18);
		tree.delete(19);
	    JFrame f = new JFrame("Tree");
        f.add(tree.printTree());
        f.setSize(300, 300);
        f.setVisible(true);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		//���Խڵ�߶�������ȷ
		
		//two.setChild(three, 0);
		//one.setChild(four, 1);
		//four.setChild(five, 1);
//		System.out.print(one.getlSubTreeHeight());
//		System.out.print(one.getrSubTreeHeight());
//		System.out.println(one.getBalanceFactor());
//		System.out.println(two.getBalanceFactor());
		//System.out.println(four.getBalanceFactor());
		//System.out.println(five.getBalanceFactor());
		}
}
