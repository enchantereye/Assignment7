/**
 * Created by coolautumn on 12/21/15.
 */

public class Node {
    public void setId(int id) {
        this.id = id;
    }

    private int id;
    private Object data;
    private Node parent;
    private Node[] children = new Node[2];
    private int lSubTreeHeight;
    private int rSubTreeHeight;

    public Node()
    {

    }
    public Node(int id,Object d)
    {
        this.id=id;
        this.data=d;
    }
    private int balanceFactor;

    public int getId() {
        return id;
    }
    public Object getData() {
        return data;
    }
    public void setData(Object data) {
        this.data = data;
    }
    public Node getParent() {
        return parent;
    }
    public void setParent(Node parent) {
        this.parent = parent;
    }
    public Node[] getChildren() {
        return children;
    }
    public void setChildren(Node[] children) {
        this.children = children;
    }
    public void setChild(Node child, int id){
        this.children[id] = child;
    }

    public int getlSubTreeHeight() {
        //TODO calculate the left sub tree height
        return getTreeHeight(children[0]);
    }
    public int getrSubTreeHeight() {
        //TODO calculate the right sub tree height
        return getTreeHeight(children[1]);
    }
    public int getBalanceFactor() {
        //TODO calculate the balance factor
        return balanceFactor;
    }
    public void setBalanceFactor(int balanceFactor) {
        this.balanceFactor = balanceFactor;
    }

    private int getTreeHeight(Node node){
        if(node==null)
        {
            return 0;
        }
        else
        {
            int lh=node.getTreeHeight(node.getChildren()[0]);
            int rh=node.getTreeHeight(node.getChildren()[1]);
            return lh>rh?lh+1:rh+1;
        }
    }
}

