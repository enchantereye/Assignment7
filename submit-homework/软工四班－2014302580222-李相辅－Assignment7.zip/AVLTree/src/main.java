import javax.swing.*;
import java.util.Scanner;

/**
 * Created by coolautumn on 12/22/15.
 */
/*
 *progress
 *  12.21   --  finish the insert method
 *  12.22 19:40 --  complete the insert and delete(only delete leaf) method debugging
 *  12.23 13.00 --  begin to deal with the delete method(only have left branch)
 *  12.23 17.00 --  complete all work
 */
public class main
{
    static AVLTree avlTree;
    static Node[] all = new Node[]{
            new Node(0,"Default"),
            new Node(1, "ant"),
            new Node(2, "apple"),
            new Node(3, "art"),
            new Node(4, "baby"),
            new Node(5, "banan"),
            new Node(6, "car"),
            new Node(7, "door"),
            new Node(8, "dress"),
            new Node(9, "frog"),
            new Node(10, "love"),
            new Node(11, "mint"),
            new Node(12, "rice"),
            new Node(13, "show"),
            new Node(14, "table"),
            new Node(15, "tree"),
            new Node(16, "trouble"),
            new Node(17, "window"),
    };

    public static void main(String[] args) {

        avlTree = new AVLTree();

        /*
         *first insert some nodes to make a tree
         */
        left_insert();

        Node getNode=avlTree.get(9);//Node(9, "frog")
        System.out.println("id:"+getNode.getId()
                +",Data:"+getNode.getData()
                +",ParentNode:"+(getNode.getParent()!=null?getNode.getParent().getData():"This is root")
                +",BF:"+getNode.getBalanceFactor());


        avlTree.insert(all[2]);
        avlTree.insert(all[16]);

        avlTree.delete(10);
        avlTree.printTree();

    }

    public static void left_insert() {
        avlTree.insert(all[14]);
        avlTree.insert(all[10]);
        avlTree.insert(all[9]);
        avlTree.insert(all[8]);
        avlTree.insert(all[7]);
        avlTree.insert(all[6]);
        avlTree.insert(all[5]);
    }

    public static void right_insert() {
        avlTree.insert(all[0]);
        avlTree.insert(all[2]);
        avlTree.insert(all[1]);
        avlTree.insert(all[5]);
        avlTree.insert(all[14]);
        avlTree.insert(all[4]);
    }
}