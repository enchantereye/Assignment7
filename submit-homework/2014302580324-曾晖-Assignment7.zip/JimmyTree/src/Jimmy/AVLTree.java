package Jimmy;

import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;

public class AVLTree implements IAVLTree
{
	private Node root = null;//根节点
	
	public AVLTree()
	{
		root = null;
	}
	
	public Node getRoot() 
	{
		return root;
	}


	
	@Override
	public Node get(int id) 
	{
		// TODO Auto-generated method stub
		return get(id,root);
	}

	private Node get(int id,Node n)
	{
		if(n == null)
			return null;
		if(n.getId() > id)
			return get(id,n.getChildren()[0]);
		if(n.getId() < id)
			return get(id,n.getChildren()[1]);
		return n;
	}
	
	@Override                          
	public void insert(Node newNode) 
	{
		// TODO Auto-generated method stub
		root = insert(root,newNode,false);
	}
	
	private Node insert(Node n,Node newNode,boolean unbalanced)
	{
		unbalanced = false; 
		//结点为空,直接插入
		if(n == null)
		{
			return newNode;
		}
		//将结点插入左子树
		if(newNode.getId() < n.getId())
		{
			//左子树空就直接插入
			if(n.getChildren()[0] == null)
			{
				n.setLC(newNode);
			}
			//递归调用插入函数
			n.setLC(insert(n.getChildren()[0],newNode,unbalanced));
			//重组
			if((n.getBalanceFactor() == 2) && (unbalanced == false))
				if(newNode.getId() < n.getChildren()[0].getId())
				{
					Node p = n.getChildren()[0];
					n.setLC(p.getChildren()[1]);
					p.setRC(n);
					n = p;
				}
				else
				{
					n.setLC(RRotation(n.getChildren()[0]));
					n = LRotation(n);
				}
			
		}
		//将结点插入右子树
		else if(newNode.getId() > n.getId())
		{
			if(n.getChildren()[1] == null)
			{
				n.setRC(newNode);
			}
			//递归调用插入函数
			n.setRC(insert(n.getChildren()[1],newNode,unbalanced));
			//重组
			if((n.getBalanceFactor() == -2) && (unbalanced == false))
				if(newNode.getId() > n.getChildren()[1].getId())
				{
					Node p = n.getChildren()[1];
					n.setRC(p.getChildren()[0]);
					p.setLC(n);
					n = p;
				}
				else
				{
					n.setRC(LRotation(n.getChildren()[1]));
					n = RRotation(n);
				}
		}
		root.setParent(null);
		return n;
	}
	
	@Override
	public void delete(int id) 
	{
		// TODO Auto-generated method stub
		delete(root,id,false);
	}
	
	private void delete(Node n,int id,boolean unbalanced) 
	{
		unbalanced = false;
		Node p = get(id,n);
		//要删除结点为空
		if(p == null)
			return;
		Node q = p.getParent();  
		Node x = p.getChildren()[1];
		//左右子树均为空
		if((p.getChildren()[0] == null) && (p.getChildren()[1]==null)&&(unbalanced == false))
		{
			if(p.getParent() == null)
			{
				root = null;
				return;
			}
			
			else if(p != p.getParent().getChildren()[0])
				p.getParent().setRC(null);
			else
				p.getParent().setLC(null);
			                      
			for(int i =0;(q != null) && (q.getBalanceFactor() < 2) && (q.getBalanceFactor() > -2);i++)
			{
				q = q.getParent();
			}
			
			while(unbalanced&&p != null)
			{
				Node node = q;
				Node u = p;
				Node r = x;
				p.setBalanceFactor(q.getBalanceFactor());
				int lSubTreeHeight = 0;
				int rSubTreeHeight = 0;
				if(node.getParent()!=null)
					u.setParent(node.getParent());
				r.setParent(u);
				u.getChildren()[0].setParent(r);
				u.getChildren()[1].setParent(node);
				node.setParent(u);
			}
			
			if(q == null)
				return;
			            
			else if(q.getBalanceFactor()==2)
				if(id > q.getChildren()[0].getId())
				{
					Node r = q.getChildren()[0];
					q.setLC(r.getChildren()[1]);
					r.setRC(q);
					q = r;
				}      
				else
				{
					q.setLC(RRotation(q.getChildren()[0]));
					q = LRotation(q);
				}
			else
				if(id < q.getChildren()[1].getId())
				{
					Node r = q.getChildren()[1];
					q.setRC(r.getChildren()[0]);
					r.setLC(q);
					q = r;
				}
				else
				{
					q.setRC(LRotation(q.getChildren()[1]));
					q = RRotation(q);
				}
		}
		
		//左为空，右不为空
		else if(p.getChildren()[0] == null)
		{
			if(p == root)
			{
				root = p.getChildren()[1];
				return;
			}
			else if(p.getParent().getChildren()[0] == p)
				p.getParent().setLC(p.getChildren()[1]);
			else
				p.getParent().setRC(p.getChildren()[1]);
			
			//对于第一个不平衡点
			for(int j =0;(q != null) && q.getBalanceFactor() < 2 && q.getBalanceFactor() > -2 && unbalanced == false;j++)
			{
				q = q.getParent();
			}
			//达到平衡
			if(q == null)
				return;
			//重组
			else if(q.getBalanceFactor()==2)
				if(id > q.getChildren()[0].getId())
				{
					Node r = q.getChildren()[0];
					q.setLC(r.getChildren()[1]);
					r.setRC(q);
					q = r;
				}

				else
				{
					q.setLC(RRotation(q.getChildren()[0]));
					q = LRotation(q);
				}
			else
				if(id < q.getChildren()[1].getId())
				{
					Node r = q.getChildren()[1];
					q.setRC(r.getChildren()[0]);
					r.setLC(q);
					q = r;
				}
				else
				{
					q.setRC(LRotation(q.getChildren()[1]));
					q = RRotation(q);
				}
		}
		//右 为空，左不为空
		else if(p.getChildren()[1] == null)
		{
			if(p == root)
			{
				root = p.getChildren()[0];
				return;
			}
			else if(p.getParent().getChildren()[0] == p)
				p.getParent().setLC(p.getChildren()[0]);
			else
				p.getParent().setRC(p.getChildren()[0]);
			//对于第一个不平衡点
			for(int k = 0;(q != null) && q.getBalanceFactor() < 2 && q.getBalanceFactor() > -2 && unbalanced == false;k++)
			{
				q = q.getParent();
			}
			//达到平衡
			if(q == null)
				return;
			//重组
			else if(q.getBalanceFactor()==2)
				if(id > q.getChildren()[0].getId())
				{
					Node r = q.getChildren()[0];
					q.setLC(r.getChildren()[1]);
					r.setRC(q);
					q = r;
				}

				else
				{
					q.setLC(RRotation(q.getChildren()[0]));
					q = LRotation(q);
				}
			else
				if(id < q.getChildren()[1].getId())
				{
					Node r = q.getChildren()[1];
					q.setRC(r.getChildren()[0]);
					r.setLC(q);
					q = r;
				}
				else
				{
					q.setRC(LRotation(q.getChildren()[1]));
					q = RRotation(q);
				}
		}
		//左右子树均不为空
		else
		{

			while(x.getChildren()[0] != null)
			{
				x = x.getChildren()[0];
			}
			//更改结点id和数值
			p.setId(x.getId());
			p.setData(x.getData());
			//删除最多有一个子树的后继结点
			delete(p.getChildren()[1],x.getId(),false);
		}
		while(unbalanced&&p != null)
		{

			Node u;
			u=p.getChildren()[0];

			Node r;

			if(p.getParent()!=null&&p.getParent().getChildren()[0] == p)
			{
				p.getParent().setChild(u, 0);
			}
			else if(p.getParent()!=null&&p.getParent().getChildren()[1] == p)
			{
				p.getParent().setChild(u, 1);
			}
		}
	}

	@Override
	public JTree printTree() 
	{
		// TODO Auto-generated method stub
		DefaultMutableTreeNode root = new DefaultMutableTreeNode(this.root.getData());
		printTree(root,this.root);
		JTree tree = new JTree(root);
		return tree;
                    
	}
	
	//左单旋
	private Node LRotation(Node n)
	{
		boolean unbalanced = false;
		Node p = n.getChildren()[0];
		n.setLC(p.getChildren()[1]);
		p.setRC(n);
		return p;
	}
	
	//右单旋
	private Node RRotation(Node n)
	{
		boolean unbalanced = false;
		Node p = n.getChildren()[1];
		n.setRC(p.getChildren()[0]);
		p.setLC(n);
		return p;
	}
	
	private JTree printTree(DefaultMutableTreeNode t,Node node)
	{
		if(node!=null)
		{
			//左子树
			if(node.getChildren()[0] != null)
			{
				DefaultMutableTreeNode lchild = new DefaultMutableTreeNode(node.getChildren()[0].getData());				
				t.add(lchild);
				printTree(lchild,node.getChildren()[0]);
			}
			//右子树
			if(node.getChildren()[1] != null)
			{
				DefaultMutableTreeNode rchild = new DefaultMutableTreeNode(node.getChildren()[1].getData());				
				t.add(rchild);
				printTree(rchild,node.getChildren()[1]);
			}
		}
		
		else 
		{
			return null;
		}
		return null;		
	}

	


	
}