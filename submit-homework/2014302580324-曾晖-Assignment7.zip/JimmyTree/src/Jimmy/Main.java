package Jimmy;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JTree;
import javax.swing.plaf.basic.BasicTreeUI.TreeCancelEditingAction;

public class Main extends JFrame
{
	JButton b1,b2,b3;
	JTextField textField;
    JLabel l1; 
    AVLTree tr = new AVLTree();
    int size = 17;
    JTree t = new JTree();
	public Main(AVLTree tree) throws IOException 
	{
		// TODO Auto-generated constructor stub
		String path = "src/Jimmy/tree_data.dat";
		File file=new File(path);
		tr = tree;
		if(!file.exists()||file.isDirectory())
			throw new FileNotFoundException();                      
		BufferedReader br = new BufferedReader(new FileReader(file));
		String[] temp = new String[17];
		int i = 0;
		while(i < 17)
		{
			temp[i] = br.readLine();
			i++;
		}           
		
		Node[] n = new Node[size]; 
		for(int j = 0; j < n.length;j++)
		{
			n[j] = new Node(j+1,temp[j]);
			tr.insert(n[j]);
			
		}
		b1 = new JButton("����");
		b2 = new JButton("ɾ��");
		b3 = new JButton("���");
		l1 = new JLabel("������������������,��ɾ����������id��");
		l1.setForeground(Color.ORANGE);
		l1.setFont(new Font("΢���ź�",Font.PLAIN,16));
		textField = new JTextField();
		
		b1.addActionListener(new ActionListener() 
		{
			
			@Override
			public void actionPerformed(ActionEvent arg0) 
			{
				// TODO Auto-generated method stub
				size++;
				Node m = new Node(size, textField.getText());
				tr.insert(m);
				t = tr.printTree();
				showMessage("���ӳɹ�");
				setVisible(false);
				try {
					Main r = new Main(tr);
					r.run();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				textField.setText("");
				System.out.println(size);
			}
		});
		
		b2.addActionListener(new ActionListener() 
		{
			
			@Override
			public void actionPerformed(ActionEvent arg0) 
			{
				// TODO Auto-generated method stub
				tr.delete(Integer.parseInt(textField.getText()));
				t = tr.printTree();
				showMessage("ɾ���ɹ�");
				setVisible(false);
				try {
					Main r = new Main(tr);
					r.run();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				textField.setText("");
				System.out.println(size);
			}
		});
		
		b3.addActionListener(new ActionListener() 
		{
			
			@Override
			public void actionPerformed(ActionEvent arg0) 
			{
				// TODO Auto-generated method stub
				textField.setText("");
			}
		});
		t = tree.printTree();
		JPanel panel = new JPanel(new BorderLayout());
		panel.add("West",t);
		panel.add("North",l1);
		JPanel panel2 = new JPanel(new GridLayout(2,2,3,1));
		panel2.add(b1);
		panel2.add(b2);
		panel2.add(b3);
		JPanel panel3 = new JPanel(new GridLayout(10,10,1,2));
		panel3.add(textField);
		panel3.add(panel2);
		panel.add("Center",panel3);
		add(panel);
		
		
	}
	
	public void run() 
	{
		setSize(500, 700);
		setVisible(true);
	}
	public static void main(String[] args) throws IOException 
	{
		AVLTree tree = new AVLTree();
		Main m = new Main(tree);
		m.run();
	}
	
	public void showMessage(String msg)
	{
		JOptionPane.showMessageDialog(this,msg,"����" ,JOptionPane.PLAIN_MESSAGE);
	}
}
