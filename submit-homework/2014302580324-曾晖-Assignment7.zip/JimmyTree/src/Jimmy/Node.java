package Jimmy;
public class Node 
{
	private int id;
	private Object data;
	private Node parent;
	private Node[] children = new Node[2];
	private int lSubTreeHeight;
	private int rSubTreeHeight;
	private int balanceFactor;
	
	public Node(int id,String data) 
	{
		// TODO Auto-generated constructor stub
		this.id = id;
		this.data = data;
		this.children[0] = null;
		this.children[1] = null;
		this.parent = null;
	}
	public void setId(int id)
	{
		this.id = id;
	}
	public int getId() 
	{
		return id;
	}
	public Object getData() 
	{
		return data;
	}
	public void setData(Object data) 
	{
		this.data = data;
	}
	public Node getParent() 
	{
		return parent;
	}
	public void setParent(Node parent) 
	{
		this.parent = parent;
	}
	public Node[] getChildren() 
	{
		return children;
	}
	public void setChildren(Node[] children) 
	{
		this.children = children;
	}
	public void setChild(Node child, int id)
	{
		this.children[id] = child;
	}
	private int getSubTreeHeight(Node n)
	{
		if(n == null)
			return 0;
		Node[]c = n.getChildren();
		if(getSubTreeHeight(c[0]) > getSubTreeHeight(c[1]))
			return getSubTreeHeight(c[0]) + 1;
		else
			return getSubTreeHeight(c[1]) + 1;
	}
	public int getlSubTreeHeight() 
	{
		//TODO calculate the left sub tree height
		lSubTreeHeight = getSubTreeHeight(children[0]);
		return lSubTreeHeight;
	}
	public int getrSubTreeHeight() 
	{
		//TODO calculate the right sub tree height
		rSubTreeHeight = getSubTreeHeight(children[1]);
		return rSubTreeHeight;
	}
	public int getBalanceFactor() 
	{
		//TODO calculate the balance factor
		balanceFactor=getlSubTreeHeight()-getrSubTreeHeight();
		return balanceFactor;
	}
	public void setBalanceFactor(int balanceFactor)
	{
		this.balanceFactor = balanceFactor;
	}
	//�������޸�������
	public void setLC(Node Lc)
	{
		this.children[0] = Lc;
		if(Lc == null)
			return;
		else
			Lc.setParent(this);
	}
	//�������޸�������
	public void setRC(Node Rc)
	{
		this.children[1] = Rc;
		if(Rc == null)
			return;
		else
			Rc.setParent(this);
	}
	
}
