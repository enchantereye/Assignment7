import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;

public class AVLTree implements IAVLTree{
	private Node root;
	int Size=0;
	@Override
	public Node get(int id) {
		// TODO Auto-generated method stub
		Node t=root;
		while(t.getId()!=id&&t!=null){
			if(id>t.getId())
				t=t.getrChildren();
			if(id<t.getId())
				t=t.getlChildren();
		}
		if(t==null)return null;
		
		return t;
	}

	@Override
	public void insert( Node newNode) {
		System.out.println("����"+newNode.getId());
		Node t=root;
		Node p;
		Node s=null;
		Node r=null;
		if(t==null){
			root=newNode;
			newNode.setParent(null);
			Size++;
			return;
		}
		p=t;
		while(t!=null){
			p=t;
		 if(newNode.getId()<t.getId())
			     t=t.getlChildren();
		 else if(newNode.getId()>t.getId())
				t=t.getrChildren();
		 else return;
		}
		t=newNode;
		if(t.getId()<p.getId())
			p.setlChild(t);
		if(t.getId()>p.getId())
			p.setrChild(t);
		Size++;
		root.update();
			while(t.getParent()!=null){
				
				if(t.getParent().getBalanceFactor()>1||t.getParent().getBalanceFactor()<-1)
				{
					s=t.getParent();
					break;
				}
				t=t.getParent();
			}
			if(s==null)return;
			if(s.getBalanceFactor()==2){
				//LRotation(s);
				Node r1=s.getlChildren();
		    	Node p1=s.getParent();
		    	boolean i=false;
		    	if(p1!=null&&p1.getrChildren()==s)
		    		i=true;
				if(r1.getBalanceFactor()==1){
					s.setlChild(r1.getrChildren());
					r1.setrChild(s);
					r1.setParent(p1);
					if(root==s)
						root=r1;
					s=r1;
				}
				else{
					Node u=r1.getrChildren();
					r1.setrChild(u.getlChildren());
					u.setlChild(r1);
					s.setlChild(u.getrChildren());
					u.setrChild(s);
					u.setParent(p1);
					if(root==s)
						root=u;
					s=u;
				}
						s.balanceFactor=0;
						if(p1!=null){
					    	if(i)p1.setrChild(s);
					    	else p1.setlChild(s);}
		}
			if(s.getBalanceFactor()==-2){
				//RRotation(s);
				System.out.println("����ת"+s.getId());
		    	
		    	Node r1=s.getrChildren();
		    	System.out.println();
		    	Node p1=s.getParent();
		    	boolean i=false;
		    	if(p1!=null&&p1.getrChildren()==s)
		    		i=true;
		    	if(r1.getBalanceFactor()==-1){
		    		s.setrChild(r1.getlChildren());
		    		r1.setlChild(s);
		    		s.balanceFactor=0;
		    		r1.setParent(p1);
		    		if(root==s)
						root=r1;
		    		s=r1;
		    		System.out.println(s.getId());
		    	}
		    	else{
		    		Node u=r1.getlChildren();
		    		r1.setlChild(u.getrChildren());
		    		u.setrChild(r1);
		    		s.setrChild(u.getlChildren());
		    		u.setrChild(s);
		    		
		    		u.setParent(p1);
		    		if(root==s)
						root=u;
		    		s=u;
		    	}
		    	s.balanceFactor=0;
		    	if(p1!=null){
		    	if(i)p1.setrChild(s);
		    	else p1.setlChild(s);}
				System.out.println(i);
			}
		root.update();
	}
	@Override
	public void delete(int id) {
		// TODO Auto-generated method stub
		Node t=get(id);
		Node p=t.getParent();
		if(t.getlChildren()==null&&t.getrChildren()==null){             //t��Ҷ��
			t.delete();
			 root.update();  //�������
			 return;
		}
		if(t.getlChildren()!=null&&t.getrChildren()==null){             //t��������
			 t.delete();
			 root.update();
			 return;
		}
		if(t.getrChildren()!=null&&t.getlChildren()==null){              //t��������
			 t.delete();
			 root.update();
			 return;
		}
		if(t.getlChildren()!=null&&t.getrChildren()!=null){               //t����������
			Node s=t.getrChildren();Node r=t;
			while(s.getlChildren()!=null){
				r=s;s=s.getlChildren();
			}
			t.setId(s.getId());
			t.setData(s.getData());
			t=s;p=r;                                                        //t�滻Ϊʵ��ɾ���Ľڵ㡣
		if(p.getBalanceFactor()==0){                                        //��p��ƽ������Ϊ0��ɾ�����ı�ƽ��
		t.delete();
		root.update();
		return;
		}
		else{                                     
		                                     //ɾ��t����������	
			t.delete();
			root.update();
			while(p!=null){                               
				                                                       //���ϼ��ƽ��,��ƽ�����ת
				if(p.getBalanceFactor()==2){
					s=p;
					//LRotation(s)
					Node r1=s.getlChildren();
			    	Node p1=s.getParent();
			    	boolean i=false;
			    	if(p1!=null&&p1.getrChildren()==s)
			    		i=true;
					if(r1.getBalanceFactor()==1){
						s.setlChild(r1.getrChildren());
						r1.setrChild(s);
						r1.setParent(p1);
						if(root==s)
							root=r1;
						s=r1;
					}
					else{
						Node u=r1.getrChildren();
						r1.setrChild(u.getlChildren());
						u.setlChild(r1);
						s.setlChild(u.getrChildren());
						u.setrChild(s);
						u.setParent(p1);
						if(root==s)
							root=u;
						s=u;
					}
							s.balanceFactor=0;
							if(p1!=null){
						    	if(i)p1.setrChild(s);
						    	else p1.setlChild(s);}
							root.update();
			}
				if(p.getBalanceFactor()==-2){
				s=p;
				//RRotation(s)
                System.out.println("����ת"+s.getId());
		    	Node r1=s.getrChildren();
		    	System.out.println();
		    	Node p1=s.getParent();
		    	boolean i=false;
		    	if(p1!=null&&p1.getrChildren()==s)
		    		i=true;
		    	if(r1.getBalanceFactor()==-1){
		    		s.setrChild(r1.getlChildren());
		    		r1.setlChild(s);
		    		s.balanceFactor=0;
		    		r1.setParent(p1);
		    		if(root==s)
						root=r1;
		    		s=r1;
		    		System.out.println(s.getId());
		    	}
		    	else{
		    		Node u=r1.getlChildren();
		    		r1.setlChild(u.getrChildren());
		    		u.setrChild(r1);
		    		s.setrChild(u.getlChildren());
		    		u.setrChild(s);
		    		
		    		u.setParent(p1);
		    		if(root==s)
						root=u;
		    		s=u;
		    	}
		    	if(p1!=null){
		    	if(i)p1.setrChild(s);
		    	else p1.setlChild(s);}
		    	root.update();
			}
				p=p.getParent();
				}
			
			}
		}
		}
		
public Node getRoot(){
	return root;
}
	@Override 
	public JTree printTree(){
		// TODO Auto-generated method stub
		JTree jt=new JTree(addTree(root));
		return jt;
	}
	private DefaultMutableTreeNode addTree(Node n){
		if(n==null){
			return null;
		}
		DefaultMutableTreeNode lchild=addTree(n.getlChildren());
		DefaultMutableTreeNode rchild=addTree(n.getrChildren());
		DefaultMutableTreeNode treeNode=new DefaultMutableTreeNode(n.getId()+"."+n.getData().toString());
		if(lchild!=null){
			treeNode.add(lchild);
		}
		if(rchild!=null){
			treeNode.add(rchild);
		}
		return treeNode;
	}

}
