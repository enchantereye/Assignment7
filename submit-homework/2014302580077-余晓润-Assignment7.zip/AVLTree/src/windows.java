import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JTree;
import javax.swing.border.EmptyBorder;
import javax.swing.JScrollPane;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class windows extends JFrame {

	private JPanel contentPane;
	private JTextField txtId;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField txtData;
	private JTree tree;
	JScrollPane scrollPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					windows frame = new windows();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public windows() {
		AVLTree avltree=new AVLTree();
		avltree.insert(new Node(1,"ant"));
		avltree.insert(new Node(2,"apple"));
		avltree.insert(new Node(3,"art"));
		avltree.insert(new Node(4,"baby"));
		avltree.insert(new Node(5,"banana"));
		avltree.insert(new Node(6,"car"));
		avltree.insert(new Node(7,"door"));
		avltree.insert(new Node(8,"dress"));
		avltree.insert(new Node(9,"frog"));
		avltree.insert(new Node(10,"love"));
		avltree.insert(new Node(11,"mint"));
		avltree.insert(new Node(12,"rice"));
		avltree.insert(new Node(13,"show"));
		avltree.insert(new Node(14,"table"));
		avltree.insert(new Node(15,"tree"));
		avltree.insert(new Node(16,"trouble"));
		avltree.insert(new Node(17,"window"));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 517, 408);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(null);
		setContentPane(contentPane);
		
		 tree =  avltree.printTree();
		tree.setBounds(10, 40, 265, 281);
		for(int i=0;i<tree.getRowCount();i++){
			tree.expandRow(i);
		}
		
		txtId = new JTextField();
		txtId.setText("id");
		txtId.setBounds(313, 24, 66, 21);
		contentPane.add(txtId);
		txtId.setColumns(10);
		txtData = new JTextField();
		txtData.setText("data");
		txtData.setBounds(313, 55, 66, 21);
		contentPane.add(txtData);
		txtData.setColumns(10);
		JButton btnInsertId = new JButton("insert ");
		btnInsertId.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				int id=Integer.parseInt(txtId.getText());
				String data=txtData.getText();
				avltree.insert(new Node(id,data));
				JTree tree =  avltree.printTree();
				tree.setBounds(10, 40, 265, 281);
				for(int i=0;i<tree.getRowCount();i++){
					tree.expandRow(i);
				}
				
				
				scrollPane.setViewportView(tree);
				
			}
		});
		btnInsertId.setBounds(398, 37, 93, 23);
		contentPane.add(btnInsertId);
		textField_1 = new JTextField();
		textField_1.setBounds(313, 83, 66, 21);
		contentPane.add(textField_1);
		textField_1.setColumns(10);
		JButton btnNewButton = new JButton("delete id");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				avltree.delete(Integer.parseInt(textField_1.getText()));
				 tree =  avltree.printTree();
				 tree.updateUI();
				tree.setBounds(10, 40, 265, 281);
				for(int i=0;i<tree.getRowCount();i++){
					tree.expandRow(i);
				}
				
				scrollPane.setViewportView(tree);
			}
		});
		btnNewButton.setBounds(398, 82, 93, 23);
		contentPane.add(btnNewButton);
		JLabel lblNewLabel = new JLabel("data:");
		lblNewLabel.setBounds(338, 178, 105, 55);
		contentPane.add(lblNewLabel);
		textField_2 = new JTextField();
		textField_2.setBounds(313, 135, 66, 21);
		contentPane.add(textField_2);
		textField_2.setColumns(10);
		JButton btnSearch = new JButton("search");
		btnSearch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
		Node n=	avltree.get(Integer.parseInt(textField_2.getText()));
		lblNewLabel.setText(lblNewLabel.getText()+n.getData().toString());
			}
		});
		btnSearch.setBounds(398, 134, 93, 23);
		contentPane.add(btnSearch);
		
		
		 scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 10, 237, 272);
		contentPane.add(scrollPane);
		
		scrollPane.setViewportView(tree);
	
	}
	
}
