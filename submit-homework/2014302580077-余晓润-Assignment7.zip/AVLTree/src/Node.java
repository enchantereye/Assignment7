
public class Node {
	private int id;
	private Object data;
	private Node parent;
	private int lSubTreeHeight;
	private int rSubTreeHeight;
	public int balanceFactor;
	private int height;
	public Node lchild;
	public Node rchild;
	public Node(){
		balanceFactor=0;
		lSubTreeHeight=0;
		rSubTreeHeight=0;
		height=0;
	}
	public Node(int id,String data){
		balanceFactor=0;
		lSubTreeHeight=0;
		rSubTreeHeight=0;
		height=0;
		lchild=null;
		rchild=null;
		parent=null;
		this.data=data;
		this.id=id;
	}
	public int getId() {
		return id;
	}
	public Object getData() {
		return data;
	}
	public void setData(Object data) {
		this.data = data;
	}
	public Node getParent() {
		return parent;
	}
	public void setParent(Node parent) {
		this.parent = parent;
	}
	public Node getlChildren() {
		return lchild;
	}
	public Node getrChildren(){
		return rchild;
	}

	public void setlChild(Node child){
		if(child==null){
			lchild=null;
			return;
		}
		this.lchild = child;
		child.setParent(this);
		
	}
	public void setrChild(Node child){
		if(child==null){
			rchild=null;
			return;
		}
		this.rchild=child;
		child.setParent(this);
	}
	public int getlSubTreeHeight() {
		//TODO calculate the left sub tree height
		return lSubTreeHeight;
	}
	public int getrSubTreeHeight() {
		//TODO calculate the right sub tree height
		return rSubTreeHeight;
	}
	public int getBalanceFactor() {
		//TODO calculate the balance factor
		return balanceFactor;
	}
	public int getHeight(){
		update();
		if(lSubTreeHeight<rSubTreeHeight)
		height=rSubTreeHeight;
		else
			height=lSubTreeHeight;
		return height;
	}
	public void update(){
		if(lchild!=null)
		lSubTreeHeight=lchild.getHeight()+1;
		if(lchild==null)
			lSubTreeHeight=0;
		if(rchild!=null)
	    rSubTreeHeight=rchild.getHeight()+1;
		if(rchild==null)
			 rSubTreeHeight=0;
		balanceFactor=lSubTreeHeight- rSubTreeHeight;
		height=(lSubTreeHeight>rSubTreeHeight)?lSubTreeHeight:rSubTreeHeight;
		System.out.println("����"+id);
	}
	public void setId(int id){
		this.id=id;
	}
	public void delete(){
		if(getlChildren()==null&&getrChildren()==null){             //��Ҷ��
			 if(parent.getlChildren()==this)parent.setlChild(null);
			 if(parent.getrChildren()==this)parent.setrChild(null);
			 return;
		}
		if(getlChildren()!=null&&getrChildren()==null){             //t��������
			 if(parent.getlChildren()==this)parent.setlChild(getlChildren());
			 if(parent.getrChildren()==this)parent.setrChild(getlChildren());
			 return;
		}
		if(getrChildren()!=null&&getlChildren()==null){              //t��������
			 if(parent.getlChildren()==this)parent.setlChild(getrChildren());
			 if(parent.getrChildren()==this)parent.setrChild(getrChildren());
			 return;
		}
	}
	@Override
	public String toString(){
		if(lchild!=null&&rchild!=null)
		return "id="+id+",bf="+balanceFactor+",height="+height+",lchild="+lchild.getId()+",rchild="+rchild.getId();
		else if(lchild==null&&rchild!=null){
			return "id="+id+",bf="+balanceFactor+",height="+height+",lchild=null"+",rchild="+rchild.getId();
		}
		else if(lchild!=null&&rchild==null){
			return "id="+id+",bf="+balanceFactor+",height="+height+",lchild="+lchild.getId()+",rchild=null";
		}
		else{
			return "id="+id+",bf="+balanceFactor+",height="+height+",lchild=null"+",rchild=null";
		}
	}
}
