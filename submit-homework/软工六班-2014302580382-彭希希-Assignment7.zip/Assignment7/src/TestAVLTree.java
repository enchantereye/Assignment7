import javax.swing.JFrame;
import javax.swing.JTree;
import javax.swing.JOptionPane;


public class TestAVLTree {
	public static void main(String[] args) {  
        AVLTree tree = new AVLTree();  
        tree.Insert(1);
        tree.Insert(2);  
        tree.Insert(6);
        tree.Insert(10);
        tree.Insert(18);
        tree.Insert(32);
        tree.Insert(28);
        tree.Insert(30);
        Node node=new Node();
        node.setId(9);
        node.setElement(25);
      
       //get����
        int id=tree.get(node, 25);
        System.out.print("ֵΪ25�Ľ���"+id+"���������������");
      
        
        
        //�������
    	 JTree showTree=tree.printTree();
		DrawFrame df=new DrawFrame(showTree);
		df.setSize(500, 500);
		df.setVisible(true);
		df.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
	
		
		//ɾ������
		JOptionPane.showMessageDialog( null,"ȷ��ɾ��2,6" ,"ɾ������", JOptionPane.PLAIN_MESSAGE );		
		tree.delete(2);  
        tree.delete(6); 
		showTree=tree.printTree();
		df.setTree(showTree);
		df.repaint();	
		
        
    }  
}


class DrawFrame extends JFrame
{
	private JTree tree;
	private JTree AfterDeleteTree;
	public void setTree(JTree tree)
	{
		this.AfterDeleteTree=tree;
		this.add(this.AfterDeleteTree);
		this.tree.setVisible(false);
	}
	public DrawFrame(JTree tree)
	{
		this.tree=tree;
		this.add(this.tree);
	}

}