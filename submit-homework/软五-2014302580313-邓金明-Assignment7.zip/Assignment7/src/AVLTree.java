import javax.swing.JTree;

public class AVLTree implements IAVLTree {

	private Node root;

	public AVLTree() {
		
	}

	@Override
	public Node get(int id) {
		
		return null;
	}

	@Override
	public void insert(int id, Node newNode) {
		if (newNode.getId()==id
				||(newNode.getId()>id&&get(id).getChildren()[1]!=null)
			||(newNode.getId()<id&&get(id).getChildren()[0]!=null)) {
			System.out.println("����λ����������");
		}else {
			insertNode(newNode, id);
		}
	}
	
	private void insertNode(Node newNode,int id){
		if (newNode.getId()>id) {
			get(id).setChild(newNode, 1);
		}else {
			get(id).setChild(newNode, 0);
		}
		newNode.setParent(get(id));
		Node s = newNode;
		do {
			s = s.getParent();
			switch (s.getBalanceFactor()) {
			case -1:
				s.setBalanceFactor(0);
				break;
			case 0:
				s.setBalanceFactor(1);
				break;
			case 1:
				
			}
		} while (s.getParent()!=null);
	}
	
	@Override
	public void delete(int id) {
		
	}

	@Override
	public JTree printTree() {

		return null;
	}

	private void LL(Node p) {
		Node l = p.getChildren()[0];
		if (l.getChildren()[1] != null) {
			p.setChild(l.getChildren()[1], 0);
		}
		l.setParent(p.getParent());
		if (l.getParent() == null) {
			root = l;
		}
		l.setChild(p, 1);
		p.setParent(l);
		p.setBalanceFactor(p.getBalanceFactor()-1);
		l.getParent().setChild(l, 0);
	}

	private void RR(Node p) {
		Node r = p.getChildren()[1];
		if (r.getChildren()[0] != null) {
			p.setChild(r.getChildren()[0], 1);
		}
		r.setParent(p.getParent());
		if (p.getParent() == null) {
			root = r;
		}
		r.setParent(p.getParent());
		r.setChild(p, 0);
		p.setParent(r);
		p.setBalanceFactor(p.getBalanceFactor()-1);
		r.getParent().setChild(r, 1);
	}

	private void LR(Node p) {
		Node s = p.getParent();
		RR(p);
		LL(s);
	}

	private void RL(Node p) {
		Node s = p.getParent();
		LL(p);
		RR(s);
	}

}
