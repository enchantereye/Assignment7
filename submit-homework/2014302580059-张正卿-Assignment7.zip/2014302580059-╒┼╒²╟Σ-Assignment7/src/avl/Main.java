package avl;

public class Main {
	public static void main(String args[]){
		Node Node1 = new Node();
		Node Node2 = new Node();
		Node Node3 = new Node();
		Node Node4 = new Node();
		Node Node5 = new Node();
		Node Node6 = new Node();
		Node1.setData(1);
		Node2.setData(2);
		Node3.setData(3);
		Node4.setData(4);
		Node5.setData(5);
		Node6.setData(6);
		
		AVLTree tree = new AVLTree();
		
		tree.insert(1, Node1);
		tree.insert(2, Node2);
		tree.insert(3, Node3);
		tree.insert(4, Node4);
		tree.insert(5, Node5);
		tree.insert(6, Node6);
		
		//tree.delete(6);
		tree.printTree();
	}
}
