package avl;

import javax.swing.JTree;

public class AVLTree implements IAVLTree {
	private int size = 0;
	private Node root = null;

	@Override
	public Node get(int id) {
		// TODO Auto-generated method stub
		Node s = root;
		if(s == null){
			while( s.getChildren(0) != null && s.getId() != id){
				s = s.getChildren(0);
			}
		}
		return s;
	}

	@Override
	public void insert(int id, Node newNode) {
		// TODO Auto-generated method stub
		Node s = root;
		Node parent = null;
		if(s == null){
			root = newNode;
			size = 1;
		}
		else if(s.getChildren(0) == null){
			parent = s;
			s = s.getChildren(0);
			s.setId(id);
			s.setParent(parent);
			s.setData(newNode.getData());
			parent.setChild(s,0);
		}else if(s.getChildren(1) == null){
			parent = s;
			s = s.getChildren(1);
			s.setId(id);
			s.setParent(parent);
			s.setData(newNode.getData());
			parent.setChild(s,1);
		}else{
			parent = s;
			s = s.getChildren(0);
			if(s.getChildren(0) == null){
				parent = s;
				s = s.getChildren(0);
				s.setId(id);
				s.setParent(parent);
				s.setData(newNode.getData());
				parent.setChild(s,0);
			}else if(s.getChildren(1) == null){
				parent = s;
				s = s.getChildren(1);
				s.setId(id);
				s.setParent(parent);
				s.setData(newNode.getData());
				parent.setChild(s,1);
			}else{
				s = parent.getChildren(1);
				if(s.getChildren(0) == null){
					parent = s;
					s = s.getChildren(0);
					s.setId(id);
					s.setParent(parent);
					s.setData(newNode.getData());
					parent.setChild(s,0);
				}else if(s.getChildren(1) == null){
					parent = s;
					s = s.getChildren(1);
					s.setId(id);
					s.setParent(parent);
					s.setData(newNode.getData());
					parent.setChild(s,1);
				}
			}
		}
	}
	


	@Override
	public void delete(int id) {
		// TODO Auto-generated method stub
		Node s = root;
		Node p = root;
		if(p == null){
			while( p.getChildren(0) != null && p.getId() != id){
				p = p.getChildren(0);
			}
		}
		if(s.getChildren(0)!=null&&s.getChildren(1)!=null){
			p.setData(s.getData());
		}
		Node replacement = (p.getChildren(0)!=null?p.getChildren(0):p.getChildren(1));
		if(replacement!=null){
			replacement.setParent(p.getParent());
			p.getParent().setChild(replacement,0);
		}
	}

	@Override
	public void printTree() {
		// TODO Auto-generated method stub
		Node s = root;
		if(s == null){
			while( s.getChildren(0) != null){
				s = s.getChildren(0);
				System.out.println(s.getData()+" ");
			}
		}
	}
}
