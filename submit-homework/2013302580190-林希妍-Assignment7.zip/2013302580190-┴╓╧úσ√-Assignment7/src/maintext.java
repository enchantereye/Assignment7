
public class maintext {
	
   // private JScrollPane js;

	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AVLTree tree=new AVLTree();
		//�Ȳ���ֵ
		tree.insert(1, new Node(1,"ant"));
		tree.insert(2, new Node(2,"apple"));
		tree.insert(3, new Node(3,"art"));
		tree.insert(4, new Node(4,"baby"));
		tree.insert(5, new Node(5,"banana"));
		tree.insert(6, new Node(6,"car"));
		tree.insert(7, new Node(7,"door"));
		tree.insert(8, new Node(8,"dress"));
		tree.insert(9, new Node(9,"frog"));
		tree.insert(10, new Node(10,"love"));
		tree.insert(11, new Node(11,"mint"));
		tree.insert(12, new Node(12,"rice"));
		tree.insert(13, new Node(13,"show"));
		tree.insert(14, new Node(14,"table"));
		tree.insert(15, new Node(15,"tree"));
		tree.insert(16, new Node(16,"trouble"));
		tree.insert(17, new Node(17,"window"));
		//�齨AVLTree
		JTreeGUI gui=new JTreeGUI(tree);
		gui.setVisible(true);
		
	}

}
