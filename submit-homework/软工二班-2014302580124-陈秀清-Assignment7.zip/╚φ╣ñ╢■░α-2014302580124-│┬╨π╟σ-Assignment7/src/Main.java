import java.util.Scanner;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTree;

public class Main {
public static void main(String[] args){
	AVLTree tree=new AVLTree();
	Node n1=new Node(1,"ant");
	Node n2=new Node(2,"apple");
	Node n3=new Node(3,"art");
	Node n4=new Node(4,"baby");
	Node n5=new Node(5,"banana");
	Node n6=new Node(6,"car");
	Node n7=new Node(7,"door");
	Node n8=new Node(8,"dress");
	Node n9=new Node(9,"frog");
	Node n10=new Node(10,"love");
	Node n11=new Node(11,"mint");
	Node n12=new Node(12,"rice");
	Node n13=new Node(13,"show");
	Node n14=new Node(14,"table");
	Node n15=new Node(15,"tree");
	Node n16=new Node(16,"trouble");
	Node n17=new Node(17,"window");
	tree.insert(n1);
	tree.insert(n2);
	tree.insert(n3);
    tree.insert(n4);
	tree.insert(n5);
	tree.insert(n6);
	tree.insert(n7);
	tree.insert(n8);
	tree.insert(n9);
    tree.insert(n10);
	tree.insert(n11);
	tree.insert(n12);
	//tree.insert(n13);
	tree.insert(n14);
	tree.insert(n15);
	tree.insert(n16);
	tree.insert(n17);
	//����get

	JTree jt=tree.printTree();
	MyFrame mf=new MyFrame(jt);
	//���Թ���
	/***
	 *����̨�������Ҫ���GUI����Ż������Ի���=-=
	 *ÿ����һ��ֻ�ܲ���һ����� 
	 *
	 */
	
	System.out.println("\n1:�����ظ�����\n"+"2:����ɾ��\n"+"3:���Բ���\n"+"4:get����\n");
	Scanner in=new Scanner(System.in);
	int choose=in.nextInt();
	
	switch(choose){
	case 1:JOptionPane.showMessageDialog( null,"����4" ,
			  "ȷ��", JOptionPane.PLAIN_MESSAGE );
	tree.insert(n4);
	jt=tree.printTree();
	mf.drawTree(jt);
	mf.repaint();
	break;

	case 2: JOptionPane.showMessageDialog( null,"ɾ��8" ,
			  "ȷ��", JOptionPane.PLAIN_MESSAGE );	
	tree.delete(8);
	jt=tree.printTree();
	mf.drawTree(jt);
	mf.repaint();
	break;
	case 3:JOptionPane.showMessageDialog( null,"����13" ,
			  "ȷ��", JOptionPane.PLAIN_MESSAGE );
	tree.insert(n13);
	jt=tree.printTree();
	mf.drawTree(jt);
	mf.repaint();
	case 4:
		System.out.println("����id:");
		int id=in.nextInt();
	    Node test=tree.get(id);
        System.out.println(test.getData().toString()+"#"+test.getId());
	}
	
}
	
public static class MyFrame extends JFrame{
	private JTree t1;
	private JTree t2;
	public void drawTree(JTree t){
		t2=t;
		t1.setVisible(false);
		add(t2);
		
	}
	public MyFrame(JTree t){
		t1=t;
	    add(t1);
	    setVisible(true);
	    setSize(300, 500);
	    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}
}
