
public class Run {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Tree AVLtree=new Tree();
		Node a=new Node();
		Node b=new Node();
		Node c=new Node();
		Node d=new Node();
		a.setId(5);
		b.setId(8);
		c.setId(2);
		d.setId(4);
		AVLtree.insert(AVLtree.root,a,true);
		AVLtree.insert(a,b,true);
		AVLtree.insert(b,c,true);
		AVLtree.insert(c,d,true);
		AVLtree.inorderTravelsal();
		//AVLtree.delete(2);
		//AVLtree.inorderTravelsal();


	}

}
