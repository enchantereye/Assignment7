import javax.swing.JTree;

public class Tree<T extends Comparable<T>> implements IAVLTree
{
	public Node root;
	
	
	public Tree()
	{
		root=null;
	}

	@Override
	public Node get(int id) {
		// TODO Auto-generated method stub
		return get(root,id);
	}
	
	public Node get(Node p,int id)
	{
		if(p==null)
			return p;
		else if(id<p.getId())
			return get(p.getChildren()[0],id);
		else if(id>p.getId())
			return get(p.getChildren()[1],id);
		else
			return p;
	}

	@Override
	public void insert(Node p,Node newNode,boolean unBalanced) {
		// TODO Auto-generated method stub
		if(p==null){
			root=newNode;
			unBalanced=true;
		}
		else if(newNode.getId()<p.getId()){
				insert(p.getChildren()[0],newNode,unBalanced);
				if(unBalanced){
					switch(p.getBalanceFactor()){
					case -1:p.setBalanceFactor(0);unBalanced=false;break;
					case 0:p.setBalanceFactor(1);break;
					case 1:LRotation(p,unBalanced);
				}
			}
		else if(newNode.getId()==p.getId()){
			unBalanced=false;
		}
		else{
			p=p.getChildren()[1];
			if(p==null){
				p=newNode;
			}
			else{
				insert(p.getChildren()[1],newNode,unBalanced);
			}
			if(unBalanced)
				switch(p.getBalanceFactor()){
				case 1:p.setBalanceFactor(0);unBalanced=false;break;
				case 0:p.setBalanceFactor(-1);break;
				case -1:RRotation(p,unBalanced);
				}
		}
	}	
}

	private void RRotation(Node s,boolean unBalanced) {
		// TODO Auto-generated method stub
		Node u,r=s.getChildren()[1];
		if(r.getBalanceFactor()==-1){
			s.setChild(r.getChildren()[0], 1);
			r.setChild(s, 0);
			s.setBalanceFactor(0);
			s=r;
		}
		else{
			u=r.getChildren()[0];
			r.setChild(u.getChildren()[1], 0);
			s.setChild(u.getChildren()[0], 1);
			u.setChild(r, 1);
			u.setChild(s, 0);
			switch(u.getBalanceFactor()){
			case 1:s.setBalanceFactor(0);r.setBalanceFactor(-1);break;
			case 0:s.setBalanceFactor(0);r.setBalanceFactor(0);break;
			case -1:s.setBalanceFactor(1);r.setBalanceFactor(0);
			}
			s=u;
		}
		s.setBalanceFactor(0);
		unBalanced=false;
	}

	@Override
	public void delete(int id) {
		// TODO Auto-generated method stub
		Node p=get(id);
		if(p==null){
			System.out.println("Not Exist!");
		}
		else if(p.getChildren()[0]==null&&p.getChildren()[1]==null){
			if(p==root)
				root=null;
			else if(p.getParent().getChildren()[0]==p){
				p.getParent().setChild(null, 0);
			}else{
				p.getParent().setChild(null, 1);
			}
		}else if(p.getChildren()[0]==null){
			if(p==root)
				root=p.getChildren()[1];
			else if(p.getParent().getChildren()[0]==p){
				p.getParent().setChild(p.getChildren()[1], 0);
			}else{
				p.getParent().setChild(p.getChildren()[1], 1);
			}
		}else if(p.getChildren()[1]==null){
			if(p==root)
				root=p.getChildren()[0];
			else if(p.getParent().getChildren()[0]==p){
				p.getParent().setChild(p.getChildren()[0], 0);
			}else{
				p.getParent().setChild(p.getChildren()[0], 1);
			}
		}else{
			Node s=p.getChildren()[1];
			while(s.getChildren()[0]!=null){
				s=s.getChildren()[0];
				if(p==root)
					root=s;
				else if(p.getParent().getChildren()[0]==p){
					p.getParent().setChild(s, 0);
				}else{
					p.getParent().setChild(s, 1);
				}
			}
			
		}
	}
				
				
				
				
			
		
			//fixafterr
		/*	boolean shorter=true;
			Node t=r.getParent();
			while(t!=null&&shorter){
				if(id>=r.getId())
					t.setBalanceFactor(t.getBalanceFactor()+1);
				else
					t.setBalanceFactor(t.getBalanceFactor()-1);
				if(t.getBalanceFactor()==1||t.getBalanceFactor()==-1){
					break;
				}
				Node m=t;
				if(t.getBalanceFactor()==2){
					Node l=m.getChildren()[0];
					switch(l.getBalanceFactor()){
					case 1:
						m.setBalanceFactor(0);
						l.setBalanceFactor(0);
						RRotation(m);
						break;
					case -1:
						Node lr=l.getChildren()[1];
						switch(lr.getBalanceFactor()){
						case 1:
							m.setBalanceFactor(-1);
							l.setBalanceFactor(0);
							break;
						case 0:
							m.setBalanceFactor(0);
							l.setBalanceFactor(0);
							break;
						case -1:
							m.setBalanceFactor(0);
							l.setBalanceFactor(1);
							break;
						}
						lr.setBalanceFactor(0);
						LRotation(m.getChildren()[0]);
						RRotation(m);
						break;
					case 0:
						l.setBalanceFactor(-1);
						m.setBalanceFactor(1);
						RRotation(m);
						shorter=false;
						break;
					}
				}
				if(t.getBalanceFactor()==-2){
					Node tr=m.getChildren()[1];
					switch(tr.getBalanceFactor()){
					case 1:
						Node rl=tr.getChildren()[0];
						switch(rl.getBalanceFactor()){
						case 1:
							m.setBalanceFactor(0);
							tr.setBalanceFactor(-1);
							break;
						case 0:
							m.setBalanceFactor(0);
							tr.setBalanceFactor(0);
							break;
						case -1:
							m.setBalanceFactor(1);
							tr.setBalanceFactor(0);
							break;
						}
						rl.setBalanceFactor(0);
						RRotation(m.getChildren()[1]);
						LRotation(m);
						break;
					case -1:
						tr.setBalanceFactor(0);
						tr.setBalanceFactor(0);
						LRotation(m);
						break;
					case 0:
						tr.setBalanceFactor(1);
						m.setBalanceFactor(1);
						LRotation(m);
						shorter=false;
						break;
					}
				}
				t=t.getParent();
			}*/
			
		
		
			/*
			//fixafterp
			boolean shorter=true;
			Node t=p.getParent();
			while(t!=null&&shorter){
				if(id>=p.getId())
					t.setBalanceFactor(t.getBalanceFactor()+1);
				else
					t.setBalanceFactor(t.getBalanceFactor()-1);
				if(t.getBalanceFactor()==1||t.getBalanceFactor()==-1){
					break;
				}
				Node m=t;
				if(t.getBalanceFactor()==2){
					Node l=m.getChildren()[0];
					switch(l.getBalanceFactor()){
					case 1:
						m.setBalanceFactor(0);
						l.setBalanceFactor(0);
						RRotation(m);
						break;
					case -1:
						Node lr=l.getChildren()[1];
						switch(lr.getBalanceFactor()){
						case 1:
							m.setBalanceFactor(-1);
							l.setBalanceFactor(0);
							break;
						case 0:
							m.setBalanceFactor(0);
							l.setBalanceFactor(0);
							break;
						case -1:
							m.setBalanceFactor(0);
							l.setBalanceFactor(1);
							break;
						}
						lr.setBalanceFactor(0);
						LRotation(m.getChildren()[0]);
						RRotation(m);
						break;
					case 0:
						l.setBalanceFactor(-1);
						m.setBalanceFactor(1);
						RRotation(m);
						shorter=false;
						break;
					}
				}
				if(t.getBalanceFactor()==-2){
					Node tr=m.getChildren()[1];
					switch(tr.getBalanceFactor()){
					case 1:
						Node rl=tr.getChildren()[0];
						switch(rl.getBalanceFactor()){
						case 1:
							m.setBalanceFactor(0);
							tr.setBalanceFactor(-1);
							break;
						case 0:
							m.setBalanceFactor(0);
							tr.setBalanceFactor(0);
							break;
						case -1:
							m.setBalanceFactor(1);
							tr.setBalanceFactor(0);
							break;
						}
						rl.setBalanceFactor(0);
						RRotation(m.getChildren()[1]);
						LRotation(m);
						break;
					case -1:
						tr.setBalanceFactor(0);
						tr.setBalanceFactor(0);
						LRotation(m);
						break;
					case 0:
						tr.setBalanceFactor(1);
						m.setBalanceFactor(1);
						LRotation(m);
						shorter=false;
						break;
					}
				}
				t=t.getParent();
			}
			
			 if(p==p.getParent().getChildren()[0])
					p.getParent().setChild(null, 0);
				else if(p==p.getParent().getChildren()[1])
					p.getParent().setChild(null, 1);
				p.setParent(null);
		*/	
		
			
		
	

	@Override
	public JTree printTree() {
		// TODO Auto-generated method stub
		return null;
	}
	
	public void LRotation(Node s,boolean unBalanced){
		Node u=s.getChildren()[0];
		Node r=s.getChildren()[0];
		if(r.getBalanceFactor()==1){
			s.setChild(r.getChildren()[1], 0);
			r.setChild(s, 1);;
			s.setBalanceFactor(0);
			s=r;
		}
		else{
			u=r.getChildren()[1];
			r.setChild(u.getChildren()[0], 1);
			u.setChild(r, 0);
			s.setChild(u.getChildren()[1], 0);
			u.setChild(s, 1);
			switch(u.getBalanceFactor())
			{
			case 1:s.setBalanceFactor(-1);r.setBalanceFactor(0);;break;
			case 0:s.setBalanceFactor(0);r.setBalanceFactor(0);break;
			case -1:s.setBalanceFactor(0);r.setBalanceFactor(1);
			}
			s=u;
		}
		s.setBalanceFactor(0);
		unBalanced=false;
	}

	public void inorderTravelsal(){
		inorderHelper(root);
	}
	
	private void inorderHelper(Node node){
		if(node==null)
			return;
		inorderHelper(node.getChildren()[0]);
		System.out.printf("%s",node.getId());
		inorderHelper(node.getChildren()[1]);
	}
	
}
