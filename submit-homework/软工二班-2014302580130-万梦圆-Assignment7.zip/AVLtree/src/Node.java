
public class Node {
	private int id;
	private Object data;
	private Node parent;
	private Node[] children = new Node[2];
	private int lSubTreeHeight;
	private int rSubTreeHeight;
	private int balanceFactor;
	
	public int getId() {
		return id;
	}
	public Object getData() {
		return data;
	}
	public void setData(Object data) {
		this.data = data;
	}
	public Node getParent() {
		return parent;
	}
	public void setParent(Node parent) {
		this.parent = parent;
	}
	public Node[] getChildren() {
		return children;
	}
	public void setChildren(Node[] children) {
		this.children = children;
	}
	public void setChild(Node child, int id){
		this.children[id] = child;
	}
	public int getlSubTreeHeight() {
		//TODO calculate the left sub tree height
		Node temp=new Node();
		if(children[0]==null){
			lSubTreeHeight=0;
		}
		else{
			temp=children[0];
			lSubTreeHeight=1;
			while(temp.children[0]!=null){
				lSubTreeHeight++;
				temp=temp.children[0];
			}
		}
		return lSubTreeHeight;
	}
	public int getrSubTreeHeight() {
		//TODO calculate the right sub tree height
		Node temp=new Node();
		if(children[1]==null){
			rSubTreeHeight=0;
		}
		else{
			temp=children[1];
			rSubTreeHeight=1;
			while(temp.children[1]!=null){
				rSubTreeHeight++;
				temp=temp.children[1];
			}
		}
		return rSubTreeHeight;
	}
	public int getBalanceFactor() {
		//TODO calculate the balance factor
		/*balanceFactor=this.getlSubTreeHeight()-this.getrSubTreeHeight();*/
		return balanceFactor;
	}
	public void setBalanceFactor(int bf){
		balanceFactor=bf;
	}
	public void setId(int num){
		id=num;
	}

}
