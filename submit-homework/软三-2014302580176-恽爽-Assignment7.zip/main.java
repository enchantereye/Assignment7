
public class main {

	public static void main(String[] args) {
		AVLTree2014302580176 myTree = new AVLTree2014302580176();
		
		Node node = new Node(1,"ant");
		Node node1 = new Node(2,"apple");
		Node node2 = new Node(3,"art");
		Node node3 = new Node(4,"baby");
		Node node4 = new Node(5,"banan");
		Node node5 = new Node(6,"car");
		Node node6 = new Node(7,"door");
		Node node7 = new Node(8,"dress");
		Node node8 = new Node(9,"frog");
		Node node9 = new Node(10,"love");
		Node node10 = new Node(11,"mint");
		Node node11 = new Node(12,"rice");
		Node node12 = new Node(13,":show");
		Node node13 = new Node(14,"table");
		Node node14 = new Node(15,"tree");
		Node node15 = new Node(16,"trouble");
		Node node16 = new Node(17,"window");
		
		myTree.insert(0,node);
		myTree.insert(0,node1);
		myTree.insert(0,node2);
		myTree.insert(0,node3);
		myTree.insert(0,node4);
		myTree.insert(0,node5);
		myTree.insert(0,node6);
		myTree.insert(0,node7);
		myTree.insert(0,node8);
		myTree.insert(0,node9);
		myTree.insert(0,node10);
		myTree.insert(0,node11);
		myTree.insert(0,node12);
		myTree.insert(0,node13);
		myTree.insert(0,node14);
		myTree.insert(0,node15);
		myTree.insert(0,node16);
		System.out.print("id=5,data=");
		System.out.println(myTree.get(5).getData());
		myTree.printTree();
	}

}
