import javax.swing.JFrame;
import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;

public class AVLTree2014302580176 implements IAVLTree{
	
	private boolean unBalanced;
	public int size;
	public Node[] elements = new Node[100];
	public Node root;
	
	public void setUnBalanced(boolean ub){
		unBalanced = ub;
	}
	public boolean getUnBalanced(){
		return unBalanced;
	}
	
	AVLTree2014302580176(){
		root = null;
	}
	
	@Override
	public Node get(int id) {
		return get(root,id);
		
	}

	@Override
	public void insert(int id, Node newNode) {
		//elements[size] = newNode;
		//size++;
		//root = elements[(int)(size/2)];
		//root = insertll(root,0,size-1);
		unBalanced = false;
		root = insert(root,newNode);
	}
	
	public Node insertll(Node current,int start,int end){
		if(start>end)return null;
		int m = start+(end-start)/2;
		current.setChild(insertll(current,start,m-1), 0);
		current.setChild(insertll(current,m+1,end),1);
		return current;
	}
	
	@Override
	public void delete(int id) {
		
	}

	
	private Node get(Node current,int id){
		if(id==current.getId())return current;
		if(id<current.getId())return get(current.getChildren()[0],id);
		if(id>current.getId())return get(current.getChildren()[1],id);
		return null;
	} 
	
	private Node insert(Node current,Node newNode){
		if(current==null){
			current = newNode;
			setUnBalanced(true);
		}
		if(newNode.getId()<current.getId()){
			root.setChild(insert(root.getChildren()[0],newNode),0);
			if(getUnBalanced())
				switch(current.getBalanceFactor()){
				case -1:{current.setBalanceFactor(0);setUnBalanced(false);break;}
				case 0:{current.setBalanceFactor(1);break;}
				case 1:{LRotation(current);break;}
				}
		}
		else if(newNode.getId()==current.getId()){
			setUnBalanced(false);
		}
		else if(newNode.getId()>current.getId()){
			current.setChild(insert(current.getChildren()[1],newNode),1);
			if(getUnBalanced())
				switch(current.getBalanceFactor()){
				case 1:{current.setBalanceFactor(0);setUnBalanced(false);break;}
				case 0:{current.setBalanceFactor(-1);break;}
				case -1:{RRotation(current);break;}
				}
		}
		return current;
	}
	
	private void RRotation(Node current) {
		Node u,r = current.getChildren()[1];
		if(r.getBalanceFactor()==-1){
			current.setChild(r.getChildren()[0], 1);
			r.setChild(current, 0);
			current.setBalanceFactor(0);
			current = r;
		}
		else{
			u=r.getChildren()[0];
			r.setChild(u.getChildren()[1], 0);
			u.setChild(r, 1);
			current.setChild(u.getChildren()[0], 1);
			u.setChild(current, 0);
			switch(u.getBalanceFactor()){
			case 1:{current.setBalanceFactor(-1);r.setBalanceFactor(0);break;}
			case 0:{current.setBalanceFactor(0);r.setBalanceFactor(0);break;}
			case -1:{current.setBalanceFactor(0);r.setBalanceFactor(-1);}
			}
			current = u;
		}
		current.setBalanceFactor(0);
		setUnBalanced(false);
	}
	

	private void LRotation(Node current) {
		Node u,r = current.getChildren()[0];
		if(r.getBalanceFactor()==1){
			current.setChild(r.getChildren()[1], 0);
			r.setChild(current, 1);
			current.setBalanceFactor(0);
			current = r;
		}
		else{
			u=r.getChildren()[1];
			r.setChild(u.getChildren()[0], 1);
			u.setChild(r, 0);
			current.setChild(u.getChildren()[1], 0);
			u.setChild(current, 1);
			switch(u.getBalanceFactor()){
			case 1:{current.setBalanceFactor(1);r.setBalanceFactor(0);break;}
			case 0:{current.setBalanceFactor(0);r.setBalanceFactor(0);break;}
			case -1:{current.setBalanceFactor(0);r.setBalanceFactor(1);}
			}
			current = u;
		}
		current.setBalanceFactor(0);
		setUnBalanced(false);
	}
	
	
	@Override
	public JTree printTree() {
		// TODO Auto-generated method stub
		DefaultMutableTreeNode node = new DefaultMutableTreeNode(root.getData());
		JTree tree = new JTree(node);
		DefaultMutableTreeNode currentNode=node;
		Node current=root;
		while(current.getChildren()[1]!=null){
			current = current.getChildren()[1];
			DefaultMutableTreeNode t_node = new DefaultMutableTreeNode(current.getData());
				currentNode.add(t_node);
				currentNode=t_node;
		}
        JFrame frame = new JFrame("JTreeDemo");
        frame.add(tree);
        frame.setSize(450, 450);
        frame.setVisible(true);
		return null;
	}
	
}
