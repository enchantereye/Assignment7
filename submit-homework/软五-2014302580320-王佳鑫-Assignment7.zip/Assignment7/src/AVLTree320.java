import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;



public class AVLTree implements IAVLTree{
	private Node root=null; 
	private int size=0;
	
	public AVLTree(Node root){
		this.root=root;
	}
	
	//get()����
	@Override
	public Node get(int id) {
		// TODO Auto-generated method stub
		return new_get(id,root);
		
	}
	public Node new_get(int id,Node root){
		if(root.getId()==id){
			return root;
		}else if(root.getChildren()[0]!=null&&root.getChildren()[1]!=null){
			if(id<root.getId()){root=root.getChildren()[0];return new_get(id,root);}
			else if(id>root.getId()){root=root.getChildren()[1];return new_get(id,root);}
			else {return null;}
		}else if(root.getChildren()[0]!=null&&root.getChildren()[1]==null){
			root=root.getChildren()[0];
			return new_get(id,root);
		}else if(root.getChildren()[1]!=null&&root.getChildren()[0]==null){
			root=root.getChildren()[1];
			return new_get(id,root);
		}else{
		return null;
		}
	}
	
	//insert()����
	@Override
	public void insert(Node newNode) {
		// TODO Auto-generated method stub
		if(root==null) {
			root=newNode;
		}else if(root!=null){
			Node parent=inP(newNode.id,root);
			if(parent!=null) {
				if(newNode.id<parent.id) {
					parent.getChildren()[0]=newNode;
				}else if(newNode.id>parent.id) {
					parent.getChildren()[1]=newNode;
				}
			}
		}
		
		//����
		Adjust();
	}
	
	//��ȡ����λ�õĸ��ڵ�
	public Node inP(int id,Node node) {
		if(node.getChildren()[0]==null&&node.getChildren()[1]==null){
			return node;
		}
		if(node.getChildren()!=null){
			if(id<node.id) {
				return inP(id,node.getChildren()[0]);
			}else if(id>node.id) {
				return inP(id,node.getChildren()[1]);
			}
			else return null;
		}
		else return null;
	}
	
	//delete()����
	@Override
	public void delete(int id) {
		// TODO Auto-generated method stub
		if(get(id) == null){
			System.out.println("This node don't exist.");
		}else{
			Node avl = get(id);
			Node c = null;
			Node s = null;
			Node r = null;
			Node q = avl.getParent();
			if(avl.getChildren()[0] != null && avl.getChildren()[1] != null){
				r = avl;
				s = avl.getChildren()[1];
				while(s.getChildren()[0] != null){
					r = s;
					s = s.getChildren()[0];				
				}
				avl.setData(s.getData());
				q = r;
				avl = s;			
			}else if(avl.getChildren()[0] != null){
				c = avl.getChildren()[0];
			}else if(avl.getChildren()[1] != null){
				c = avl.getChildren()[1];
			}else{
				avl = null;
			}
			if(avl == root){
				root = c;
			}else{
				if(avl == q.getChildren()[0]){
					q.getChildren()[0] = c;//delete the left child
				}else{
					q.getChildren()[1] = c;//delete the right child
				}
				avl = null;
			}				
		}
				//����
				Adjust();
				
	}
		
	
	//�ж��Ƿ�ƽ��
	public boolean isBalanced(Node node) {
			
		if(node!=null) {
		if(node.getBalanceFactor()==2||node.getBalanceFactor()==-2)
			return false;
		else
			return (isBalanced(node.getChildren()[0])==false||isBalanced(node.getChildren()[1])==false)?false:true;			
		}else
			return true;
			
	}
	//��ȡ�������ƽ����������
		public Node getUnbalanced(Node a) {
			if(a!=null) {
				if(!isBalanced(a.getChildren()[0]))
					return getUnbalanced(a.getChildren()[0]);
				else if(!isBalanced(a.getChildren()[1]))
					return getUnbalanced(a.getChildren()[1]);
				else 
					return a;
			
			}
			else 
				return null;
			
		}
		
		//��ƽ�����ȵĸ��ڵ㣬���ڵ��ں��������
		public Node unbalancedParent(Node node) {
			Node n=getUnbalanced(root);
			if(node.getChildren()[0]==n||node.getChildren()[1]==n)
				return node;
			else {
				if(!isBalanced(node.getChildren()[0])) 
					return unbalancedParent(node.getChildren()[0]);
				else
					return unbalancedParent(node.getChildren()[1]);
			}
		}
	
		public void Adjust(){
			Node d,s;
			if(!isBalanced(root)) {
					d=getUnbalanced(root);
					if(d!=null) {
						switch(d.getBalanceFactor()) {
						case 2:
							s=d.getChildren()[0];
							if(s.getBalanceFactor()==1)
								//����ת
								LL(d,s);
							if(s.getBalanceFactor()==-1)
								//��˫��ת
								LR(d,s);
							break;
						case -2:
							s=d.getChildren()[1];
							if(s.getBalanceFactor()==-1)
								RR(d,s);
							if(s.getBalanceFactor()==1)
								RL(d,s);
						}
					}
				}
		}
		
	//����ת
		public void LL(Node n1,Node n2) {
			//�����ڵ㲻ƽ�⣬Ҫ�������ۣ��ı���ڵ�
			if(n1==root) {
			    n1.getChildren()[0]=n2.getChildren()[1];
				n2.getChildren()[1]=n1;
				root=n2;
			}else {
				Node p=unbalancedParent(root);
			    n1.getChildren()[0]=n2.getChildren()[1];
			    n2.getChildren()[1]=n1;
			    //�븸�ڵ�����
			    if(!isBalanced(p.getChildren()[0]))
		            p.getChildren()[0]=n2;
		        else
		            p.getChildren()[1]=n2;
			}
		}
		
	    //��˫��ת
		private void LR(Node n1,Node n2) {
			Node u=n2.getChildren()[1];
			n1.getChildren()[0]=u.getChildren()[1];
			n2.getChildren()[1]=u.getChildren()[0];
			u.getChildren()[0]=n2;
			u.getChildren()[1]=n1;
			if(n1==root)
				root=u;
			else {
				Node p=unbalancedParent(root);
				if(!isBalanced(p.getChildren()[0]))
		            p.getChildren()[0]=u;
		        else
		            p.getChildren()[1]=u;
			}
		}
		
		//�ҵ���ת
		private void RR(Node n1,Node n2) {
			if(n1==root) {
				n1.getChildren()[1]=n2.getChildren()[0];
			    n2.getChildren()[0]=n1;
			    root=n2;
			}else {
				Node p=unbalancedParent(root);
	            n1.getChildren()[1]=n2.getChildren()[0];
	            n2.getChildren()[0]=n1;
	            if(!isBalanced(p.getChildren()[0]))
	            p.getChildren()[0]=n2;
	            else
	            	p.getChildren()[1]=n2;
			}
		}
		
		//��˫��ת
		public void RL(Node n1,Node n2) {
			Node u=n2.getChildren()[0];
			n1.getChildren()[1]=u.getChildren()[0];
			n2.getChildren()[0]=u.getChildren()[1];
			u.getChildren()[0]=n1;
			u.getChildren()[1]=n2;
			if(n1==root)
				root=u;
			else {
				Node p=unbalancedParent(root);
				if(!isBalanced(p.getChildren()[0]))
		            p.getChildren()[0]=u;
		        else
		            p.getChildren()[1]=u;
			}
			
		}
	
	@Override
	public JTree printTree() {
		// TODO Auto-generated method stub
		return new JTree(printTree1(root));
	}
	private DefaultMutableTreeNode printTree1(Node root){
		if(root != null){
			DefaultMutableTreeNode node=new DefaultMutableTreeNode(root.getData().toString()
					+"("+"Id:"+root.getId()+")");
			DefaultMutableTreeNode lChild=printTree1(root.getChildren()[0]);
			DefaultMutableTreeNode rChild=printTree1(root.getChildren()[1]);
			if(lChild != null && rChild != null){
				node.add(lChild);
				node.add(rChild);
			}else if(lChild != null){
				node.add(lChild);
			}else if(rChild != null){
				node.add(rChild);
			}
			return node;
		}else{
			return null;
		}
	}
		

}
