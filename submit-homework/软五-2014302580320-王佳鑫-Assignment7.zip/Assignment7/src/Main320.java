import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileReader;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class Main {
	public static void main(String[] args){
		Node[] nodes = new Node[17];
		//��ȡtree_data.dat�����ݣ������ڵ�
		try{
			int i=0;
			FileReader fs = new FileReader("src\\tree_data.dat");
			@SuppressWarnings("resource")
			BufferedReader br = new BufferedReader(fs);
			String record = new String();
			String[] no = new String[17];
			while((record = br.readLine()) != null){
				no[i]=record;
				i++;
			}
			
			for(int j=0;j<17;j++){
				Node node = new Node();
				String[]info = no[j].split("#");
				node.setData(info[0]);
				node.id=Integer.valueOf(info[1]).intValue();
	
				nodes[j]=node;
			}
		}
		catch(Exception e){
			System.out.print(e.toString());
		}
		//�����ʼƽ�������
//		AVLTree tree = new AVLTree(null);
		
		AVLTree tree = new AVLTree(nodes[5]);
		Node[] children1 = {nodes[4],nodes[7]};
		Node[] children2 = {nodes[3],null};
		Node[] children3 = {nodes[6],nodes[8]};
		Node[] children4 = {nodes[2],null};
		nodes[5].setChildren(children1);
		nodes[4].setChildren(children2);
		nodes[7].setChildren(children3);
		nodes[3].setChildren(children4);
		
//		tree.insert(nodes[9]);
//		System.out.println(tree.get(10).getData()+" "+String.valueOf(tree.get(10).getId()));
		
		JFrame fr=new JFrame();
		JButton get=new JButton("get");
		get.setBounds(0, 400, 100, 30);
		get.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				JFrame fr=new JFrame();
				JTextArea t0 = new JTextArea("ID:"+tree.get(6).getId()+"                        Data:"+tree.get(6).getData()
												+"           ID:"+tree.get(9).getId()+"                        Data:"+tree.get(9).getData()
												+"         ID:"+tree.get(4).getId()+"                        Data:"+tree.get(4).getData());
//				JTextField t1 = new JTextField("ID:"+tree.get(9).getId()+"            Data:"+tree.get(6).getData());
//				JTextField t2 = new JTextField("ID:"+tree.get(4).getId()+"            Data:"+tree.get(6).getData());
				t0.setLineWrap(true);
				t0.setEditable(false);
				fr.add(t0);
//				fr.add(t1);
//				fr.add(t2);
				fr.setBounds(560, 300, 300, 100);
				fr.setVisible(true);
				fr.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			}
		});
		
		JButton insert = new JButton("insert");
		insert.setBounds(100, 400, 100, 30);
		insert.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				tree.insert(nodes[5]);
				tree.insert(nodes[1]);
				tree.insert(nodes[3]);
				tree.insert(nodes[0]);
				tree.insert(nodes[7]);
				tree.insert(nodes[10]);
				tree.insert(nodes[13]);
				tree.insert(nodes[6]);
				tree.insert(nodes[15]);
				tree.insert(nodes[2]);
				System.out.println(tree.get(14).getData()+" "+String.valueOf(tree.get(14).getId()));
				JFrame fr=new JFrame();
				fr.add(tree.printTree());
				fr.setBounds(550, 100, 316, 549);
				
				fr.setVisible(true);
				fr.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			}
		});
		
		JButton delete = new JButton("delete");
		delete.setBounds(200, 400, 100, 30);
		delete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				tree.delete(9);
				
				JFrame fr=new JFrame();
				fr.add(tree.printTree());
				fr.setBounds(550, 100, 316, 549);
				
				fr.setVisible(true);
				fr.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			}
		});
		
		fr.add(get);
		fr.add(insert);
		fr.add(delete);
		fr.add(tree.printTree());
		fr.setBounds(550, 100, 316, 549);
		
		fr.setVisible(true);
		fr.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		
		
	}

}
