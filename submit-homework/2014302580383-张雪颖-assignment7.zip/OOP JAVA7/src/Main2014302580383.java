import javax.swing.JFrame;
import javax.swing.JTree;


public class Main2014302580383 extends JFrame {
	public static void main(String[] args) {
		 AVLTree tree = new AVLTree();
		 Node n1=new Node(1,"ant");
		 tree.insert(1, n1);
		 Node n2=new Node(2,"apple");
		 tree.insert(2, n2);
		 Node n3=new Node(3,"art");
		 tree.insert(3, n3);
		 Node n4=new Node(4,"baby");
		 tree.insert(4, n4);
		 Node n5=new Node(5,"banana");
		 tree.insert(5, n5);
		 Node n6= new Node(6,"car");
		 tree.insert(6,n6);
		 Node n7=new Node(7,"door");
		 tree.insert(7, n7);
		 //����get����
		 System.out.println(tree.get(6).getId() +"#" + tree.get(6).getData());
		 //���Բ��빦��
		 Node n10=new Node(10,"cash");
		 tree.insert(10, n10);
		//����ɾ������
		 tree.delete(5);
		JTree show = tree.printTree();
		Main2014302580383 test = new Main2014302580383();
		test.add(show);
		test.repaint();
		test.setSize(400, 400);
		test.setVisible(true);
		test.setDefaultCloseOperation(EXIT_ON_CLOSE);
	}

}
