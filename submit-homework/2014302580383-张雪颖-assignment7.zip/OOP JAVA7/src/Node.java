
public class Node {
	private int id;
	private Object data;
	private Node parent;
	private Node[] children = new Node[2];
	private int lSubTreeHeight;
	private int rSubTreeHeight;
	private int balanceFactor;
	public Node(){}
	public Node(int id,Object data){
		this.id=id;
		this.data=data;
	}
	public int getId() {
		return id;
	}
	public void setId(int id){
		this.id=id;
	}
	public Object getData() {
		return data;
	}
	public void setData(Object data) {
		this.data = data;
	}
	public Node getParent() {
		return parent;
	}
	public void setParent(Node parent) {
		this.parent = parent;
	}
	public Node[] getChildren() {
		return children;
	}
	public void setChildren(Node[] children) {
		this.children = children;
	}
	public void setChild(Node child, int id){
		this.children[id] = child;
	}
	//�ݹ����ý���������߶�
	public int getlSubTreeHeight() {
	    if(this.getChild(0)==null)
	    	lSubTreeHeight=0;
	    else {
	    	if(this.getChild(0).getlSubTreeHeight()>this.getChild(1).getrSubTreeHeight())
	    		lSubTreeHeight=this.getChild(0).getlSubTreeHeight()+1;
	    	else
	    		lSubTreeHeight=this.getChild(0).getrSubTreeHeight()+1; 		
	    }
	    return lSubTreeHeight;

	}
	//�ݹ����ý���������߶�
	public int getrSubTreeHeight() {
		if(this.getChild(1)==null)
			rSubTreeHeight=0;
		else{
			if(this.getChild(1).getrSubTreeHeight()>this.getChild(1).getlSubTreeHeight())
				rSubTreeHeight=this.getChild(1).getrSubTreeHeight()+1;
			else
				rSubTreeHeight=this.getChild(1).getlSubTreeHeight()+1;
		}
		return rSubTreeHeight;
	}
	//����ƽ������
	public int getBalanceFactor() {
		balanceFactor=this.getlSubTreeHeight()-this.getrSubTreeHeight();
		return balanceFactor;
	}
	public void setBalanceFactor(int balanceFactor){
		this.balanceFactor=balanceFactor;
	}
	public Node getChild(int i){
		if(i==0||i==1)return children[i];
		else return null;
	}

}
