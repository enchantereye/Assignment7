import javax.swing.JOptionPane;
import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;

public class AVLTree implements IAVLTree {
    public  Node root=new Node();
    //���ҽ���㷨,�����������Id����null
    public Node search(int id){
    	return search(root,id);
    } 
   private Node search(Node root,int id){
	   while(root!=null){
		   if(root.getId()==id)return root;
		   else if(root.getId()<id){
			   root=root.getChild(1);
		   }
		   else if(root.getId()>id){
			   root=root.getChild(0);
		   }
	   }
	   return null;
   }
   
	@Override
	public Node get(int id) {
		return search(id);
	}
//����
	@Override
	public void insert(int id, Node newNode) {
		insert(this.root,newNode,false);
	}
    private void insert(Node root,Node newNode,boolean Balanced){
    	if(root==null){
    		root=new Node();
    		Balanced=false;
    	}
    	else if(newNode.getId()<root.getId()){
    		if(Balanced){
    			switch(root.getBalanceFactor()){
    			case -1:
    				root.setBalanceFactor(0);
    				Balanced=true;
    				break;
    			case 0:
    				root.setBalanceFactor(1);
    				break;
    			case 1:
    				LRotation(root,Balanced);
    				break;
    			}
    		}
    		else if(newNode.getId()==root.getId()){
    			JOptionPane.showMessageDialog(null,"����Ѵ��ڣ����ܲ���","����",JOptionPane.ERROR_MESSAGE);
    		}
    		else{
    			if(Balanced){
    				switch (root.getBalanceFactor()){
    				case 1:
    					root.setBalanceFactor(0);
    					Balanced=true;
    					break;
    				case 0:
    					root.setBalanceFactor(-1);
    					break;
    				case -1:
    					RRotation(root,Balanced);
    					break;
    				}
    			}
    		}
    	}
    }
   //ɾ��
	@Override
	public void delete(int id) {
		Node temp=get(id);
		if(temp == null){
			System.out.println("�ý�㲻���ڣ�����ɾ��.");
		}else{
			Node c = new Node();
			Node s = new Node();
			Node r = new Node();
			Node q = temp.getParent();
			if(temp.getChild(0) != null && temp.getChild(1) != null){
				r = temp;
				s = temp.getChild(1);
				while(s.getChild(0) != null){
					r = s;
					s = s.getChild(0);				
				}
				temp.setData(s.getData());
				q = r;
				temp= s;			
			}else if(temp.getChild(0) != null){
				c = temp.getChild(0);
			}else if(temp.getChild(1) != null){
				c = temp.getChild(1);
			}else{
				temp = null;
			}
			if(temp == root){
				root = c;
			}else{
				if(temp == q.getChild(0)){
					q.setChild(c, 0);
				}else{
					q.setChild(c, 1);
				}
				temp= null;
			}				
		}

	}
	//����ת
    public void LRotation(Node root,boolean unBalanced){
    	Node u=new Node();
    	Node r=root.getChild(0);
    	if(r.getBalanceFactor()==1){
    		root.setChild(r.getChild(1), 0);
    		root.setChild(root, 1);
    		root.setBalanceFactor(0);
    		root=r;
    	}
    	else{
    		u=r.getChild(1);
    		r.setChild(u.getChild(0), 1);
    		u.setChild(r, 0);
    		root.setChild(u.getChild(1), 0);
    		u.setChild(root, 1);
    		switch(u.getBalanceFactor()){
    		case 1:
    			root.setBalanceFactor(-1);
    			r.setBalanceFactor(0);
    			break;
    		case 0:
    			root.setBalanceFactor(0);
    			r.setBalanceFactor(0);
    			break;
    		case -1:
    			root.setBalanceFactor(0);
    			r.setBalanceFactor(1);
    			break;
    		}
    		root=u;
    	}
    	root.setBalanceFactor(0);
    	unBalanced=false;
    }
    //����ת
    public void RRotation(Node root,boolean unBalanced){
	    Node u,r = root.getChild(1);
		if(r.getBalanceFactor() == -1){
			root.setChild(r.getChild(0), 1);
			r.setChild(root, 0);
		    root.setBalanceFactor(0);
			root= r;
		}else{
			u = r.getChild(0);
			r.setChild(u.getChild(1), 0);
            root.setChild(u.getChild(0), 1);
            u.setChild(r, 1);
			u.setChild(root, 0);
			switch(u.getBalanceFactor()){
			case 1:
				root.setBalanceFactor(0);
				r.setBalanceFactor(1);
				break;
			case 0:
				root.setBalanceFactor(0);
				r.setBalanceFactor(0);
				break;
			case -1:
				root.setBalanceFactor(1);
				r.setBalanceFactor(0);
				break;
			}
			root = u;
		}
		root.setBalanceFactor(0);
		unBalanced = false;
	
}
	@Override
	public JTree printTree() {
		DefaultMutableTreeNode defalutNode=new DefaultMutableTreeNode(this.root.getId()+"#"+this.root.getData());
		printTree(defalutNode,this.root);
		JTree temp=new JTree(defalutNode);
		return temp;
	}
	private void printTree(DefaultMutableTreeNode dNode,Node node){
		if(node!=null){
			Node l=node.getChild(0);
			Node r=node.getChild(1);
			if(l!=null){
				DefaultMutableTreeNode dnl=new DefaultMutableTreeNode(l.getId()+"#"+l.getData());
				dNode.add(dnl);
				printTree(dnl,l);
			}
			if(r!=null){
				DefaultMutableTreeNode dnr=new DefaultMutableTreeNode(r.getId()+"#"+r.getData());
				dNode.add(dnr);
				printTree(dnr,r);
			}
		}
	}

}
