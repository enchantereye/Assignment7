import java.util.ArrayList;

import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;

public class AVLTree implements IAVLTree {
	public Node t;
	public AVLTree(){
		t = null;
	}
	//比较两节点的id
	private int compare(int a,int b){
		if(a<b){return -1;}
		else if(a>b){return 1;}
		else{return 0;}
		
	}
	
	//左侧单旋转
	private Node rotateWithLeftChild(Node k2){
		Node k1 = k2.getChildren()[0];
		k2.getChildren()[0]=k1.getChildren()[1];
		k1.getChildren()[1]=k2;
		k2.height=Math.max(k2.getChildren()[0].height, k2.getChildren()[1].height)+1;
		k1.height=Math.max(k1.getChildren()[0].height, k2.height)+1;
		return k1;
	}
	//右侧单旋转
	private Node rotateWithRightChild(Node k2){
		Node k1 = k2.getChildren()[1];
		k2.getChildren()[1]=k1.getChildren()[0];
		k1.getChildren()[0]=k2;
		k2.height=Math.max(k2.getChildren()[1].height, k2.getChildren()[0].height)+1;
		k1.height=Math.max(k1.getChildren()[1].height, k2.height)+1;
		return k1;
	}
	//左侧双旋转
	private Node doubleWithLeftChild(Node k3){
		k3.getChildren()[0]=rotateWithRightChild(k3.getChildren()[0]);
		return rotateWithLeftChild(k3);
	}
	//右侧双旋转
	private Node doubleWithRightChild(Node k3){
		k3.getChildren()[1]=rotateWithLeftChild(k3.getChildren()[0]);
		return rotateWithRightChild(k3);
	}
	//先序遍历
	public void preOrder(Node root){     
          ArrayList<Node> nodes=new ArrayList<Node>();
          if(root!=null){
			  nodes.add(root);
			  preOrder(root.getChildren()[0]);
			  preOrder(root.getChildren()[1]);
			  }
          
		 }
	
	//私有的insert函数
	private Node insert(Node newNode,int id){
		id=t.getId();
		if(t == null){
			new Node(newNode.getId(),null,null);
			}
		int compareResult = compare(newNode.getId(),id);
		if(compareResult<0){
		t.getChildren()[0]=insert(newNode,t.getChildren()[0].getId());
			if(t.getChildren()[0].height-t.getChildren()[1].height==2){
				if(compare(newNode.getId(),t.getChildren()[0].getId())<0){
					t=rotateWithLeftChild(t);
				}
				else{t=doubleWithLeftChild(t);}
			}
		}
		else if(compareResult>0){
			t.getChildren()[1]=newNode;
			if(t.getChildren()[0].height-t.getChildren()[1].height==2){
				if(compare(newNode.getId(),t.getChildren()[1].getId())>0){
					t=rotateWithRightChild(t);
					
				}
				else{t=doubleWithRightChild(t);}
			}
		}
		else;
		t.height=Math.max(t.getChildren()[0].height, t.getChildren()[1].height)+1;
		return t;
		}
	//私有delete函数
	private Node delete(int id,Node t){
		if(t==null){
			return t;
		}
		int compareResult=compare(id,t.getId());
		if(compareResult<0){
			t.getChildren()[0]=delete(id,t.getChildren()[0]);
			}
			
		else if(compareResult>0){
			t.getChildren()[1]=delete(id,t.getChildren()[1]);
		}
		
		
		
		return t;
	
		
		
	}
	//私有的printTree函数
	private DefaultMutableTreeNode printTree(Node r){
		if(r!= null){
			DefaultMutableTreeNode temp=new DefaultMutableTreeNode(r.getId());
			if(r.getChildren()[0]!=null){
				temp.add(printTree(r.getChildren()[0]));
			}
			if(r.getChildren()[1]!=null){
				temp.add(printTree(r.getChildren()[1]));
			}
			return temp;
		}
		return null;
	}

	

	@Override
	public Node get(int id) {
		
		// TODO Auto-generated method stub
		Node node=t;
		for(;id != node.getId();){
			if(id < node.getId()){
				if(node.getChildren()[0] == null){
					return null;
				}
				node = node.getChildren()[0];
			}
			else{
				if(node.getChildren()[1] == null){
					return null;
				}
				node = node.getChildren()[1];
			}
		}
		return node;
		
	}
	@Override
	public void  insert(Node newNode) {
		// TODO Auto-generated method stub
		
		if(t == null){
			t = newNode;
		}
		else{
			insert(newNode,t.getId());
		}	
		
	}
	
	
	

	@Override
	public void delete(int id) {
		// TODO Auto-generated method stub
		if(t == null){
			return;
		}
		else{delete(id, t);
		}
	}

	@Override
	public JTree printTree() {
		// TODO Auto-generated method stub
		DefaultMutableTreeNode rootNode = printTree(t);	
		if(rootNode == null){
			rootNode = new DefaultMutableTreeNode("二叉树为空");
		}
		DefaultTreeModel tm = new DefaultTreeModel(rootNode);
		return new JTree(tm);
	}
	}
