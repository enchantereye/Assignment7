import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;

public class AVLTree implements IAVLTree{
	private Node root=null;
	
	
	public Node getRoot() {
		return root;
	}
	public AVLTree(){
		root=null;
	}

	@Override	
	public Node get(int id) {
		// TODO Auto-generated method stub
		return get(root,id);
	}
	
	private Node get(Node n,int id){
		if(n==null)return null;
		if(n.getId()>id)return get(n.getChildren()[0],id);
		if(n.getId()<id)return get(n.getChildren()[1],id);
		return n;
	}
	
	@Override
	public void insert(Node newNode) {
		// TODO Auto-generated method stub
		root=insert(newNode,root);
	}
	
	private Node insert(Node newNode,Node n){
		if(n==null)return newNode;
		if(newNode.getId()<n.getId()){
			if(n.getChildren()[0]==null){
				n.setLChild(newNode);
			}
			n.setLChild(insert(newNode,n.getChildren()[0]));
			if(n.getBalanceFactor()==2)
				if(newNode.getId()<n.getChildren()[0].getId())
					n=LSingleRotation(n);
				else
					n=LDoubleRotation(n);
		}
		else if(newNode.getId()>n.getId()){
			if(n.getChildren()[1]==null){
				n.setRChild(newNode);
			}
		
			n.setRChild(insert(newNode,n.getChildren()[1]));
			if(n.getBalanceFactor()==-2)
				if(newNode.getId()>n.getChildren()[1].getId())
					n=RSingleRotation(n);
				else
					n=RDoubleRotation(n);
		}
		else;
		root.setParent(null);
		return n;
	}
	

	@Override
	public void delete(int id) {
		// TODO Auto-generated method stub
		delete(id,root);
		
	}
	
	private void delete(int id,Node n){
		
		Node d=get(n,id);
		if(d==null)return;
	
		if(d.getChildren()[0]==null&&d.getChildren()[1]==null){
			if(d.getParent()==null){
				root=null;return;
			}
			else if(d==d.getParent().getChildren()[0])
				d.getParent().setLChild(null);
			else
				d.getParent().setRChild(null);
			Node s=d.getParent();
			//�ҵ���һ��ƽ�����Ӿ���ֵΪ2�Ľ��
			while((s!=null)&&s.getBalanceFactor()<2&&s.getBalanceFactor()>-2){
				s=s.getParent();
			}
			//Ϊ��ʱ֤�����ﵽƽ��
			if(s==null)return;
			//��ƽ��ʱ����ת����
			else if(s.getBalanceFactor()==2)
				if(id>s.getChildren()[0].getId())
					s=LSingleRotation(s);
				else
					s=LDoubleRotation(s);
			else
				if(id<s.getChildren()[1].getId())
					s=RSingleRotation(s);
				else
					s=RDoubleRotation(s);
		}
		else if(d.getChildren()[0]==null){
			if(d==root){
				root=d.getChildren()[1];return;
			}
			else if(d.getParent().getChildren()[0]==d)
				d.getParent().setLChild(d.getChildren()[1]);
			else
				d.getParent().setRChild(d.getChildren()[1]);
			Node s=d.getParent();
			while((s!=null)&&s.getBalanceFactor()<2&&s.getBalanceFactor()>-2){
				s=s.getParent();
			}
			if(s==null)return;
			else if(s.getBalanceFactor()==2)
				if(id>s.getChildren()[0].getId())
					s=LSingleRotation(s);
				else
					s=LDoubleRotation(s);
			else
				if(id<s.getChildren()[1].getId())
					s=RSingleRotation(s);
				else
					s=RDoubleRotation(s);
		}
		//������Ϊ�գ���������Ϊ��
		else if(d.getChildren()[1]==null){
			if(d==root){
				root=d.getChildren()[0];return;
			}
			else if(d.getParent().getChildren()[0]==d)
				d.getParent().setLChild(d.getChildren()[0]);
			else
				d.getParent().setRChild(d.getChildren()[0]);
			Node s=d.getParent();
			//�ҵ���һ����ƽ���
			while((s!=null)&&s.getBalanceFactor()<2&&s.getBalanceFactor()>-2){
				s=s.getParent();
			}
			//Ϊ��ʱ֤�����ﵽƽ��
			if(s==null)return;
			//��ƽ��ʱ����ת����
			else if(s.getBalanceFactor()==2)
				if(id>s.getChildren()[0].getId())
					s=LSingleRotation(s);
				else
					s=LDoubleRotation(s);
			else
				if(id<s.getChildren()[1].getId())
					s=RSingleRotation(s);
				else
					s=RDoubleRotation(s);
		}
		//������������Ϊ��
		else{
			//�ҵ�ֱ�Ӻ�̽��
			Node u=d.getChildren()[1];
			while(u.getChildren()[0]!=null){
				u=u.getChildren()[0];
			}
			//���Ľ��id����ֵ
			d.setId(u.getId());
			d.setData(u.getData());
			//ɾ�������һ�������ĺ�̽��
			delete(u.getId(),d.getChildren()[1]);
		}
	}
	
	private Node LSingleRotation(Node n){
		Node r=n.getChildren()[0];
			n.setLChild(r.getChildren()[1]);
			r.setRChild(n);
			return r;
	}
	
	private Node RSingleRotation(Node n){
		Node r=n.getChildren()[1];
		n.setRChild(r.getChildren()[0]);
		r.setLChild(n);
		return r;
	}
	
	private Node LDoubleRotation(Node n){
		n.setLChild(RSingleRotation(n.getChildren()[0]));
		return LSingleRotation(n);
	}
	
	private Node RDoubleRotation(Node n){
		n.setRChild(LSingleRotation(n.getChildren()[1]));
		return RSingleRotation(n);
	}

	@Override
	public JTree printTree() {
		// TODO Auto-generated method stub
		DefaultMutableTreeNode rootNode=new DefaultMutableTreeNode();
		creatNodes(rootNode,root);
		JTree temp=new JTree(rootNode);
		return temp;
	}


}
