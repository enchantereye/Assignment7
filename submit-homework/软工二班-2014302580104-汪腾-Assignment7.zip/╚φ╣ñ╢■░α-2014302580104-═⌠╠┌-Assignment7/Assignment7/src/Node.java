
public class Node {
	private int id;
	private String data;
	private Node parent;
	private Node[] children = new Node[2];
	private int lSubTreeHeight;
	private int rSubTreeHeight;
	private int balanceFactor;
	
	public Node(int id,String data){
		this.id=id;
		this.data=data;
	}
	

	private int getSubTreeHeight(Node n){
		if(n==null)return 0;
		Node[]c=n.getChildren();
		int lh=getSubTreeHeight(c[0]);
		int rh=getSubTreeHeight(c[1]);
		return (lh>rh?lh:rh)+1;
	}
	public int getlSubTreeHeight() {
		//TODO calculate the left sub tree height
		lSubTreeHeight=getSubTreeHeight(children[0]);
		return lSubTreeHeight;
	}
		public int getrSubTreeHeight() {
			//TODO calculate the right sub tree height
			rSubTreeHeight=getSubTreeHeight(children[1]);
			return rSubTreeHeight;
		}
		//��ȡƽ������
		public int getBalanceFactor() {
			//TODO calculate the balance factor
			balanceFactor=getlSubTreeHeight()-getrSubTreeHeight();
			return balanceFactor;
		}	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id=id;
	}
	public String getData() {
		return data;
	}
	public void setData(String data) {
		this.data = data;
	}
	public Node getParent() {
		return parent;
	}
	public void setParent(Node parent) {
		this.parent = parent;
	}
	public Node[] getChildren() {
		return children;
	}
	public void setChildren(Node[] children) {
		this.children = children;
	}
	
	
}
