
public class Node {
	private int id;
	private Object data;
	private Node parent;
	private Node[] children = new Node[2];
	private int lSubTreeHeight;
	private int rSubTreeHeight;
	private int balanceFactor;
	
	public Node(int ID){
		id=ID;
	}
	
	public Node(int ID,Object Data){
		id=ID;
		data=Data;
	}
	
	public void setId(int ID){
		id=ID;
	}
	public int getId() {
		return id;
	}
	public Object getData() {
		return data;
	}
	public void setData(Object data) {
		this.data = data;
	}
	public Node getParent() {
		return parent;
	}
	public void setParent(Node parent) {
		this.parent = parent;
	}
	public Node[] getChildren() {
		return children;
	}
	public void setChildren(Node[] children) {
		this.children = children;
	}
	public void setChild(Node child, int id){
		this.children[id] = child;
	}
	public int getlSubTreeHeight() {
		Node p=children[0];
		if(p==null){
			lSubTreeHeight=0;
		}else{
			if(p.getlSubTreeHeight()>p.getrSubTreeHeight()){
				lSubTreeHeight=p.getlSubTreeHeight()+1;
			}else{
				lSubTreeHeight=p.getrSubTreeHeight()+1;
			}
		}
		return lSubTreeHeight;
	}
	public int getrSubTreeHeight() {
		Node p=children[1];
		if(p==null){
			rSubTreeHeight=0;
//		}else if((p.getChildren()[1]==null)&&(p.getChildren()[0]==null)){
//			rSubTreeHeight=1;
		}else{
			if(p.getlSubTreeHeight()>=p.getrSubTreeHeight()){
				rSubTreeHeight=p.getlSubTreeHeight()+1;
			}else{
				rSubTreeHeight=p.getrSubTreeHeight()+1;
			}
		}
		return rSubTreeHeight;
	}
	public int getBalanceFactor() {
		balanceFactor=this.getlSubTreeHeight()-this.getrSubTreeHeight();
		return balanceFactor;
	}
	

}
