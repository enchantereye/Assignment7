import java.awt.BorderLayout;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;

/**
 * 
 */

/**
 * @author ��
 *
 */
public class AVLTree implements IAVLTree{
	private Node root=null;
	
	private int height;
	
	public AVLTree(){
		root=null;
	}
	
	private boolean LRotation(Node s){                 //��ת�����е�unBalnacedΪ�ٱ�ʾ
		boolean unBalanced=true;                       //�������ƽ�⵽��ԭ��һ���ĸ߶�
		Node r=s.getChildren()[0];
		Node u;
		if(r.getBalanceFactor()==1){
			s.setChild(r.getChildren()[1],0);
			if(r.getChildren()[1]!=null){
				r.getChildren()[1].setParent(s);
			}
			r.setChild(s, 1);
			r.setParent(s.getParent());
			if(s.getParent()!=null){
				s.getParent().setChild(r, (s.getParent().getChildren()[0]==s)?0:1);
			}else{
				root=s;
			}
			s.setParent(r);
		}else{
			u=r.getChildren()[1];
			r.setChild(u.getChildren()[0], 1);
			if(u.getChildren()[0]!=null){
				u.getChildren()[0].setParent(r);
			}
			u.setChild(r, 0);
			r.setParent(u);
			s.setChild(u.getChildren()[1], 0);
			if(u.getChildren()[1]!=null){
				u.getChildren()[1].setParent(s);
			}
			u.setChild(s, 1);
			u.setParent(s.getParent());
			if(s.getParent()!=null){
				s.getParent().setChild(u, (s.getParent().getChildren()[0]==s)?0:1);
			}else{
				root=u;
			}
			s.setParent(u);
		}
		unBalanced=false;
		return unBalanced;                                           
	}
	
	private boolean RRotation(Node s){
		boolean unBalanced=true;
		Node r=s.getChildren()[1];
		Node u;
		if(r.getBalanceFactor()==-1){
			s.setChild(r.getChildren()[0], 1);
			if(r.getChildren()[0]!=null){
				r.getChildren()[0].setParent(s);
			}
			r.setChild(s, 0);
			r.setParent(s.getParent());
			if(s.getParent()!=null){
				s.getParent().setChild(r, (s.getParent().getChildren()[0]==s)?0:1);
			}else{
				root=r;
			}
			s.setParent(r);
		}else{
			u=r.getChildren()[0];
			s.setChild(u.getChildren()[0], 1);
			if(u.getChildren()[0]!=null){
				u.getChildren()[0].setParent(s);
			}
			r.setChild(u.getChildren()[1], 0);
			if(u.getChildren()[1]!=null){
				u.getChildren()[1].setParent(r);
			}
			u.setChild(s, 0);
			u.setParent(s.getParent());
			if(s.getParent()!=null){
				s.getParent().setChild(u, (s.getParent().getChildren()[0]==s)?0:1);
			}else{
				root=u;
			}
			s.setParent(u);
			u.setChild(r, 1);
			r.setParent(u);
		}
		unBalanced=false;
		return unBalanced;
	}
	
	public int Height(){
		int l=root.getlSubTreeHeight();
		int r=root.getrSubTreeHeight();
		height=1+((l>r)?l:r);
		return height;
	}

	/* (non-Javadoc)
	 * @see IAVLTree#get(int)
	 */
	@Override
	public Node get(int id) {
		Node p=root;
		while(p != null){
			if(id<p.getId()){
				p=p.getChildren()[0];
			}else if(id>p.getId()){
				p=p.getChildren()[1];
			}else{
				return p;
			}
		}
		System.out.println("δ�ҵ�");
		return null;
	}
	
	/* (non-Javadoc)
	 * @see IAVLTree#insert(Node)
	 */
	@Override
	public void insert(Node newNode) {
		insert(root,newNode);
	}
	
	private boolean insert(Node s,Node newNode){
		boolean unBalanced=true;
		Node p=s;
		if(p==null){
			root=newNode;                            //�˴�Ϊ���ڵ�����
			unBalanced=true;                         //�˴���û��Ϊ�½������˫��
		}
		else if((newNode.getId()<p.getId())){
			if(p.getChildren()[0]==null){
				p.setChild(newNode,0);               //�������������˫��
				newNode.setParent(p);
				if(p.getBalanceFactor()==0){
					unBalanced=false;
				}else{
					unBalanced=true;
				}
			}else{
				int bFBeforeChange0=p.getBalanceFactor();
				unBalanced=insert(p.getChildren()[0],newNode);
				if(unBalanced){
					switch(bFBeforeChange0){
					case -1:{
						unBalanced=false;
						break;}
					case 0:break;
					case 1:unBalanced=LRotation(p);
					}//end switch
				}//end if
			}//end else
		}//end else if
		else if(newNode.getId()>p.getId()){
			if(p.getChildren()[1]==null){
				p.setChild(newNode, 1);                //�������������˫��
				newNode.setParent(p);
				if(p.getBalanceFactor()==0){
					unBalanced=false;
				}else{
					unBalanced=true;
				}
			}else{
				int bFBeforeChange1=p.getBalanceFactor();
				unBalanced=insert(p.getChildren()[1],newNode);
				if(unBalanced){
					switch(bFBeforeChange1){
					case 1:{unBalanced=false;
						break;
						}
					case 0:break;
					case -1:unBalanced=RRotation(p);
					}//end switch
				}//end if
			}
		}
		else{
			System.out.println("�ظ���");
		}
		
		return unBalanced;
	}
	
	
	/* (non-Javadoc)
	 * @see IAVLTree#delete(int)
	 */
	@Override
	public void delete(int id) {
		delete(root,id);
	}

	private boolean delete(Node s,int id){
		boolean shorter=true;                   //shorter��ʾ��ǰ����ƽ���ĸ߶��Ƿ�仯��
		Node p=s;                               //false���߶Ȳ��䣬��Ӱ��˫��ƽ������
		if(p==null){
			System.out.println("δ�ҵ��ý��");
		}else if(id<p.getId()){
			int bFBeforeChange0=p.getBalanceFactor();     //��ס�������ڵ�ƽ��֮ǰ��ƽ������
			shorter=delete(p.getChildren()[0],id);
			if(shorter){
				switch(bFBeforeChange0){
				case 0:{
						shorter=false;     
						break;
						}
				//ɾ���ϸ������Ľ�㣬ƽ��δ�ƻ����߶ȼ�С
				case 1:{
						shorter=true;
						break;   
						}
				//ɾ���ϰ�������㣬ƽ�ⱻ�ƻ����߶ȱ仯δ֪
				case -1:{
					Node r=p.getChildren()[1];    //rΪp�Ľϸ�����
					switch(r.getBalanceFactor()){
					case 0:{                      //RR��ת
							RRotation(p);
							shorter=false;
							break;
							}
					case -1:{                     //RR��ת
							RRotation(p);
							shorter=true;
							break;
							}
					case 1:{                      //RL��ת
							RRotation(p);
							shorter=true;
							}//end case 1(r)
					}//end switch(r)
				}//end case -1(p)
				}//end switch(p)
			}//end if
		}else if(id>p.getId()){
			int bFBeforeChange1=p.getBalanceFactor();        //��ס�������ڵ�ƽ��֮���ƽ������
			shorter=delete(p.getChildren()[1],id);
			if(shorter){
				switch(bFBeforeChange1){
				case 0:{
						shorter=false;
						break;
						}
				case -1:{
						shorter=true;
						break;
						}
				case 1:{
					Node r=p.getChildren()[0];
					switch(r.getBalanceFactor()){
					case 0:{
							LRotation(p);              //LL��ת
							shorter=false;
							break;
							}
					case 1:{
							LRotation(p);              //LL��ת
							shorter=true;
							break;
							}
					case -1:{
							LRotation(p);              //LR��ת
							shorter=true;
							}//end case -1(r)
					}//end switch(r)
				}//end case 1(p)
				}//end switch(p)
			}//end if
		}else{
			//ɾ������
			Node a;
			if((p.getChildren()[0]!=null)&&(p.getChildren()[1]!=null)){
				a=p.getChildren()[1];
				while(a.getChildren()[0]!=null){
					a=a.getChildren()[0];                      //a��Ϊʵ����ɾ�Ľ�㣨ɾ���󽫶�������ƽ�����Ӱ��Ľ�㣩
				}
				p.setId(a.getId());
				p.setData(a.getData());
				p=a;
			}
			if(p.getChildren()[0]!=null){                      //���ڶ���ƽ������ֻ��һ��������ζ��ֻ��һ��Ҷ��㺢��
				p.setId(p.getChildren()[0].getId());
				p.setData(p.getChildren()[0].getData());
				p.setChildren(p.getChildren()[0].getChildren());
				if(p.getChildren()[0]!=null){
					p.getChildren()[0].setParent(p);            //������p�ĺ����Ѿ��޸ĵĻ�����
				}
				if(p.getChildren()[1]!=null){
					p.getChildren()[1].setParent(p);
				}
				shorter=true;
			}else if((p.getChildren()[0]==null)&&(p.getChildren()[1]==null)){
				p.getParent().setChild(null, (p.getParent().getChildren()[0]==p)?0:1);
			}else{
				p.setId(p.getChildren()[1].getId());
				p.setData(p.getChildren()[1].getData());
				p.setChildren(p.getChildren()[1].getChildren());
				if(p.getChildren()[0]!=null){
					p.getChildren()[0].setParent(p);            
				}
				if(p.getChildren()[1]!=null){
					p.getChildren()[1].setParent(p);
				}
				shorter=true;
			}
		}
		return shorter;
	}

	/* (non-Javadoc)
	 * @see IAVLTree#printTree()
	 */
	@Override
	public JTree printTree() {
		JFrame jFrame=new JFrame();
        JPanel jPanel=new JPanel();
        DefaultMutableTreeNode top=new DefaultMutableTreeNode(root.getId()+"#"+root.getData());
        
        toJTreeNode(top, root);
        final JTree jTree=new JTree(top);

        jPanel.setLayout(new BorderLayout());
        jPanel.add(new JScrollPane(jTree));
        jFrame.add(jPanel);
        jFrame.setSize(500,400);
        jFrame.setVisible(true);
        jFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        return jTree;
	}
	
	private void toJTreeNode(DefaultMutableTreeNode dn,Node n){
		if(n==null){
			dn=null;
		}else{
			if(n.getChildren()[0]!=null){
				Node nl=n.getChildren()[0];
				DefaultMutableTreeNode dn1=new DefaultMutableTreeNode(nl.getId()+"#"+nl.getData());
				dn.add(dn1);
				toJTreeNode(dn1,nl);
				
			}
			if(n.getChildren()[1]!=null){
				Node nr=n.getChildren()[1];
				DefaultMutableTreeNode dn2=new DefaultMutableTreeNode(nr.getId()+"#"+nr.getData());
				dn.add(dn2);
				toJTreeNode(dn2,nr);
			}//end if
		}//end else	
	}//end toJTreeNode
	
	

}
