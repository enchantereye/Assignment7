import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

/**
 * 
 */

/**
 * @author ��
 *
 */
public class Main {
	
	public static void main(String[] args) throws IOException{
		AVLTree aTree=new AVLTree();
		FileReader fr=new FileReader("tree_data.dat");
		BufferedReader br=new BufferedReader(fr);
		String nextLine=null;
		String ragex="#";
		while((nextLine=br.readLine())!=null){
			String a[]=nextLine.split(ragex);
			int id=Integer.valueOf(a[1]);
			Object data=a[0];
			Node n=new Node(id,data);
			aTree.insert(n);
		}
		br.close();
		fr.close();
		aTree.printTree();
		Node n=aTree.get(8);
		System.out.println("id:"+n.getId()+"\ndata:"+n.getData()+"\n");

		aTree.delete(8);
		aTree.printTree();

	}
}
