import javax.swing.JFrame;
import javax.swing.JOptionPane;




public class Main extends AVLTree{
	

	public static void main(String[] args) {
	
		AVLTree avlTree=new AVLTree();
		Node node1=new Node();
		node1.setData("ant");
	    node1.setId(1);
		avlTree.insert(1,node1);
		Node node2=new Node();
		node2.setId(2);
		node2.setData("apple");
		avlTree.insert(2,node2);
		Node node3=new Node();
		node3.setId(3);
		node3.setData("art");
		avlTree.insert(3,node3);
		Node node4=new Node();
		node4.setId(4);
		node4.setData("baby");
		avlTree.insert(4,node4);
		Node node5=new Node();
		node5.setId(5);
		node5.setData("banan");
		avlTree.insert(5,node5);
		Node node6=new Node();
		node6.setId(6);
		node6.setData("car");
		avlTree.insert(6,node6);
		Node node7=new Node();
		node7.setId(7);
		node7.setData("door");
		avlTree.insert(7,node7);
		Node node8=new Node();
		node8.setId(8);
		node8.setData("dress");
		avlTree.insert(8,node8);
		Node node9=new Node();
		node9.setId(9);
		node9.setData("frog");
		avlTree.insert(9,node9);
		Node node10=new Node();
		node10.setId(10);
		node10.setData("love");
		avlTree.insert(10,node10);
		Node node11=new Node();
		node11.setId(11);
		node11.setData("mint");
		avlTree.insert(11,node11);
		Node node12=new Node();
		node12.setId(12);
		node12.setData("rice");
		avlTree.insert(12,node12);
		Node node13=new Node();
		node13.setId(13);
		node13.setData("show");
		avlTree.insert(13,node13);
		Node node14=new Node();
		node14.setId(14);
		node14.setData("table");
		avlTree.insert(14,node14);
		Node node15=new Node();
		node15.setId(15);
		node15.setData("tree");
		avlTree.insert(15,node15);
		Node node16=new Node();
		node16.setId(16);
		node16.setData("trouble");
		avlTree.insert(16,node16);
		Node node17=new Node();
		node17.setId(17);
		node17.setData("window");
		avlTree.insert(17,node17);
		for(int i=0;i<17;i++)
		{
			System.out.println("���"+(i+1)+"��Ϣ:"+avlTree.get(i+1).getId()+" "+avlTree.get(i+1).getData());
	}
		JFrame frame = new JFrame("���ݽṹ-Java��������");
        frame.add(avlTree.printTree());
        frame.setSize(500, 500);
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
       JOptionPane.showMessageDialog(null, "��ɾ��6��9��16����֤�漣��ʱ��ǧ������");
       try {
		Thread.sleep(3000);
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
        frame.dispose();
        avlTree.delete(6);
        avlTree.delete(9);
        avlTree.delete(16);
        frame = new JFrame("���ݽṹ-Java��������");
        frame.add(avlTree.printTree());
        frame.setSize(500, 500);
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	
}

	}
	
