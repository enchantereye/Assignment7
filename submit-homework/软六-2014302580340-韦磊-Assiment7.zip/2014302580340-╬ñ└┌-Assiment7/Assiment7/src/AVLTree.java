import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;


public class AVLTree implements IAVLTree{
	public Node root=null;
	
	/**
	 * get the node by index
	 * @param id, the node id to get
	 * @return
	 */
	public Node get(int id)
	{
		return find(root,id);
	}
	public Node find(Node Node1,int id)
	{
		if(Node1!=null)
		{
			if(Node1.getId()==id)
			{
				return Node1;
			}
			else if(Node1.getId()>id)
			{
				return find(Node1.getChildren()[0],id);
			}
			else
			{
				return find(Node1.getChildren()[1],id);
			}
		}
	else
		{
			return null;
		}
		
	}
	/**
	 * insert the node by id
	 * @param id, the parent node id to insert
	 * @return 
	 */
	public void insert(int id,Node newNode)
	{
		if(root==null)
		{
			root=newNode;
		}else 
			infix(root,newNode);
	}
/*private static int height(Node t)
{
    return t==null?-1:t.height;
}*/
	public Node infix(Node n, Node newNode)
	{
	/*if(newNode==null)
		{
			newNode=new Node();
		}else*/
		if(n.getId()<newNode.getId())
		{
			//newNode.getChildren()[0]=infix(id,newNode.getChildren()[0]);
			if(n.getChildren()[1]==null)
			{
				n.setChild(newNode, 1);
				newNode.setParent(n);
			}
			else
				infix(n.getChildren()[1],newNode);
			//n.setChild(newNode, 0);
			//newNode.setParent(n);
			if(newNode.getlSubTreeHeight()-newNode.getrSubTreeHeight()==2)
				if(n.getId()<newNode.getChildren()[0].getId())
					newNode=rotateWithLeftChild(newNode);
				else
					newNode=doubleWithLeftChild(newNode);
		}else if(n.getId()>newNode.getId())
		{
			//newNode.getChildren()[1]=infix(n,newNode.getChildren()[1]);
			if(n.getChildren()[0]==null)
			{
				n.setChild(newNode, 0);
				newNode.setParent(n);
			}
			else
				infix(n.getChildren()[0],newNode);
			
			if(newNode.getrSubTreeHeight()-newNode.getlSubTreeHeight()==2)
				if(n.getId()>newNode.getChildren()[1].getId())
					newNode=rotateWithRightChild(newNode);
				else
					newNode=doubleWithRightChild(newNode);
		}else
			;
		newNode.height=Math.max(newNode.getlSubTreeHeight(),newNode.getrSubTreeHeight())+1;
		return newNode;
	}
	/*private static int max(int height, int height2) {
		// TODO Auto-generated method stub
		if(height>height2)
			return height;
		else
			return height2;
	}*/
	private static Node rotateWithLeftChild(Node n2)
	{
		Node n1=n2.getChildren()[0];
		n2.getChildren()[0]=n1.getChildren()[1];
		n1.getChildren()[1]=n2;
		n2.height=Math.max(n2.getlSubTreeHeight(),n2.getrSubTreeHeight())+1;
		n1.height=Math.max(n1.getlSubTreeHeight(),n1.getrSubTreeHeight())+1;
		return n1;
	}
	
	private static Node rotateWithRightChild(Node n2)
	{
		Node n1=n2.getChildren()[1];
		n2.getChildren()[1]=n1.getChildren()[0];
		n1.getChildren()[0]=n2;
		n2.height=Math.max(n2.getlSubTreeHeight(),n2.getrSubTreeHeight())+1;
		n1.height=Math.max(n1.getlSubTreeHeight(),n1.getrSubTreeHeight())+1;
		return n1;
	}
	
	private static Node doubleWithLeftChild(Node n3)
	{
		n3.getChildren()[0]=rotateWithRightChild(n3.getChildren()[0]);
		return rotateWithLeftChild(n3);
	}
	private static Node doubleWithRightChild(Node n3)
	{
		n3.getChildren()[1]=rotateWithRightChild(n3.getChildren()[1]);
		return rotateWithLeftChild(n3);
	}
	/**
	 * the node id to delete
	 * @param id
	 */
	public void delete(int id)
	{
		Node tmp,node,p=root,prev=null;
		while(p!=null&&p.getId()!=id){
		prev=p;
		if(p.getId()<id)
			p=p.getChildren()[1];
		else p=p.getChildren()[0];
		}
		node=p;
		if(p!=null&&p.getId()==id)
		{
			if(node.getChildren()[1]==null)
				node=node.getChildren()[0];
			else if(node.getChildren()[0]==null)
				node=node.getChildren()[1];
			else{
				tmp=node.getChildren()[0];
				while(tmp.getChildren()[1]!=null)
				
					tmp=tmp.getChildren()[1];
					tmp.getChildren()[1]=
							node.getChildren()[1];
					node = node.getChildren()[0];
			}
				if(p==root)
					root=node;
				else if(prev.getChildren()[0]==p)
					prev.getChildren()[0]=node;
				else prev.getChildren()[1]=node;
			}
			else if(root!=null)
				System.out.println("key"+id+"is not in th tree");
			else System.out.println("key"+id+"is not in th tree");
		}
	
	/*private Node remove(int id,Node Node2)
	{
		if(Node2==null)
		{
			return null;
		}
		if(id<Node2.getId())
		{
			Node2.getChildren()[0]=remove(id,Node2.getChildren()[0]);
		}else if(id>Node2.getId())
		{
			Node2.getChildren()[1]=remove(id,Node2.getChildren()[1]);
		}else if(Node2.getChildren()[0]!=null&&Node2.getChildren()[1]!=null)
		{
			Node2.getId()=findMin(Node2.getChildren()[1]).getId();
			Node2.getChildren()[1]=remove(id,Node2.getChildren()[1]);
		}else
			Node2=(Node2.getChildren()[0]!=null)?Node2.getChildren()[0]:Node2.getChildren()[1];
			return Node2;
	}
	private Node findMin(Node n)
	{
		if(n==null)
			return null;
		else if(n.getChildren()[0]==null)
			return n;
		return findMin(n.getChildren()[0]);
	}*/
	/**
	 * print the whole tree
	 * @return a java swing Object JTree
	 */
	public JTree printTree()
	{
		DefaultMutableTreeNode defalutNode=new DefaultMutableTreeNode();
		print(defalutNode,root);
		JTree temp=new JTree(defalutNode);
		return temp;
	}
	
	
	
	
	
	
	
	
	
	private void print( DefaultMutableTreeNode node1,Node p)
	{
		if(p!=null)
		{
			if(p.getChildren()[0]!=null)
			{
				print(node1, p.getChildren()[0]);
			}
			DefaultMutableTreeNode defaul=new DefaultMutableTreeNode(p);
			if(p.getChildren()[0]!=null)
				defaul.add(new DefaultMutableTreeNode(p.getChildren()[0]));
			if(p.getChildren()[1]!=null)
				defaul.add(new DefaultMutableTreeNode(p.getChildren()[1]));
			node1.add(defaul);
			if(p.getChildren()[1]!=null)
			{
				print(node1, p.getChildren()[1]);
			}
		}
		
	}
	
}
