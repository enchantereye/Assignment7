
public class Node {
	private int id;
	private Object data;
	private Node parent;
	private Node left;
	private Node right;
	private int lh;
	private int rh;
	private int bf;
	//private int balanceFactor;
	
	public int getBf() {
		return bf;
	}

	public void setBf(int bf) {
		this.bf = bf;
	}

	public Node(int id,Object data,Node l,Node r)
	{
		this.id = id;
		this.data = data;
		this.left = l;
		this.right = r;
		lh = 0;
		rh = 0;
		bf = 0;
	}
	
	public Node()
	{
	}
	
	public Node(int id,Object data)
	{
		this(id, data, null, null);
	}
	
	public int getId() {
		return id;
	}
	
	public Object getData() {
		return data;
	}
	
	public void setData(Object data) {
		this.data = data;
	}
	
	public Node getParent() {
		return parent;
	}
	
	public void setParent(Node parent) {
		this.parent = parent;
	}
	
	public Node getLeft() {
		return left;
	}
	
	public void setLeft(Node left) {
		this.left = left;
	}
	
	public Node getRight() {
		return right;
	}
	
	public void setRight(Node right) {
		this.right = right;
	}
	
	public void setId(int id) {
		this.id = id;
	}

	public int getLh() {
		return lh;
	}

	public void setLh(int lh) {
		this.lh = lh;
	}

	public int getRh() {
		return rh;
	}

	public void setRh(int rh) {
		this.rh = rh;
	}
	

}
