
import java.awt.List;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.SocketAddress;
import java.util.*;

import javax.security.auth.x500.X500Principal;
import javax.swing.JFormattedTextField;
import javax.swing.JFrame;
import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;

public class AVLTree2014302580187 implements IAVLTree
{
    public Node root = null;
    public ArrayList<Node> nodes = new ArrayList<Node>();
    public static boolean unBalanced = true;
    
    
    public AVLTree2014302580187(String url) throws Exception {
		// TODO Auto-generated constructor stub
    	root = new Node();
    	getInformation(url);
    	
	}
    
    //get tree data from .dat file
	private void getInformation(String url) throws Exception
	{
		BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(url)));
		String data = null;
		while((data = br.readLine())!=null)
		{
			
			String info[] = data.split("#");
			this.nodes.add(new Node(Integer.parseInt(info[1]),(Object)info[0]));
		}
		int i=1;
		this.root = new Node(nodes.get(0).getId(),nodes.get(0).getData());
		this.root = nodes.get(0);
		this.root.setBf(0);
		while(i<nodes.size())
		{   
			unBalanced = true;
			this.insert(new Node(nodes.get(i).getId(),nodes.get(i).getData()));
			i++;
		}
	}
	
/*************The rotation of the AvlTree***************/	
	//Decide which rotation does the tree do


	private void LRotation(Node s)
	{
		
		Node r = s.getLeft();
		if(r.getBf()==1)
		{
			boolean isRight = true;
			if(s.getParent()!=null)
			{
			    if(s.getParent().getRight().getId()==s.getId())
			    {
			    	isRight = true;
		    	}
			    else 
		    	{
		    		isRight = false;
		    	}
		    }
			if(r.getRight()!=null)
			{
				r.getRight().setParent(s);
			}
			s.setLeft(r.getLeft());
			r.setParent(s.getParent());
     		s.setParent(r);
			r.setRight(s);
			r.setBf(0);
			s.setBf(0);
			if(r.getParent()==null)
			{
				this.root = r;
			}
			else 
			{
				if(isRight == true)
				{
					r.getParent().setRight(r);
				}
				
				else 
					r.getParent().setLeft(r);
			}
		}
		
		if(r.getBf() == -1)
		{
			Node u = r.getRight();
			boolean isRight = false;
			if(s.getParent().getRight().getId()==s.getId())
			{
				isRight = true;
			}
			else 
			{
				isRight = false;
			}
			
			u.setParent(s.getParent());
			s.setParent(u);
			r.setParent(u);
			
			
			if(u.getBf()==1)
			{
				s.setBf(-1);
				r.setBf(0);
			}
			else{
				s.setBf(0);
				r.setBf(1);
			}
			if(u.getLeft()!=null)
			{
				u.getLeft().setParent(r);
			}
			r.setRight(u.getLeft());
			s.setLeft(u.getRight());
			if(u.getRight()!=null)
			{
				u.getRight().setParent(s);
			}
			u.setLeft(r);
			u.setRight(s);
			u.setBf(0);
			if(u.getParent()==null)
			{
				this.root = u;
			}
			else 
			{
				if(isRight == true)
				{
					u.getParent().setRight(u);
				}
				
				else 
					u.getParent().setLeft(u);
			}
		}
	}
	
	private void RRotation(Node s)
	{
		
		Node r = s.getRight();
		if(r.getBf()==-1)
		{
			boolean isRight = true;
			if(s.getParent()!=null)
			{
			    if(s.getParent().getRight().getId()==s.getId())
			    {
			    	isRight = true;
		    	}
			    else 
		    	{
		    		isRight = false;
		    	}
		    }
			if(r.getLeft()!=null)
			{
				r.getLeft().setParent(s);
			}
			s.setRight(r.getLeft());
			r.setParent(s.getParent());
     		s.setParent(r);
			r.setLeft(s);
			r.setBf(0);
			s.setBf(0);
			if(r.getParent()==null)
			{
				this.root = r;
			}
			else 
			{
				if(isRight == true)
				{
					r.getParent().setRight(r);
				}
				
				else 
					r.getParent().setLeft(r);
			}
		}
		
		if(r.getBf() == 1)
		{
			Node u = r.getLeft();
			boolean isRight = false;
			if(s.getParent().getRight().getId()==s.getId())
			{
				isRight = true;
			}
			else 
			{
				isRight = false;
			}
			
			u.setParent(s.getParent());
			s.setParent(u);
			r.setParent(u);
			
			s.setRight(u.getLeft());
			if(u.getBf()==1)
			{
				s.setBf(0);
				r.setBf(-1);
			}
			else{
				s.setBf(1);
				r.setBf(0);
			}
			if(u.getLeft()!=null)
			{
				u.getLeft().setParent(s);
			}
			r.setLeft(u.getRight());
			if(u.getRight()!=null)
			{
				u.getRight().setParent(r);
			}
			u.setLeft(s);
			u.setRight(r);
			u.setBf(0);
			if(u.getParent()==null)
			{
				this.root = u;
			}
			else 
			{
				if(isRight == true)
				{
					u.getParent().setRight(u);
				}
				
				else 
					u.getParent().setLeft(u);
			}
		}
	}
	
	public void recursion(Node p,int id,Object data) {
		// TODO Auto-generated method stub
		if(id<p.getId())
		{
			if(p.getLeft()== null)
			{
				p.setLeft(new Node(id,data));
				p.getLeft().setParent(p);
			}
			else 
			{
				recursion(p.getLeft(),id,data);
			}
			switch (p.getBf()) {
			case -1:
				if(unBalanced==true)
				{
					p.setBf(0);			
				    unBalanced = false;
				}
				break;
			case 0:
				if(unBalanced==true)
				{
					p.setBf(1);		
				}
				break;
			case 1:
				if(unBalanced == true)
				{
					LRotation(p);
					unBalanced = false;
				}				
			}
		}
		else if (id == p.getId()) {
			unBalanced = false;
			System.out.println("已存在该节点，插入失败！");
		}
		else if (id>p.getId()) {
			if(p.getRight() == null)
			{
				p.setRight(new Node(id,data));
				p.getRight().setParent(p);
			}
			else 
			{
				recursion(p.getRight(), id,data);
			}
			switch (p.getBf()) {
			case 1:
				if(unBalanced==true)
				{
					p.setBf(0);
					unBalanced = false;
				}
				break;
			case 0:
				if(unBalanced==true)
				{
					p.setBf(-1);
				}
				break;
			case -1:
				if(unBalanced == true)
				{
					RRotation(p);
				    unBalanced = false;
				}
			}
		}
		return;
	}

	public DefaultMutableTreeNode setTreeNode(Node e) {
		// TODO Auto-generated method stub
		if(e==null)
		{
			return null;
		}
		
		DefaultMutableTreeNode tmp = new DefaultMutableTreeNode(e.getData());
		DefaultMutableTreeNode l = setTreeNode(e.getLeft());
		DefaultMutableTreeNode r = setTreeNode(e.getRight());
		if(l!=null)
			tmp.add(l);
		if(r!=null)
			tmp.add(r);   
		return tmp;
	}
	
	public Node getNearest(Node e)
	{
		Node nearest = e;
		while(nearest.getLeft()!=null)
		{
			nearest = nearest.getLeft();
		}
		return nearest;
	}
	

/********************************************************/
	//Get node by id
	@Override
	public Node get(int id) {
		// TODO Auto-generated method stub
		Node target = this.root;
		while(target!=null)
		{
			if(id>target.getId())
			{
				target = target.getRight();
				continue;
			}
			if(id<target.getId())
			{
				target = target.getLeft();
				continue;
			}
			if(id==target.getId())
			{
				System.out.println("成功找到该节点：<"+target.getData()+","+target.getId()+">");
				break;
			}
		}
		if(target==null)
		{
			System.out.println("不包含该节点！");
			return null;
		}
		return target;
	}

	//insert new node 
	@Override
	public void insert(Node newNode) {
		// TODO Auto-generated method stub
		recursion(this.root, newNode.getId(), newNode.getData());
	}
	
	@Override
	public void delete(int id) {
		// TODO Auto-generated method stub
		
		Node target = this.get(id);
		Node stand;
		if(target.getRight()!=null)
		{
			stand = getNearest(target.getRight());
			target.setId(stand.getId());
			target.setData(stand.getData());
		}
		else 
		{
			stand = target;
		}	
		Node p = stand.getParent();
		boolean shorter = true;
		if(stand.getRight()!=null)
		{
			stand.getRight().setParent(p);
		}
		p.setLeft(stand.getRight());
		
	while(p.getParent()!=null)
	{	
			switch (p.getBf()) {
		case 0:
			if(shorter==true)
			{
				p.setBf(-1);
			   
			    shorter = false;
			}
			break;
		case 1:
			if(shorter==true)
			{
				p.setBf(0);
			    shorter = false;
			}
			break;
		case -1:
			if(shorter == true)
			{
				Node r = p.getRight();
				switch (r.getBf()) {
				case 0:
					r.setParent(p.getParent());
					if(p.getParent()==null)
					{
						this.root = r;
					}
					else 
					{
						if(p.getParent().getRight().getId()==p.getId())
					    {
							p.getParent().setRight(r);
					    }
					    else 
					    {
					    	p.getParent().setLeft(r);
					    }	
					}
					p.setParent(r);
					p.setRight(r.getLeft());
					r.setLeft(p);
					r.setBf(1);
					p.setBf(-1);
					shorter = false;
					break;
				case -1:
					r.setParent(p.getParent());
					if(p.getParent()==null)
					{
						this.root = r;
					}
					else 
					{
						if(p.getParent().getRight().getId()==p.getId())
					    {
							p.getParent().setRight(r);
							p.getParent().setBf(r.getParent().getBf()+1);
					    }
					    else 
					    {
					    	p.getParent().setLeft(r);
					    	p.getParent().setBf(r.getParent().getBf()-1);
					    }	
					}
					p.setParent(r);
					p.setRight(r.getLeft());
					r.setLeft(p);
					r.setBf(0);
					p.setBf(0);
					shorter = true;
				case 1:
					Node u = r.getLeft();
					u.setParent(p.getParent());
					if(p.getParent().getRight().getId()==p.getId())
				    {
						p.getParent().setRight(u);
						p.getParent().setBf(p.getParent().getBf()+1);
				    }
				    else 
				    {
				    	p.getParent().setLeft(u);
				    	p.getParent().setBf(p.getParent().getBf()-1);
				    }	
					if(u.getBf()==0)
					{
						p.setBf(0);
						r.setBf(0);
					}
					if(u.getBf()==1)
					{
						p.setBf(0);
						r.setBf(-1);
					}
					if(u.getBf()==-1)
					{
						p.setBf(1);
						r.setBf(0);						
					}
					p.setParent(u);
					r.setParent(u);
					p.setRight(u.getLeft());
					r.setLeft(u.getLeft());
					u.setLeft(p);
					u.setRight(r);				
				}
			}
			break;			
		}
			if(shorter == true)
				break;
			p = p.getParent();
	}
		
	}

	@Override
	public JTree printTree() {
		// TODO Auto-generated method stub
		JTree tree=new JTree(this.setTreeNode(this.root));
		return tree;
	}

	/**************************************************/
	
	public static void main(String args[]) throws Exception
    {
    	 AVLTree2014302580187 tmp = new AVLTree2014302580187(".\\tree_data.dat");
    	 tmp.delete(8);
    	 tmp.delete(15);
    	 tmp.delete(6);
    	 JFrame frame = new JFrame("平衡二叉树");
    	 frame.add( tmp.printTree());
       	 frame.setSize(300, 600);
       	 frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
       	 frame.setVisible(true);
    }




	
}
