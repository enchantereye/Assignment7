import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;


public class AVLTree implements IAVLTree
{

	private Node root;
	private boolean head = true;
	private boolean taller;
	private static int m = 0;
	
	private int i =1;
	DefaultMutableTreeNode root1;
	DefaultMutableTreeNode child;
	DefaultMutableTreeNode chosen;
	JTree tree;
	DefaultTreeModel model;
	public AVLTree()
	{
		root = null;
	}
	public Node getRoot()
	{
		return root;
	}

	public int getM()
	{
		return m;
	}
	//get()����
	@Override
	public Node get(int id) {
		
		// TODO Auto-generated method stub
		Node node = root;
		while(node != null)
		{
			int result = id - node.getId();
			
			if(result < 0)
				node = node.getChildren()[0];
			else if(result > 0)
				node = node.getChildren()[1];
			else
				return node;
		}
		
		return null;
	}

	//����ת
	private void RightRotate(Node p)
	{
		if(p != null)
		{
			Node l = p.getChildren()[0];
			p.getChildren()[0] = l.getChildren()[1];
			
			if(l.getChildren()[1] != null){
				l.getChildren()[1].setParent(p);
			}
			l.setParent(p.getParent());
			
			if(p.getParent() == null)
				root = l;
			else if(p.getParent().getChildren()[1] == p)
				p.getParent().getChildren()[1] = l;
			else
				p.getParent().getChildren()[0] = l;
			
			l.getChildren()[1] = p;
			p.setParent(l);
		}
	}
	
	private void fix(Node p)
	{
		if(p.getBalanceFactor() == 2)
			leftBalance(p);
		if(p.getBalanceFactor() == -2)
			rightBalance(p);
	}
	
	private boolean leftBalance(Node t)
	{
		boolean heightLower = true;
		Node l = t.getChildren()[0];
		
		switch(l.getBalanceFactor()){
		case 1:
			t.setBalanceFactor(0);
			l.setBalanceFactor(0);
			RightRotate(t);
			break;
		case -1:
			Node rd = l.getChildren()[1];
			switch(rd.getBalanceFactor()){
			case 1:
				t.setBalanceFactor(-1);
				l.setBalanceFactor(0);
				break;
			case 0:
				t.setBalanceFactor(0);
				l.setBalanceFactor(0);
				break;
			case -1:
				t.setBalanceFactor(0);
				l.setBalanceFactor(1);
				break;
			}
			rd.setBalanceFactor(0);
			LeftRotate(t.getChildren()[0]);
			RightRotate(t);
			break;
		case 0:
			l.setBalanceFactor(-1);
			t.setBalanceFactor(1);
			RightRotate(t);
			heightLower = false;
			break;
		}
		return heightLower;
		
		
	}
	
	private boolean rightBalance(Node t){
		boolean heightLower = true;
		Node r = t.getChildren()[1];
		switch(r.getBalanceFactor()){
		case 1:
			Node ld = r.getChildren()[0];
			switch(ld.getBalanceFactor()){
			case 1:
				t.setBalanceFactor(0);
				r.setBalanceFactor(-1);
				break;
			case 0:
				t.setBalanceFactor(0);
				r.setBalanceFactor(0);
				break;
			case -1:
				t.setBalanceFactor(1);
				r.setBalanceFactor(0);
				break;
			}
			ld.setBalanceFactor(0);
			RightRotate(t.getChildren()[1]);
			LeftRotate(t);
			break;
		case -1:
			t.setBalanceFactor(0);
			r.setBalanceFactor(0);
			LeftRotate(t);
			break;
		case 0:
			r.setBalanceFactor(1);
			t.setBalanceFactor(-1);
			LeftRotate(t);
			heightLower = false;
			break;
		}
		return heightLower;
	}
	//����ת
	private void LeftRotate(Node p )
	{
		if(p != null)
		{
			Node r = p.getChildren()[1];
			p.getChildren()[1] = r.getChildren()[0];
			
			if(r.getChildren()[0] != null)
				r.getChildren()[0].setParent(p);
			r.setParent(p.getParent());
			
			if(p.getParent() == null)
				root = r;
			else if(p.getParent().getChildren()[0] == p)
				p.getParent().getChildren()[0] = r;
			else
				p.getParent().getChildren()[1] = r;
			p.setParent(r);
		}
	}
	@Override
	public void insert(int id,Node newNode) {
		// TODO Auto-generated method stub
		if(root == null)
		{
			root = new Node(newNode.getId(),newNode.getData());
			m++;
			return;
		}
		Node t = root;
		int cmp;
		Node parent;
		m++;
		do{
			parent =t;
			cmp = id - t.getId();
			if(cmp < 0)
				t = t.getChildren()[0];
			else if(cmp > 0)
				t = t.getChildren()[1];
			else
				break;
		}while(t != null);
		
		Node child = new Node(newNode.getId(),newNode.getData());
		child.setParent(parent);
		
		if(cmp < 0 )
			parent.getChildren()[0] = child;
		else
			parent.getChildren()[1] = child;
		
		while(parent != null)
		{
			cmp = id - parent.getId();
			
			if(cmp < 0){
				parent.setBalanceFactor(parent.getBalanceFactor()+1);
			}else{
				parent.setBalanceFactor(parent.getBalanceFactor()-1);
			}
			if(parent.getBalanceFactor() == 0){
				break;
			}
			
			if(Math.abs(parent.getBalanceFactor()) == 2){
				fix(parent);
				break;
			}	
		}	
		
	}

	private void Fix(Node p)
	{
		boolean heightLower = true;
		
		Node t = p.getParent();
		int cmp;
		while(t != null && heightLower)
		{
			cmp = p.getId() - t.getId();
			
			if(cmp >= 0){
				t.setBalanceFactor(t.getBalanceFactor()+1);
			}
			else{
				t.setBalanceFactor(t.getBalanceFactor()-1);
			}
			
			if(Math.abs(t.getBalanceFactor()) == 1){
				break;
			}
			
			Node r = t;
			
			if(t.getBalanceFactor() == 2)
				heightLower = leftBalance(r);
			else if(t.getBalanceFactor() == -2)
				heightLower = rightBalance(r);
			
			t = t.getParent();
		}
	}
	
	private Node successor(Node t){
		if(t == null)
			return null;
		else if(t.getChildren()[1] == null){
			Node p = t.getChildren()[1];
			
			while(p.getChildren()[0] != null)
				p = p.getChildren()[0];
			return p;
		}else{
			Node p = t.getParent();
			Node ch = t;
			while(p != null && ch == p.getChildren()[1]){
				ch = p;
				p = p.getParent();
			}
			return p;
		}
		
	}
	private void remove(Node p){
		if(p.getChildren()[0] != null && p.getChildren()[1] != null){
			Node s = successor(p);
			p.setId(s.getId());
			p = s;
		}
		Node replacement = (p.getChildren()[0] != null ?p.getChildren()[0] : p.getChildren()[1]);
		
		if(replacement != null){
			replacement.setParent(p.getParent());
			if(p.getParent() == null)
				root = replacement;
			else if(p == p.getParent().getChildren()[0])
				p.getParent().getChildren()[0] = replacement;
			else
				p.getParent().getChildren()[1] = replacement;
			
			p.getChildren()[0] = p.getChildren()[1] = null;
			p.setParent(null);
			
			Fix(replacement);
		}else if(p.getParent() == null)
		{
			root = null;
		}else{
			Fix(p);
			if(p.getParent() != null)
				p.getParent().getChildren()[0] = null;
			else if(p == p.getParent().getChildren()[1]){
				p.getParent().getChildren()[1] = null;
				p.setParent(null);
			}
		}
	}
	
	@Override
	public void delete(int id) {
		// TODO Auto-generated method stub
		
		
		Node e = get(id);
		
		if(e != null){
			remove(e);
			m--;
		}
	}

	
	@Override
	public JTree printTree() {
		// TODO Auto-generated method stub
		JFrame frame = new JFrame();
	   Container contentPane = frame.getContentPane();
	   JPanel panel = new JPanel(new BorderLayout());
	   root1 = new DefaultMutableTreeNode("root");
	   tree = new JTree(root1);
	   panel.add(new JScrollPane(tree),BorderLayout.CENTER);
	   model = (DefaultTreeModel)tree.getModel();
	  child = new DefaultMutableTreeNode(get(1).getData());
	  int n;
	  if(m%2 ==0)
		  n = m/2;
	  else
		  n = m/2+1;
		for(i=2;i <= n;i++)
		{
			if(get(i) != null)
			{
			 child.add(new DefaultMutableTreeNode(get(i).getData()));
			 chosen = (DefaultMutableTreeNode)tree.getLastSelectedPathComponent();
			 if(chosen == null)
				 chosen = root1;
					 
			 model.insertNodeInto(child, chosen, 0);
			}
		}
	   contentPane.add(panel);
	   frame.setVisible(true);
	   frame.setSize(300,500);
	   frame.setLocation(400,100);
	   return tree;
	}
	
	public String readFile(String url) throws IOException{
        File file=new File(url);
        if(!file.exists() || file.isDirectory())
           throw new FileNotFoundException();
        BufferedReader br=new BufferedReader(new FileReader(file));
        String temp=null;
        StringBuffer sb=new StringBuffer();
        temp=br.readLine();
        while(temp!=null){
            sb.append(temp+" ");
            temp=br.readLine();
        }
        return sb.toString();
    }

}
