import java.io.IOException;

public class AVLTree2014302580254 
{
	public static void main(String[] args) throws IOException
	{
		 String result = new AVLTree().readFile(System.getProperty("user.dir")+"\\src\\tree_data.dat");//AVLTree2014302580254.class.getResource("/tree_data.dat").toString());
		String result2 = result.replaceAll("#", " ");
		 String[] m1 = result2.split(" ");
		 int n = (m1.length)/2;
		 String[] m2 = new String[n];
		 System.out.println(m2.length);
		for(int i = 0;i<m2.length;i++)
		{
			int j = 2*i;
			m2[i] = m1[j];
		}
		for(int i =0;i<m2.length;i++)
		{
			System.out.println(m2[i]);
		}
		AVLTree tree = new AVLTree();
		System.out.println("Insert");

	    Node node1 = new Node(1,m2[0]);
	    tree.insert(1,node1);
	    tree.insert(1,node1);
	    Node node2 = new Node(2,m2[1]);
	    tree.insert(2,node2);
	    tree.insert(2,node2);
	    Node node3 = new Node(3,m2[2]);
	    tree.insert(3,node3);
	    tree.insert(3,node3);
	    Node node4 = new Node(4,m2[3]);
	    tree.insert(4,node4);
	    tree.insert(4,node4);
	    Node node5 = new Node(5,m2[4]);
	    tree.insert(5,node5);
	    tree.insert(5,node5);
	    Node node6 = new Node(6,m2[5]);
	    tree.insert(6,node6);
	    tree.insert(6,node6);
	    Node node7 = new Node(7,m2[6]);
	    tree.insert(7,node7);
	    tree.insert(7,node7);
	    Node node8 = new Node(8,m2[7]);
	    tree.insert(8,node8);
	    tree.insert(8,node8);
	    Node node9 = new Node(9,m2[8]);
	    tree.insert(9,node9);
	    tree.insert(9,node9);
	    Node node10 = new Node(10,m2[9]);
	    tree.insert(10,node10);
	    tree.insert(10,node10);
	    Node node11 = new Node(11,m2[10]);
	    tree.insert(11,node11);
	    tree.insert(11,node11);
	    Node node12 = new Node(12,m2[11]);
	    tree.insert(12,node12);
	    tree.insert(12,node12);
	    Node node13 = new Node(13,m2[12]);
	    tree.insert(13,node13);
	    tree.insert(13,node13);
	    Node node14 = new Node(14,m2[13]);
	    tree.insert(14,node14);
	    tree.insert(14,node14);
	    Node node15 = new Node(15,m2[14]);
	    tree.insert(15,node15);
	    tree.insert(15,node15);
	    Node node16 = new Node(16,m2[15]);
	    tree.insert(16,node16);
	    tree.insert(16,node16);
	    Node node17 = new Node(17,m2[16]);
	    tree.insert(17,node17);
	    tree.insert(17,node17);
	    
	    Node m = tree.get(1);
	    System.out.println("get()������ʾ�����");
	    System.out.printf("ID:%d",m.getId());
	    System.out.println();
	    System.out.printf("Data:%s",m.getData());
	    System.out.println(tree.getM());
		System.out.println();
		tree.printTree();
		System.out.println("Delete");
		tree.delete(15);
		System.out.println(tree.getM());
		tree.printTree();

	}
}
