import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;

public class AVLTree implements IAVLTree{
	private Node root;

	@Override
	public Node get(int id) {
		// TODO Auto-generated method stub
		if (root == null) {
			System.out.println("���ڵ�Ϊ��");
			return null;
		} 
		if (id == root.getId()){
			return root;
		}
		else {
			Node n = root;
			while ((n != null) && (id != n.getId())) {
				if(id < n.getId()) {
					n = n.getChildren()[0];
				} else {
					n = n.getChildren()[1];
				}				 
			} 
			if (n == null) {
				System.out.println("AVLTree�в�����id="+id+"�Ľ��");				
				return null;
			}
			return n;
		}
	}

	@Override
	public void insert(int id, Node newNode) {
		// TODO Auto-generated method stub
		if (root == null) {
			root = newNode;
		} else {
			Node n = root;
			Node parent;
			while (true) {
				if (id == n.getId()) {
					break;
				}
				
				parent = n;
				boolean goLeft = id < n.getId();
				n = goLeft ? n.getChildren()[0] : n.getChildren()[1];
				
				if (n == null) {
					if (goLeft) {
						parent.setChild(n, 0);
					} else {
						parent.setChild(n, 1);
					}
					rebalance(parent);
					break;
				}
			}
		}
	}

	@Override
	public void delete(int id) {
		// TODO Auto-generated method stub
        if (root == null)
            return;
        Node n = root;
        Node parent = root;
        Node delNode = null;
        Node child = root;
 
        while (child != null) {
            parent = n;
            n = child;
            child = delNode.getId() <= n.getId() ? n.getChildren()[0] : n.getChildren()[1];
            if (delNode.getId() == n.getId())
                delNode = n;
        }
 
        if (delNode != null) {
            delNode.setId(n.getId());
 
            child = n.getChildren()[0] != null ? n.getChildren()[0] : n.getChildren()[1];
 
            if (root.getId() == delNode.getId()) {
                root = child;
            } else {
                if (parent.getChildren()[0] == n) {
                    parent.setChild(child, 0);
                } else {
                    parent.setChild(child, 1);
                }
                rebalance(parent);
            }
        }
	}

	@Override
	public JTree printTree() {
		// TODO Auto-generated method stub
		DefaultMutableTreeNode rootNode = new DefaultMutableTreeNode(null); 
		
		JTree JTree = new JTree(rootNode);
		return JTree;
	}
	
	private void rebalance(Node n) {
		setBalance(n);
		
		if (n.getBalanceFactor() == -2) {
			if (height(n.getChildren()[0].getChildren()[0]) >= 
					height(n.getChildren()[0].getChildren()[1]))
				n = rotateRight(n);
			else
				n = rotateLeftThenRight(n);
		} else if (n.getBalanceFactor() == 2) {
			if (height(n.getChildren()[1].getChildren()[1]) >= 
					height(n.getChildren()[1].getChildren()[1]))
				n = rotateLeft(n);
			else
				n = rotateRightThenLeft(n);
		}
		
        if (n.getParent() != null) {
            rebalance(n.getParent());
        } else {
            root = n;
        }
	}
	
	private void setBalance(Node...nodes){
        for (Node n : nodes)
            n.setBalanceFactor();
	}
	
    private Node rotateLeft(Node a) {
   	 
        Node b = a.getChildren()[1];
        b.setParent(a.getParent());
 
        a.setChild(b.getChildren()[0], 1);
 
        if (a.getChildren()[1] != null)
            a.getChildren()[1].setParent(a);
 
        b.setChild(a, 0);
        a.setParent(b);
 
        if (b.getParent() != null) {
            if (b.getParent().getChildren()[1] == a) {
                b.getParent().setChild(b, 1);
            } else {
                b.getParent().setChild(b, 0);
            }
        }
 
        setBalance(a, b);
 
        return b;
    }

    private Node rotateRight(Node a) {
    	 
        Node b = a.getChildren()[0];
        b.setParent(a.getParent());
 
        a.setChild(b.getChildren()[1], 0);
 
        if (a.getChildren()[0] != null)
            a.getChildren()[0].setParent(a);
 
        b.setChild(a, 1);
        a.setParent(b);
 
        if (b.getParent() != null) {
            if (b.getParent().getChildren()[1] == a) {
                b.getParent().setChild(b, 1);
            } else {
                b.getParent().setChild(b, 0);
            }
        }
 
        setBalance(a, b);
 
        return b;
    }
    
    private Node rotateLeftThenRight(Node n) {
        n.setChild(rotateLeft(n.getChildren()[0]), 0);
        return rotateRight(n);
    }
 
    private Node rotateRightThenLeft(Node n) {
        n.setChild(rotateLeft(n.getChildren()[1]), 1);
        return rotateLeft(n);
    }
    
    private int height(Node n) {
    	if (n == null)
    		return -1;
    	
    	return 1 + Math.max(n.getlSubTreeHeight(), n.getrSubTreeHeight());

    }

}
