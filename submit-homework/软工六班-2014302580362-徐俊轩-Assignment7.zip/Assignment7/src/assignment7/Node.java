package assignment7;

import static java.lang.Math.abs;


public class Node {
	private int id;
	private Object data;   
	private Node parent;
	private Node[] children = new Node[2];
	private int lSubTreeHeight;
	private int rSubTreeHeight;
	private int balanceFactor;
        
        Node(){
            
        }
        
        Node(Object d){
            data=d;
        }    
        
        Node(int i,Object d){
            id=i;
            data=d;
        }
        
	public int getId() {
		return id;
	}
        public void setId(int k){
                this.id=k;
        }
	public Object getData() {
		return data;
	}
	public void setData(Object data) {
		this.data = data;
	}
	public Node getParent() {
		return parent;
	}
	public void setParent(Node parent) {
            if(parent!=null){
		this.parent = parent;
            }
            else{
                this.parent=null;
            }
	}
	public Node[] getChildren() {
		return children;
	}
	public void setChildren(Node[] children) {
		if(children!=null)this.children = children;
                if(children[0]!=null)children[0].setParent(this);
                if(children[1]!=null)children[1].setParent(this);
	}
	public void setChild(Node child, int id,int pos){
            	if(pos != 0 && pos !=1){
                    return;
		}
		if(child!=null)
                {this.children[pos] = child;
                child.setParent(this);}
                else
                {
                    this.children[pos] =null;
                }
	}
	public int getlSubTreeHeight() {
		//TODO calculate the left sub tree height
		int lstLsth = 0;
		int lstRsth = 0;
		if(children[0] == null){
			return 0;
		}
		lstLsth = children[0].getlSubTreeHeight();
		lstRsth = children[0].getrSubTreeHeight();
		lSubTreeHeight = (lstLsth > lstRsth ? lstLsth:lstRsth) + 1;
		return lSubTreeHeight;
	}
	public int getrSubTreeHeight() {
		//TODO calculate the right sub tree height
		int rstLsth = 0;//ÓÒ×ÓÊ÷µÄ×ó×ÓÊ÷¸ß¶È
		int rstRsth = 0;//ÓÒ×ÓÊ÷µÄÓÒ×ÓÊ÷¸ß¶È
		if(children[1] == null){
			return 0;  
		}
		rstLsth = children[1].getlSubTreeHeight();
		rstRsth = children[1].getrSubTreeHeight();
		rSubTreeHeight = (rstLsth > rstRsth ? rstLsth:rstRsth) + 1;
		return rSubTreeHeight;
	}
	public int getBalanceFactor() {
		//TODO calculate the balance factor
                balanceFactor=getrSubTreeHeight()-getlSubTreeHeight();
		return balanceFactor;
	}

        boolean hasChild(int i) {
            return children[i] != null;
        }

        public int compare(Node n){
            if(this.data.toString().compareTo(n.data.toString())>0 ){
                    return 1;
            }else if(this.data.toString().compareTo(n.data.toString())<0){
                    return -1;
            }
            return 0;
	}
        
        private void swap(Node a, Node b){
		int tempId = a.getId();
		Object tempData = a.getData();
		a.setId(b.getId());
		a.setData(b.getData());
		b.setId(tempId);
		b.setData(tempData);	
	}
        
        public int jugdeChild(){
            return compare(this.getParent());
        }

        public int judgeAxis(Node n){
            return compare(n);
        }
}
