/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package assignment7;


import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;

/**
 *
 * @author Administrator
 */
public class myAVLTree implements IAVLTree { 

    private Node root;
    


    myAVLTree(){
            root = null;
    }
    
    myAVLTree(Node n){
            root = n;
    }    

    
    public void setRoot(Node k){
        this.root=k;
        k.setParent(null);
    }
    
    @Override
    public Node get(int id) {
        Node temp=this.root;
        
        while(true)
        {
            if (id>temp.getId()&&temp.hasChild(1)){
                temp=temp.getChildren()[1];
            }
            else if (id<temp.getId()&&temp.hasChild(0)){
                temp=temp.getChildren()[0];
            }
            else if (id>temp.getId())
            {
                return null;
                //break ;
            }
            else if (id<temp.getId())
            {
                return null;
                //break;

            }
            else if (id==temp.getId())
            {
                return temp;

            }                
            else
            {
                return null;
            }
        }
        
        
        //return null;
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void insert(int id, Node newNode) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        Node temp=this.root;
        
        if (temp==null)
        {
            this.setRoot(newNode);
        }
        else
        {
            while(true)
            {
                if (newNode.compare(temp)==1&&temp.hasChild(1)){
                    temp=temp.getChildren()[1];
                }
                else if (newNode.compare(temp)==-1&&temp.hasChild(0)){
                    temp=temp.getChildren()[0];
                }
                else if (newNode.compare(temp)==1)
                {
                    temp.setChild(newNode, id, 1);
                    Node newTemp=temp;
                    break ;
                }
                else if (newNode.compare(temp)==-1)
                {
                    temp.setChild(newNode, id, 0);
                    break;

                }
                else if (newNode.compare(temp)==0)
                {
                    temp.setChild(newNode, id, 0);
                    break;

                }                
                else
                {
                    return;
                }
            }
        }
        
        
        if(this.findUnbalance(newNode)!=null){
            Node aNode=this.findUnbalance(newNode);
            int JC=newNode.jugdeChild();
            int JA=newNode.judgeAxis(aNode);
        
            if(JC==1){
                if(JA==1){
                    if (aNode.getParent()!=null){
                        Node aTemp=aNode.getParent();
                        aNode=SingleRotateWithRight(aNode);
                        if(aTemp.compare(aNode)==1){aTemp.setChild(aNode, id, 0);}
                        else{aTemp.setChild(aNode, id, 1);}
                        
                    }
                    else{
                        Node aTemp=aNode.getParent();
                        aNode=SingleRotateWithRight(aNode);
                        if(aTemp.compare(aNode)==1){aTemp.setChild(aNode, id, 0);}
                        else{aTemp.setChild(aNode, id, 1);}
                    }
                    
                }
                else if(JA==-1){
                    Node aTemp=aNode.getParent();
                    aNode=DoubleRotateRight(aNode);
                    if(aTemp.compare(aNode)==1){aTemp.setChild(aNode, id, 0);}
                    else{aTemp.setChild(aNode, id, 1);}
                }
            }
            else if(JC==-1){
                if(JA==1){
                        Node aTemp=aNode.getParent();
                        aNode=SingleRotateWithRight(aNode);
                        if(aTemp.compare(aNode)==1){aTemp.setChild(aNode, id, 0);}
                        else{aTemp.setChild(aNode, id, 1);}
                }
                else if(JA==-1){
                    Node aTemp=aNode.getParent();
                    aNode=DoubleRotateLeft(aNode);
                    if(aTemp.compare(aNode)==1){aTemp.setChild(aNode, id, 0);}
                    else{aTemp.setChild(aNode, id, 1);}
                }
            }
        }
        
        
        
    
//        int Ctemp=newNode.compare(temp);
//        while (Ctemp==1&&temp.hasChild(1)||Ctemp==-1&&temp.hasChild(0)||Ctemp==0&&temp.hasChild(0)==true&&temp.hasChild(1)==true)
//        {
//            if(Ctemp==1){
//                temp=temp.getChildren()[1];
//            }
//            else if(Ctemp==-1){
//                temp=temp.getChildren()[0];
//            }
//            else
//            {
//                temp=temp.getChildren()[1];
//            }
//           //temp=temp.getChildren()[0];
//        }
//        if(Ctemp==1){
//            temp.setChild(newNode, id,1);
//        }
//        else if(Ctemp==-1){
//            temp.setChild(newNode, id,0);
//        }
//        else{
//            if(temp.getBalanceFactor()>0)
//            {
//                temp.setChild(newNode, id,0);
//            }
//            else if(temp.getBalanceFactor()<0)
//            {
//                temp.setChild(newNode, id,1);
//            }
//            else{
//                //if(temp.hasChild(0)&&temp.)
//            }
//        }
//        temp.setChild(newNode, id,0);
        
        
    }

    @Override
    public void delete(int id) {
        Node temp=this.root;
        int flag=0; 
        while(true)
        {
            if (id>temp.getId()&&temp.hasChild(1)){
                temp=temp.getChildren()[1];
                flag=1;
            }
            else if (id<temp.getId()&&temp.hasChild(0)){
                temp=temp.getChildren()[0];
                flag=-1;
            }
            else if (id>temp.getId())
            {
                //return null;
                //break ;
            }
            else if (id<temp.getId())
            {
                //return null;
                //break;
            }
            else if (id==temp.getId())
            {
                //return temp;
               if(!temp.hasChild(0)&&!temp.hasChild(1)){
                   if(flag==1){temp.getParent().setChild(null, 1, 1);}
                   else if(flag==-1){temp.getParent().setChild(null, 0, 0);}
               }
               else if(temp.hasChild(0)||temp.hasChild(1)){
                   if(temp.hasChild(0)){temp.getChildren()[0].setChild(temp.getChildren()[1], 0, 1);temp=temp.getChildren()[0];}
                   else if(temp.hasChild(1)){temp.getChildren()[0].setChild(temp.getChildren()[0], 0, 0);temp=temp.getChildren()[1];}
               }  
               else if(temp.hasChild(0)&&temp.hasChild(1)){
                   Node ltemp=temp;
                   while(ltemp.hasChild(0)){ltemp=ltemp.getChildren()[0];}
                   temp=ltemp;
               }   
               break;
            }                
            else
            {
                //return null;
            }
        }
    }

    private DefaultMutableTreeNode printTree(Node n){
            if(n != null){
                    DefaultMutableTreeNode temp = new DefaultMutableTreeNode(n.getData());
                    if(n.hasChild(0)){
                            temp.add(printTree(n.getChildren()[0]));
                    }
                    if(n.hasChild(1)){
                            temp.add(printTree(n.getChildren()[1]));
                    }
                    return temp;
            }
            return null;
    }
    
    
    @Override
    public JTree printTree() {
        DefaultMutableTreeNode rootNode = printTree(root);	
        if(rootNode == null){
                rootNode = new DefaultMutableTreeNode("Empty");
        }
        DefaultTreeModel tm = new DefaultTreeModel(rootNode);
        return new JTree(tm);
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    public Node findUnbalance(Node n){
        while (n.getParent()!=null){
            if (n.getBalanceFactor()>=2||n.getBalanceFactor()<=-2){
                return n;
            }
            n=n.getParent();
        }
        return null;
    }
    
    /////////////////////////////////////////
    
static Node SingleRotateWithLeft(Node k2)     // LL旋转  
{  
    Node k1;  
    k1=k2.getChildren()[0];  
    k2.setChild(k1.getChildren()[1],0,0);  
    k1.setChild(k2,0,1);  
    // 因为比较的是左右孩子的高度，所以求父节点的高度要加1  
    return k1;  
}  
/* 
 *  此函数用于k1只有一个右孩子的单旋转， 
 *  在K1和它的右孩子之间旋转， 
 *  更新高度，返回新的根节点 
 */  
static Node SingleRotateWithRight(Node k1)  // RR旋转  
{  
    Node k2;  
    k2=k1.getChildren()[1];  
    k1.setChild(k2.getChildren()[0],0,1);
    k2.setChild(k1, 0, 0);
     /*结点的位置变了, 要更新结点的高度值*/  
    
    return k2;  
}  
/* 
 * 此函数用于当 如果 k3有一个左孩子，以及 
 * 它的左孩子又有右孩子，执行这个双旋转 
 * 更新高度，返回新的根节点 
 */  
static Node DoubleRotateLeft(Node k3)    // LR旋转  
{  
    //在 k3 的左孩子，执行右侧单旋转  
    k3.setChild(SingleRotateWithRight(k3.getChildren()[0]),0,0);  
    // 再对 k3 进行 左侧单旋转  
    return SingleRotateWithLeft(k3);  
}  
/* 
 * 此函数用于当 如果 k4有一个右孩子，以及 
 * 它的右孩子又有左孩子，执行这个双旋转 
 * 更新高度，返回新的根节点 
 */  
static Node DoubleRotateRight(Node k4)    // RL旋转  
{  
    //在 k4 的右孩子，执行左侧单旋转  
    k4.setChild(SingleRotateWithLeft(k4.getChildren()[1]),0,1);  
    // 再对 k4 进行 右侧单旋转  
    return SingleRotateWithRight(k4);  
}  
    


}
