import java.awt.Frame;

import javax.swing.JFrame;
import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.xml.transform.Templates;


public class AVITree implements IAVLTree {
	private boolean m_unBanlance;
	private boolean m_shorter;
	private Node m_root;
	
	public AVITree() {
		m_unBanlance=false;
		m_root=null;
	}
	
	@Override
	public Node get(int id) {
		// TODO �Զ����ɵķ������
		Node temp=m_root;
		while(temp.getId()!=id){
			if(temp.getId()>id){
				temp=temp.getChildren()[0];
			}else{
				temp=temp.getChildren()[1];
			}
		}
		return temp;
	}

	@Override
	public void insert( Node newNode) {
		// TODO �Զ����ɵķ������
		if(m_root==null){
			m_root=newNode;
			return;
		}
		if(m_root.getId()<newNode.getId()){
			insert(newNode,m_root,1,null);
		}else{
			insert(newNode, m_root, 0,null);
		}
	}

	private void insert(Node newNode,Node parent,int id,Node ancestor){
		if(parent.getChildren()[id]==null){
			parent.setChild(newNode, id);;
			newNode.setParent(parent);
			if(id==0){
				parent.setBF(parent.getBalanceFactor()+1);
			}else{
				parent.setBF(parent.getBalanceFactor()-1);
			}
			m_unBanlance=true;
			return;
		}
		if(parent.getChildren()[id].getId()<newNode.getId()){
			insert(newNode,parent.getChildren()[id],1,parent);
			if(m_unBanlance){
				switch (parent.getBalanceFactor()) {
				case -1:{
					rightRotation(parent,ancestor);
					break;
				}
				case 0:{
					//parent.getChildren()[id].setBF(-1);
					parent.setBF(-1);
					break;
				}
				case 1:{
					parent.getChildren()[id].setBF(0);
					parent.setBF(0);
					m_unBanlance=false;
					break;
				}
				}
			}
		}
		else if(parent.getChildren()[id].getId()>newNode.getId()){
			insert(newNode,parent.getChildren()[id],0,parent);
			if(m_unBanlance){
				switch (parent.getBalanceFactor()) {
				case 1:{
					leftRotation(parent,ancestor);
					break;
				}
				case 0:{
					parent.setBF(1);
					break;
				}
				case -1:{
					parent.setBF(0);
					m_unBanlance=false;
					break;
				}
				}
			}
		}
	}
	
	@Override
	public void delete(int id) {
		// TODO �Զ����ɵķ������
		Node temp=get(id);
		//������������Ϊ��
		if(temp.getChildren()[1]!=null&&temp.getChildren()[0]!=null){
			Node change=temp.getChildren()[1];
			Node parent=temp;
			while(change.getChildren()[0]!=null&&change.getChildren()[1]!=null){
				parent=change;
				change=change.getChildren()[0];
			}
			if(change.getChildren()[0]==null&&change.getChildren()[1]==null){
				temp.setData(change.getData());
				temp.setId(change.getId());
				deleteAndBanlance(parent,change,0);
			}else if(change.getChildren()[0]==null){
				temp.setData(change.getData());
				temp.setId(change.getId());
				change.setData(change.getChildren()[1].getData());
				change.setId(change.getChildren()[1].getId());
				deleteAndBanlance(change,change.getChildren()[1],1);
			}else{
				temp.setData(change.getData());
				temp.setId(change.getId());
				change.setData(change.getChildren()[0].getData());
				change.setId(change.getChildren()[0].getId());
				deleteAndBanlance(change,change.getChildren()[0],0);
			}
		}
		//����������Ϊ��
		else if(temp.getChildren()[1]==null&&temp.getChildren()[0]==null){
			Node p=getParent(temp.getId());
			deleteAndBanlance(p,temp, getID(p,temp));
		}
		//������Ϊ��
		else if(temp.getChildren()[1]==null){
			temp.setData(temp.getChildren()[0].getData());
			temp.setId(temp.getChildren()[0].getId());
			deleteAndBanlance(temp,temp.getChildren()[0],0);
		}
		//������Ϊ��
		else if(temp.getChildren()[0]==null){
			temp.setData(temp.getChildren()[1].getData());
			temp.setId(temp.getChildren()[1].getId());
			deleteAndBanlance(temp,temp.getChildren()[1],1);
		}
		
	}
	//0Ϊ��1Ϊ��
	private int getID(Node parent,Node child){
		return parent.getChildren()[0]==child?0:1;
	}
	
	private void deleteAndBanlance(Node parent,Node node,int id){
		parent.setChild(null, id);
		if(parent.getBalanceFactor()==0){
			parent.setBF(id==0?-1:1);
			return;
		}else{
			//parent.setBF(0);
			m_shorter=true;
		}
		if(parent!=m_root&&m_shorter){
			Node tempParent=getParent(parent.getId());
			while(m_shorter){
				if((parent.getBalanceFactor()==-1&&id==1)
						||(parent.getBalanceFactor()==1&&id==0)){
					parent.setBF(0);
					continue;
				}
				else if(parent.getBalanceFactor()==0){
					parent.setBF(id==0?-1:1);
					m_shorter=false;
				}
				else if(parent.getBalanceFactor()==1&&id==1){
					//��߽ϸ�ʱɾ������
					if(tempParent!=m_root){
						if(parent.getChildren()[0].getBalanceFactor()==0){
							m_shorter=false;
						}
						leftRotation(tempParent, getParent(tempParent.getId()));
					}else{
						leftRotation(tempParent, null);
					}
				}
				else if(parent.getBalanceFactor()==-1&&id==0){
					//�ұ߽ϸ�ʱɾ������
					if(tempParent!=m_root){
						if(parent.getChildren()[1].getBalanceFactor()==0){
							m_shorter=false;
						}
						rightRotation(parent, tempParent);
					}else{
						rightRotation(tempParent, null);
					}
				}
				id=getID(tempParent, parent);
				parent=tempParent;
				if(parent==m_root){
					break;
				}else{
					tempParent=getParent(parent.getId());
				}
			}
		}
		else{
			m_shorter=false;
		}
		m_shorter=false;
	}
	
	private Node getParent(int id){
		Node parent=null;
		Node temp=m_root;
		while(temp.getId()!=id){
			if(temp.getId()>id){
				parent=temp;
				temp=temp.getChildren()[0];
			}else{
				parent=temp;
				temp=temp.getChildren()[1];
			}
		}
		return parent;
	}
	
	//��ɾ��parent�ڵ��id�����Ӳ���change�ڵ��滻
	//private void deleteNode(Node parent,Node change,int id){
	//	if(change.getChildren()[0]==null&&change.getChildren()[1]==null){
	//		parent.setChild(change, id);
	//		if(parent.getBalanceFactor()==0){
	//			m_shorter=false;
	//			parent.setChild(change, id);
	//		}else if(parent.getBalanceFactor()==1&&)
	//	}
	//}

	@Override
	public JTree printTree() {
		// TODO �Զ����ɵķ������
		DefaultMutableTreeNode top=new DefaultMutableTreeNode(String.format("%s,%d", m_root.getData(),m_root.getId()));
		creatJTree(m_root.getChildren()[0],top);
		creatJTree(m_root.getChildren()[1],top);
		JTree tree=new JTree(top);
		JFrame f=new JFrame("��");
		f.add(tree);
		f.setSize(500, 500);
		f.setVisible(true);
		//f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		return tree;
	}

	private void creatJTree(Node node,DefaultMutableTreeNode jnodeParent){
		if(node==null){
			return;
		}
		DefaultMutableTreeNode n=new DefaultMutableTreeNode(String.format("%s,%d", node.getData(),node.getId()));
		jnodeParent.add(n);
		creatJTree(node.getChildren()[0], n);
		creatJTree(node.getChildren()[1], n);
	}
	
	private void leftRotation(Node ancestor,Node ancesParent){
		//node[0]Ϊ����
		Node[]nodes=new Node[2];
		nodes[0]=ancestor.getChildren()[0];
		nodes[1]=ancestor.getChildren()[1];
		//��LL��ת
		if(nodes[0].getBalanceFactor()==1){
			ancestor.setChild(nodes[0].getChildren()[1], 0);
			nodes[0].setChild(ancestor, 1);
			//���ø��ڵ�
			if(ancestor==m_root){
				m_root=nodes[0];
			}
			else if(ancesParent.getChildren()[1]==ancestor){
				ancesParent.setChild(nodes[0], 1);
			}else{
				ancesParent.setChild(nodes[0], 0);
			}
			//�޸�ƽ��ֵ
			ancestor.setBF(0);
			nodes[0].setBF(0);
			m_unBanlance=false;
		}else{
			//��LR��ת
			
			Node[]temp=new Node[2];
			temp[0]=nodes[1].getChildren()[0];
			temp[1]=nodes[1].getChildren()[1];
			
			nodes[0].setChild(temp[1].getChildren()[0], 1);
			ancestor.setChild(temp[1].getChildren()[1], 0);
			temp[1].setChild(nodes[0], 0);
			temp[1].setChild(ancestor, 1);
			//�޸ĸ��ڵ�
			if(ancestor==m_root){
				m_root=temp[1];
			}
			else if(ancesParent.getChildren()[1]==ancestor){
				ancesParent.setChild(temp[0], 1);
			}else{
				ancesParent.setChild(temp[0], 0);
			}
			//�޸�ƽ��ֵ
			switch(temp[1].getBalanceFactor()){
			case -1:{
				nodes[0].setBF(1);
				ancestor.setBF(0);
			}
			case 1:{
				ancestor.setBF(-1);
				nodes[0].setBF(0);
			}
			}
			temp[0].setBF(0);
			m_unBanlance=false;
		}
	}
	private void rightRotation(Node ancestor,Node ancesParent){
		//node[0]Ϊ����
		Node[]nodes=new Node[2];
		nodes[0]=ancestor.getChildren()[0];
		nodes[1]=ancestor.getChildren()[1];
		//��RR��ת
		if(nodes[1].getBalanceFactor()==-1||nodes[1].getBalanceFactor()==0){
			ancestor.setChild(nodes[1].getChildren()[0], 1);
			nodes[1].setChild(ancestor, 0);
			//���ø��ڵ�
			if(ancestor==m_root){
				m_root=nodes[1];
			}
			else if(ancesParent.getChildren()[0]==ancestor){
				ancesParent.setChild(nodes[1], 0);
			}else{
				ancesParent.setChild(nodes[1], 1);
			}
			//�޸�ƽ��ֵ
			ancestor.setBF(0);
			nodes[1].setBF(0);
			m_unBanlance=false;
		}else{
			//��RL��ת
			
			Node[]temp=new Node[2];
			temp[0]=nodes[1].getChildren()[0];
			temp[1]=nodes[1].getChildren()[1];
			
			//nodes[1].setChild(temp[0].getChildren()[1], 0);
			//ancestor.setChild(temp[0].getChildren()[0], 1);
			//temp[0].setChild(nodes[1], 1);
			//temp[0].setChild(ancestor, 0);
			nodes[1].setChild(temp[0].getChildren()[1], 0);
			ancestor.setChild(temp[0].getChildren()[0], 1);
			temp[0].setChild(nodes[1], 1);
			temp[0].setChild(ancestor, 0);

			//�޸ĸ��ڵ�
			if(ancestor==m_root){
				m_root=temp[0];
			}
			else if(ancesParent.getChildren()[0]==ancestor){
				ancesParent.setChild(temp[1], 0);
			}else{
				ancesParent.setChild(temp[1], 1);
			}
			//�޸�ƽ��ֵ
			switch(temp[0].getBalanceFactor()){
			case 1:{
				nodes[1].setBF(-1);
				ancestor.setBF(0);
			}
			case -1:{
				ancestor.setBF(1);
				nodes[1].setBF(0);
			}
			}
			temp[0].setBF(0);
			m_unBanlance=false;
		}
	}
}
