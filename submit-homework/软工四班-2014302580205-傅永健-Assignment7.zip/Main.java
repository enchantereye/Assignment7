import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;


public class Main {
	public static void main(String []args) throws FileNotFoundException{
		AVITree tree=new AVITree();
		File f=new File("tree_data.dat");
		Scanner s=new Scanner(f);
		while(s.hasNextLine()){
			String temp=s.nextLine();
			String [] data=temp.split("#");
			Node n=new Node();
			n.setData(data[0]);
			n.setId(Integer.valueOf(data[1]));
			tree.insert(n);
		}
		Node n=tree.get(5);
		System.out.println(String.format("%s,%d", n.getData(),n.getId()));
		Node newNode=new Node();
		newNode.setData("window");
		newNode.setId(17);
		tree.printTree();
		tree.insert(newNode);
		tree.printTree();
		tree.delete(12);
		tree.printTree();
	}
}
