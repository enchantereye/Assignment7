import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Created by LinLi on 2015/12/31.
 */
public class Main {
    static int id=-1;
    static String data="";
    enum State{
        ADD,
        DELETE,
    }
    static State state=State.ADD;
    static JScrollPane jScrollPane;
    static int counter=1;
    public static void main(String[] args) {
        AVLTree tree = new AVLTree();

            JFrame mainFrame = new JFrame("test");
            JFrame addFrame = new JFrame("operate");


            //create addFrame
            JTextField idField = new JTextField();
            JTextField dataField = new JTextField();
            JButton submit = new JButton("submit");
            JLabel idLabel = new JLabel("id:");
            JLabel dataLable = new JLabel("data:");
            submit.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    id = Integer.parseInt(idField.getText());
                    data = dataField.getText();
                    if (state == State.ADD) {
                        tree.Insert(new Node(data), id);
                    } else if (state == State.DELETE) {
                        tree.Delete(id);
                    }

                    mainFrame.remove(jScrollPane);
                    jScrollPane = new JScrollPane(tree.PrintTree());
                    jScrollPane.setBounds(100, 50, 200, 200);
                    mainFrame.add(jScrollPane);
                    mainFrame.setVisible(true);

                    addFrame.setVisible(false);
                }
            });

            addFrame.setLayout(null);
            idLabel.setBounds(60, 20, 20, 20);
            dataLable.setBounds(60, 60, 50, 20);
            addFrame.add(idLabel);
            addFrame.add(dataLable);
            idField.setBounds(100, 20, 120, 30);
            addFrame.add(idField);
            dataField.setBounds(100, 60, 120, 30);
            addFrame.add(dataField);
            submit.setBounds(120, 100, 80, 30);
            addFrame.add(submit);
            addFrame.setSize(300, 200);
            addFrame.setResizable(false);

            //create mainFrame
            mainFrame.setSize(400, 500);
            mainFrame.setLayout(null);

            jScrollPane = new JScrollPane(tree.PrintTree());
            jScrollPane.setBounds(100, 50, 200, 200);

            JButton addButton = new JButton("add");
            addButton.setBounds(100, 250, 80, 30);
            JButton deleteButton = new JButton("delete");
            deleteButton.setBounds(220,250, 80, 30);

            addButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    state = State.ADD;
                    idField.setText("");
                    dataField.setText("");
                    dataField.setEditable(true);
                    addFrame.setVisible(true);
                }
            });
            deleteButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    state = State.DELETE;
                    idField.setText("");
                    dataField.setText("");
                    dataField.setEditable(false);
                    addFrame.setVisible(true);
                }
            });

            JButton searchButton=new JButton("search");
            JLabel searchLabel=new JLabel("id:");
            JTextField searchTextField=new JTextField();
            JTextArea searchTextArea=new JTextArea();
            searchTextArea.setRows(2);
            searchTextArea.setColumns(20);

            searchButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    int i=Integer.parseInt(searchTextField.getText());
                    searchTextArea.setText("data:"+tree.Get(i).getData()+"\nid:"+tree.Get(i).getId());
                }
            });

            searchLabel.setBounds(100,300,50,30);
            searchTextField.setBounds(120,300,100,25);
            searchButton.setBounds(220,296,80,30);
            searchTextArea.setBounds(100,345,200,50);

            mainFrame.add(searchLabel);
            mainFrame.add(searchButton);
            mainFrame.add(searchTextField);
            mainFrame.add(searchTextArea);
            mainFrame.add(addButton);
            mainFrame.add(deleteButton);
            mainFrame.add(jScrollPane);

            mainFrame.setVisible(true);
            mainFrame.setResizable(false);
            mainFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
    }
}

