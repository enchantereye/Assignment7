/**
 * Created by LinLi on 2015/12/15.
 */

public class Node {
    private int id;
    private Object data;
    private Node parent;
    private Node leftChildren;
    private Node rightChildren;
    private int lSubTreeHeight;
    private int rSubTreeHeight;
    private int balanceFactor;
    private int height;

    public Node(String n)
    {
        User user=new User(n);
        data=user;
        height=1;
        leftChildren=null;
        rightChildren=null;
        parent=null;
        id=-1;
    }

    public void setId(int id){this.id=id;}
    public int getId() {
        return id;
    }
    public Object getData() {
        return data;
    }
    public void setData(Object data) {
        this.data = data;
    }
    public Node getParent() {
        return parent;
    }
    public void setParent(Node parent) {
        this.parent = parent;
    }
    public Node getLeftChildren() {
        return leftChildren;
    }
    public void setLeftChildren(Node children) {
        this.leftChildren = children;
    }
    public Node getRightChildren() {
        return rightChildren;
    }
    public void setRightChildren(Node children) {
        this.rightChildren = children;
    }
    public int getHeight(){
        return height;
    }

    public void setHeight(int n){height=n;}

    //public int Max(int a,int b)
    //{
      //  return a>b?a:b;
    //}

    public int getlSubTreeHeight() {
        //TODO calculate the left sub tree height
        if(leftChildren==null)
        {
            lSubTreeHeight=0;
        }else{
            lSubTreeHeight= 1+getlSubTreeHeight();
        }
        return lSubTreeHeight;
    }
    public int getrSubTreeHeight() {
        //TODO calculate the right sub tree height
        if(rightChildren==null)
        {
            rSubTreeHeight=0;
        }else {
            rSubTreeHeight=1+getrSubTreeHeight();
        }
        return rSubTreeHeight;
    }
    //��ʵ��û���õ����������
    public int getBalanceFactor() {
        //TODO calculate the balance factor
        return balanceFactor;
    }
}

class User
{
    private String name;
    public User(String n)
    {
        name=n;
    }
    public String getName()
    {
        return name;
    }

    public void setName(String n)
    {
        name=n;
    }

    public String toString()
    {
        return name;
    }
}
