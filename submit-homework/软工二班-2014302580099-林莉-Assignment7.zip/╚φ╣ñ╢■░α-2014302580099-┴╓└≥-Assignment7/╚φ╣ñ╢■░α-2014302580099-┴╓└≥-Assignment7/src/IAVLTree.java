import javax.swing.*;

/**
 * Created by LinLi on 2015/12/15.
 */
public interface IAVLTree {
    Node Get(int id);
    void Insert(Node newNode,int id);
    void Delete(int id);
    JTree PrintTree();
}
