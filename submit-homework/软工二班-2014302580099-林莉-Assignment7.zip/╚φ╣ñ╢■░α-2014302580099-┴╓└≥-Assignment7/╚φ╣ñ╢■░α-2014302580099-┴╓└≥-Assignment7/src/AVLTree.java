import javax.swing.*;
import javax.swing.tree.DefaultMutableTreeNode;

/**
 * Created by LinLi on 2015/12/15.
 */
public class AVLTree implements IAVLTree {

    private Node root=null;
    private int size=0;

    public int GetSize()
    {
        return size;
    }

    //LL
    private Node SingRotateLeft(Node node)
    {
        Node leftNode=node.getLeftChildren();
        node.setLeftChildren(leftNode.getRightChildren());
        if(leftNode.getRightChildren()!=null) {
            leftNode.getRightChildren().setParent(node);
        }
        leftNode.setRightChildren(node);
        node.setParent(leftNode);
        //node.setHeight(Max(node.getLeftChildren().getHeight(),node.getRightChildren().getHeight()));
        if(node.getLeftChildren()!=null&&node.getRightChildren()!=null) {
            node.setHeight(Max(node.getLeftChildren().getHeight() + 1, node.getRightChildren().getHeight() + 1));
        }else if(node.getLeftChildren()!=null)
        {
            node.setHeight(node.getLeftChildren().getHeight()+1);
        }
        else if(node.getRightChildren()!=null){
            node.setHeight(node.getRightChildren().getHeight()+1);
        }else{
            node.setHeight(1);
        }
        //leftNode.setHeight(Max(leftNode.getLeftChildren().getHeight(),node.getHeight()));
        if(leftNode.getLeftChildren()!=null&&leftNode.getRightChildren()!=null) {
            leftNode.setHeight(Max(leftNode.getLeftChildren().getHeight() + 1, leftNode.getRightChildren().getHeight() + 1));
        }else if(leftNode.getLeftChildren()!=null)
        {
            leftNode.setHeight(leftNode.getLeftChildren().getHeight()+1);
        }
        else if(leftNode.getRightChildren()!=null){
            leftNode.setHeight(leftNode.getRightChildren().getHeight()+1);
        }else{
            leftNode.setHeight(1);
        }

        leftNode.setParent(null);
        return leftNode;
    }

    //RR
    private Node SingRotateRight(Node node)
    {
        Node rightNode=node.getRightChildren();
        node.setRightChildren(rightNode.getLeftChildren());
        if(rightNode.getLeftChildren()!=null) {
            rightNode.getLeftChildren().setParent(node);
        }
        rightNode.setLeftChildren(node);
        node.setParent(rightNode);
        //node.setHeight(Max(node.getLeftChildren().getHeight()+1,node.getRightChildren().getHeight()+1));
        if(node.getLeftChildren()!=null&&node.getRightChildren()!=null) {
            node.setHeight(Max(node.getLeftChildren().getHeight() + 1, node.getRightChildren().getHeight() + 1));
        }else if(node.getLeftChildren()!=null)
        {
            node.setHeight(node.getLeftChildren().getHeight()+1);
        }
        else if(node.getRightChildren()!=null){
            node.setHeight(node.getRightChildren().getHeight()+ 1);
        }else{
            node.setHeight(1);
        }
        //rightNode.setHeight(Max(rightNode.getRightChildren().getHeight(),node.getHeight()));
        if(rightNode.getLeftChildren()!=null&&rightNode.getRightChildren()!=null) {
            rightNode.setHeight(Max(rightNode.getLeftChildren().getHeight()+1, rightNode.getRightChildren().getHeight()+1));
        }else if(rightNode.getLeftChildren()!=null)
        {
            rightNode.setHeight(rightNode.getLeftChildren().getHeight()+1);
        }
        else if(rightNode.getRightChildren()!=null){
            rightNode.setHeight(node.getRightChildren().getHeight()+1);
        }else{
            rightNode.setHeight(1);
        }
        rightNode.setParent(null);
        return rightNode;
    }


    //LR
    private Node DoubleRotateLR(Node node)
    {
        Node leftNode = node.getLeftChildren();
        leftNode=SingRotateRight(leftNode);
        int i=leftNode.getId();
        node.setLeftChildren(leftNode);
        leftNode.setParent(node);
        return SingRotateLeft(node);
    }

    //RL
    private Node DoubleRotateRL(Node node)
    {
        Node rightNode=node.getRightChildren();
        rightNode=SingRotateLeft(rightNode);
        node.setRightChildren(rightNode);
        rightNode.setParent(node);
        return SingRotateRight(node);
    }

    public AVLTree()
    {
        root=null;
    }

    public void MakeEmpty()
    {
        root=null;
    }

    public boolean IsEmpty()
    {
        return root==null;
    }

    public Node Get(int id){
        return Get(id,root);
    }

    /*循环
    public Node get(int id) {
    for (Node node = root; node!=null&&node.getId()!=id; ) {
        if (node.getId() < id) {
            node = node.getRChild();
        }
        if (node.getId() > id) {
            node = node.getLChild();
        }
    }
    return node;
}
     */

    private Node Get(int id,Node node)
    {
        if(node==null)
        {
            return null;
        }else {
            if (id < node.getId()) {
                return Get(id, node.getLeftChildren());
            } else if (id > node.getId()) {
                return Get(id, node.getRightChildren());
            } else {
                return node;
            }
        }
    }

    public void Insert(Node newNode,int id){
        newNode.setId(id);
        if(root==null)
        {
            root=newNode;
        }
        else{
            root=Insert(newNode,id,root);
        }
    }
    private Node Insert(Node newNode,int id,Node rootNode)
    {
        if(rootNode==null)
        {
            rootNode=newNode;
        }else {
            if (id < rootNode.getId()) {
                newNode.setParent(rootNode);
                rootNode.setLeftChildren(Insert(newNode, id, rootNode.getLeftChildren()));

                int i=rootNode.getId();
                int j=newNode.getId();
                int h;
                if(rootNode.getLeftChildren()!=null&&rootNode.getRightChildren()!=null) {
                    h = rootNode.getLeftChildren().getHeight() - rootNode.getRightChildren().getHeight();
                }else if(rootNode.getLeftChildren()!=null)
                {
                    //String n=rootNode.getLeftChildren().getData().toString();
                    h=rootNode.getLeftChildren().getHeight();
                }else if(rootNode.getRightChildren()!=null)
                {
                    h=rootNode.getRightChildren().getHeight();
                }else{
                    h=0;
                }
                if (h == 2) {
                    if (id < rootNode.getLeftChildren().getId()) {
                        rootNode = SingRotateLeft(rootNode);//LL
                        //String s=rootNode.getData().toString();
                        //System.out.println(s);
                    } else {
                        rootNode = DoubleRotateLR(rootNode);//LR
                        //String s=rootNode.getData().toString();
                        //System.out.print(s);
                    }
                } else if (h == -2) {
                    if (id > rootNode.getLeftChildren().getId()) {
                        rootNode = SingRotateRight(rootNode);//RR
                        //String s=rootNode.getData().toString();
                    } else {
                        rootNode = DoubleRotateRL(rootNode);//RL
                        //String s=rootNode.getData().toString();
                    }
                }
            } else if (id > rootNode.getId()) {
                newNode.setParent(rootNode);
                rootNode.setRightChildren(Insert(newNode, id, rootNode.getRightChildren()));
                int h;
                if(rootNode.getLeftChildren()!=null&&rootNode.getRightChildren()!=null) {
                    h = rootNode.getLeftChildren().getHeight() - rootNode.getRightChildren().getHeight();
                }else if(rootNode.getLeftChildren()!=null)
                {
                    h=rootNode.getLeftChildren().getHeight();
                }else if(rootNode.getRightChildren()!=null)
                {
                    h=-rootNode.getRightChildren().getHeight();
                }else{
                    h=0;
                }
                if (h == 2) {
                    if (id < rootNode.getLeftChildren().getId()) {
                        rootNode = SingRotateLeft(rootNode);//LL
                    } else {
                        rootNode = DoubleRotateLR(rootNode);//LR
                    }
                } else if (h == -2) {
                    if (id > rootNode.getRightChildren().getId()) {
                        rootNode = SingRotateRight(rootNode);//RR
                    } else {
                        rootNode = DoubleRotateRL(rootNode);//RL
                    }
                }
            }
        }
        //newNode.setParent(rootNode);
        if(rootNode.getLeftChildren()!=null&&rootNode.getRightChildren()!=null) {
            rootNode.setHeight(Max(rootNode.getLeftChildren().getHeight()+1, rootNode.getRightChildren().getHeight()+1));
        }else if(rootNode.getLeftChildren()!=null)
        {
            rootNode.setHeight(rootNode.getLeftChildren().getHeight()+1);
        }
        else if(rootNode.getRightChildren()!=null){
            rootNode.setHeight(rootNode.getRightChildren().getHeight()+1);
        }else{
            rootNode.setHeight(1);
        }

        return rootNode;
    }

    public void Delete(int id){

        Node current=Get(id);
        Node parent=current.getParent();
        if(current==null)
        {
            System.out.println("no exist");
        }
        else{
            boolean isLeftChild=true;

            if(parent!=null) {
                if (current.getId() < parent.getId()) {
                    isLeftChild = true;
                } else {
                    isLeftChild = false;
                }
            }


            if(current.getLeftChildren()==null&&current.getRightChildren()==null)
            {
                if(current.getId()==root.getId())
                {
                    root=null;
                }
                if(parent!=null) {
                    if (current.getId() < parent.getId()) {
                        parent.setLeftChildren(null);
                    } else {
                        parent.setRightChildren(null);
                    }
                }
            }


            else if(current.getLeftChildren()==null)
            {
                if(current==root)
                {
                    root=current.getRightChildren();
                }else if(isLeftChild==true)
                {
                    parent.setLeftChildren(current.getRightChildren());
                }else{
                    parent.setRightChildren(current.getRightChildren());
                }
            }
            else if(current.getRightChildren()==null)//???????
            {
                if(current==root)
                {
                    root=current.getLeftChildren();
                }else if(isLeftChild)
                {
                    parent.setLeftChildren(current.getLeftChildren());
                }else{
                    parent.setRightChildren(current.getLeftChildren());
                }
            }


            else{
                Node successor=FindDirectSuccessor(current);
                //int a=current.getId();
                int d=root.getId();
                if(current.getId()==root.getId())
                {
                    root=successor;
                }else if(isLeftChild)
                {
                    parent.setLeftChildren(successor);
                }else
                {
                    parent.setRightChildren(successor);
                }
                successor.setLeftChildren(current.getLeftChildren());
            }

        }
    }


    private Node FindDirectSuccessor(Node node)
    {
        Node current=node.getRightChildren();
        Node successor=node;

        while(current!=null)
        {
            successor=current;
            current=current.getLeftChildren();
        }


        if(successor!=node.getRightChildren())
        {
            successor.getParent().setLeftChildren(successor.getRightChildren());
            successor.setRightChildren(node.getRightChildren());
        }

        return successor;
    }


   /* public void PrintTree()
    {
        PrintTree(root);
    }

    public void PrintTree(Node node)
    {
        if(node!=null)
        {
            int n=node.getId();
            PrintTree(node.getLeftChildren());
            System.out.print(node.getData().toString()+" ");
            PrintTree(node.getRightChildren());
        }
    }*/


    public int Max(int a,int b)
    {
        return a>b?a:b;
    }

    public Node getRoot()
    {
        return root;
    }

    public JTree PrintTree(){
        JTree jTree=new JTree(PrintTree(root));
        jTree.updateUI();
        return jTree;
    }

    public DefaultMutableTreeNode PrintTree(Node node) {
        if (root != null) {
            DefaultMutableTreeNode treeNode = new DefaultMutableTreeNode(node.getData().toString());
            if (node.getLeftChildren() != null) {
                DefaultMutableTreeNode leftNode = PrintTree(node.getLeftChildren());
                treeNode.add(leftNode);
            }
            if (node.getRightChildren() != null) {
                DefaultMutableTreeNode rightNode = PrintTree(node.getRightChildren());
                treeNode.add(rightNode);
            }
            return treeNode;
        }
        return null;
    }
}
