import java.io.IOException;
import java.util.Scanner;

import javax.swing.JFrame;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.tree.DefaultMutableTreeNode;


public class HaveATry {
	private Scanner input; 
	public static void main(String[] args) throws IOException {
		// TODO �Զ����ɵķ������
		AVLTree test=new AVLTree();
		///*
		Node put;
		String data="";
	for(int i=1;i<18;i++){
		put=new Node(i);
		switch(i){
		case 1:data="ant";break;
		case 2:data="apple";break;
		case 3:data="art";break;
		case 4:data="baby";break;
		case 5:data="banana";break;
		case 6:data="car";break;
		case 7:data="door";break;
		case 8:data="dress";break;
		case 9:data="frog";break;
		case 10:data="love";break;
		case 11:data="mint";break;
		case 12:data="rice";break;
		case 13:data="show";break;
		case 14:data="table";break;
		case 15:data="tree";break;
		case 16:data="trouble";break;
		case 17:data="window";break;
		default:break;
		}
		put.setData(data);
		test.insert(put.getId(),put);
	}
		int find=9;
		System.out.println("id: "+find);
		System.out.println("data: "+test.get(find).getData());
		System.out.println("lSubTreeHeight: "+test.get(find).getlSubTreeHeight());
		System.out.println("rSubTreeHeight: "+test.get(find).getrSubTreeHeight());
		System.out.println("getBalanceFactor: "+test.get(find).getBalanceFactor());
		System.out.println("lSubTreeHeight: "+test.get(find).getlSubTreeHeight());
		System.out.println("parent's id: "+test.get(find).getParent().getId());
		System.out.println("child0's id: "+test.get(find).getChildren()[0].getId());
		System.out.println("child1's id: "+test.get(find).getChildren()[1].getId());
		
	   test.delete(4);
	   test.delete(6);
	   test.delete(13);
	   test.delete(17);
		
		
		
		
		 JFrame f = new JFrame("JTreeDemo");
		    f.setBounds(400, 100, 500, 500);
	        f.setSize(600, 600);
	        f.add(test.printTree());
	        
	        f.setVisible(true);
	        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	        test.printTree().addTreeSelectionListener(new TreeSelectionListener() {
	        	 
	            @Override
	            public void valueChanged(TreeSelectionEvent e) {
	                DefaultMutableTreeNode node = (DefaultMutableTreeNode) test.printTree()
	                        .getLastSelectedPathComponent();
	                if (node == null)
	                    return;
	                Object object = node.getUserObject();
	 
	            }
	        });
	        
	}

}
