

import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;


public class AVLTree implements IAVLTree {
    private Node root=new Node(-1);
    private Node spinning(Node p,int top) {
 
    	Node q ,u,t,noi;
		Node a,b,c,d;//ep.left
		boolean next=true;
    	while(next==true){
			if(p.getParent().getId()==top)return p;
			q=p.getParent();
			if(p.getId()<q.getId())	q.setChild(p,0);
			else q.setChild(p, 1);
				if(q.getBalanceFactor()*q.getBalanceFactor()==4){
					int tc = 0;
					switch(q.getBalanceFactor()){case 2:tc=1;break;case -2:tc=0;break;}
					switch(p.getBalanceFactor()*q.getBalanceFactor()){
                   case 2:
                   case 0:
						b=p.getChildren()[tc];
						b.setParent(q);
						t=q.getParent();
						q.setChild(b, 1-tc);
						q.setParent(p);
						p.setChild(q, tc);
						p.setParent(t);
						p.getParent().setChild(p, 1-tc);;						
						break;
					case -2:
						t=q.getParent();
						u=p.getChildren()[tc];
						b=u.getChildren()[1-tc];
						b.setParent(p);
						c=u.getChildren()[tc];
						c.setParent(q);
						p.setChild(b, tc);
						p.setParent(u);
						q.setChild(c, 1-tc);
						q.setParent(u);
						u.setChild(p, 1-tc);
						u.setChild(q, tc);
						u.setParent(t);
						p=u;
						break;
					
						default:System.out.println("Not spinning");break;
					}
				}
				else p=q;
		
				
			
			}
		return p;
    }
	@Override
	public Node get(int id) {
		// TODO �Զ����ɵķ������
		Node p;
		boolean next=true;
		if(root.getId()<0)return new Node(-1);
		if(id==root.getId()){return root;}
		if(root.getChildren()[0].getId()==root.getChildren()[1].getId())next=false;
        p=root;
		while(next==true){
        if(id==p.getId()){return p;}
        if(id<p.getId())p=p.getChildren()[0];
        else p=p.getChildren()[1];
        if(p.getId()<0)next=false;
        else if(p.getChildren()[0].getId()==p.getChildren()[1].getId())next=false;        
		}
		if(id==p.getId())return p;
		return new Node(-1);
	}
    public AVLTree(){root.setParent(new Node(-1));}
	@Override
	public void insert(int id, Node newNode) {
		// TODO �Զ����ɵķ������
		Node p,q ,u,t,inewNode;
	//	Node a,b,c,d;
		boolean next=true;
		inewNode=newNode;
		inewNode.setChild(new Node(-1),0);
		inewNode.setChild(new Node(-1),1);
		inewNode.setParent(new Node(-1));
		if(root.getId()<0){inewNode.setParent(root.getParent());root=inewNode;return;}
		if(id==get(id).getId()){
			System.out.println("the id is occupied");
			return ;
			}
		if(root.getChildren()[0].getId()==root.getChildren()[1].getId()){
		inewNode.setParent(root);
		if(id<root.getId())root.setChild(inewNode, 0);
		else root.setChild(inewNode, 1);
		return;
		}
        p=root;
        q=p.getParent();
        //search insert point
		while(next==true){
			if(p.getId()<0)break;
        if(p.getChildren()[0].getId()==p.getChildren()[1].getId())break;
        q=p;
        if(id<p.getId())p=p.getChildren()[0];
        else p=p.getChildren()[1];  
        if(p == null)p=new Node(-1);
        p.setParent(q);
		}
		if(p.getId()<0)p=inewNode;
		else if(id<p.getId()){q=p;p=p.getChildren()[0];p=inewNode;}
		      else {q=p;p=p.getChildren()[1];p=inewNode;}
		p.setParent(q);
		next=true;
		//insert 
		root=spinning(p,root.getParent().getId());
		
	}

	@Override
	public void delete(int id) {
		
		// TODO �Զ����ɵķ������
		if(root.getId()<0)return;
		Node p,q,t,ni;
		int tc,exc;
		boolean next=true;
		p=get(id);
		if(p.getId()!=id) return;
		if(root.getChildren()[0].getId()==root.getChildren()[1].getId()){root=new Node(-1);return;}

	//exchange
		t=p;
		if(p.getChildren()[0].getId()!=p.getChildren()[1].getId()){
		if(p.getBalanceFactor()==1)tc=0;
		else tc=1;
		p=p.getChildren()[tc];
		while(p.getChildren()[1-tc].getId()>0)
			p=p.getChildren()[1-tc];
		t=p;
		p.getChildren()[tc].setParent(p.getParent());
		p=p.getChildren()[tc];
		if(p.getParent().getChildren()[0].getId()==t.getId())
		p.getParent().setChild(p,0);
		else p.getParent().setChild(p,1);
		}
		else {p.getChildren()[0].setParent(p.getParent());p=p.getChildren()[0];
		if(p.getParent().getChildren()[0].getId()==t.getId())
			p.getParent().setChild(p,0);
			else p.getParent().setChild(p,1);
		}
		ni=new Node(-1);
		//rebuild
		while(next==true){
			if(p.getParent().getId()==-1){root=p;break;}
			if(p.getId()==p.getParent().getChildren()[0].getId()||id==p.getParent().getChildren()[0].getId()){q=p.getParent();q.setChild(p, 0);}
			else{q=p.getParent();q.setChild(p, 1);}
			if(q.getId()==id){
				t.setParent(q.getParent());t.setChildren(q.getChildren());t.setData(q.getData());
				t.getChildren()[0].setParent(t);
				t.getChildren()[1].setParent(t);
				q=t;
				p.setParent(q);
			}
			
			if(q.getBalanceFactor()*q.getBalanceFactor()==4){
				if(p.getId()==q.getChildren()[0].getId())tc=0;
				else tc=1;
				p=q.getChildren()[1-tc];
				q= spinning(p,q.getParent().getId());
			}
			
			p=q;
		}
	

		
	}

	private void  doprintTree(DefaultMutableTreeNode top,Node p){
		if(p.getChildren()[0]==p.getChildren()[1])return;
		if(p.getChildren()[0].getId()>0){
		   DefaultMutableTreeNode child0 =     new DefaultMutableTreeNode(p.getChildren()[0]);
		   top.add(child0);
		   doprintTree(child0,p.getChildren()[0]);
		   }
		if(p.getChildren()[1].getId()>0){
			DefaultMutableTreeNode child1 =     new DefaultMutableTreeNode(p.getChildren()[1]);
			top.add(child1);
			doprintTree(child1,p.getChildren()[1]);
			}
	} 
	
	@Override
	public JTree printTree() {
		// TODO �Զ����ɵķ������
		Node p=root;
		DefaultMutableTreeNode top =     new DefaultMutableTreeNode(p);   
		if(p.getId()<0)return new JTree(top);
		doprintTree( top, p);  
		
		return new JTree(top);
	}

}
