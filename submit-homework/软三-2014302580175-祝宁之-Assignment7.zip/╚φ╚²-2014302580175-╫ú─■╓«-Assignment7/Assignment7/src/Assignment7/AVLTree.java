package Assignment7;

import javax.swing.JTree;
import javax.swing.JFrame;
import javax.swing.tree.DefaultMutableTreeNode;


public class AVLTree implements IAVLTree {
	Node root;
	AVLTree(){root=null;}

	public void insert(int id, Node newNode){
		boolean b=true;
		Node temp;
		Node tparent;
		temp=root;
		if(temp==null){
			newNode.setParent(null);
			root=newNode;
			temp=root;}
		else {
			do{
				tparent=temp;
			if (id<temp.getId())
			{temp=temp.getChildren()[0];}
			else if(id>temp.getId())
			{temp=temp.getChildren()[1];}
			else{b=false; temp=null;}
			}while (temp!=null);
			
			
	if(b==true){
			newNode.setParent(tparent);
			if (id<tparent.getId())
			{tparent.setChild(newNode, 0);}
			else
			{tparent.setChild(newNode, 1);}
			
			
			while(tparent!=null)
			{  
	             if(id< tparent.getId()){    
	                tparent.balanceFactor++;  
	                }else{          
	                tparent.balanceFactor--;  
	           }  
	           if(tparent.balanceFactor == 0){    
	               break;  
	           }  
	           if(tparent.balanceFactor == 2){  
	        	   LRotation(tparent);  
	                break;                 
	           }  
	           if(tparent.balanceFactor ==-2){  
	        	   RRotation(tparent);  
	                break;                 
	           }  
	           tparent = tparent.getParent();  
	        } 
	                 }
			
  } 
			
    }

	private void LRotation(Node s){
	    Node u;
		Node r=s.getChildren()[0];
		if(r.balanceFactor==1){
			s.setChild(r.getChildren()[1], 0);
			r.setChild(s, 1);
			s.balanceFactor=0;s=r;
		}
		else {
			u=r.getChildren()[1];r.setChild(u.getChildren()[0],1);
			u.setChild(r,0);s.setChild(u.getChildren()[1],0);
			u.setChild(s,1);
			switch(u.balanceFactor){
			case 1:s.balanceFactor=-1;r.balanceFactor=0;break;
			case 0:s.balanceFactor=r.balanceFactor=0;break;
			case -1:s.balanceFactor=0;r.balanceFactor=1;
			}
			s=u;
		}
      s.balanceFactor=0;

	}
	
	private void RRotation(Node s){
		Node u;
		Node r=s.getChildren()[1];
		if(r.balanceFactor==-1){
			s.setChild(r.getChildren()[0], 1);
			r.setChild(s, 0);
			s.balanceFactor=0;s=r;
		}
		else {
			u=r.getChildren()[0];r.setChild(u.getChildren()[1],0);
			u.setChild(r,1);s.setChild(u.getChildren()[0],1);
			u.setChild(s,0);
			switch(u.balanceFactor){
			case 1:s.balanceFactor=0;r.balanceFactor=1;break;
			case 0:s.balanceFactor=r.balanceFactor=0;break;
			case -1:s.balanceFactor=1;r.balanceFactor=0;
			}
			s=u;
		}
      s.balanceFactor=0;
	}
	
	public Node get(int id) {
		Node first = root;    
	    while (first != null) {    
	      if (id == first.getId()) {    
	        return first;    
	    } else if (id<first.getId()) {    
	        first = first.getChildren()[0];    
	    } else {    
	        first = first.getChildren()[1];    
	    }    
	}    
	     return null;
		
	}
	
  public  void delete(int id){}
	

public JTree printTree() {
	JTree tree = new JTree(createNode(root));
    JFrame frame = new JFrame("JTreeDemo");
    frame.add(tree);
    frame.setSize(300, 300);
    frame.setVisible(true);
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	return null;
} 
private DefaultMutableTreeNode createNode(Node root){
	DefaultMutableTreeNode node = new DefaultMutableTreeNode(root.getData());
	if(root.getChildren()[0]!=null)
		node.add(createNode(root.getChildren()[0]));
	if(root.getChildren()[1]!=null)
		node.add(createNode(root.getChildren()[1]));
	
	return node;
}


public static void main(String[] args) {
	AVLTree myTree = new AVLTree();
	Node node = new Node("1");
	Node node1 = new Node("2");

	myTree.insert(1,node);
	myTree.insert(2,node1);

	myTree.printTree();
}

}
