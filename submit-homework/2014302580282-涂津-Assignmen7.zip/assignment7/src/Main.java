
import javax.swing.JFrame;
import javax.swing.JTree;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.tree.DefaultMutableTreeNode;

public class Main {
    public static void main(String[] args) {

        // 创建没有父节点和子节点、但允许有子节点的树节点，并使用指定的用户对象对它进行初始化。
        // public DefaultMutableTreeNode(Object userObject)
        DefaultMutableTreeNode node1 = new DefaultMutableTreeNode("ant");
        node1.add(new DefaultMutableTreeNode(new Data("apple")));
        node1.add(new DefaultMutableTreeNode(new Data("art")));
        node1.add(new DefaultMutableTreeNode(new Data("baby")));
        node1.add(new DefaultMutableTreeNode(new Data("table")));
        node1.add(new DefaultMutableTreeNode(new Data("tree")));
        node1.add(new DefaultMutableTreeNode(new Data("trouble")));
        node1.add(new DefaultMutableTreeNode(new Data("window")));

        DefaultMutableTreeNode node2 = new DefaultMutableTreeNode("banan");
        node2.add(new DefaultMutableTreeNode(new Data("car")));
        node2.add(new DefaultMutableTreeNode(new Data("door")));
        node2.add(new DefaultMutableTreeNode(new Data("dress")));
        node2.add(new DefaultMutableTreeNode(new Data("mint")));
        node2.add(new DefaultMutableTreeNode(new Data("rice")));
        node2.add(new DefaultMutableTreeNode(new Data("show")));

        DefaultMutableTreeNode top = new DefaultMutableTreeNode("frog");

        top.add(new DefaultMutableTreeNode(new Data("love")));
        top.add(node1);
        top.add(node2);
        final JTree tree = new JTree(top);
        JFrame f = new JFrame("Assignment7");
        f.add(tree);
        f.setSize(300, 300);
        f.setVisible(true);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        // 添加选择事件
        tree.addTreeSelectionListener(new TreeSelectionListener() {

            @Override
            public void valueChanged(TreeSelectionEvent e) {
                DefaultMutableTreeNode node = (DefaultMutableTreeNode) tree
                        .getLastSelectedPathComponent();

                if (node == null)
                    return;

                Object object = node.getUserObject();
                if (node.isLeaf()) {
                    Data data = (Data) object;
                    System.out.println("你选择了：" + data.toString());
                }

            }
        });
    }
}

class Data {
    private String name;

    public Data(String n) {
        name = n;
    }

    // 重点在toString，节点的显示文本就是toString
    public String toString() {
        return name;
    }
}