import javax.swing.*;

public class AVLTree implements IAVLTree {
    @Override
    public Node get(int id) {
        Node temp = root;
        while (temp != null)
        {
            if (temp.getId() == id)
            {
                return temp;
            }
            else if (temp.getId() > id)
            {
                temp = temp.getLChild();
            }
            else
            {
                temp = temp.getRChild();
            }
        }
        return null;
    }

    public class Roate {
        public void roate(int[] arrays, int lenght) {
            if (null == arrays || lenght < 1) {
                System.out.println("input error!");
                return;
            }
            roate(arrays, 0, lenght - 1);
        }

        public void roate(int[] arrays, int start, int end) {
            if(start>=end){
                return;
            }

            int i = start;
            int j = end;
            int value = arrays[i];
            boolean flag = true;
            while (i != j) {
                if (flag) {
                    if (value > arrays[j]) {
                        swap(arrays, i, j);
                        flag=false;

                    } else {
                        j--;
                    }
                }else{
                    if(value<arrays[i]){
                        swap(arrays, i, j);
                        flag=true;
                    }else{
                        i++;
                    }
                }
            }
            snp(arrays);
            roate(arrays, start, j-1);
            roate(arrays, i+1, end);

        }

        public void snp(int[] arrays) {
            for (int i = 0; i < arrays.length; i++) {
                System.out.print(arrays[i] + " ");
            }
            System.out.println();
        }

        private void swap(int[] arrays, int i, int j) {
            int temp;
            temp = arrays[i];
            arrays[i] = arrays[j];
            arrays[j] = temp;
        }
    }
    @Override
    public void insert(int id, Node newNode)
    {
        if(root == null)
        {
            root = newNode;
        }
    }

    @Override
    public void delete(int id) {
        Node temp = get(id);
        if(temp==root)
        {
            if(root.getChildren()[0] != temp)
            {
                root=root.getChildren()[0];
            }
            else if(root.getChildren()[1]!=null)
            {
                root.getChildren()[1].setParent(null);
                root=root.getChildren()[1];
            }

        }
    }

    @Override
    public JTree printTree() {
        return null;
    }

    private Node root;

}
