package cheny;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JTree;

public class JTreeGUI extends JFrame{	
	JButton operate;
	JFrame list;
	AVLTree tree;
	public void display(){
		JTree jf=new JTree();
		jf=tree.printTree();
		jf.setBounds(0, 0, 200, 400);
		list=new JFrame("AVLTree");
	    list.setSize(200, 500);
		list.setVisible(true);
		list.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		list.setLayout(null);
		list.add(jf);
		operate=new JButton("����");
		operate.setBounds(0, 410, 70, 30);
		operate.addActionListener(new myAction());
		list.add(operate);
		list.setVisible(true);
	}
	class myAction implements ActionListener{
		public void actionPerformed(ActionEvent e) {
				GUI gui=new GUI();
				gui.tree=tree;
				list.setVisible(false);
				gui.display();
				gui.setVisible(true);
				
			}
		};

}
	
