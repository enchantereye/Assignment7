package cheny;
//���ڵ�
class Node< T>{
    Node(){};
    Node( T data ,int id)
    {
        this( data, id,null );
    }
    Node( T datas, int idd,Node< T> par )
    {
        data  = datas;
        id=idd;
        parent   = par;
        balance  = 0;
    }
	//�ڵ��е�����
    T     data;   //�ڵ�����
    int id;//�ڵ�ID
    Node< T>  parent;  
	Node< T>  lchild;         // ����
    Node< T>  rchild;        // �Һ���
    int    balance;       // �ڵ��ƽ������
    public int getBalance() {
		return balance;
	}
	public void setBalance(int balance) {
		this.balance = balance;
	}
	public T getData() {
		return data;
	}
	public void setData(T data) {
		this.data = data;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
    public Node<T> getLchild() {
			return lchild;
		}
	public void setLchild(Node<T> lchild) {
			this.lchild = lchild;
		}
	public Node<T> getRchild() {
			return rchild;
		}
	public void setRchild(Node<T> rchild) {
			this.rchild = rchild;
		}
	public Node<T> getParent() {
		return parent;
	}
	public void setParent(Node<T> parent) {
		this.parent = parent;
	}

}
 