package cheny;
import java.awt.event.ActionEvent;
	import java.awt.event.ActionListener;
	import javax.swing.JButton;
import javax.swing.JFrame;
	import javax.swing.JLabel;
	import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JTree;
public class GUI extends JFrame{
	//��������Ҫ�Ŀؼ�
	JFrame list=new JFrame();
    JButton insert=new JButton("����");
	JButton search=new JButton("��ѯ");
	JButton delete=new JButton("ɾ��");
    JButton show=new JButton("��ʾ");
    JLabel  ids=new JLabel("id:");
    JLabel  datas=new JLabel("����:");
	JTextField id=new JTextField();
	JTextField data=new JTextField();
	JTextArea view;
	AVLTree<String> tree;

	void display(){	
	    list.setDefaultCloseOperation(EXIT_ON_CLOSE);
		list.setBounds(100,100,300,500);
		list.setLayout(null);
		
		ids.setBounds(10, 10, 50, 20);
		list.add(ids);
		datas.setBounds(10, 40, 50, 20);
		list.add(datas);
		
		id.setBounds(120, 10, 60, 20);
		list.add(id);
		
		data.setBounds(120, 40, 60, 20);
		list.add(data);
		view=new JTextArea();
		view.setBounds(10, 80, 300, 300);
		list.add(view);
		
		insert.setBounds(10, 400, 70, 40);
		insert.addActionListener(new myAction());
		list.add(insert);
		search.setBounds(80, 400, 70, 40);
		search.addActionListener(new myAction());
		list.add(search);
		delete.setBounds(150, 400, 70, 40);
		delete.addActionListener(new myAction());
		list.add(delete);
		show.setBounds(220, 400, 70, 40);
		show.addActionListener(new myAction());
		list.add(show);
		list.setVisible(true);
	}
	class myAction implements ActionListener{
		public void actionPerformed(ActionEvent e) {
			String mdata=data.getText();
			if(e.getSource()==insert){
				if(id.getText()==null||data.getText()==null){
					view.setText("����д������������д");
				}
				else{
					view.setText(id.getText());
				if(tree.get(Integer.parseInt(id.getText()))!=null)
					view.setText("�����ӵĽڵ��Ѵ���");
									
				else if(data.getText()!=null){
					tree.insert( new Node<String>(mdata,Integer.parseInt(id.getText())));
					view.setText("�ѳɹ�����");
				}	
				}
				id.setText("");
				data.setText("");
				
			}
			if(e.getSource()==search){
					if(id.getText()==null){
						view.setText("������������������д");
					}
					if(tree.get(8).getData()!=null){
						view.setText("��ѯ�Ľ���ǣ�"+tree.get(Integer.parseInt(id.getText())).getId()+tree.get(Integer.parseInt(id.getText())).getData().toString());
						}
					else{
						view.setText("δ�ҵ�");	
					}
					id.setText("");
					data.setText("");
				}		
	      if(e.getSource()==delete){
					if(tree.get(Integer.parseInt(id.getText()))==null){
						view.setText("�����ڸýڵ�");
					}
					if(tree.get(Integer.parseInt(id.getText()))!=null){
						tree.delete(Integer.parseInt(id.getText()));
						view.setText("�Գɹ�ɾ���ڵ�"+tree.get(Integer.parseInt(id.getText())).getId());
					}
					id.setText("");
					data.setText("");
					view.setText("");
				}
		
			if(e.getSource()==show){
					JTreeGUI jg=new JTreeGUI();
					jg.tree=tree;
					jg.display();
					setVisible(false);
					jg.setVisible(true);
				}
		}
		
	}
	
			
		
	}



