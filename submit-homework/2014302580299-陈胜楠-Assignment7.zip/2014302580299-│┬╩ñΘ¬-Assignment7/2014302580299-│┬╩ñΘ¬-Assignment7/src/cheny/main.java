package cheny;
public class main {
	public static void main(String[] args) {
		AVLTree<String>tree=new AVLTree<String>();
		//�Ȳ���ֵ
		tree.insert(new Node<String>("ant",1));
		tree.insert(new Node<String>("apple",2));
		tree.insert(new Node<String>("art",3));
		tree.insert(new Node<String>("baby",4));
		tree.insert(new Node<String>("banana",5));
		tree.insert(new Node<String>("car",6));
		tree.insert(new Node<String>("door",7));
		tree.insert(new Node<String>("dress",8));
		tree.insert(new Node<String>("frog",9));
		tree.insert(new Node<String>("love",10));
		tree.insert(new Node<String>("mint",11));
		tree.insert(new Node<String>("rice",12));
		tree.insert(new Node<String>("show",13));
		tree.insert(new Node<String>("table",14));
		tree.insert(new Node<String>("tree",15));
		tree.insert(new Node<String>("trouble",16));
		tree.insert(new Node<String>("window",17));
		JTreeGUI guitree=new JTreeGUI();
		guitree.tree=tree;
		guitree.display();
	}
}
