package cheny;

public class UnderflowException extends Exception {

}
