/**
 * 
 */
package AVLTree;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

/**
 * �ı���C++ƽ�������
 *
 */
public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		String s1="",s2="";
		try {
			File file=new File("data.txt");
			FileReader fileReader=new FileReader(file);
			BufferedReader bufferedReader=new BufferedReader(fileReader);
			while((s1=bufferedReader.readLine())!=null)
			{
				s2=s2+s1+",";
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
		String[] data=s2.split(",");
		AVLTree avlTree=new AVLTree();
		Node[] numNodes=new Node[17];
		for(int i=0;i<17;i++)
		{
			numNodes[i]=new Node();
			numNodes[i].setID(i+1);
			numNodes[i].setData(data[i].split("#")[0]);
			avlTree.insert(i+1, numNodes[i]);
			
		}
		for(int i=0;i<17;i++)  
		{
			System.out.println("���"+(i+1)+"��Ϣ:"+avlTree.get(i+1).getId()+" "+avlTree.get(i+1).getData());
		}
		 JFrame f = new JFrame("�ı��Ա�ѧ��C++ƽ�������");
	        f.add(avlTree.printTree());
	        f.setSize(300, 600);
	        f.setVisible(true);
	        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	       JOptionPane.showMessageDialog(null, "��ɾ��4��8��17��ע��۲�");
	       try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	        f.dispose();
	        avlTree.delete(4);
	        avlTree.delete(8);
	        avlTree.delete(17);
	        f = new JFrame("�ı��Ա�ѧ��C++ƽ�������");
	        f.add(avlTree.printTree());
	        f.setSize(300, 600);
	        f.setVisible(true);
	        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
	}

}
