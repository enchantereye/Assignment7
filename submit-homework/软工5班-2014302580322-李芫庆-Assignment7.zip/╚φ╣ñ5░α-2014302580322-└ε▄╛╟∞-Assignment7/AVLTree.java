package AVLTree;

import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;

public class AVLTree implements IAVLTree {

	//�����
	private Node root;
	public AVLTree()
	{
		root=null;
	}
	@Override
	public Node get(int id) {
		Node p=root;
		while(p!=null&&p.getId()!=id)
		{
			if(p.getId()<id)
				p=p.getChildren()[1];
			else {
				p=p.getChildren()[0];
			}
		}
		if(p==null)
			return null;
		return p;
	}

	@Override
	public void insert(int id, Node newNode) {
		// TODO Auto-generated method stub
		StringBuilder stringBuilder=new StringBuilder();
		root=inser(id, newNode, stringBuilder, root);
	}

	@Override
	public void delete(int id) {
		// TODO Auto-generated method stub
		Node c=null,s=null,r=null,p=root,q=null;
		while(p!=null&&p.getId()!=id)
		{
			q=p;
			if(id<p.getId())
				p=p.getChildren()[0];
			else {
				p=p.getChildren()[1];
			}
		}
		if(p==null)
		{
			System.out.println("��㲻����");
			return;
		}
		if(p.getChildren()[0]!=null&&p.getChildren()[1]!=null)
		{
			s=p.getChildren()[1];
			r=p;
			while(s.getChildren()[0]!=null)
			{
				r=s;
				s=s.getChildren()[0];
			}
			p.setID(s.getId());
			p.setData(s.getData());
			p=s;
			q=r;
		}
		if(p.getChildren()[0]!=null)
			c=p.getChildren()[0];
		else
			c=p.getChildren()[1];
		if(p==root)
			root=c;
		else if (p==q.getChildren()[0]) {
			q.setChild(c, 0);
			switch (q.getBalanceFactor()) {
			case 0:
				q.setBalanceFactor(-1);
				break;
			case 1:
				q.setBalanceFactor(0);
				break;
			case -1:
				StringBuilder stringBuilder=new StringBuilder();
				RRotation(q,stringBuilder );
				break;
			}
		}
		else {
			q.setChild(c, 1);
			switch (q.getBalanceFactor()) {
			case 0:
				q.setBalanceFactor(1);
				break;
			case 1:
				StringBuilder stringBuilder=new StringBuilder();
				LRotation(q,stringBuilder );
				break;
			case -1:
				q.setBalanceFactor(0);
				break;
			}
		}
		
				
	}

	@Override
	public JTree printTree() {
		DefaultMutableTreeNode defaultMutableTreeNode=new DefaultMutableTreeNode();
		print(defaultMutableTreeNode, root);
		return new JTree(defaultMutableTreeNode);
	}
	//����ת
	private Node LRotation(Node p,StringBuilder s)
	{
		Node u,r=p.getChildren()[0];
		if(r.getBalanceFactor()==1)
		{
			p.setChild(r.getChildren()[1],0);
			r.setChild(p, 1);
			p.setBalanceFactor(0);
			r.setBalanceFactor(0);
			s.insert(0,0);
			s.setLength(1);
			return r;
		}
		else {
			u=r.getChildren()[1];
			r.setChild(u.getChildren()[0], 1);
			u.setChild(r, 0);
			p.setChild(u.getChildren()[1], 0);
			u.setChild(p, 1);
			switch (u.getBalanceFactor()) {
			case 1:
				p.setBalanceFactor(-1);r.setBalanceFactor(0);
				break;
			case 0:
				p.setBalanceFactor(0);r.setBalanceFactor(0);
				break;
			case -1:
				p.setBalanceFactor(0);
				r.setBalanceFactor(1);
				break;
			}
			u.setBalanceFactor(0);
			s.insert(0,0);
			s.setLength(1);
			return u;
		}
		
	}
	//����ת
	private Node RRotation(Node p,StringBuilder s)
	{
		Node u=null,r=p.getChildren()[1];
		if(r.getBalanceFactor()==-1)
		{
			p.setChild(r.getChildren()[0], 1);
			r.setChild(p, 0);
			p.setBalanceFactor(0);
			r.setBalanceFactor(0);
			s.insert(0,0);
			s.setLength(1);toString();
			return r;
		}
		else {
			u=r.getChildren()[0];
			r.setChild(u.getChildren()[1], 0);
			p.setChild(u.getChildren()[0], 1);
			u.setChild(r ,1);
			u.setChild(p, 0);
			switch (u.getBalanceFactor()) {
			case 1:
				p.setBalanceFactor(0);
				r.setBalanceFactor(-1);
				break;
			case 0:
				p.setBalanceFactor(0);
				r.setBalanceFactor(0);
				break;
			case -1:
				p.setBalanceFactor(1);
				r.setBalanceFactor(0);
				break;
			}
			u.setBalanceFactor(0);
			s.insert(0,0);
			s.setLength(1);
			return u;
		}
		
	}
	//˽�в��뺯��
	private Node inser(int id, Node newNode,StringBuilder string,Node root1) {
		// TODO Auto-generated method stub
		if(root1==null)
		{	
			string.insert(0,1);string.setLength(1);
			return newNode;
		}
		else if(id<root1.getId())
		{
			root1.setChild(inser(id, newNode, string, root1.getChildren()[0]),0);
			if("1".equals(string.toString()))
			{
				switch (root1.getBalanceFactor()) {
				case -1:
					root1.setBalanceFactor(0);string.insert(0,0);string.setLength(1);
					break;
				case 0:
					root1.setBalanceFactor(1);
					break;
				case 1:
					root1=LRotation(root1, string);		
				}
			}
		}
			else if (id==root1.getId()) {
				string.insert(0, 0);string.setLength(1);
			}
			else {
				root1.setChild(inser(id, newNode, string, root1.getChildren()[1]),1);
				if("1".equals(string.toString()))
				{
					switch (root1.getBalanceFactor()) {
					case -1:
						root1=RRotation(root1, string);
						break;
					case 0:
						root1.setBalanceFactor(-1);
						break;
					case 1:
						root1.setBalanceFactor(0);string.insert(0,0);string.setLength(1);	
						break;
					}
					
				}
			}
		return root1;
			
	}
	//˽���������
	private void print( DefaultMutableTreeNode node1,Node p)
	{
		if(p!=null)
		{
			if(p.getChildren()[0]!=null)
			{
				print(node1, p.getChildren()[0]);
			}
			DefaultMutableTreeNode defaul=new DefaultMutableTreeNode(p);
			if(p.getChildren()[0]!=null)
				defaul.add(new DefaultMutableTreeNode(p.getChildren()[0]));
			if(p.getChildren()[1]!=null)
				defaul.add(new DefaultMutableTreeNode(p.getChildren()[1]));
			node1.add(defaul);
			if(p.getChildren()[1]!=null)
			{
				print(node1, p.getChildren()[1]);
			}
		}
		
	}
	
		
}
