import javax.swing.tree.DefaultMutableTreeNode;

public class Node extends DefaultMutableTreeNode {
	public int key;
	private Object data;
	public Object p;
	
	public int height;
	public Node rNode;
	public Node lNode;
	public int freq;
	
	public void setData(Object data){
		p = new String("not null");
		this.data = data; 
	}
	public Object getData(){
		return data;
	}
	public Node(int key, Object data){
		this.key = key;
		this.data = data;
		height = 0;
		freq = 1;
		rNode = null;
		lNode = null;
		p = new String("not null");
	}
	public Node(){
		height = 0;
		freq = 1;
		rNode = null;
		lNode = null;
		p = null;
	}
	public String toString(){
		return data.toString();
	}
}
