import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTree;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JLabel;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.UnsupportedEncodingException;
import java.awt.event.ActionEvent;

public class Main extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	static public JTree Mytree = null;
	static public AVLTree avltree = null;
	static public JLabel label_1 = null;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Main frame = new Main();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Main() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 666, 645);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		avltree = new AVLTree();
		Mytree = avltree.printTree();
		
		Mytree.setBounds(20, 102, 594, 495);
		contentPane.add(Mytree);
		
		// add data from file
		JButton button = new JButton("���ļ���������");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				avltree = new AVLTree();
				// add data from file
				//avltree.insert(0, new Node(0, "hello"));
				//avltree.insert(1, new Node(1, "teee"));
				//avltree.insert(2, new Node(2, "aaa"));
				//avltree.insert(3, new Node(3, "bbb"));
			//	avltree.insert(1, new Node(1, "two"));
				FileInputStream fls = null;
				try {
					fls = new FileInputStream(textField.getText());
				} catch (FileNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				try {
					InputStreamReader isr = new InputStreamReader(fls, "UTF-8");
					BufferedReader br = new BufferedReader(isr);
					String line = "";
					String [] arrs = null;
					while((line = br.readLine()) != null){
						arrs = line.split("#");
						System.out.println(arrs[0] + arrs[1]);
						avltree.insert(Integer.parseInt(arrs[1]), new Node(Integer.parseInt(arrs[1]), arrs[0]));
					}
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				
				contentPane.remove(Mytree);
				Mytree = avltree.printTree();
				Mytree.setBounds(20, 102, 594, 495);
				contentPane.add(Mytree);
				contentPane.repaint();
				label_1.setText("װ�سɹ�");
			}
		});
		button.setBounds(22, 32, 160, 23);
		contentPane.add(button);
		
		textField = new JTextField();
		textField.setBounds(358, 33, 282, 21);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JLabel label = new JLabel("�ļ�����/���·��");
		label.setBounds(243, 36, 105, 15);
		contentPane.add(label);
		
		label_1 = new JLabel("");
		label_1.setBounds(20, 65, 504, 15);
		contentPane.add(label_1);
	}
}
