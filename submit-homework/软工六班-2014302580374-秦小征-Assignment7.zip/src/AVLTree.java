import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;

public class AVLTree implements IAVLTree {

	private Node root;
	@Override
	public Node get(int id) {
		return find(root, id);
	}

	@Override
	public void insert(int id, Node newNode) {
		System.out.println("insert " + newNode.getData());
		insertToNode(root, newNode);
	}

	@Override
	public void delete(int id) {
		deleteFromNode(root, id);
	}

	@Override
	public JTree printTree() {
		if(root.p == null){
			System.out.println("root.p == null");
			JTree jtree2 =  new JTree(new DefaultMutableTreeNode("����Ϊ����"));
			return jtree2;
		}
		insubtree(root);
		JTree jtree = new JTree(root);
		return jtree;
	}
	private void insubtree(Node node){
		if(node == null)
			return;
		if(node.p == null)
			return;
		insubtree(node.lNode);
		node.removeAllChildren();
		if(node.lNode != null && node.lNode.p != null){
			node.add(node.lNode);
			System.out.println("add " + node.lNode.getData() + " to " + node.getData());
		}
		if(node.rNode != null && node.rNode.p != null){
			node.add(node.rNode);
			System.out.println("add " + node.rNode.getData() + " to " + node.getData());
		}
		insubtree(node.rNode);
	}
	public AVLTree(){
		root = new Node();
		System.out.println("new AVLTree");
	}
	private int height(Node node){
		if(node == null){
			return -1;
		}
		if(node.p != null){
			return node.height;
		}
		return -1;
	}
	private void SingRotateLeft(Node in){
		System.out.println("SingRotateLeft " + in.getData());
		Node k1 = null;
		Node k2 = in;
		
		int temint = k2.key;
		Object temO = k2.getData();
		
		k1 = k2.lNode;
		
		k2.key = k1.key;
		k2.setData(k1.getData());
		
		k1.key = temint;
		k1.setData(k2.getData());
		
		k2.lNode = k1.lNode;
		k1.lNode = k1.rNode;
		k1.rNode = k2.rNode;
		k2.rNode = k1;

		k2.height = Max(height(k2.lNode), height(k2.rNode)) + 1;
		k1.height = Max(height(k1.rNode), k2.height) + 1;
		
		/* c++ version
		k1 = k2.lNode;
		k2.lNode = k1.rNode;
		k1.rNode = k2;
		
		k2.height = Max(height(k2.lNode), height(k2.rNode));
		k1.height = Max(height(k1.lNode), k2.height) + 1;
		*/
	}
	private void SingRotateRight(Node in){
		System.out.println("SingRotateRight " + in.getData());
		Node k1 = null;
		Node k2 = in;
		
		int temint = k2.key;
		Object temO = k2.getData();
		
		k1 = k2.rNode;
		
		k2.key = k1.key;
		k2.setData(k1.getData());
		
		k1.key = temint;
		k1.setData(temO);
		
		k2.rNode = k1.rNode;
		k1.rNode = k1.lNode;
		k1.lNode = k2.lNode;
		k2.lNode = k1;

		k2.height = Max(height(k2.lNode), height(k2.rNode)) + 1;
		k1.height = Max(height(k1.rNode), k2.height) + 1;
		/* c++ version
		k1 = k2.rNode;
		k2.rNode = k1.lNode;
		k1.lNode = k2;
		
		k2.height = Max(height(k2.lNode), height(k2.rNode)) + 1;
		k1.height = Max(height(k1.rNode), k2.height) + 1;
		*/
	}
	private void DoubleRotateLR(Node k3){
		System.out.println("DoubleRotateLR");
		SingRotateRight(k3.lNode);
		SingRotateLeft(k3);
	}
	private void DoubleRotateRL(Node k3){
		System.out.println("DoubleRotateRL");
		SingRotateLeft(k3.rNode);
		SingRotateRight(k3);
	}
	int Max(int a, int b){
		return a > b ? a : b;
	}
	void insertToNode(Node node, Node newNode){
		if(node.p == null){
			node.key = newNode.key;
			node.setData(newNode.getData());
			node.height = 0;
			node.freq = 1;
			node.p = new String("not null");
		/*	if(root.p == null){
				System.out.println("79");
				
			}else{
				System.out.println(node.getData().toString());
			}*/
			return;
		}
		if(node.key > newNode.key){ // �ڽڵ���������в���
			if(node.lNode == null){
				node.lNode = new Node();
			}
			insertToNode(node.lNode, newNode);
			if(2 == height(node.lNode) - height(node.rNode)){
				if(newNode.key < node.lNode.key)
					SingRotateLeft(node);
				else
					DoubleRotateLR(node);
			}
		}else if(node.key < newNode.key){ // �ڽڵ���������в���
			if(node.rNode == null){
				System.out.println("here");
				node.rNode = new Node();
			}
			insertToNode(node.rNode, newNode);
			System.out.println("height(node.rNode) - height(node.lNode) = " + (int)(height(node.rNode) - height(node.lNode)));
			if(2 == height(node.rNode) - height(node.lNode)){
				if(newNode.key > node.rNode.key){
					SingRotateRight(node);
					System.out.println("here2");
				}
				else
					DoubleRotateRL(node);
			}
		}else
			node.freq++;
		node.height = Max(height(node.lNode), height(node.rNode)) + 1;
		
	}
	private Node find(Node node, int key){
		if(node.p == null){
			return null;
		}
		if(node.key > key)
			return find(node.lNode, key);
		else if(node.key < key)
			return find(node.rNode, key);
		else 
			return node;
	}
	private void deleteFromNode(Node node, int key){
		if(node.p == null)
			return;
		if(key < node.key){
			deleteFromNode(node.lNode, key);
			if(2 == height(node.rNode) - height(node.lNode))
				if(node.rNode.lNode.p != null && (height(node.rNode.lNode) > height(node.rNode.rNode)))
					DoubleRotateRL(node);
				else
					SingRotateRight(node);
		}else if(key > node.key){
			deleteFromNode(node.rNode, key);
			if(2 == height(node.lNode) - height(node.rNode))
				if(node.lNode.rNode.p != null && (height(node.lNode.rNode) > height(node.lNode.lNode)))
					DoubleRotateLR(node);
				else
					SingRotateLeft(node);
		}else{
			if(node.lNode.p != null && node.rNode.p != null){
				Node tem = node.rNode;
				while(tem.lNode.p != null)
					tem = tem.lNode;
				node.key = tem.key;
				node.setData(tem.getData());
				node.freq = tem.freq;
				deleteFromNode(node.rNode, tem.key);
				if(2 == height(node.lNode) - height(node.rNode))
					if(node.lNode.rNode.p != null && (height(node.lNode.rNode) > height(node.lNode.lNode)))
						DoubleRotateLR(node);
					else
						SingRotateLeft(node);
			}else{
				Node tem = node;
				if(node.lNode.p == null)
					node = node.rNode;
				else if(node.rNode.p == null)
					node = node.lNode;
				// todo some differences
			}
		}
		if(node.p == null)
			return;
		node.height = Max(height(node.lNode), height(node.rNode)) + 1;
	}
}
