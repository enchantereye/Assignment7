import javax.swing.JTree;
import javax.swing.event.TreeSelectionListener;
import javax.swing.tree.DefaultMutableTreeNode;

public class AVLTree implements IAVLTree {
	private Node root = null;

	/**
	 * get the node by index
	 * 
	 * @param id,
	 *            the node id to get
	 * @return
	 */
	public Node get(int id) {
		if (root != null) {
		
			Node now = root;
	
			while (now != null) {
				if (now.getId() == id){
			
					return now;
				}
				else if (id < now.getId())
					now = now.getChildren()[0];// left child
				else if (id > now.getId())
					now = now.getChildren()[1]; // right chid
			}
		}
		return null;
	}

	/**
	 * insert the node by id
	 * 
	 * @param id,
	 *            the parent node id to insert
	 */
	public void insert(int id, Node newNode) {
		// check if it has been insert
		if (get(id) == null){
			// we do not care the content of the node (the Object)
			if (root == null){
				root = newNode;
				}
			else {
				Node now = root;
				while (now != null) {
					Node Children[] = now.getChildren();
					if (id < now.getId()) {
						// left tree height plus
						//now.lSubTreeHeight++;
						// left child tree
						if (Children[0] == null) {
							now.setChild(newNode, 0);
							break;
						} else {

							now = Children[0];
							continue;
						}
					} else if (id > now.getId()) {
						//now.rSubTreeHeight++;
						// right child tree height plus
						if (Children[1] == null) {
							now.setChild(newNode, 1);
							break;
						} else {
							now = Children[1];
							continue;
						}
					}

				}
				// check if it need rotate
				if (id < now.getId()) {
					now.lSubTreeHeight++;
				} else { 
					now.rSubTreeHeight++;
				}
				while (now.getParent() != null) {
					Node temp = now.getParent();
					if(now.getId()<temp.getId()){
						//判读是否合适
						if(id<now.getId()&&now.lSubTreeHeight>=now.rSubTreeHeight){
							temp.lSubTreeHeight++;
						}
						else if(id>now.getId()&&now.rSubTreeHeight>=now.lSubTreeHeight){
							temp.lSubTreeHeight++;
						}
						
					}
					else {
						//判断是否需要增加
						if(id<now.getId()&&now.lSubTreeHeight>=now.rSubTreeHeight){
							temp.rSubTreeHeight++;
						}
						else if(id>now.getId()&&now.rSubTreeHeight>=now.lSubTreeHeight){
							temp.rSubTreeHeight++;
						}
						
					}
					if (now.getParent().lSubTreeHeight - now.getParent().rSubTreeHeight == 2) {
						if (id < now.getId()) {
							// LL
							rotateLeftChild(now.getParent());
							break;
						} else { 
							rotateLR(now.getParent());
							break;
							// LR
						}
					} else if (now.getParent().rSubTreeHeight - now.getParent().lSubTreeHeight == 2) {
						
						if (id > now.getId()) {
							// RR
							rotateRightChild(now.getParent());
							break;
						} else {
							rotateRL(now.getParent());
							break;
							// RL
						}
					}
					now = temp;
				}
			}}
	}

	public int FindMax(Node root) {
		while (root.getChildren()[1] != null) {
			root = root.getChildren()[1];
		}
		return root.getId();
	}

	public int FindMin(Node root) {
		while (root.getChildren()[0] != null) {
			root = root.getChildren()[0];
		}
		return root.getId();
	}

	public void checkback(int id, Node bottom) {
		
		while (bottom != null) {
			Node temp =  bottom.getParent();
			if (bottom.lSubTreeHeight == bottom.rSubTreeHeight) {
				if (id < bottom.getId()) {
					bottom.lSubTreeHeight--;
				} else {
					bottom.rSubTreeHeight--;
				}
				break;
			} else if (id < bottom.getId()) {
				// left
				if (bottom.lSubTreeHeight > bottom.rSubTreeHeight) {
					bottom.lSubTreeHeight--;
				} else {
					if (bottom.getChildren()[1] != null) {
						System.out.println("xuanzhuantest");
						if (bottom.getChildren()[1].lSubTreeHeight - bottom.getChildren()[1].rSubTreeHeight == 0) {
							System.out.println("1");
							bottom.lSubTreeHeight--;
							rotateRightChild(bottom);
							bottom.getParent().lSubTreeHeight++;
							break;
						} else if ((bottom.getChildren()[1].lSubTreeHeight
								- bottom.getChildren()[1].rSubTreeHeight) == bottom.lSubTreeHeight
										- bottom.rSubTreeHeight) {
							System.out.println("2");
							bottom.lSubTreeHeight--;
							rotateRightChild(bottom);
							bottom.getParent().rSubTreeHeight++;
						} else {
							// double
							System.out.println("3");
							bottom.lSubTreeHeight--;
							rotateRL(bottom);
							bottom.getParent().rSubTreeHeight++;
							bottom.getParent().lSubTreeHeight = bottom.getParent().rSubTreeHeight;
						}
					} else {
						bottom.lSubTreeHeight--;
					}
				}

			} else if (id > bottom.getId()) {
				// right
				if (bottom.rSubTreeHeight > bottom.lSubTreeHeight) {
					bottom.rSubTreeHeight--;
				} else {
					bottom.rSubTreeHeight--;
					if (bottom.getChildren()[0] != null)
						if (bottom.getChildren()[0].rSubTreeHeight - bottom.getChildren()[0].lSubTreeHeight == 0) {
							rotateLeftChild(bottom);
							bottom.getParent().rSubTreeHeight++;
							break;
						} else if ((bottom.getChildren()[0].lSubTreeHeight
								- bottom.getChildren()[0].rSubTreeHeight) == bottom.lSubTreeHeight
										- bottom.lSubTreeHeight) {
							rotateLeftChild(bottom);
							bottom.getParent().getChildren()[0].lSubTreeHeight++;

						} else {
							rotateLR(bottom);
							bottom.getParent().lSubTreeHeight++;
							bottom.getParent().rSubTreeHeight = bottom.getParent().lSubTreeHeight;
						}

				}

			}

			id = bottom.getId();
			bottom = temp;
			
		}
		// check back
	}

	/**
	 * the node id to delete
	 * 
	 * @param id
	 */
	public void delete(int id) {
		Node deleteone = this.get(id);
		if (deleteone != null) {
			if (deleteone.getChildren()[0] != null && deleteone.getChildren()[1] != null) {
				if (deleteone.lSubTreeHeight - deleteone.rSubTreeHeight <= 0) {
					// find min
					Node min = get(FindMin(deleteone.getChildren()[1]));
					if(min.getId()<min.getParent().getId())
					min.getParent().setChild(null, 0);
					else min.getParent().setChild(null, 1);
					Node check = min.getParent();
					Node point = deleteone.getParent();
					if (point != null) {
						if (id < point.getId()) {
							point.setChild(min, 0);
						} else {
							point.setChild(min, 1);
						}

					} else {
						this.root = min;
						this.root.setParent(null);
					}
					min.setChildren(deleteone.getChildren());
					min.lSubTreeHeight = deleteone.lSubTreeHeight;
					min.rSubTreeHeight = deleteone.rSubTreeHeight;
					checkback(min.getId(), check);
				} else {
					Node max = get(FindMax(deleteone.getChildren()[0]));
					if(max.getId()<max.getParent().getId())
						max.getParent().setChild(null, 0);
						else max.getParent().setChild(null, 1);
					Node check = max.getParent();
					Node point = deleteone.getParent();
					if (point != null) {
						if (id < point.getId()) {
							point.setChild(max, 0);
						} else {
							point.setChild(max, 1);
						}
					} else {
						this.root = max;
						this.root.setParent(null);
					}
					// find max
					max.setChildren(deleteone.getChildren());
					// fix max instead delete one‘s height change（only exchange）
					max.lSubTreeHeight = deleteone.lSubTreeHeight;
					max.rSubTreeHeight = deleteone.rSubTreeHeight;
					checkback(max.getId(), check);
				}
				// check from max or min to change height or rotate
			} else if (deleteone.getChildren()[0] != null && deleteone.getChildren()[1] == null) {
				Node point = deleteone.getParent();
				if (point != null) {
					if (id < point.getId()) {
						point.setChild(deleteone.getChildren()[0], 0);
					} else {
						point.setChild(deleteone.getChildren()[0], 1);
					}
				} else {
					this.root = deleteone.getChildren()[0];
					this.root.setParent(null);
				}
				checkback(id, point);
			} else if (deleteone.getChildren()[0] == null && deleteone.getChildren()[1] != null) {
				Node point = deleteone.getParent();
				if (point != null) {
					if (id < point.getId()) {
						point.setChild(deleteone.getChildren()[1], 0);
					} else {
						point.setChild(deleteone.getChildren()[1], 1);
					}
					// check back if it need rotate change height
					checkback(id, point);
				} else {
					this.root = deleteone.getChildren()[1];
					this.root.setParent(null);
				}

			} else if (deleteone.getChildren()[0] == null && deleteone.getChildren()[1] == null) {
				Node point = deleteone.getParent();
				if (point != null) {
					if (id < point.getId()) {
						point.setChild(null, 0);
					} else {
						point.setChild(null, 1);
					}
					// check back if it need rotate change height
					checkback(id, point);
				} else {
					this.root = null;
				}

			}
		} else {
			System.out.println("删除出错！查无此节点！");
		}
	}

	/**
	 * print the whole tree
	 * 
	 * @return a java swing Object JTree
	 */
	public JTree printTree() {
		DefaultMutableTreeNode top = new DefaultMutableTreeNode(String.valueOf(this.root.getId()) + "  " +this.root.getData());
		addpoint(this.root, top);
		final JTree tree = new JTree(top);
		return tree;
	}
	
	private void addpoint(Node now,DefaultMutableTreeNode nowtree){
		if(now.getChildren()[0]!=null){
			DefaultMutableTreeNode temp = new DefaultMutableTreeNode(new User(String.valueOf(now.getChildren()[0].getId()) + "  "+now.getChildren()[0].getData()));
			addpoint(now.getChildren()[0], temp);
			nowtree.add(temp);
		}
		if(now.getChildren()[1]!=null){
			DefaultMutableTreeNode temp = new DefaultMutableTreeNode(new User(String.valueOf(now.getChildren()[1].getId()) + "  "+now.getChildren()[1].getData()));
			addpoint(now.getChildren()[1], temp);
			nowtree.add(temp);
		}
	}
	
	private void rotateLeftChild(Node input) {
		if (input.getParent() == null) {
			this.root = input.getChildren()[0];
			root.setParent(null);
			input.setChild(this.root.getChildren()[1], 0);
			this.root.setChild(input, 1);
			input.lSubTreeHeight = this.root.rSubTreeHeight;
			this.root.rSubTreeHeight = this.root.lSubTreeHeight;
		} else {
			Node root = input.getParent();
			if(input.getId()<root.getId()){
				root.setChild(input.getChildren()[0], 0);
				input.setChild(root.getChildren()[0].getChildren()[1], 0);
				root.getChildren()[0].setChild(input, 1);
				input.lSubTreeHeight = root.getChildren()[0].rSubTreeHeight;
				root.getChildren()[0].rSubTreeHeight = root.getChildren()[0].lSubTreeHeight;
			}
			else{
				root.setChild(input.getChildren()[0], 1);
				input.setChild(root.getChildren()[1].getChildren()[1], 0);
				root.getChildren()[1].setChild(input, 1);
				input.lSubTreeHeight = root.getChildren()[1].rSubTreeHeight;
				root.getChildren()[1].rSubTreeHeight = root.getChildren()[1].lSubTreeHeight;
			}
		}
	}

	private void rotateRightChild(Node input) {
		
		if (input.getParent() == null) {
		
			this.root = input.getChildren()[1];
			this.root.setParent(null);
			input.setChild(this.root.getChildren()[0], 1);
			this.root.setChild(input, 0);
			input.rSubTreeHeight = this.root.lSubTreeHeight;
			this.root.lSubTreeHeight = this.root.rSubTreeHeight;
		} else {
			
			Node root = input.getParent();
			if(input.getId()<root.getId()){
				
				root.setChild(input.getChildren()[1], 0);
				input.setChild(root.getChildren()[0].getChildren()[0], 1);
				root.getChildren()[0].setChild(input, 0);
				input.rSubTreeHeight = root.getChildren()[0].lSubTreeHeight;
				root.getChildren()[0].lSubTreeHeight = root.getChildren()[0].rSubTreeHeight;
				
			}else{
				
				root.setChild(input.getChildren()[1], 1);
				input.setChild(root.getChildren()[1].getChildren()[0], 1);
				root.getChildren()[1].setChild(input, 0);
				input.rSubTreeHeight = root.getChildren()[1].lSubTreeHeight;
				root.getChildren()[1].lSubTreeHeight = root.getChildren()[1].rSubTreeHeight;
			
			}
			
		}
	}

	private void rotateLR(Node input) {
		rotateRightChild(input.getChildren()[0]);
		rotateLeftChild(input);
	}

	private void rotateRL(Node input) {
		rotateLeftChild(input.getChildren()[1]);
		rotateRightChild(input);
	}
}
