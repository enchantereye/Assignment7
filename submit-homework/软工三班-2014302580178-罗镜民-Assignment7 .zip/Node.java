
public class Node {
	private int id;
	private Object data;
	private Node parent = null;
	private Node[] children = new Node[2];
	public int lSubTreeHeight = 0;
	public int rSubTreeHeight = 0;
//	public int balanceFactor = 0;
	Node(int id){
		this.id  = id;
		this.children[0] = null;
		this.children[1] = null;
	}
	public int getId() {
		return id;
	}
	public Object getData() {
		return data;
	}
	public void setData(Object data) {
		this.data = data;
	}
	public Node getParent() {
		return parent;
	}
	public void setParent(Node parent) {
		this.parent = parent;
	}
	public Node[] getChildren() {
		return children;
	}
	public void setChildren(Node[] children) {
		this.children = children;
		if(children[0]!=null)children[0].setParent(this);
		if(children[1]!=null)children[1].setParent(this);
	}
	public void setChild(Node child, int id){
		
		this.children[id] = child;
		if(child!=null)child.setParent(this);
	}

}
