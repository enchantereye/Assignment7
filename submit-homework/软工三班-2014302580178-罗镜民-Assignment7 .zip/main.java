import java.util.Scanner;

import javax.swing.JFrame;
import javax.swing.JTree;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.tree.DefaultMutableTreeNode;



public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		boolean out;
		AVLTree tree = new AVLTree();
		String datas[] = {"ant","apple","art","baby","banan","car","door","dress", "frog", "love", "mint", "rice", "show","table","tree","trouble","window"};
		for(int i=1;i<18;i++){//可以调
			Node temp = new Node(i);
			temp.setData(datas[i-1]);
			tree.insert(i, temp);
		}
		while(out = true){	
			System.out.println("欢迎来到不知道是什么的AVL");
			System.out.print("按1插入\n"
					+ "按2查找\n"
					+ "按3删除\n"
					+ "按4展示\n"
					+ "5退出....\n"
					+ "\n");
			Scanner in = new Scanner(System.in);
			int systemnumber = in.nextInt();
			switch (systemnumber) {
			case 1:
				System.out.println("请输入插入id");
				int id = in.nextInt();
				System.out.println("请输入插入数据");
				String data = in.next();
				Node insert = new Node(id);
				insert.setData(data);
				tree.insert(id, insert);
				break;
			case 2:
				System.out.println("请输入要查找的number");
				int id2 = in.nextInt();
				if(tree.get(id2) == null)continue;
				System.out.println(tree.get(id2).getData());
				break;
			case 3:
				System.out.println("输入要删除的id");
				int id3 = in.nextInt();
				tree.delete(id3);
				System.out.println("sd!");
				break;
			case 4:
				System.out.println("水平问题，重按4窗口内数据会再加载");
				JFrame f = new JFrame("hi");
				JTree treea = tree.printTree();
				f.add(treea);
				f.setSize(500, 500);
				f.setVisible(true);
				f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				treea.addTreeSelectionListener(new TreeSelectionListener() {
			            @Override
			            public void valueChanged(TreeSelectionEvent e) {
			                DefaultMutableTreeNode node = (DefaultMutableTreeNode) treea.getLastSelectedPathComponent();
			                if (node == null)
			                    return;
			                Object object = node.getUserObject();
			                if (node.isLeaf()) {
			                 
			                }
			 
			            }

			        });
				break;
			case 5:
				out = false;
				break;
			default:
				System.out.println("乱打尼玛！");
				break;
			}
			
		}
	}

}
