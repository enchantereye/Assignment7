	public class User {
	    private String name;
	    public User(String n) {
	        name = n;
	    }
	    public String toString() {
	        return name;
	    }
	}