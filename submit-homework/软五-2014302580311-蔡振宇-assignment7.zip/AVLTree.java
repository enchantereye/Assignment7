package AVLTree;

import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;

public class AVLTree implements IAVLTree{
	public Node root;

             public Node get2(Node t,int id){
            	 if(t!=null)
            	 {
            		 if(t.getId()==id)
            		 {
            			 return t;
            		 }
            		 else{
            			 if(t.getId()>id){
            				 return get2(t.getChildren()[0],id);
            			 }
            			 else
            			 {
            				 return get2(t.getChildren()[1],id);
            			 }
            		 }
            	 }
				return null;
             }
      
  
	@Override
	public Node get(int id) {
		// TODO Auto-generated method stub
		return get2(root,id);
	}

	public void insert(Node p,Node newNode)
	{
		
		if(newNode.getId()<p.getId())
		{
			
			if(p.getChildren()[0]==null)
			{
				p.setChild(newNode, 0);
				newNode.setParent(p);
			}
			else
				insert(p.getChildren()[0],newNode);
			
			
			if(p.getBalanceFactor()==1)
			{
				if(p.getParent()!=null)
				{
					if(p.getParent().getBalanceFactor()>1||p.getParent().getBalanceFactor()<-1)
						LR(p.getParent());
				}
			}
		
			
		}
		else if(newNode.getId()==p.getId())
		{
			
		}
		else if(newNode.getId()>p.getId())
		{
			
			if(p.getChildren()[1]==null)
			{
				p.setChild(newNode, 1);
				newNode.setParent(p);
			}
			else
				insert(p.getChildren()[1],newNode);
			
			
			
			if(p.getBalanceFactor()==-1)
			{
				if(p.getParent()!=null)
				{
					if(p.getParent().getBalanceFactor()>1||p.getParent().getBalanceFactor()<-1)
						RR(p.getParent());
				} 
			}
			
		}
	}
	@Override
	public void insert( Node newNode) {
		// TODO Auto-generate
		if(root==null){
			root=newNode;
		}
		else
			insert(root,newNode);
	}
void delete(Node t){
	if(t.getParent().getChildren()[0]==t)		
		{t=null;
		if(t.getChildren()[0]!=null)
		{
			t.getChildren()[0].setParent(t.getParent());	
			t.getParent().setChild(t.getChildren()[0], 0);
			t=t.getChildren()[0];
		}
		else if(t.getChildren()[1]!=null)
		{
			t.getChildren()[1].setParent(t.getParent());
			t.getParent().setChild(t.getChildren()[1], 0);
			t=t.getChildren()[1];
		}
		else
		{
			t=t.getParent();
			t.setChild(null, 0);
		}	
	}
	else if(t.getParent().getChildren()[1]==t)
	{
		if(t.getChildren()[0]!=null)
		{
			t.getChildren()[0].setParent(t.getParent());
			t.getParent().setChild(t.getChildren()[0], 1);
			t=t.getChildren()[0];
		}
		else if(t.getChildren()[1]!=null)
		{
			t.getChildren()[1].setParent(t.getParent());
			t.getParent().setChild(t.getChildren()[1], 1);
			t=t.getChildren()[1];
		}
		else
		{
			t=t.getParent();
			t.setChild(null, 1);
		}
	}
}
	@Override
	public void delete(int id) {
		// TODO Auto-generated method stub
		Node t=get(id);
		if(t!=null)
		{
			if(t.getChildren()[0]!=null&&t.getChildren()[1]!=null)
			{
				Node n2=null;
				int Id2=id+1;
				while(n2==null)
				{
					n2=get(Id2);
					Id2++;
				}
				t.setId(n2.getId());
				t.setData(n2.getData());
				id=Id2;
				t=n2;
			}		
			if(t==root)
			{
				
				if(root.getChildren()[0]!=null)
				{
					root.getChildren()[0].setParent(null);
					root=root.getChildren()[0];
				}
				else if(root.getChildren()[1]!=null)
				{	
					root.getChildren()[1].setParent(null);
					root=root.getChildren()[1];
				}
				
			}
			else if(t!=null)
			{			
				if(t.getParent().getBalanceFactor()==0)
				{
					delete(t);
				}
				
				if(t.getParent().getBalanceFactor()==1&&t.getParent().getChildren()[0]==t)
				{
					delete(t);
					while(t.getParent().getBalanceFactor()<=1&&t.getParent().getBalanceFactor()>=-1)
					{
						t=t.getParent();	
						if(t.getParent()==null)
							break;									
					}
					
					if(t.getParent()!=null)
					{
						if(t.getParent().getBalanceFactor()==-2)
							RR(t.getParent());
						else if(t.getParent().getBalanceFactor()==2)
							LR(t.getParent());
					}
						
				}
				else if(t.getParent().getBalanceFactor()==-1&&t.getParent().getChildren()[1]==t)
				{
					delete(t);
					while(t.getParent().getBalanceFactor()<=1&&t.getParent().getBalanceFactor()>=-1)
					{
						t=t.getParent();	
						if(t.getParent()==null)
							break;									
					}
					
					if(t.getParent()!=null)
					{
						if(t.getParent().getBalanceFactor()==-2)
							RR(t.getParent());
						else if(t.getParent().getBalanceFactor()==2)
							LR(t.getParent());
					}
				}
				
				if(t.getParent().getBalanceFactor()==1&&t.getParent().getChildren()[1]==t)
				{
					delete(t);
					while(t.getParent().getBalanceFactor()<=1&&t.getParent().getBalanceFactor()>=-1)
					{
						t=t.getParent();	
						if(t.getParent()==null)
							break;									
					}
					
					if(t.getParent()!=null)
					{
						if(t.getParent().getBalanceFactor()==-2)
							RR(t.getParent());
						else if(t.getParent().getBalanceFactor()==2)
							LR(t.getParent());
					}
						
				}
				else if(t.getParent().getBalanceFactor()==-1&&t.getParent().getChildren()[0]==t)
				{
					delete(t);
					while(t.getParent().getBalanceFactor()<=1&&t.getParent().getBalanceFactor()>=-1)
					{
						t=t.getParent();	
						if(t.getParent()==null)
							break;									
					}
					
					if(t.getParent()!=null)
					{
						if(t.getParent().getBalanceFactor()==-2)
							RR(t.getParent());
						else if(t.getParent().getBalanceFactor()==2)
							LR(t.getParent());
					}
				}
			}
		}
	}

	@Override
	public JTree printTree()
	{
		
		return new JTree(buildJTree(this.root));
	}
	private DefaultMutableTreeNode buildJTree(Node node){
		if(node==null){
			return null;
		}
		DefaultMutableTreeNode l=buildJTree(node.getChildren()[0]);
		DefaultMutableTreeNode r=buildJTree(node.getChildren()[1]);
		DefaultMutableTreeNode tNode=new DefaultMutableTreeNode(node.getData().toString()
				+"-"+node.getId());
		if(l!=null){
			tNode.add(l);
		}
		if(r!=null){
			tNode.add(r);
		}
		return tNode;
	}

	
	public void LR(Node t){
		Node x,y=t.getChildren()[0];
		if(y.getBalanceFactor()!=1)
		{
			x=t.getChildren()[1];
			y.setChild(x.getChildren()[0], 1);
			x.setChild(y, 0);
			t.setChild(x.getChildren()[1], 0);
			x.setChild(t, 1);
			t=x;
			
		}
		else
		{
			t.setChild(y.getChildren()[1], 0);
			y.setChild(t,1);
			t=y;
		}
	}
	public void RR(Node t){
		Node x,y=t.getChildren()[1];
		if(y.getBalanceFactor()==1)
		{
			x=y.getChildren()[0];
			y.setChild(x.getChildren()[1], 0);
			if(x.getChildren()[1]!=null)
			{
				x.getChildren()[1].setParent(y);
			}
			x.setChild(null, 1);
			x.setParent(null);
			
			
			t.setChild(x.getChildren()[0], 1);			
			y.setParent(null);
			x.getChildren()[0].setParent(t);
			x.setChild(null, 0);
			
			x.setChild(y, 1);
			x.setChild(t, 0);

			if(t.getParent()!=null)
			{
				if(t.getParent().getChildren()[0]==t)
				{
					x.setParent(t.getParent());
					t.getParent().setChild(x, 0);
				}else
				{
					x.setParent(t.getParent());
					t.getParent().setChild(x, 1);
				}
			}
			else
			{
				root=x;
			}
			t.setParent(x);
			y.setParent(x);
		}
		else if(y.getBalanceFactor()==-1)
		{
			t.setChild(y.getChildren()[0], 1);
			if(y.getChildren()[0]!=null)
			{			
				y.getChildren()[0].setParent(t);
			}
			y.setParent(null);
			y.setChild(null, 0);
			y.setChild(t, 0);
			if(t.getParent()!=null)
			{
				if(t.getParent().getChildren()[0]==t)
				{
					y.setParent(t.getParent());
					t.getParent().setChild(y, 0);
				}else
				{
					y.setParent(t.getParent());
					t.getParent().setChild(y, 1);
				}
			}else
			{
				root=y;
			}
			t.setParent(y); 
		}
		
	}
}
