package AVLTree;

import javax.swing.JFrame;
import javax.swing.JTree;
import javax.swing.WindowConstants;

public class Main2014302580311 {
public static void main(String arg[]){
	   
       AVLTree t = new AVLTree();
       try{
           getTree(t);
         
       }catch (Exception e) {
           e.printStackTrace();
       }
       show(t);
       
}

public static void getTree(AVLTree tree) throws Exception {
    
   /* Node node1 = new Node();
    Node node2 = new Node();
    Node node3 = new Node();
    Node node4 = new Node();
    Node node5 = new Node();
    Node node6 = new Node();
    Node node7 = new Node();
    Node node8 = new Node();
    Node node9 = new Node();*/
    Node node10 = new Node();
    Node node11 = new Node();

  /*      node1.setData("ant");
        node1.setId(1);
        node2.setData("apple");
        node2.setId(2);
        node3.setData("art");
        node3.setId(3);
        node4.setData("baby");
        node4.setId(4);
        node5.setData("butterfly");
        node5.setId(5);
        node6.setData("beast");
        node6.setId(6);
        node7.setData("cat");
        node7.setId(7);
        node8.setData("cow");
        node8.setId(8);
        node9.setData("dog");
        node9.setId(9);*/
        node10.setData("fox");
        node10.setId(10);
        node11.setData("Ghibli");
        node11.setId(11);
        
    /*    tree.insert(node1);
        tree.insert(node2);
        tree.insert(node3);
        tree.insert(node4);
        tree.insert(node5);
        tree.insert(node6);
        tree.insert(node7);
        tree.insert(node8);
        tree.insert(node9);*/
        tree.insert(node10);
        tree.insert(node11);
        tree.delete(node11);
       System.out.println( tree.get(11));
       
}
public static void show(AVLTree tree) {
    JFrame JFrame = new JFrame("平衡树");
    JFrame.setBounds(100,100,800,600);
    JFrame.setVisible(true);
    JFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
    JTree JTree = tree.printTree();
    JFrame.add(JTree);
}
}