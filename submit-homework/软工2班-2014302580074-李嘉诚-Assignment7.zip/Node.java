public class Node {
	private int id;
	private Object data;
	private Node parent;
	private Node[] children = new Node[2];
	private int lSubTreeHeight;
	private int rSubTreeHeight;
	private int balanceFactor;
	
	public int getId() 
	{
		return id;
	}
	public void setId(int id)
	{
		this.id = id;
	}
	
	public Object getData() 
	{
		return data;
	}
	public void setData(Object data)
	{
		this.data = data;
	}
	public Node getParent()
	{
		return parent;
	}
	public void setParent(Node parent) 
	{
		this.parent = parent;
	}
	public Node[] getChildren() 
	{
		return children;
	}
	public void setChildren(Node[] children) 
	{
		this.children = children;
	}
	public void setChild(Node child, int id)
	{
		this.children[id] = child;
	}
	
	/*
	 * ���õݹ��㷨�����������߶�
	 */
	public int getlSubTreeHeight() 
	{
		if(this.getChildren(0)==null)
			lSubTreeHeight=0;
		else if(this.getChildren(0)!=null)
		{
			if(this.getChildren(0).getlSubTreeHeight()>this.getChildren(0).getrSubTreeHeight())
				lSubTreeHeight=this.getChildren(0).getlSubTreeHeight()+1;
			else
				lSubTreeHeight=this.getChildren(0).getrSubTreeHeight()+1;	
		}
		return lSubTreeHeight;
	}
	
	/*
	 * ���õݹ��㷨�����������߶�
	 */
	public int getrSubTreeHeight() 
	{
		if(this.getChildren(1)==null)
			rSubTreeHeight=0;
		else if(this.getChildren(1)!=null)
		{
			if(this.getChildren(1).getlSubTreeHeight()>this.getChildren(1).getrSubTreeHeight())
				rSubTreeHeight=this.getChildren(1).getlSubTreeHeight()+1;
			else
				rSubTreeHeight=this.getChildren(1).getrSubTreeHeight()+1;
		}
		return rSubTreeHeight;
	}
	/*
	 * ��������ļ���߶�������ƽ������
	 */
	public int getBalanceFactor() 
	{	
		balanceFactor=this.getlSubTreeHeight()-this.getrSubTreeHeight();
		return balanceFactor;
	}
	public void setBanlanceFactor(int balanceFactor)
	{
		this.balanceFactor=balanceFactor;
	}
	
	public Node getChildren(int id)
	{
		if(id!=0&&id!=1){
			return null;
		}else{
			return children[id];
		}
	}
	
	@Override
	public String toString()
	{
		if(this.getData()!=null)
			return "id:"+String.valueOf(this.getId())+" data:"+String.valueOf(this.getData());
		else
			return "id:"+String.valueOf(this.getId());
	}
}

