package com.utils;


public class Node {
	private int id;
	private Object data;
	private Node parent;
	private Node[] children = new Node[2];
	private int lSubTreeHeight;
	private int rSubTreeHeight;
	private int balanceFactor;
	
	public Node(){
		
	}
	
	public Node(int id,Object o){
		this.id=id;
		setData(o);
	}
	
	public int getId() {
		return id;
	}
	public Object getData() {
		return data;
	}
	public void setData(Object data) {
		this.data = data;
	}
	public Node getParent() {
		return parent;
	}
	public void setParent(Node parent) {
		this.parent = parent;
	}
	public Node[] getChildren() {
		return children;
	}
	public Node getLChild() {
		return children[0];
	}
	public void setLChild(Node l){
		children[0]=l;
	}
	
	public Node getRChild() {
		return children[1];
	}
	
	public void setRChild(Node r){
		children[1]=r;
	}

	public void setChildren(Node[] children) {
		this.children = children;
	}

	public int getlSubTreeHeight() {
		//TODO calculate the left sub tree height
		return lSubTreeHeight;
	}
	public int getrSubTreeHeight() {
		//TODO calculate the right sub tree height
		return rSubTreeHeight;
	}
	public int getBalanceFactor() {
		//TODO calculate the balance factor
		return balanceFactor;
	}
	public void setBalanceFactor(int newBalance) {
		//TODO calculate the balance factor
		balanceFactor = newBalance;
	}

	public void setId(int id) {
		this.id = id;
	}

}
