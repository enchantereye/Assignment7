package com.utils;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;

public class AVLTree implements IAVLTree{

	private Node root = null;
	private boolean isBalance;

	@Override
	public Node get(int id) {
		return get(id,root);
	}

	public Node get(int id,Node p) {
		if(p == null)return null;
		if(id == p.getId()){
			return p;
		}else if(id < p.getId()){
			return get(id, p.getLChild());
		}else if(id > p.getId()){
			return get(id, p.getRChild());
		}else{
			return null;
		}
	}

	@Override
	public void insert(Node newNode) {
		if(newNode == null)return;
		if (root == null) {
			root = newNode;
		}else insert(root, newNode);
	}

	private void insert(Node pNode, Node newNode) {
		if(pNode==null){
			pNode = newNode;
			isBalance = false;
		}else if(pNode.getId() == newNode.getId()){
			JOptionPane.showMessageDialog(null, "插入节点重复");
		}else if(pNode.getId() > newNode.getId()){
			if(pNode.getLChild() == null ){
				pNode.setLChild(newNode);
				newNode.setParent(pNode);
			}else{
				insert(pNode.getLChild(),newNode);
			}
			if(!isBalance){
				switch (pNode.getBalanceFactor()) {
				case -1:
					pNode.setBalanceFactor(0);
					isBalance = true;
					break;
				case 0:
					pNode.setBalanceFactor(1);
					break;
				case 1:
					LRotation(pNode, !isBalance);
				default:
					break;
				}
			}
		}else{
			if(pNode.getRChild()==null){
				pNode.setRChild(newNode);
				newNode.setParent(pNode);
			}else{
				insert(pNode.getRChild(),newNode);
			}

			if(!isBalance){
				switch (pNode.getBalanceFactor()) {
				case 1:
					pNode.setBalanceFactor(0);
					isBalance = true;
					break;
				case 0:
					pNode.setBalanceFactor(-1);
					break;
				case -1:
					RRotation(pNode, !isBalance);
				default:
					break;
				}

			}
		}
		return;
	}


	@Override
	public void delete(int id) {
		Node p = get(id);
		if(p==null)return;
		if (p.getLChild() != null && p.getRChild() != null) {
			Node s = null;
			int i = id + 1;
			while (s==null) {
				s = get(i);
				i++;
			}
			p.setId(s.getId());
			p.setData(s.getData());
			id = i;
			p = s;
		}
		if(p!=root)return;
		
		if (root.getLChild() != null) {
			root.getLChild().setParent(null);
			root = root.getLChild();
		} else if (root.getRChild() != null) {
			root.getRChild().setParent(null);
			root = root.getRChild();
		} else {
			if (p.getParent().getBalanceFactor()==1&& p.getParent().getLChild() == p)
			{
				delete(p);		
				while(p.getParent().getBalanceFactor()<=1&&p.getParent().getBalanceFactor()>=-1){
					p=p.getParent();
					if(p.getParent()==null) break;
				}
				if(p.getParent()!=null){
					if(p.getParent().getBalanceFactor()==-2) RRotation(p.getParent(),true);
					else if(p.getParent().getBalanceFactor()==2) LRotation(p.getParent(),true);
				}
			}else if(p.getParent().getBalanceFactor()==-1&&p.getParent().getRChild()==p){
				delete(p);
				while(p.getParent().getBalanceFactor()<=1&&p.getParent().getBalanceFactor()>=-1){
					p=p.getParent();
					if(p.getParent()==null) break;
				}
				if(p.getParent()!=null){
					if(p.getParent().getBalanceFactor()==-2){
						RRotation(p.getParent(),true);
					}else if(p.getParent().getBalanceFactor()==2){
						LRotation(p.getParent(),true);
					}
				}
			}else if(p.getParent().getBalanceFactor()==0){
				delete(p);
			}else if(p.getParent().getBalanceFactor()==1&&p.getParent().getRChild()==p){
				delete(p);
				while(p.getParent().getBalanceFactor()<=1&&p.getParent().getBalanceFactor()>=-1){
					p=p.getParent();
					if(p.getParent()==null) break;
				}
				if(p.getParent()!=null){
					if(p.getParent().getBalanceFactor()==-2) RRotation(p.getParent(),true);
					else if(p.getParent().getBalanceFactor()==2) LRotation(p.getParent(),true);
				}
			}else if(p.getParent().getBalanceFactor()==-1&&p.getParent().getLChild()==p){
				delete(p);
				while(p.getParent().getBalanceFactor()<=1&&p.getParent().getBalanceFactor()>=-1){
					p=p.getParent();
					if(p.getParent()==null) break;
				}
				if(p.getParent()!=null){}
				if(p.getParent().getBalanceFactor()==-2) RRotation(p.getParent(),true);
				else if(p.getParent().getBalanceFactor()==2) LRotation(p.getParent(),true);
			}
		}


	}

	void delete(Node n) {
		if(n.getId()<n.getParent().getId()){
			if(n.getLChild()!=null){
				n.getLChild().setParent(n.getParent());
				n.getParent().setLChild(n.getLChild());
				n= n.getLChild();	
			}else if(n.getRChild()!=null){
				n.getRChild().setParent(n.getParent());
				n.getParent().setRChild(n.getRChild());
				n= n.getRChild();
			}else{
				n = n.getParent();
				n.setLChild(null);
			}
		}
		else if (n.getId()>n.getParent().getId()){
			if(n.getLChild()!=null){
				n.getLChild().setParent(n.getParent());
				n.getParent().setRChild(n.getLChild());
				n=n.getLChild();
			}else if(n.getRChild()!=null){
				n.getRChild().setParent(n.getParent());
				n.getParent().setRChild(n.getRChild());
				n=n.getRChild();
			}else{
				n= n.getParent();
				n.setRChild(null);
			}
		}
	}

	@Override
	public JTree printTree() {
		JTree tree = new JTree(make(root));
		JFrame frame = new JFrame("AVLTREE");
		frame.add(tree);
		frame.setSize(400, 400);
		frame.setVisible(true);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		return null;
	}
	private DefaultMutableTreeNode make(Node p){
		DefaultMutableTreeNode node = new DefaultMutableTreeNode(p.getData());
		if(p.getLChild()!=null)
			node.add(make(p.getLChild()));
		if(p.getRChild()!=null)
			node.add(make(p.getRChild()));

		return node;

	}

	public void RRotation(Node s,boolean ub) {

		Node u = new Node();
		Node r = new Node();
		r = s.getRChild();
		if (r.getBalanceFactor() == -1) {
			s.setRChild(r.getLChild());
			r.setLChild(s);
			s.setBalanceFactor(0);
			s = r;
		} else {
			u = r.getLChild();
			r.setLChild(u.getRChild());
			s.setRChild(u.getLChild());
			u.setRChild(r);
			u.setLChild(s);
			switch (u.getBalanceFactor()) {
			case 1:
				s.setBalanceFactor(0);
				r.setBalanceFactor(-1);
				break;
			case 0:
				s.setBalanceFactor(0);
				r.setBalanceFactor(0);
				break;
			case -1:
				s.setBalanceFactor(1);
				r.setBalanceFactor(0);
			}
			s = u;
		}
		s.setBalanceFactor(0);
		ub = false;
	}

	public void LRotation(Node s,boolean ub){
		Node u = new Node();
		Node r = new Node();
		r=s.getLChild();
		if(r.getBalanceFactor()==1){
			s.setLChild(r.getRChild());
			r.setRChild(s);
			s.setBalanceFactor(0);
			s=r;
		}else{
			u=r.getRChild();
			r.setRChild(u.getLChild());
			s.setLChild(u.getRChild());
			u.setLChild(r);
			u.setRChild(s);
			switch(u.getBalanceFactor()){
			case 1:
				s.setBalanceFactor(-1);
				r.setBalanceFactor(0);
				break;
			case 0:
				s.setBalanceFactor(0);
				r.setBalanceFactor(0);
				break;
			case -1:
				s.setBalanceFactor(0);
				r.setBalanceFactor(1);
			}
			s=u;
		}
		s.setBalanceFactor(0);
		ub = false ;
	}


	public static void main(String[] args) {
		AVLTree myTree = new AVLTree();
		Node node0 = new Node(1,"a");
		Node node1 = new Node(0,"b");
		Node node2 = new Node(4,"c");
		Node node3 = new Node(1,"d");
		Node node4 = new Node(3,"e");
		Node node5 = new Node(2,"f");
		Node node6 = new Node(6,"g");

		myTree.insert(node0);
		myTree.insert(node1);
		myTree.insert(node2);
		myTree.insert(node3);
		myTree.insert(node4);
		myTree.insert(node5);
		myTree.insert(node6);

		//get操作
		Node temp = new Node();
		temp=myTree.get(6);
		System.out.println("ID:"+temp.getId());
		System.out.println("Data:"+temp.getData());

		//insert操作
		Node a = new Node(44,"h");
		Node b = new Node(-3,"i");
		Node c = new Node(35,"j");
		Node d = new Node(13,"k");
		myTree.insert(a);
		myTree.insert(b);
		myTree.insert(c);
		myTree.insert(d);
		myTree.printTree();
		//delete操作
		myTree.delete(a);
		myTree.delete(b);
		myTree.delete(c);
		myTree.printTree();

	}

}
