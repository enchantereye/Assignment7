package twochashu;

public class Node {
	private int id;
	private Object data;
	private Node parent;
	private Node[] children = new Node[2];
	private int lSubTreeHeight;
	private int rSubTreeHeight;
	private int balanceFactor;
	public Node(int id,String data){
		this.id=id;
		this.data=data;
		this.children[0]=null;
		this.children[1]=null;
		this.parent=null;
	}
	public int getId() {
		return id;
	}
	public void SetId(int id){
		this.id=id;
	}
	public Object getData() {
		return data;
	}
	public void setData(Object data) {
		this.data = data;
	}
	public Node getParent() {
		return parent;
	}
	public void setParent(Node parent) {
		this.parent = parent;
	}
	public Node[] getChildren() {
		return children;
	}
	public void setChildren(Node[] children) {
		this.children = children;
	}
	public int getSubTreeHeight(Node n){//�����߶�
		if(n==null)return 0;
		Node[]c=n.getChildren();
		int lh=getSubTreeHeight(c[0]);
		int rh=getSubTreeHeight(c[1]);
		return (lh>rh?lh:rh)+1;
	}
	public int getlSubTreeHeight() {//�������߶�
		//TODO calculate the left sub tree height
		lSubTreeHeight=getSubTreeHeight(children[0]);
		return lSubTreeHeight;
	}
	public int getrSubTreeHeight() {//�������߶�
		//TODO calculate the right sub tree height
		rSubTreeHeight=getSubTreeHeight(children[1]);
		return rSubTreeHeight;
	}
	public int getBalanceFactor() {//ƽ������
		//TODO calculate the balance factor
		balanceFactor=getlSubTreeHeight()-getrSubTreeHeight();
		return balanceFactor;
	}
	public void setLChild(Node Lchild) {//������
		// TODO Auto-generated method stub
		this.children[0] = Lchild;
		if(Lchild!=null)
		Lchild.setParent(this);
		
	}
	public void setRChild(Node Rchild) {//������
		// TODO Auto-generated method stub
		this.children[1] = Rchild;
		if(Rchild!=null)
		Rchild.setParent(this);
	}
}
