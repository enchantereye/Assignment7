package twochashu;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;

public class AVLTree implements IAVLTree {
	private Node root=null;//��ʼ�����ڵ�
	public Node getRoot() {
		return root;
	}
	 
	@Override
	public Node get(int id) {
		// TODO Auto-generated method stub
		return getInfo(root,id);
	}
	private Node getInfo(Node n,int id){
		if(n==null)return null;
		if(n.getId()>id)return getInfo(n.getChildren()[0],id);//Ѱ��������
		if(n.getId()<id)return getInfo(n.getChildren()[1],id);//Ѱ��������
		return n;//���ʱ
	}

	@Override
	public void insert(Node newNode) {
		// TODO Auto-generated method stub
		root=insert(newNode,root);
	}
	private Node insert(Node newNode,Node n){
		//����Ϊ��ʱ��ֱ�ӷ����½��
		if(n==null)return newNode;
		//������������ʱ
		if(newNode.getId()<n.getId()){
			if(n.getChildren()[0]==null){
				n.setLChild(newNode);
			}
			//�ݹ飬����������
			n.setLChild(insert(newNode,n.getChildren()[0]));
			//��ת����
			if(n.getBalanceFactor()==2)
				if(newNode.getId()<n.getChildren()[0].getId())
					n=LSingleRotation(n);
				else
					n=RSingleRotation(n);
		}
		//���������������
		else if(newNode.getId()>n.getId()){
			if(n.getChildren()[1]==null){
				n.setRChild(newNode);
			}
			//�ݹ����
			n.setRChild(insert(newNode,n.getChildren()[1]));
			//��ת����
			if(n.getBalanceFactor()==-2)
				if(newNode.getId()>n.getChildren()[1].getId())
					n=RSingleRotation(n);
				else
					n=RDoubleRotation(n);
		}
		else;
		root.setParent(null);
		return n;
	}
	
	private Node RDoubleRotation(Node n) {
		// TODO Auto-generated method stub
		n.setRChild(LSingleRotation(n.getChildren()[1]));
		return RSingleRotation(n);
	}

	private Node RSingleRotation(Node n) {
		// TODO Auto-generated method stub
		Node m=n.getChildren()[1];
		n.setRChild(m.getChildren()[0]);
		m.setLChild(n);
		return m;
	}

	private Node LSingleRotation(Node n) {
		// TODO Auto-generated method stub
		Node m=n.getChildren()[0];
		n.setLChild(m.getChildren()[1]);
		m.setRChild(n);
		return m;
	}
    private Node LDoubleRotation(Node n){
    	n.setLChild(RSingleRotation(n.getChildren()[0]));
		return LSingleRotation(n);
    }
	@Override
	public void delete(int id) {//ɾ���ڵ�
		// TODO Auto-generated method stub
		delete(id,root);
	}
	private void delete(int id,Node n){
		//Ѱ��Ҫɾ���Ľڵ㣬��Ϊ�գ�����
		Node d=getInfo(n,id);
		if(d==null)return;
		//������������Ϊ��ʱ��ֱ��ɾ��
		if(d.getChildren()[0]==null&&d.getChildren()[1]==null){
			if(d.getParent()==null){
				root=null;return;
			}
			else if(d==d.getParent().getChildren()[0]){
				d.getParent().setLChild(null);
			}
			else d.getParent().setRChild(null);
			Node e=d.getParent();
			//Ѱ�ҵ�һ��ƽ������Ϊ2�Ľڵ�
			while((e!=null)&&e.getBalanceFactor()<2&&e.getBalanceFactor()>-2){
				e=e.getParent();//��ȡ�丸�ڵ�
			}
			if(e==null)return;//ƽ��ʱ����
			else if(e.getBalanceFactor()==2){//��ƽ��ʱ����LR,RR��ת
				if(id>e.getChildren()[0].getId())
					e=LSingleRotation(e);
				else
					e=LDoubleRotation(e);
			}
			else{
				if(id<e.getChildren()[1].getId())
					e=RSingleRotation(e);
				else
					e=RDoubleRotation(e);
			}
	    }
		//������Ϊ�գ���������Ϊ��ʱ
		else if(d.getChildren()[0]==null){
			if(d==root){
				root=d.getChildren()[1];return;
			}
			else if(d.getParent().getChildren()[0]==d)
				d.getParent().setLChild(d.getChildren()[1]);
			else
				d.getParent().setRChild(d.getChildren()[1]);
			Node e=d.getParent();
			//Ѱ�ҵ�һ����ƽ���
			while((e!=null)&&e.getBalanceFactor()<2&&e.getBalanceFactor()>-2){
				e=e.getParent();//��ȡ�丸�ڵ�
			}
			if(e==null)return;
			else if(e.getBalanceFactor()==2){//��ƽ��ʱ����LR,RR��ת
				if(id>e.getChildren()[0].getId())
					e=LSingleRotation(e);
				else
					e=LDoubleRotation(e);
			}
			else{
				if(id<e.getChildren()[1].getId())
					e=RSingleRotation(e);
				else
					e=RDoubleRotation(e);
			}
		}
		//������Ϊ�գ���������Ϊ��ʱ
		else if(d.getChildren()[1]==null){
			if(d==root){
				root=d.getChildren()[0];return;
			}
			else if(d.getParent().getChildren()[0]==d)
			    d.getParent().setLChild(d.getChildren()[0]);
			else
				d.getParent().setRChild(d.getChildren()[0]);
			Node e=d.getParent();
			//Ѱ�ҵ�һ����ƽ���
			while((e!=null)&&e.getBalanceFactor()<2&&e.getBalanceFactor()>-2){
				e=e.getParent();//��ȡ�丸�ڵ�
			}
			if(e==null)return;
			else if(e.getBalanceFactor()==2){//��ƽ��ʱ����LR,RR��ת
				if(id>e.getChildren()[0].getId())
					e=LSingleRotation(e);
				else
					e=LDoubleRotation(e);
			}
			else{
				if(id<e.getChildren()[1].getId())
					e=RSingleRotation(e);
				else
					e=RDoubleRotation(e);
			}
		}
		//������������Ϊ��
		else{//Ѱ��ֱ�Ӻ�̽ڵ�
			Node f=d.getChildren()[1];
			while(f.getChildren()[0]!=null){
				f=f.getChildren()[0];
			}
			d.SetId(f.getId());
			d.setData(f.getData());
			//ɾ�������һ�������ĺ�̽ڵ�
			delete(f.getId(),d.getChildren()[1]);
		}
	}

public static void readFile() throws IOException{//��ȡDAT����
		    File file=new File("C:\\Users\\zhujiatong123\\Documents\\Tencent Files\\920478183\\FileRecv\\tree_data.dat");
			BufferedReader reader=null;
			String tempString=null;
			try 
			{
			System.out.println("��ȡ���ݳɹ�");
			reader = new BufferedReader(new FileReader(file));
			while ((tempString = reader.readLine()) != null) 
			{
			System.out.println(tempString);
			}
			reader.close();
		    } 
			catch (FileNotFoundException e) 
			{
		    // TODO Auto-generated catch block
			e.printStackTrace();
			} 
			catch (IOException e) 
			{
		    // TODO Auto-generated catch block
			e.printStackTrace();
		    }
			finally
			{
			if(reader != null)
			{
			try 
			{
		    reader.close();
			} 
			catch (IOException e) 
			{
			// TODO Auto-generated catch block
			e.printStackTrace();
			} 
			}
			}
}
private void createNodes(DefaultMutableTreeNode rootNode, Node root2) {
	// TODO Auto-generated method stub
	if(root2==null)return;
	if(root2.getChildren()[0]!=null){//�������ݹ����ڵ�
		DefaultMutableTreeNode defaultNode=new DefaultMutableTreeNode(root2.getChildren()[0].getData());
		rootNode.add(defaultNode);
		createNodes(defaultNode,root2.getChildren()[0]);
	}
	rootNode.add(new DefaultMutableTreeNode(root2.getData()));//���뵱ǰ�ڵ�
	if(root2.getChildren()[1]!=null){//�������ݹ����ڵ�
		DefaultMutableTreeNode defaultNode2=new DefaultMutableTreeNode(root2.getChildren()[1].getData());
		rootNode.add(defaultNode2);
		createNodes(defaultNode2,root2.getChildren()[1]);
	}
}

@Override
public JTree printTree() {
	// TODO Auto-generated method stub
	DefaultMutableTreeNode rootNode=new DefaultMutableTreeNode();
	createNodes(rootNode,root);
	JTree temp=new JTree(rootNode);
	return temp;
}
}
