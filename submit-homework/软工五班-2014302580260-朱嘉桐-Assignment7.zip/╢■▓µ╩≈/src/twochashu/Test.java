package twochashu;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JTree;
import javax.swing.border.EmptyBorder;



public class Test extends JFrame{
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public static void main(String[]args){
	AVLTree tree1=new AVLTree();
		//��ʼ���ڵ�
		Node n1=new Node(1,"ant");	
		Node n2=new Node(2,"apple");	
		Node n3=new Node(3,"art");	
		Node n4=new Node(4,"baby");	
		Node n5=new Node(5,"banan");	
		Node n6=new Node(6,"car");	
		Node n7=new Node(7,"door");			
		Node n8=new Node(8,"dress");	
		Node n9=new Node(9,"frog");	
		Node n10=new Node(10,"love");	
		Node n11=new Node(11,"mint");	
		Node n12=new Node(12,"rice");	
		Node n13=new Node(13,"show");	
		Node n14=new Node(14,"table");	
		Node n15=new Node(15,"tree");	
		Node n16=new Node(16,"trouble");	
		Node n17=new Node(17,"window");
		//������
		tree1.insert(n1);
		tree1.insert(n2);
		tree1.insert(n3);
		tree1.insert(n4);
		tree1.insert(n5);
		tree1.insert(n6);
		tree1.insert(n7);
		tree1.insert(n8);
		tree1.insert(n9);
		tree1.insert(n10);
		tree1.insert(n11);
		tree1.insert(n12);
		tree1.insert(n13);
		tree1.insert(n14);
		tree1.insert(n15);
		tree1.insert(n16);
		tree1.insert(n17);
		TreeFrame TFrame=new TreeFrame(tree1);
		TFrame.setVisible(true);
    }
}
class TreeFrame extends JFrame{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	//Ҫ��ӡ��JTree����
	private AVLTree tree;
	private JTree j=new JTree();
	private JPanel panel=new JPanel();
	//����Ҫɾ���Ľ��ID���ı���
	private JTextField t=new JTextField();
	private JLabel label=new JLabel();
	private JButton b1 =new JButton("��ȡ��Ϣ");
	private JButton b2 =new JButton("����");
	private JButton b3 =new JButton("ɾ��");
	
	public TreeFrame(AVLTree a){
		tree=a;
		j=tree.printTree();
		
		panel.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(panel);
		panel.setLayout(null);
		
		j.setBounds(10, 10, 300, 800);
		label.setBounds(350, 150, 150, 50);
		t.setBounds(350, 250, 150, 30);
		b1.setBounds(370, 320, 100, 50);
		b2.setBounds(370, 390, 100, 50);
		b3.setBounds(370, 460, 100, 50);
		
		panel.add(j);
		panel.add(label);
		panel.add(t);
		panel.add(b1);
		panel.add(b2);
		panel.add(b3);
		//���ҽڵ�
		b1.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				if(!t.getText().equals(null)){
					int id=Integer.parseInt(t.getText());
					//��AVL�����ҵ����
					Node n=tree.get(id);
					String s=n.getId()+" "+n.getData();
					label.setText(s);
				}
			}
		});
		//����ڵ�
		b2.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				if(!t.getText().equals(null)){
					String s=t.getText();
					int id=Integer.parseInt(s.split(" ")[0]);
					System.out.println(id);
					String data=s.split(" ")[1];
					System.out.println(data);
					Node n=new Node(id,data);
					//��AVL���в�����
					tree.insert(n);
					//���������µ�Frame
					TreeFrame tf=new TreeFrame(tree);
					//ˢ��ҳ��
					update(tf);
				}
			}
		});
		//ɾ���ڵ�
		b3.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				if(!t.getText().equals(null)){
					int id=Integer.parseInt(t.getText());
					//��AVL����ɾ�����
					tree.delete(id);
					//���������µ�Frame
					TreeFrame tf=new TreeFrame(tree);
					//ˢ��ҳ��
					update(tf);
				}
			}
		});
		
		panel.setVisible(true);
		setVisible(true);
		setSize(550, 850);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
//ˢ��ҳ��
public void update(TreeFrame t){
	this.setVisible(false);
	t.setVisible(true);
}
}