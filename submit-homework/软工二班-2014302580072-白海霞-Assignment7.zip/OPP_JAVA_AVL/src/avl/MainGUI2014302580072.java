package avl;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.JTree;
import javax.swing.JLabel;

import java.awt.Font;


public class MainGUI2014302580072 extends JFrame{
	/**
	 * 
	 */
	private static final long serialVersionUID = -8661645051760137938L;
	
	private static JTree jtree;
	private static JFrame a;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	
	private String data1; 
	

	public MainGUI2014302580072(final AVLTree2014302580072 avltree){	
		//��������
		a=new JFrame("My Tree");
		a.setBounds(250, 150, 500, 400);
		a.getContentPane().setLayout(null);
		
		//����JTree
		jtree = avltree.printTree();
		jtree.setBounds(10, 10, 250, 300);
		a.getContentPane().add(jtree);
		jtree.setVisible(true);
		
		textField = new JTextField();
		textField.setFont(new Font("����", Font.PLAIN, 14));
		textField.setBounds(328, 44, 52, 21);
		a.getContentPane().add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setFont(new Font("����", Font.PLAIN, 14));
		textField_1.setColumns(10);
		textField_1.setBounds(422, 45, 52, 21);
		a.getContentPane().add(textField_1);
		
		textField_2 = new JTextField();
		textField_2.setFont(new Font("����", Font.PLAIN, 14));
		textField_2.setColumns(10);
		textField_2.setBounds(328, 116, 52, 21);
		a.getContentPane().add(textField_2);
		
		textField_3 = new JTextField();
		textField_3.setFont(new Font("����", Font.PLAIN, 14));
		textField_3.setColumns(10);
		textField_3.setBounds(328, 190, 52, 21);
		a.getContentPane().add(textField_3);
		
		textField_4 = new JTextField();
		textField_4.setFont(new Font("����", Font.PLAIN, 14));
		textField_4.setColumns(10);
		textField_4.setBounds(422, 187, 52, 21);
		a.getContentPane().add(textField_4);
				
		//���밴ť
		JButton button_insert=new JButton("����");
		button_insert.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				jtree.setVisible(false);
				String id = textField.getText();
				int id1 = Integer.parseInt(id);
				String data = textField_1.getText();
				Node newNode = new Node(id1,data);
				avltree.insert(id1, newNode);
				
			}
		});
		a.getContentPane().add(button_insert);
		button_insert.setBounds(409, 78, 65, 25);
		
		//ɾ����ť
		JButton button_delete = new JButton("\u5220\u9664");
		button_delete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String id = textField_2.getText();
				int id1 = Integer.parseInt(id);
				if(avltree.get(id1) != null){
					avltree.delete(id1);
					jtree = avltree.printTree();
					jtree.setBounds(10, 10, 250, 300);
					a.getContentPane().add(jtree);
					jtree.setVisible(true);	
				}
			}
		});
		button_delete.setBounds(409, 152, 65, 25);
		a.getContentPane().add(button_delete);
		
		//���Ұ�ť
		JButton button_get = new JButton("\u67E5\u627E");
		button_get.addActionListener(new ActionListener() {
			public void
			actionPerformed(ActionEvent e) {
				String id = textField_3.getText();
				int id1 = Integer.parseInt(id);
				Node n = null;
				n = avltree.get(id1);
				if(n != null){
					data1 = n.getData();
					textField_4.setText(data1);
				}
				
			}
		});
		button_get.setBounds(409, 229, 65, 25);
		a.getContentPane().add(button_get);
		
		JLabel lblId = new JLabel("id:");
		lblId.setFont(new Font("����", Font.PLAIN, 14));
		lblId.setBounds(292, 43, 30, 25);
		a.getContentPane().add(lblId);
		
		JLabel lblData = new JLabel("data:");
		lblData.setFont(new Font("����", Font.PLAIN, 14));
		lblData.setBounds(384, 43, 36, 25);
		a.getContentPane().add(lblData);
		
		JLabel label = new JLabel("id:");
		label.setFont(new Font("����", Font.PLAIN, 14));
		label.setBounds(292, 115, 30, 25);
		a.getContentPane().add(label);
		
		JLabel label_1 = new JLabel("id:");
		label_1.setFont(new Font("����", Font.PLAIN, 14));
		label_1.setBounds(292, 188, 30, 25);
		a.getContentPane().add(label_1);
		
		JLabel label_2 = new JLabel("data:");
		label_2.setFont(new Font("����", Font.PLAIN, 14));
		label_2.setBounds(384, 187, 36, 25);
		a.getContentPane().add(label_2);
		
		JButton button_print = new JButton("\u6253\u5370");
		button_print.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				jtree = avltree.printTree();
				jtree.setVisible(true);
			}
		});
		button_print.setBounds(391, 328, 93, 23);
		a.getContentPane().add(button_print);
		
		 
		a.setVisible(true);
		}
	public static void main(String[] args){
		AVLTree2014302580072 avltree1 = new AVLTree2014302580072();
		avltree1.insert(1, new Node(1,"ant"));
		avltree1.insert(2, new Node(2,"apple"));
		avltree1.insert(3, new Node(3,"art"));
		avltree1.insert(4, new Node(4,"baby"));
		avltree1.insert(5, new Node(5,"banana"));
		avltree1.insert(6, new Node(6,"car"));
		avltree1.insert(7, new Node(7,"door"));
		avltree1.insert(8, new Node(8,"dress"));
		avltree1.insert(9, new Node(9,"frog"));
		avltree1.insert(10, new Node(10,"love"));
		avltree1.insert(11, new Node(11,"mint"));
		avltree1.insert(12, new Node(12,"rice"));
		avltree1.insert(13, new Node(13,"show"));
		avltree1.insert(14, new Node(14,"table"));
		avltree1.insert(15, new Node(15,"tree"));
		avltree1.insert(16, new Node(16,"trouble"));
		avltree1.insert(17, new Node(17,"window"));
		
		MainGUI2014302580072 gui = new MainGUI2014302580072(avltree1);
	}
	}