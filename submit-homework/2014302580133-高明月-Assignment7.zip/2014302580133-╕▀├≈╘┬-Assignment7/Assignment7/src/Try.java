import java.util.Iterator;

/**
 * 
 */

/**
 * @author Administrator
 *
 */
public class Try {

	 public static void main(String[] args) {
		 AVLTree tree = new AVLTree();  
		 Node node=new Node();
		 node.setData("С��");
			tree.insert(1,node);  
			 Node node1=new Node();
			 node1.setData("Сè");
				tree.insert(2,node1);  
				Node node2=new Node();
				 node2.setData("С��");
					tree.insert(3,node2); 
					
					
	 }

}
