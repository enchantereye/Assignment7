/**
 * 
 */

/**
 * @author Administrator
 *
 */
public class AVLTree {

	private static final int LH=1;
	private static final int EH=0;
	private static final int RH=-1;
	
	private Node root=null;//avl����
	
	//����һ���ڵ�
	public void insert(int id, Node newNode){
		newNode.setId(id);
		Node t=root;
		if(t==null){
			root=newNode;
		}//�������޸�����ô�²���ĵ�Ϊ��
		else{
		Node parent;
		do{
			parent=t;
			if(newNode.getId()<parent.getId()){
				t=t.getChildren()[0];
			}else if(newNode.getId()>parent.getId()){
				t=t.getChildren()[1];
			}else{
				System.out.println("ƽ�����д�����ͬ����\n��������ʱ����");
			}
		}while(t!=null);
		
		if(newNode.getId()<parent.getId()){
			parent.getChildren()[0]=newNode;
		}else{
			parent.getChildren()[1]=newNode;
		}
		
		while(parent!=null){
			if(parent.getBalanceFactor()==0){
				break;
			}
			if(Math.abs(parent.getBalanceFactor())==2){
				fixAfterInSertion(parent);
				break;
			}
			parent=parent.getParent();
		}
		}
		
	}
	
	
	/**
	 * @param parent
	 */
	private void fixAfterInSertion(Node p) {
		// TODO Auto-generated method stub
		
	}


	private void fixAfterInsertion(Node p){
		if(p.getBalanceFactor()==2){
			leftBalance(p);
		}
		if(p.getBalanceFactor()==-2){
			rightBalance(p);
		}
	}
	
	private void leftBalance(Node t){
		boolean heightLower=true;
		Node l=t.getChildren()[0];
		switch(l.getBalanceFactor()){
		case LH://��㣬������������ת�����ĸ߶ȼ�С
			t.setBalanceFactor(EH);
			l.setBalanceFactor(EH);
			rotateRight(t);
			break;
		case RH://�Ҹߣ����������
			Node rd=l.getChildren()[1];
			switch(rd.getBalanceFactor()){
			case LH://���1
				t.setBalanceFactor(RH);
				l.setBalanceFactor(EH);
				break;
			case EH://���2
				t.setBalanceFactor(EH);
				l.setBalanceFactor(EH);
				break;
			case RH://���3
				t.setBalanceFactor(EH);
				l.setBalanceFactor(LH);
				break;
			}
			rd.setBalanceFactor(EH);
			rotateLeft(t.getChildren()[0]);
			rotateRight(t);
			break;
		case EH://�������4���������ֻ����ɾ��ʱ�ſ��ܳ��֣���ת����������߶Ȳ���
			l.setBalanceFactor(RH);
			t.setBalanceFactor(LH);
			rotateRight(t);
			heightLower=false;
			break;
			
			}
		}
	
	private void rightBalance(Node t){
		boolean heightLower=true;
		Node r=t.getChildren()[1];
		switch(r.getBalanceFactor()){
		case LH://��ߣ����������
			Node ld=r.getChildren()[0];
			switch(ld.getBalanceFactor()){
			case LH://���1
				t.setBalanceFactor(EH);
				r.setBalanceFactor(RH);
				break;
			case EH://���2
			t.setBalanceFactor(EH);
			r.setBalanceFactor(EH);
			break;
			case RH://���3
				t.setBalanceFactor(LH);
				r.setBalanceFactor(EH);
				break;
			}
			ld.setBalanceFactor(EH);
			rotateRight(t.getChildren()[1]);
			rotateLeft(t);
			break;
		case RH://�Ҹߣ���������
			t.setBalanceFactor(EH);
			r.setBalanceFactor(EH);
			rotateLeft(t);
			break;
		case EH://�������4
			r.setBalanceFactor(LH);
			t.setBalanceFactor(RH);
			rotateLeft(t);
			heightLower=false;
			break;
		}
	}
	
	private void rotateLeft(Node p)
	{
		System.out.println("��"+p.getId()+p.getData()+"����");
		if(p!=null){
			Node r=p.getChildren()[1];
			p.setChild(r.getChildren()[0], 1);
			if(r.getChildren()[0]!=null)
			{
				r.getChildren()[0].setParent(p);
				r.setParent(p.getParent());
			}
			if(p.getParent()==null)
				root=r;  
			else if(p.getParent().getChildren()[0]==p)
			  p.getParent().setChild(r, 0);
			else
			{
				p.getParent().setChild(r, 1);
				r.setChild(p, 0);
				p.setParent(r);
			}	
		}
	}
	
	private void rotateRight(Node p)
	{
		System.out.println("��"+p.getId()+p.getData()+"����");
		if(p!=null){
			Node l=p.getChildren()[0];
			p.setChild(l.getChildren()[1], 0);
			if(l.getChildren()[1]!=null)
				{
				l.getChildren()[1].setParent(p);
				l.setParent(p.getParent());
				}
			
			if (p.getParent()==null)
				root=l;
			else if(p.getParent().getChildren()[1]==p)
				p.getParent().setChild(l, 1);
				else{
					p.getParent().setChild(l, 0);
					l.setChild(p, 1);
					p.setParent(l);
				}
			
		}
		
	}
	
	
}
