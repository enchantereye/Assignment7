import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTree;

public class MainAVLTree {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		new AVLTreePlay();
	}
	
}

class AVLTreePlay extends JFrame{
	AVLTree tree=new AVLTree();
	String line;
	//Node node=new Node();
	public AVLTreePlay() throws NumberFormatException, IOException{
		FileReader fr=new FileReader("tree_data.dat");
		BufferedReader br=new BufferedReader(fr);
			while((line=br.readLine())!=null){
				Node node=new Node();
				String [] cons=line.split("#");
				node.setData(cons[0]);
				node.setId(Integer.valueOf(cons[1]));
				tree.insert(node);
			}
			br.close();	
		JFrame jf=new JFrame("AVLTree");
		jf.setBounds(400, 130, 450, 500);
		jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		JOptionPane.showMessageDialog( null,"�������������������" ,
				  "ȷ��", JOptionPane.PLAIN_MESSAGE );
		JTree jtree=tree.printTree();
		jf.setVisible(true);
		jf.add(jtree);
		JOptionPane.showMessageDialog( null,"get������idΪ4�Ľ��:"+tree.get(4),
				  "ȷ��", JOptionPane.PLAIN_MESSAGE );
		JOptionPane.showMessageDialog( null,"ɾ��������ɾ��idΪ4�Ľ��" ,
				  "ȷ��", JOptionPane.PLAIN_MESSAGE );
		tree.delete(4);
		jtree=tree.printTree();
		jf.add(jtree);
		jf.repaint();
		
}
}
