import javax.swing.JOptionPane;
import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;

public class AVLTree implements IAVLTree
{
	Node root;
	
	@Override
	public Node get(int id)
	{
		return getNode(root,id);
	}
	
	//����
	 @Override
     public void insert(Node newNode)
     {
			// TODO �Զ����ɵķ������
			if(root==null)
			{
				root=newNode;
			}
			else
				insert(root,newNode);
	 }
		
    //ɾ��
	@Override
	public void delete(int id)
	{
		Node p=get(id);
		if(p!=null)
		{
			
			if(p.getChildren(0)!=null&&p.getChildren(1)!=null)
			{
				Node s=p.getChildren(1);
				Node r=p;
				while(s.getChildren(0)!=null)
				{
					r=s;s=s.getChildren(0);
				}
				p.setId(s.getId());
				p.setData(s.getData());
				p=s;
			}	//pΪ���ֻ��һ������
			
			
			if(p==root)
			{
				for(int i=0;i<2;i++)
				{
					if(root.getChildren(i)!=null)
					{
						root.getChildren(i).setParent(null);
						root=root.getChildren(i);
						i=3;
					}
				}
				
			}
			else if(p!=null)
			{			
				if(p.getParent().getBalanceFactor()==0)
					delete(p);
				
				else if(p.getParent().getBalanceFactor()==1&&p.getParent().getChildren(0)==p)
				{
					delete(p);
					//Node q=p.getParent();
					while(p.getParent()!=null&&p.getParent().getBalanceFactor()<=1&&p.getParent().getBalanceFactor()>=-1)
					{
						p=p.getParent();										
					}
					if(p.getParent()==null)
					{
						return;
					}
					else 
					{
						switch(p.getParent().getBalanceFactor()){
						case 2:
							LRotation(p.getParent());
						case -2:
							RRotation(p.getParent());
						}
					}
				}
				else if(p.getParent().getBalanceFactor()==-1&&p.getParent().getChildren(1)==p)
				{
					delete(p);
					while(p.getParent()!=null&&p.getParent().getBalanceFactor()<=1&&p.getParent().getBalanceFactor()>=-1)
					{
						p=p.getParent();										
					}
					if(p.getParent()==null)
					{
						return;
					}
					else 
					{
						switch(p.getParent().getBalanceFactor()){
						case 2:
							LRotation(p.getParent());
						case -2:
							RRotation(p.getParent());
						}
					}
				}

				if(p.getParent().getBalanceFactor()==1&&p.getParent().getChildren(1)==p)
				{
					delete(p);
					while(p.getParent()!=null&&p.getParent().getBalanceFactor()<=1&&p.getParent().getBalanceFactor()>=-1)
					{
						p=p.getParent();										
					}
					if(p.getParent()==null)
					{
						return;
					}
					else 
					{
						switch(p.getParent().getBalanceFactor()){
						case 2:
							LRotation(p.getParent());
						case -2:
							RRotation(p.getParent());
						}
					}
				}
				else if(p.getParent().getBalanceFactor()==-1&&p.getParent().getChildren(0)==p)
				{
					delete(p);
					while(p.getParent()!=null&&p.getParent().getBalanceFactor()<=1&&p.getParent().getBalanceFactor()>=-1)
					{
						p=p.getParent();										
					}
					if(p.getParent()==null)
					{
						return;
					}
					else 
					{
						switch(p.getParent().getBalanceFactor()){
						case 2:
							LRotation(p.getParent());
						case -2:
							RRotation(p.getParent());
						}
					}
				}
			}
		}
	}
	
	@Override
	public JTree printTree()
	{
		// TODO �Զ����ɵķ������
		DefaultMutableTreeNode dt=new DefaultMutableTreeNode();
		printTree(dt,root);
		return new JTree(dt);
	}
	
	

	private Node getNode(Node node,int id)
	{
		if(node!=null)
		{
			if(node.getId()==id)
				return node;
			else
			{
				if(node.getId()>id)
					return getNode(node.getChildren(0),id);
				else
					return getNode(node.getChildren(1),id);
			}
		}
		else
			return null;
	}
	private void insert(Node p,Node newNode)
	{
		if(newNode.getId()<p.getId())
		{
			//����������
			if(p.getChildren(0)==null)
			{
				p.setChild(newNode, 0);
				newNode.setParent(p);
			}
			else
				insert(p.getChildren(0),newNode);
				
			if(p.getBalanceFactor()==1)
			{
				if(p.getParent()!=null)
				{
					if(p.getParent().getBalanceFactor()>1||p.getParent().getBalanceFactor()<-1)
						LRotation(p.getParent());
				}
			}
		
			
		}
		else if(newNode.getId()==p.getId())
			System.out.println("�ý���Ѵ��ڡ�");
		else if(newNode.getId()>p.getId())
		{
			//����������			
			if(p.getChildren(1)==null)
			{
				p.setChild(newNode, 1);
				newNode.setParent(p);
			}
			else
				insert(p.getChildren(1),newNode);

			if(p.getBalanceFactor()==-1)
			{
				if(p.getParent()!=null)
				{
					if(p.getParent().getBalanceFactor()>1||p.getParent().getBalanceFactor()<-1)
						RRotation(p.getParent());
				} 
			}
			
		}
		
	}
	//����ת
	private void LRotation(Node s)
	{
		Node u;
		Node r=s.getChildren(0);
		switch(r.getBalanceFactor())
		{
		case 1:
			s.setChild(r.getChildren(1),0);
			if(r.getChildren(1)!=null)
			r.getChildren(1).setParent(s);				
			r.setParent(s.getParent());
			r.setChild(s, 1);
			if(s.getParent()==null)
			{
				root=r;
			}
			else
			{
				for(int i=0;i<2;i++)
				{
					if(s==s.getParent().getChildren(i))
						s.getParent().setChild(r, i);
				}
			}
			
			s.setParent(r);
		case -1:
			u=r.getChildren(1);
			r.setChild(u.getChildren(0), 1);
			if(u.getChildren(1)!=null)
			u.getChildren(0).setParent(r);
			u.setParent(s.getParent());
			s.setChild(u.getChildren(1), 0);
			u.getChildren(1).setParent(s);
			u.setChild(r, 0);
			u.setChild(s, 1);
			
			if(s.getParent()==null)
			{
				root=u;
			}
			else
			{
				for(int i=0;i<2;i++)
				{
					if(s==s.getParent().getChildren(i))
						s.getParent().setChild(u, i);
				}
			}
			
			s.setParent(u);
			r.setParent(u);
		}
		
	}
	//����ת
	private void RRotation(Node s)
	{
		Node u;
		Node r=s.getChildren(1);
		switch(r.getBalanceFactor())
		{
		case 1:
			u=r.getChildren(0);
			r.setChild(u.getChildren(1), 0);
			if(u.getChildren(1)!=null)
				u.getChildren(1).setParent(r);
			u.setParent(s.getParent());
			s.setChild(u.getChildren(0), 1);			
			u.getChildren(0).setParent(s);
			u.setChild(r, 1);
			u.setChild(s, 0);
			if(s.getParent()==null)
				root=u;
			else
			{
				for(int i=0;i<2;i++)
				{
					if(s==s.getParent().getChildren(i))
						s.getParent().setChild(u, i);
				}
			}
			s.setParent(u);
			r.setParent(u);
		case -1:
              s.setChild(r.getChildren(0), 1);
			
			if(r.getChildren(0)!=null)
				r.getChildren(0).setParent(s);
			
			r.setParent(s.getParent());
			r.setChild(s, 0);
			if(s.getParent()==null)
				root=r;
			else
			{
				for(int i=0;i<2;i++)
				{
					if(s==s.getParent().getChildren(i))
						s.getParent().setChild(r, i);
				}
			}		
			s.setParent(r); 		
		}
	}

	
	
	
	
	
	private void delete(Node node)
	{
		Node p=node.getParent();
		if(p.getChildren(0)==node)
		{		
			
			if(node.getChildren(0)==null&&node.getChildren(1)==null)
			{
				node=p;
				node.setChild(null, 0);
			}
			else
			{
				for(int i=0;i<2;i++)
				{
					if(node.getChildren(i)!=null)
					{
						node.getChildren(i).setParent(p);
						p.setChild(node.getChildren(i), 0);
						node=node.getChildren(i);
					}
				}
			}
		}
		
		else if(p.getChildren(1)==node)
		{
			if(node.getChildren(0)==null&&node.getChildren(1)==null)
			{
				node=p;
				node.setChild(null, 1);
			}
			else
			{
				
				for(int i=0;i<2;i++)
				{
					if(node.getChildren(i)!=null)
					{
						node.getChildren(i).setParent(p);
						p.setChild(node.getChildren(i), 1);
						node=node.getChildren(i);
					}
				}
			}

		}
	}
	
	private void printTree(DefaultMutableTreeNode defalutNode,Node node)
	{
		
		if(node!=null)
		{
			for(int i=0;i<2;i++)
			{
				if(node.getChildren(i)!=null)
				{
					DefaultMutableTreeNode defalutNode0=new DefaultMutableTreeNode(node.getChildren(i));
					defalutNode.add(defalutNode0);
					if(i==0)
						defalutNode.add(new DefaultMutableTreeNode(node));
					printTree(defalutNode0,node.getChildren(i));
				}
			}
		
		}
	}
	
}

