public class Node {
	private int id;
	private Object data;
	private Node parent;
	private Node[] children = new Node[2];
	private int lSubTreeHeight;
	private int rSubTreeHeight;
	private int balanceFactor;
	
	public int getId() {
		return id;
	}
	public Object getData() {
		return data;
	}
	public Node getParent() {
		return parent;
	}
	public Node[] getChildren() {
		return children;
	}
	
	public Node getChildren(int id)
	{
		return children[id];
	}
	
	public int getlSubTreeHeight() {
		//TODO calculate the left sub tree height
		//boolean b=this.getChildren(0).getlSubTreeHeight()>this.getChildren(0).getrSubTreeHeight();
		if(this.getChildren(0)!=null)
		{
			boolean b=this.getChildren(0).getlSubTreeHeight()>this.getChildren(0).getrSubTreeHeight();
			if(b==true)
				lSubTreeHeight=this.getChildren(0).getrSubTreeHeight()+1;
			else
			{
				lSubTreeHeight=this.getChildren(0).getlSubTreeHeight()+1;
			}
		}
		else
		{
			rSubTreeHeight=0;
		}
		
		return lSubTreeHeight;
	}
	public int getrSubTreeHeight() {
		//TODO calculate the right sub tree height
		if(this.getChildren(1)!=null)
		{
			if(this.getChildren(1).getlSubTreeHeight()<this.getChildren(1).getrSubTreeHeight())
				rSubTreeHeight=this.getChildren(1).getrSubTreeHeight()+1;
			else
				rSubTreeHeight=this.getChildren(1).getlSubTreeHeight()+1;
		}
		else
		{
			rSubTreeHeight=0;
		}
		return rSubTreeHeight;
	}
	public int getBalanceFactor() {
		//TODO calculate the balance factor
		return this.getlSubTreeHeight()-this.getrSubTreeHeight();
		
	}
	public void setId(int id)
	{
		this.id = id;
	}
	public void setData(Object data) {
		this.data = data;
	}
	
	public void setParent(Node parent) {
		this.parent = parent;
	}
	
	public void setChildren(Node[] children) {
		this.children = children;
	}
	public void setChild(Node child, int id){
		this.children[id] = child;
	}
	public void setBanlanceFactor(int balanceFactor)
	{
		this.balanceFactor=balanceFactor;
	}

	@Override
	public String toString()
	{
		String id=String.valueOf(this.getId());
		String data=String.valueOf(this.getData());
		if(this.getData()==null)
			return "id:"+id+" dataΪ��";
		else
			return "id:"+id+" data:"+data;
	}
}