package com.jyz.avlTree;

public class Main {
	
	public static void main(String[] args){
		AVLTree avlTree=new AVLTree();
		Node[] nodes = new Node[17];
		nodes[0]=new Node(1,"ant");
		nodes[1]=new Node(2, "apple");
		nodes[2]=new Node(3, "art");
		nodes[3]=new Node(4, "baby");
		nodes[4]=new Node(5, "banan");
		nodes[5]=new Node(6, "car");
		nodes[6]=new Node(7, "door");
		nodes[7]=new Node(8, "dress");
		nodes[8]=new Node(9, "frog");
		nodes[9]=new Node(10, "love");
		nodes[10]=new Node(11, "mint");
		nodes[11]=new Node(12, "rice");
		nodes[12]=new Node(13, "show");
		nodes[13]=new Node(14, "table");
		nodes[14]=new Node(15, "tree");
		nodes[15]=new Node(16, "trouble");
		nodes[16]=new Node(17, "window");
		avlTree.setRoot(nodes[0]);
		for(int i=1;i<nodes.length;i++){
			avlTree.insert(nodes[i]);
		}
		for(int i=1;i<nodes.length;i++){
			System.out.println(i+"    "+nodes[i].getBalanceFactor());
		}
		
		avlTree.printTree();
	}
}
