package com.jyz.avlTree;

public class Node {
	private int id;
	private Object data;
	private Node parent;
	private Node lChild;
	private Node rChild;
	private int lSubTreeHeight;
	private int rSubTreeHeight;
	private int balanceFactor;
	
	
	public Node(int id,Object data){
		this.parent=null;
		this.lChild=null;
		this.rChild=null;
		this.balanceFactor=0;
		this.id=id;
		this.data=data;
	}
	
	public int getId() {
		return this.id;
	}
	public Object getData() {
		return this.data;
	}
	
	
	
	
	
	public Node getParent() {
		return this.parent;
	}
	public void setParent(Node parent) {
		this.parent = parent;
	}
	public Node getLChild() {
		return this.lChild;
	}
	public void setLChild(Node lChild){
		this.lChild =lChild;
	}
	public Node getRChild() {
		return this.rChild;
	}
	public void setRChild(Node rChild){
		this.rChild =rChild;
	}
	
	
	
	
	
	
	
	public int getlSubTreeHeight() {
		//TODO calculate the left sub tree height
		if(this.getLChild()==null){lSubTreeHeight=0;}
		else{
			if(this.getLChild().getlSubTreeHeight()>this.getLChild().getrSubTreeHeight()){
				lSubTreeHeight=this.getLChild().getlSubTreeHeight()+1;
			}else{
				lSubTreeHeight=this.getLChild().getrSubTreeHeight()+1;
			}
		}
		return lSubTreeHeight;
	}
	public int getrSubTreeHeight() {
		//TODO calculate the right sub tree height
		if(this.getRChild()==null){rSubTreeHeight=0;}
		else{
			if(this.getRChild().getlSubTreeHeight()>this.getRChild().getrSubTreeHeight()){
				rSubTreeHeight=this.getRChild().getlSubTreeHeight()+1;
			}else{
				rSubTreeHeight=this.getRChild().getrSubTreeHeight()+1;
			}
		}
		return rSubTreeHeight;
	}
	public int getBalanceFactor() {
		//TODO calculate the balance factor
		balanceFactor=this.getlSubTreeHeight()-this.getrSubTreeHeight();
	    return balanceFactor;
	}
	

}

