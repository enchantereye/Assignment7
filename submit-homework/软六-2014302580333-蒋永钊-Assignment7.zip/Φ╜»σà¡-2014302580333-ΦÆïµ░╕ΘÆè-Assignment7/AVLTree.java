package com.jyz.avlTree;
import java.awt.Container;
import java.util.concurrent.locks.ReentrantReadWriteLock;

import javax.swing.JFrame;
import javax.swing.JTree;
import javax.swing.WindowConstants;
import javax.swing.tree.DefaultMutableTreeNode;

public class AVLTree implements IAVLTree{
	private Node root;
	public void setRoot(Node root) {
		this.root = root;
	}

	@Override
	public Node get(int id) {
		// TODO Auto-generated method stub
		Node temp=root;
		while(temp!=null){
			
			if(id==temp.getId()){
				System.out.println("find "+temp.getId()+"-"+temp.getData());
				return temp;
			}
			else if(temp.getId()<id){
				temp=temp.getRChild();
			}
			else{
				temp=temp.getLChild();
			}
			
		}
		System.out.println("don't find "+String.valueOf(id));
		return null;
	}

	public void insert(Node newNode){
			Node temp=root;
			int id=temp.getId();
			while(temp!=null){
				id=temp.getId();
				if(temp.getId()<newNode.getId()){temp=temp.getRChild();}
				else if(temp.getId()>newNode.getId()){temp=temp.getLChild();}
				else{System.out.println("don't insert the same node");}
			}
			insert(id, newNode);
			System.out.println("insert "+newNode.getId()+"-"+newNode.getData());
			
			temp=newNode;
		    while(temp!=null){
		    	if(temp.getBalanceFactor()==2){}
		    	else if (temp.getBalanceFactor()==-2){
		    		//右旋转
		    		if(temp==root){
		    			root=temp.getRChild();
		    		}
		    		Node n1=temp.getRChild();
		    		Node n2=temp.getRChild().getLChild();
		    		n1.setParent(null);
		    		n1.setLChild(null);
		    		temp.setRChild(null);
		    		if(n2!=null){
		    			n2.setParent(null);
		    			temp.setRChild(n2);
			    		n2.setParent(temp);
		    		}
		    		n1.setLChild(temp);
		    		temp.setParent(n1);
		    		
		    		
		    	}
		    	else{
		    		temp=temp.getParent();
		    	}
		    }
		
		
	}
	@Override
	public void insert(int id, Node newNode) {
		// TODO Auto-generated method stub
		Node parent=get(id);
		if(id<newNode.getId()){
			parent.setRChild(newNode);
			newNode.setParent(parent);
		}else if(id>newNode.getId()){
			parent.setLChild(newNode);
			newNode.setParent(parent);
		}
	}

	@Override
	public void delete(int id) {
		// TODO Auto-generated method stub
		
	}

	public DefaultMutableTreeNode getAVLTree(Node root){
		DefaultMutableTreeNode defaultMutableTreeNode = new DefaultMutableTreeNode(root.getData());
		if(root.getLChild()!=null)
			defaultMutableTreeNode.add(getAVLTree(root.getLChild()));
		if(root.getRChild()!=null)
			defaultMutableTreeNode.add(getAVLTree(root.getRChild()));
		
		return defaultMutableTreeNode;
	}
	
	@Override
	public JTree printTree() {
		// TODO Auto-generated method stub
		System.out.println(root.getId());
		JFrame jFrame=new JFrame("jTree-AVLTree");
		JTree jTree=new JTree(getAVLTree(root));
		jFrame.add(jTree);
		jFrame.setSize(500, 500);
		jFrame.setVisible(true);
		jFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		return null;
	}

}
