import javax.swing.JTree;
import javax.swing.JFrame;
import javax.swing.tree.DefaultMutableTreeNode;

public class AVLTree implements IAVLTree{
	public Node root;
	public AVLTree(){
		root=null;
	}
	public void insert(int id){
		if(root==null){
			 System.out.println( "" );
		}
		root=insert(id,root);
	}
	public Node get(int id){
		Node p=root;
		while(p!=null)
			if(id<p.getId()) p=p.getChildren()[0];
			else if(id>p.getId()) p=p.getChildren()[1];
			else if(id==p.getId()) return p;
		return p;
	}
	public Node insert(int id,Node newNode){
		if( newNode == null )
            return new Node(id,null,null);
        
        int compareResult = id-newNode.getId();
        
        if( compareResult < 0 )
        {
            newNode.getChildren()[0]=insert( id, newNode.getChildren()[0] );//��x������������
            if( newNode.getlSubTreeHeight()- newNode.getrSubTreeHeight() == 2 )//����ƽ��
                if( id-newNode.getChildren()[0].getId()  < 0 )//LL�ͣ������ͣ�
                    newNode = rotateWithLeftChild( newNode );
                else   //LR�ͣ������ͣ�
                    newNode = doubleWithLeftChild( newNode );
        }
        else if( compareResult > 0 )
        {
            newNode.getChildren()[1] = insert( id, newNode.getChildren()[1] );//��x������������
            if( newNode.getrSubTreeHeight()- newNode.getlSubTreeHeight() == 2 )//����ƽ��
                if( id-newNode.getChildren()[1].getId() > 0 )//RR�ͣ������ͣ�
                    newNode = rotateWithRightChild( newNode );
                else                           //RL��
                    newNode = doubleWithRightChild( newNode );
        }
        else
            ;  // �ظ����ݣ�ʲôҲ����
        
        return newNode;
        
	}
	public void printTree(){
            printTree( root );
	}
	 private void printTree( Node t )
	    {
	        if( t != null )
	        {
	            printTree( t.getChildren()[0] );
	            System.out.println( t.getId() );
	            printTree( t.getChildren()[1] );
	        }
	    }
	 private Node rotateWithLeftChild( Node k2 )
	    {
	        Node k1 = k2.getChildren()[0];
	        k2.getChildren()[0] = k1.getChildren()[1];
	        k1.getChildren()[1] = k2;
	        //k2.height = Math.max( height( k2.left ), height( k2.right ) ) + 1;
	       // k1.height = Math.max( height( k1.left ), k2.height ) + 1;
	        return k1;
	    }
	    //����������ת��������RR��
	    private Node rotateWithRightChild( Node k1 )
	    {
	        Node k2 = k1.getChildren()[1];
	        k1.getChildren()[1] = k2.getChildren()[0];
	        k2.getChildren()[0] = k1;
	        //k1.height = Math.max( height( k1.left ), height( k1.right ) ) + 1;
	        //k2.height = Math.max( height( k2.right ), k1.height ) + 1;
	        return k2;
	    }
	    //˫��ת��������LR��
	    private Node doubleWithLeftChild( Node k3 )
	    {
	        k3.getChildren()[0] = rotateWithRightChild( k3.getChildren()[0] );
	        return rotateWithLeftChild( k3 );
	    }
	    //˫��ת,������RL��
	    private Node doubleWithRightChild( Node k1 )
	    {
	        k1.getChildren()[1] = rotateWithLeftChild( k1.getChildren()[1] );
	        return rotateWithRightChild( k1 );
	    }
	    public static void main(String[] args){
	    	AVLTree t=new AVLTree();
	    	t.insert(4);
	    	t.insert(5);
	    	t.insert(7);
	    	t.insert(2);
	    	t.insert(1);
	    	t.insert(6);
	    	t.printTree();
	    	
	    }
	    
	/*public void LRotation(Node s){
		Node u,r=s.getChildren()[0];
		if(r.getBalanceFactor()==1){
			s.getChildren()[0]=r.getChildren()[1];
			r.getChildren()[1]=s;
			s=r;
		}
		else{
			u=r.getChildren()[1];
			r.getChildren()[1]=u.getChildren()[0];
			u.getChildren()[0]=r;
			s.getChildren()[0]=u.getChildren()[1];
			u.getChildren()[1]=s;
			s=u;
		}
		
	}
	public void RRotation(Node s){
		Node u,r=s.getChildren()[1];
		if(r.getBalanceFactor()==1){
			 s.getChildren()[1]=r.getChildren()[0];
			 r.getChildren()[0]=s;
			 s=r;
			 }
		else{
			u=r.getChildren()[1];
			r.getChildren()[0]=u.getChildren()[1];
			u.getChildren()[1]=r;
			s.getChildren()[1]=u.getChildren()[0];
			u.getChildren()[0]=s;
			s=u;
		}
	}*/
	public void delete(int id){
		Node c,s,r=root,q=null;
		Node p1=this.get(id);
		int x=q.getId();
		if(p1.getChildren()[0]!=null && p1.getChildren()[1]!=null){
			s=p1.getChildren()[1];
			r=p1;
			while(s.getChildren()[0]!=null){
				r=s;
				s=s.getChildren()[0];
			}
			p1=s;
			q=r;
		}
		if(p1.getChildren()[0]!=null)
			c=p1.getChildren()[0];
		else
			c=p1.getChildren()[1];
		if(p1==root)
			root=c;
		else if(p1==q.getChildren()[0])
			q.getChildren()[0]=c;
		else
			q.getChildren()[1]=c;
		
			
	}
	/*public JTree printTree(){
		DefaultMutableTreeNode node1 = new DefaultMutableTreeNode(4);
        node1.add(new DefaultMutableTreeNode(2));
        node1.add(new DefaultMutableTreeNode(6));
        
 
        DefaultMutableTreeNode node2 = new DefaultMutableTreeNode("���۲�");
        node2.add(new DefaultMutableTreeNode(new User("СҶ")));
        node2.add(new DefaultMutableTreeNode(new User("С��")));
        node2.add(new DefaultMutableTreeNode(new User("С��")));
 
        DefaultMutableTreeNode top = new DefaultMutableTreeNode("ְԱ����");
 
        top.add(new DefaultMutableTreeNode(new User("�ܾ���")));
        top.add(node1);
        top.add(node2);
        final JTree tree = new JTree(top);
        JFrame f = new JFrame("JTreeDemo");
        f.add(tree);
        f.setSize(300, 300);
        f.setVisible(true);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        return tree;

	}
	 */
	
	 
	// ����û�и��ڵ���ӽڵ㡢���������ӽڵ�����ڵ㣬��ʹ��ָ�����û�����������г�ʼ����
    // public DefaultMutableTreeNode(Object userObject)
	        /*DefaultMutableTreeNode node1 = new DefaultMutableTreeNode("������");
	        node1.add(new DefaultMutableTreeNode(new User("С��")));
	        node1.add(new DefaultMutableTreeNode(new User("С��")));
	        node1.add(new DefaultMutableTreeNode(new User("С��")));
	 
	        DefaultMutableTreeNode node2 = new DefaultMutableTreeNode("���۲�");
	        node2.add(new DefaultMutableTreeNode(new User("СҶ")));
	        node2.add(new DefaultMutableTreeNode(new User("С��")));
	        node2.add(new DefaultMutableTreeNode(new User("С��")));
	 
	        DefaultMutableTreeNode top = new DefaultMutableTreeNode("ְԱ����");
	 
	        top.add(new DefaultMutableTreeNode(new User("�ܾ���")));
	        top.add(node1);
	        top.add(node2);
	        final JTree tree = new JTree(top);
	        JFrame f = new JFrame("JTreeDemo");
	        f.add(tree);
	        f.setSize(300, 300);
	        f.setVisible(true);
	        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	        */

}
