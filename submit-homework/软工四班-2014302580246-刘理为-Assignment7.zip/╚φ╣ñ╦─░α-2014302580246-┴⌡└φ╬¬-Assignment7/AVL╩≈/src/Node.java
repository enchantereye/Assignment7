
public class Node {
	private int id;
	private Object data;
	private Node parent;
	private Node[] children = new Node[2];
	private int lSubTreeHeight;
	private int rSubTreeHeight;
	private int balanceFactor;
	Node(int id){
		this(id,null,null);
	}
	Node(int id,Node lt,Node rt){
		this.id=id;
		this.getChildren()[0]=lt;
		this.getChildren()[1]=rt;
		
	}
	
	public int getId() {
		return id;
	}
	public Object getData() {
		return data;
	}
	public void setData(Object data) {
		this.data = data;
	}
	public Node getParent() {
		return parent;
	}
	public void setParent(Node parent) {
		this.parent = parent;
	}
	public Node[] getChildren() {
		return children;
	}
	public void setChildren(Node[] children) {
		this.children = children;
	}
	public void setChild(Node child, int id){
		this.children[id] = child;
	}
	public int getlSubTreeHeight() {
		//TODO calculate the left sub tree height
		//һֱ������Һ��ӣ�ֱ�����Һ��ӽ��ΪNULL��ȡ���Һ����и߶Ƚϴ��һ����Ϊ�µĴ��ݽ�㣻ÿ��ȡһ���µĽ�㣬�߶�����1
		Node p = this.getChildren()[0];//����Һ��ӽ�㣻
		if(p!=null){
			Node[] q=p.getChildren();
			//����Һ��ӵ����Һ��ӣ�
			int lSubTreeHeight=1;
	        if(q[0]==null||q[1]==null){
	        	lSubTreeHeight=1;
	        }
		   //�߶�
	        else{
		    Node newNode=null;//�µĴ��ݽ��
		    while(q!=null)
		     {
			if(q[0].getHeight()>q[1].getHeight())
				newNode=q[0];
			else
				newNode=q[1];
			lSubTreeHeight++;
			q=newNode.getChildren();
			
		     }
	        }
		return lSubTreeHeight;
		}
		return lSubTreeHeight;
		/*
		 * if(p==null)
		 * return null;
		 * else
		 * return max(p.getrS,p.getlS)
		 */
			
		
		
	}
	public int getrSubTreeHeight() {
		//TODO calculate the right sub tree height
		Node p = this.getChildren()[1];//����Һ��ӽ�㣻
		if(p!=null){
			Node[] q=p.getChildren();
			//����Һ��ӵ����Һ��ӣ�
			int rSubTreeHeight=1;
	        if(q[0]==null||q[1]==null){
	        	rSubTreeHeight=1;
	        }
		   //�߶�
	        else{
		    Node newNode=null;//�µĴ��ݽ��
		    while(q!=null)
		     {
			if(q[0].getHeight()>q[1].getHeight())
				newNode=q[0];
			else
				newNode=q[1];
			rSubTreeHeight++;
			q=newNode.getChildren();
			
		     }
	        }
		return rSubTreeHeight;
		}
		return rSubTreeHeight;
		
	}
	public int getHeight(){
		if(this.getlSubTreeHeight()>this.getrSubTreeHeight())
			return this.getlSubTreeHeight();
		else
			return this.getrSubTreeHeight();
	}
	public int getBalanceFactor() {
		//TODO calculate the balance factor
		balanceFactor=lSubTreeHeight-rSubTreeHeight;
		return balanceFactor;
	}
}
