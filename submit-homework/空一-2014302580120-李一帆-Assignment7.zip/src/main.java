
public class main {

	public static void main(String[] args) {
		Object[] data = {"ant", "apple", "art", "baby", "banana", "car", "door", "dress", "frog", "love", "mint", "rice", "show", "table", "tree", "trouble", "window"};
		
		AVLTree tree = new AVLTree();
		//����������
		for (int i=1; i<=17; i++) {
			tree.insert(i, new Node(i, data[i-1]));
		}
		
		GUI frame = new GUI(tree);
		frame.setVisible(true);

	}

}
