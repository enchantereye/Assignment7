
public class Node {
	private int id;
	private Object data;
	private Node parent;
	//��children[2]��ΪlChild��rChild
	private Node lChild;
	private Node rChild;
	private int lSubTreeHeight;
	private int rSubTreeHeight;
	private int balanceFactor;
	
	public Node() {}
	
	public Node(int id, Object data) {
		this.id = id;
		this.data = data;
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	public Object getData() {
		return data;
	}
	public void setData(Object data) {
		this.data = data;
	}
	public Node getParent() {
		return parent;
	}
	public void setParent(Node parent) {
		this.parent = parent;
	}
	
	public Node getlChild() {
		return lChild;
	}
	public void setlChild(Node lChild) {
		this.lChild = lChild;
	}
	
	public Node getrChild() {
		return rChild;
	}
	public void setrChild(Node rChild) {
		this.rChild = rChild;
	}
	
	public int getlSubTreeHeight() {
		return lSubTreeHeight;
	}
	/**
	 * ���ý���������߶�
	 * @param height
	 */
	public void setlSubTreeHeight(int height) {
		this.lSubTreeHeight = height;
	}
	public int getrSubTreeHeight() {
		return rSubTreeHeight;
	}
	/**
	 * ���ý���������߶�
	 * @param height
	 */
	public void setrSubTreeHeight(int height) {
		this.rSubTreeHeight = height;
	}
	public int getBalanceFactor() {
		return balanceFactor;
	}
	/**
	 * ���������ƽ������
	 * @param balanceFactor
	 */
	public void setBalanceFactor(int balanceFactor) {
		this.balanceFactor = balanceFactor;
	}

	

}