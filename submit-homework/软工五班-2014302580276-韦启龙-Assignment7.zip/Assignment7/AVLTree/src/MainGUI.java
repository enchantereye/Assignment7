import javax.swing.*;
import javax.swing.tree.TreeNode;
import javax.swing.tree.TreePath;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.Enumeration;

/**
 * Created by Jason_Wei on 2016/1/3.
 */
public class MainGUI
{
    private static JTree jTree;
    private static JScrollPane pane;

    public static void expandTree(JTree tree)
    {
        TreeNode root = (TreeNode) tree.getModel().getRoot();
        expandAll(tree, new TreePath(root), true);
    }

    private static void expandAll(JTree tree, TreePath parent, boolean expand)
    {
        TreeNode node = (TreeNode) parent.getLastPathComponent();
        if (node.getChildCount() >= 0) {
            for (Enumeration e = node.children(); e.hasMoreElements(); )
            {
                TreeNode n = (TreeNode) e.nextElement();
                TreePath path = parent.pathByAddingChild(n);
                expandAll(tree, path, expand);
            }
        }
        if (expand)
        {
            tree.expandPath(parent);
        }
        else
        {
            tree.collapsePath(parent);
        }
    }

    public static void main(String[] args)
    {
        JFrame window = new JFrame("AVLTree");

        window.setResizable(false);

        window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        window.setSize(500, 650);

        window.setVisible(true);
        window.setLayout(null);


        AVLTree tree = new AVLTree();
        try
        {
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(new FileInputStream("tree_data.dat")));
            String line = bufferedReader.readLine();
            while (line != null)
            {
                String[] data = line.split("#");
                tree.insert(new Node(Integer.parseInt(data[1]), data[0]));
                line = bufferedReader.readLine();
            }
        } catch (Exception e)
        {
            e.printStackTrace();
        }

        jTree = tree.printTree();
        expandTree(jTree);

        pane = new JScrollPane(jTree);
        window.add(pane);
        pane.setBounds(0, 2, 495, 470);
        pane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        pane.setBorder(BorderFactory.createLineBorder(Color.GRAY, 4));

        JLabel label = new JLabel("     id:");
        window.add(label);
        label.setBounds(2, 472, 50, 50);

        JTextField input_find = new JTextField("");
        window.add(input_find);
        input_find.setBounds(52, 472, 200, 50);

        JButton find = new JButton("Get");
        window.add(find);
        find.setBounds(252, 472, 100, 50);

        find.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent event) {
                Node temp = tree.get(Integer.parseInt(input_find.getText()));
                if (temp == null)
                    JOptionPane.showConfirmDialog(null, "Not found the node with this ID",
                            "!!!", JOptionPane.CANCEL_OPTION);
                else
                    JOptionPane.showConfirmDialog(null, "Found: id=" + temp.getId() + " data=" + temp.getData(),
                            "!!!", JOptionPane.CANCEL_OPTION);
            }
        });

        JLabel label2 = new JLabel("     id:");
        window.add(label2);
        label2.setBounds(2, 522, 50, 50);

        JTextField input_delete = new JTextField("");
        window.add(input_delete);
        input_delete.setBounds(52, 522, 200, 50);

        JButton delete = new JButton("Delete");
        window.add(delete);
        delete.setBounds(252, 522, 100, 50);

        delete.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent event) {
                tree.delete(Integer.parseInt(input_delete.getText()));

                window.remove(pane);
                jTree = tree.printTree();
                expandTree(jTree);
                pane = new JScrollPane(jTree);
                window.add(pane);
                pane.setBounds(0, 2, 495, 470);
                pane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
                pane.setBorder(BorderFactory.createLineBorder(Color.GRAY, 4));
            }
        });

        JLabel label3 = new JLabel("     id:");
        window.add(label3);
        label3.setBounds(2, 572, 50, 50);

        JTextField input_insert_id = new JTextField("");
        window.add(input_insert_id);
        input_insert_id.setBounds(52, 572, 100, 50);

        JLabel label4 = new JLabel("   data:");
        window.add(label4);
        label4.setBounds(152, 572, 50, 50);

        JTextField input_insert_data = new JTextField("");
        window.add(input_insert_data);
        input_insert_data.setBounds(202, 572, 100, 50);

        JButton insert = new JButton("Insert");
        window.add(insert);
        insert.setBounds(302, 572, 100, 50);

        insert.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent event) {
                tree.insert(new Node(Integer.parseInt(input_insert_id.getText()), input_insert_data.getText()));

                window.remove(pane);
                jTree = tree.printTree();
                expandTree(jTree);
                pane = new JScrollPane(jTree);
                window.add(pane);
                pane.setBounds(0, 2, 495, 470);
                pane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
                pane.setBorder(BorderFactory.createLineBorder(Color.GRAY, 4));
            }
        });
    }
}
