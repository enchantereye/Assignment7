import javax.swing.*;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;

/**
 * Created by Jason_Wei on 2016/1/3.
 */
public class AVLTree implements IAVLTree
{
    private static final int LEFT_HIGHER = 1;
    private static final int EQUAL_HEIGHT = 0;
    private static final int RIGHT_HIGHER = -1;

    private Node root = null;

    private void rotateLeft(Node p)
    {
        if (p != null)
        {
            Node r = p.getRChild();
            p.setRChild(r.getLChild());
            if (r.getLChild() != null)
                r.getLChild().setParent(p);
            r.setParent(p.getParent());
            if (p.getParent() == null)
                root = r;
            else if (p.getParent().getLChild() == p)
                p.getParent().setLChild(r);
            else
                p.getParent().setRChild(r);
            r.setLChild(p);
            p.setParent(r);
        }
    }

    private void rotateRight(Node p)
    {
        if (p != null)
        {
            Node l = p.getLChild();
            p.setLChild(l.getRChild());
            if (l.getRChild() != null)
                l.getRChild().setParent(p);
            l.setParent(p.getParent());
            if (p.getParent() == null)
                root = l;
            else if (p.getParent().getRChild() == p)
                p.getParent().setRChild(l);
            else
                p.getParent().setLChild(l);
            l.setRChild(p);
            p.setParent(l);
        }
    }

    private void fixAfterInsertion(Node p)
    {
        if (p.getBalance() == 2)
        {
            leftBalance(p);
        }
        if (p.getBalance() == -2)
        {
            rightBalance(p);
        }
    }

    private boolean leftBalance(Node t)
    {
        boolean heightLower = true;
        Node l = t.getLChild();
        switch (l.getBalance())
        {
            case LEFT_HIGHER:
                t.setBalance(EQUAL_HEIGHT);
                l.setBalance(EQUAL_HEIGHT);
                rotateRight(t);
                break;
            case RIGHT_HIGHER:
                Node rd = l.getRChild();
                switch (rd.getBalance())
                {
                    case LEFT_HIGHER:
                        t.setBalance(RIGHT_HIGHER);
                        l.setBalance(EQUAL_HEIGHT);
                        break;
                    case EQUAL_HEIGHT:
                        t.setBalance(EQUAL_HEIGHT);
                        l.setBalance(EQUAL_HEIGHT);
                        break;
                    case RIGHT_HIGHER:
                        t.setBalance(EQUAL_HEIGHT);
                        l.setBalance(LEFT_HIGHER);
                        break;
                }
                rd.setBalance(EQUAL_HEIGHT);
                rotateLeft(t.getLChild());
                rotateRight(t);
                break;
            case EQUAL_HEIGHT:
                l.setBalance(RIGHT_HIGHER);
                t.setBalance(LEFT_HIGHER);
                rotateRight(t);
                heightLower = false;
                break;
        }
        return heightLower;
    }

    private boolean rightBalance(Node t)
    {
        boolean heightLower = true;
        Node r = t.getRChild();
        switch (r.getBalance())
        {
            case LEFT_HIGHER:
                Node ld = r.getLChild();
                switch (ld.getBalance())
                {
                    case LEFT_HIGHER:
                        t.setBalance(EQUAL_HEIGHT);
                        r.setBalance(RIGHT_HIGHER);
                        break;
                    case EQUAL_HEIGHT:
                        t.setBalance(EQUAL_HEIGHT);
                        r.setBalance(EQUAL_HEIGHT);
                        break;
                    case RIGHT_HIGHER:
                        t.setBalance(LEFT_HIGHER);
                        r.setBalance(EQUAL_HEIGHT);
                        break;
                }
                ld.setBalance(EQUAL_HEIGHT);
                rotateRight(t.getRChild());
                rotateLeft(t);
                break;
            case RIGHT_HIGHER:
                t.setBalance(EQUAL_HEIGHT);
                r.setBalance(EQUAL_HEIGHT);
                rotateLeft(t);
                break;
            case EQUAL_HEIGHT:
                r.setBalance(LEFT_HIGHER);
                t.setBalance(RIGHT_HIGHER);
                rotateLeft(t);
                heightLower = false;
                break;
        }
        return heightLower;
    }

    private void deleteNode(Node p)
    {
        if (p.getLChild() != null && p.getRChild() != null)
        {
            Node s = successor(p);
            p.setId(s.getId());
            p.setData(s.getData());
            p = s;
        }
        Node replacement = (p.getLChild() != null ? p.getLChild() : p.getRChild());

        if (replacement != null)
        {
            replacement.setParent(p.getParent());
            if (p.getParent() == null)
                root = replacement;
            else if (p == p.getParent().getLChild())
                p.getParent().setLChild(replacement);
            else
                p.getParent().setRChild(replacement);

            p.setLChild(null);
            p.setRChild(null);
            p.setParent(null);

            fixAfterDeletion(replacement);

        }
        else if (p.getParent() == null)
        {
            root = null;
        }
        else
        {
            fixAfterDeletion(p);
            if (p.getParent() != null) {
                if (p == p.getParent().getLChild())
                    p.getParent().setLChild(null);
                else if (p == p.getParent().getRChild())
                    p.getParent().setRChild(null);
                p.setParent(null);
            }
        }
    }

    private Node successor(Node t) //��ȡ��ɾ���ڵ�����������ֱ�Ӻ�̽ڵ�
    {
        if (t == null)
            return null;
        else if (t.getRChild() != null)
        {
            Node p = t.getRChild();
            while (p.getLChild() != null)
                p = p.getLChild();
            return p;
        }
        else
        {
            Node p = t.getParent();
            Node ch = t;
            while (p != null && ch == p.getRChild())
            {
                ch = p;
                p = p.getParent();
            }
            return p;
        }
    }

    private void fixAfterDeletion(Node p)
    {
        boolean heightLower = true;
        Node t = p.getParent();
        while (t != null && heightLower)
        {
            if (t.getId() > p.getId())
            {
                t.setBalance(t.getBalance() + 1);
            }else
            {
                t.setBalance(t.getBalance() - 1);
            }
            if (Math.abs(t.getBalance()) == 1)
            {
                break;
            }
            Node r = t;
            if (t.getBalance() == 2)
            {
                heightLower = leftBalance(r);
            }
            else if(t.getBalance() == -2)
            {
                heightLower = rightBalance(r);
            }
            t = t.getParent();
        }
    }

    private DefaultMutableTreeNode getTreeNode(Node node)
    {
        DefaultMutableTreeNode root = new DefaultMutableTreeNode();
        if (node == null)
            return null;
        root.setUserObject(node.getData() + "(id=" + node.getId() + ")");

        DefaultMutableTreeNode left = getTreeNode(node.getLChild());
        DefaultMutableTreeNode right = getTreeNode(node.getRChild());
        if (left != null)
            root.add(left);
        if (right != null)
            root.add(right);

        return root;
    }

    public Node get(int id)
    {
        Node tmp = root;
        while (tmp != null)
        {
            if (tmp.getId() == id)
            {
                return tmp;
            }
            else if (id < tmp.getId())
            {
                tmp = tmp.getLChild();
            }
            else
            {
                tmp = tmp.getRChild();
            }
        }
        return null;
    }

    public void insert(Node newNode)
    {
        Node t = root;
        if (t == null)
        {
            root = newNode;
            return;
        }
        Node parent;
        do
        {
            parent = t;
            if (newNode.getId() < t.getId())
            {
                t = t.getLChild();
            }
            else if (newNode.getId() > t.getId())
            {
                t = t.getRChild();
            }
            else
            {
                return;
            }
        } while (t != null);

        newNode.setParent(parent);
        if (newNode.getId() < parent.getId())
        {
            parent.setLChild(newNode);
        }
        else
        {
            parent.setRChild(newNode);
        }
        while (parent != null)
        {
            if (newNode.getId() < parent.getId())
            {
                parent.setBalance(parent.getBalance() + 1);
            }
            else
            {
                parent.setBalance(parent.getBalance() - 1);
            }
            if (parent.getBalance() == 0)
            {
                break;
            }
            if (Math.abs(parent.getBalance()) == 2)
            {
                fixAfterInsertion(parent);
                break;
            }
            parent = parent.getParent();
        }
    }

    @Override
    public void delete(int id)
    {
        Node e = get(id);
        if (e != null)
            deleteNode(e);
    }

    public JTree printTree()
    {
        return new JTree(new DefaultTreeModel(getTreeNode(root)));
    }
}
