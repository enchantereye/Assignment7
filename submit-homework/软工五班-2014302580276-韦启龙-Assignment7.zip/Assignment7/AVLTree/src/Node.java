/**
 * Created by Jason_Wei on 2016/1/3.
 */
public class Node
{
    private int id;
    private Object data;

    private Node lChild;
    private Node rChild;
    private Node parent;
    private int balance;

    public Node(int id, Object data)
    {
        this.id = id;
        this.data = data;
    }

    public int getId()
    {
        return id;
    }

    public void setId(int id)
    {
        this.id = id;
    }

    public Object getData()
    {
        return data;
    }

    public void setData(Object data)
    {
        this.data = data;
    }

    public Node getLChild()
    {
        return lChild;
    }

    public void setLChild(Node lChild)
    {
        this.lChild = lChild;
    }

    public Node getRChild()
    {
        return rChild;
    }

    public void setRChild(Node rChild)
    {
        this.rChild = rChild;
    }

    public Node getParent()
    {
        return parent;
    }

    public void setParent(Node parent)
    {
        this.parent = parent;
    }

    public int getBalance()
    {
        return balance;
    }

    public void setBalance(int balance)
    {
        this.balance = balance;
    }

    @Override
    public String toString() {
        return id +" BF="+balance;
    }
}
