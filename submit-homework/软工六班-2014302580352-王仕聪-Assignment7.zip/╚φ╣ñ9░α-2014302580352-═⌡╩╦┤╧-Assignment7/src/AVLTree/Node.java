package AVLTree;

public class Node<T> {
	private int id;
	private T data;
	private Node<T> parent;
	private Node<T> left;
	private Node<T> right;
	private int lSubTreeHeight;
	private int rSubTreeHeight;
	private int balanceFactor;
	public Node(int id,T data){
		this.id=id;
		this.data=data;
		this.parent=null;
		this.left=null;
		this.right=null;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public T getData() {
		return data;
	}
	public void setData(T data) {
		this.data = data;
	}
	public Node<T> getParent() {
		return parent;
	}
	public void setParent(Node<T> parent) {
		this.parent = parent;
	}
	public Node<T> getLeft() {
		return left;
	}
	public Node<T> getRight() {
		return right;
	}
	public void setLeft(Node<T> left) {
		this.left=left;
	}
	public void setRight(Node<T> right){
		this.right=right;
	}
	public int getHeight(Node<T> node){
		int height=1;
		if(node==null){
			return 0;
		}
		int left=getHeight(node.getLeft());
		int right=getHeight(node.getRight());
		int add=left>right?left:right;
		height+=add;
		return height;
	}
	public int getBalanceFactor() {
		//TODO calculate the balance factor
		lSubTreeHeight=getHeight(left);
		rSubTreeHeight=getHeight(right);
		balanceFactor=lSubTreeHeight-rSubTreeHeight;
		return balanceFactor;
	}
}
