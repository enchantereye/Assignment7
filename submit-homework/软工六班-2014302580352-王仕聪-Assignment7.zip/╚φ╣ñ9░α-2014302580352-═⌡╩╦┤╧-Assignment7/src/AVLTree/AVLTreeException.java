package AVLTree;


public class AVLTreeException extends Exception {
	
	public AVLTreeException(){}
	
	public AVLTreeException(String message){
		super(message);
	}
}
