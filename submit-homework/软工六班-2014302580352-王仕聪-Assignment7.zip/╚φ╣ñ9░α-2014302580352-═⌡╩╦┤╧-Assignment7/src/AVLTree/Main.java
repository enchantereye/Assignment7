package AVLTree;

import java.io.IOException;

public class Main {

	public static void main(String[] args) throws NumberFormatException, IOException, AVLTreeException {
		// TODO Auto-generated method stub
              new Test();
	}

}
