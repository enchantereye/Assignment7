package AVLTree;

import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;

public class AVLTree<T> implements IAVLTree<T> {
	private Node<T> root; //���ڵ�
	private int nodeNum;  //�ڵ���
	//����ת����
	private static final int LL=1;
	private static final int RR=2;
	private static final int LR=3;
	private static final int RL=4;

	public AVLTree(){
		root=null;
		nodeNum=0;
	}
	public AVLTree(Node<T> root){
		this.root=root;
		nodeNum=1;
	}
	@Override
	public Node<T> get(int id) throws AVLTreeException{
		// TODO Auto-generated method stub
		Node<T> temp=root;
		while(temp!=null){
			if(id<temp.getId()){
				temp=temp.getLeft();
			}
			else if(id>temp.getId()){
				temp=temp.getRight();
			}
			else{
				break;
			}
		}
		if(temp==null){
			throw new AVLTreeException("�Ҳ���ָ���������ڵ�!");
		}
		return temp;
	}

	@Override
	public void insert(Node<T> newNode) throws AVLTreeException{
		// TODO Auto-generated method stub
		Node<T> temp=root;
		Node<T> old =null;   //�洢���ڵ�
		while(temp!=null){
			old=temp;
			if(newNode.getId()<temp.getId()){
				temp=temp.getLeft();
			}
			else if(newNode.getId()>temp.getId()){
				temp=temp.getRight();
			}
			else{
				throw new AVLTreeException("�ýڵ��Ѿ��ڶ������д���!");
			}
		}
		if(root==null){
			this.root=newNode;
		}
		else if(newNode.getId()<old.getId()){
			newNode.setParent(old);
			old.setLeft(newNode);
		}
		else{
			newNode.setParent(old);
			old.setRight(newNode);
		}
		balance(newNode);
		nodeNum++;
	}

	@Override
	public void delete(int id) throws AVLTreeException{
		// TODO Auto-generated method stub
		if(root!=null){
			Node<T> pointer=root; //ָ��Ҫɾ���Ľڵ�
			Node<T> replace=null; //����ڵ�
			while(pointer!=null){
				if(id<pointer.getId()){
					pointer=pointer.getLeft();
				}
				else if(id>pointer.getId()){
					pointer=pointer.getRight();
				}
				else{
					break;
				}
			}
			if(pointer==null){
				throw new AVLTreeException("��������Ҫɾ�����ڵ�!");
			}
			//��������������
			if(pointer.getLeft()!=null&&pointer.getRight()!=null){
				replace=pointer.getRight();
				while(replace.getLeft()!=null){
					replace=replace.getLeft();
				}
				pointer.setId(replace.getId());
				pointer.setData(replace.getData());
				//ɾ�������̽ڵ�
				pointer=replace;
			}
			//����ڣ��Ҳ�����
			if(pointer.getLeft()!=null&&pointer.getRight()==null){
				pointer.getLeft().setParent(pointer.getParent());
				if(pointer.getParent()!=null){
					if(pointer.getLeft().getId()<pointer.getParent().getId()){
						pointer.getParent().setLeft(pointer.getLeft());
					}
					else{
						pointer.getParent().setRight(pointer.getLeft());
					}
				}
			}
			//�󲻴��ڣ��Ҵ���
			else if(pointer.getLeft()==null&&pointer.getRight()!=null){
				pointer.getRight().setParent(pointer.getParent());
				if(pointer.getParent()!=null){
					if(pointer.getRight().getId()<pointer.getParent().getId()){
						pointer.getParent().setLeft(pointer.getRight());
					}
					else{
						pointer.getParent().setRight(pointer.getRight());
					}
				}
				else{
					pointer.getRight().setParent(null);
					root=pointer.getRight();
				}
			}
			//���Ҷ�������
			else{
				if(pointer.getParent()==null){
					root=null;
				}
				else if(pointer.getId()<pointer.getParent().getId()){
					pointer.getParent().setLeft(null);
				}
				else{
					pointer.getParent().setRight(null);
				}
			}
			balance(pointer);
			nodeNum--;
		}
	}
	//��ת����
	private void rotation(Node<T> node,int type){
		switch(type){
		case AVLTree.LL:
			Node<T> left=node.getLeft();
			//�����ת�Ľڵ�Ϊ���ڵ㣬����Ҫ��������
			if(node==root){
				root=left;
			}
			left.setParent(node.getParent());
			if(node.getParent()!=null){
				if(node.getParent().getLeft()==node){
					node.getParent().setLeft(left);
				}
				else{
					//LR��תר��
					node.getParent().setRight(left);
				}
			}
			node.setParent(left);
			if(left.getRight()!=null){
				left.getRight().setParent(node);
			}
			node.setLeft(left.getRight());
			left.setRight(node);
			break;
		case AVLTree.RR:
			Node<T> right=node.getRight();
			if(node==root){
				root=right;
			}
			right.setParent(node.getParent());
			if(node.getParent()!=null){
				if(node.getParent().getRight()==node){
					node.getParent().setRight(right);
				}
				else{
					//RL��תר��
					node.getParent().setLeft(right);
				}
			}
			node.setParent(right);
			if(right.getLeft()!=null){
				right.getLeft().setParent(node);
			}
			node.setRight(right.getLeft());
			right.setLeft(node);
			break;
			//RL=LL+RR��LR=RR+LL
		case AVLTree.LR:
			rotation(node.getLeft(),AVLTree.RR);
			rotation(node,AVLTree.LL);
			break;
		case AVLTree.RL:
			rotation(node.getRight(),AVLTree.LL);
			rotation(node,AVLTree.RR);
			break;
		default:
			break;
		}
	}
	private void balance(Node<T> node){
		node=node.getParent();//ָ��node�ڵ㵽���ڵ��·���ϵĽڵ�
		Node<T> flag=node;
		//��node�ڵ�ĸ���㿪ʼ�����ε���
		while(flag!=null){
			//Ѱ�Ҳ�ƽ�����С����
			while(node!=null&&Math.abs(node.getBalanceFactor())<2){
				node=node.getParent();
			}
			if(node!=null){
				flag=node.getParent();
				int bf=node.getBalanceFactor();
				//�ж���ת����,������ƽ������Ϊ2��-2���ڸ����亢�ӵ�ƽ�������ж���ת����
				if(bf==2){
					if(node.getLeft().getBalanceFactor()==-1
							||node.getLeft().getBalanceFactor()==0){
						rotation(node,AVLTree.LR);
					}
					else if(node.getLeft().getBalanceFactor()==1){
						rotation(node,AVLTree.LL);
					}
				}
				if(bf==-2){
					if(node.getRight().getBalanceFactor()==-1){
						rotation(node,AVLTree.RR);
					}
					else if(node.getRight().getBalanceFactor()==1
							||node.getRight().getBalanceFactor()==0){
						rotation(node,AVLTree.RL);
					}
				}
				node=flag;
			}
			else{
				flag=null;
			}
		}
	}
	@Override
	public JTree printTree() {
		// TODO Auto-generated method stub
		return new JTree(buildJTree(this.root));	
	}
	private DefaultMutableTreeNode buildJTree(Node<T> node){
		if(node==null){
			return null;
		}
		DefaultMutableTreeNode left=buildJTree(node.getLeft());
		DefaultMutableTreeNode right=buildJTree(node.getRight());
		//�Խڵ��id��data����JTree�ڵ�
		DefaultMutableTreeNode treeNode=new DefaultMutableTreeNode(node.getData().toString()
				+"::"+node.getId());
		if(left!=null){
			treeNode.add(left);
		}
		if(right!=null){
			treeNode.add(right);
		}
		return treeNode;
	}
}
