package AVLTree;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTree;

public class Test extends JFrame implements ActionListener{
	private JTree jTree;
	private AVLTree<String> tree;
	private JButton add,delete,search;
	private JScrollPane showTree;
	public Test() throws AVLTreeException{
		this.setTitle("����ƽ����");
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		Dimension screen=Toolkit.getDefaultToolkit().getScreenSize();
		int width=(int) screen.getWidth();
		int height=(int)screen.getHeight();
		this.setBounds(width/4, height/5, width/3, height*2/3);

		tree=new AVLTree<>();

		try {
			BufferedReader in=new BufferedReader(new FileReader("tree_data.dat"));
			ArrayList<Node<String>> nodes=new ArrayList<>();
			String data=null;
			while((data=in.readLine())!=null){
				String[] line=data.split("#");
				nodes.add(new Node<String>(Integer.parseInt(line[1]),line[0]));
			}
			in.close();
			for(Node<String> node:nodes){
				try{
					tree.insert(node);
				}catch (AVLTreeException e1){
					JOptionPane.showMessageDialog(null, e1.getMessage(),
							"���󾯸�", JOptionPane.CLOSED_OPTION);
					e1.printStackTrace();
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}

		jTree=tree.printTree();
		//�����еĽڵ�
		this.openAllNode(jTree);

		JPanel option=new JPanel();
		option.setLayout(new GridLayout(3,1));

		showTree=new JScrollPane();
		showTree.setViewportView(jTree);

		add=new JButton("����Ԫ��");
		add.addActionListener(this);
		option.add(add);

		delete=new JButton("ɾ��Ԫ��");
		delete.addActionListener(this);
		option.add(delete);

		search=new JButton("����Ԫ��");
		search.addActionListener(this);
		option.add(search);

		this.add(option,BorderLayout.WEST);
		this.add(showTree,BorderLayout.CENTER);
		this.setVisible(true);
	}
	//ʹ���еĽڵ��
	private void openAllNode(JTree tree){
		for(int i=0;i<tree.getRowCount();i++){
			tree.expandRow(i);
		}
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource()==add){
			String id=JOptionPane.showInputDialog(null, "����������Ҫ����ڵ�Ĺؼ���:",
					"�ؼ���",JOptionPane.PLAIN_MESSAGE);
			String data=null;
			if(id!=null){
				data=JOptionPane.showInputDialog(null, "��������Ӧ����:",
						"����",JOptionPane.PLAIN_MESSAGE);
			}
			if(id!=null&&!id.matches("\\s*")&&data!=null){
				try {
					tree.insert(new Node<String>(Integer.parseInt(id.replaceAll("\\s*", "")),data));
				} catch (NumberFormatException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (AVLTreeException e1) {
					// TODO Auto-generated catch block
					JOptionPane.showMessageDialog(null, e1.getMessage(),
							"���󾯸�", JOptionPane.CLOSED_OPTION);
					e1.printStackTrace();
				}

			}
			jTree=tree.printTree();
			this.openAllNode(jTree);
			showTree.setViewportView(jTree);
		}
		else if(e.getSource()==delete){
			String id=JOptionPane.showInputDialog(null,
					"����������Ҫɾ���ڵ�Ĺؼ���:",
					"ɾ����",JOptionPane.PLAIN_MESSAGE);
			if(id!=null&&!id.matches("\\s*")){
				try {
					tree.delete(Integer.parseInt(id.replaceAll("\\s*", "")));
					JOptionPane.showMessageDialog(null, "�����ɹ�!", "ɾ�����", JOptionPane.CLOSED_OPTION);
				} catch (NumberFormatException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (AVLTreeException e1) {
					// TODO Auto-generated catch block
					JOptionPane.showMessageDialog(null, e1.getMessage(),
							"���󾯸�", JOptionPane.CLOSED_OPTION);
					e1.printStackTrace();
				}
				jTree=tree.printTree();
				this.openAllNode(jTree);
				showTree.setViewportView(jTree);
			}
		}
		else if(e.getSource()==search){
			String id=JOptionPane.showInputDialog(null,
					"����������Ҫ�����ڵ�Ĺؼ���:",
					"����",JOptionPane.PLAIN_MESSAGE);
			if(id!=null&&!id.matches("\\s*")){
				Node<String> node;
				try {
					node = tree.get(Integer.parseInt(id.replaceAll("\\s*", "")));
					JOptionPane.showMessageDialog(null, node.getData(),
							"���ؽ��", JOptionPane.CLOSED_OPTION);
				} catch (NumberFormatException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (AVLTreeException e1) {
					// TODO Auto-generated catch block
					JOptionPane.showMessageDialog(null, e1.getMessage(),
							"���󾯸�", JOptionPane.CLOSED_OPTION);
					e1.printStackTrace();
				}

			}
		}
	}
}

