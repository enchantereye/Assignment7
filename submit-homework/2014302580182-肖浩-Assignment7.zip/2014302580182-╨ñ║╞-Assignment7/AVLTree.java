import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Comparator;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;


public class AVLTree implements IAVLTree {
	int height;
	public Node root;
    public Node left;
    public Node right;
	private int height(Node t){
		return t==null?-1:t.height;
	}
	
	public AVLTree(){
		root=null;
	}
	
	@Override
	public Node get(int id) {
		// TODO �Զ����ɵķ������
		Node a=root;
		while(a.getId()!=id){
			if(a.getId()>id){
				a=a.getChildren()[0];
			}else{
				a=a.getChildren()[1];
			}
		}
		return null;
	}

	
	
	//����
	//root.getChildren()[0]��ʾroot�����ӣ�root.getChildren()[1]��ʾroot���Һ���
	@Override
	public Node insert(int id, Node newNode) {
		if(newNode==null)
			return newNode;
		int compareResult=compare(id,root.getId());
		if(compareResult<0)
		{
			root.getChildren()[0]=insert(newNode.getId(),root.getChildren()[0]);
			if(height(newNode.getChildren()[0])-height(newNode.getChildren()[1])==2)
				if(compare(newNode.getId(),root.getChildren()[0].getId())<0)
					root=rotateWithLeftChild(root);
			       else
			    	root=doubleWithLeftChild(root);
		}
		else if(compareResult>0){
			root.getChildren()[1]=insert(newNode.getId(),root.getChildren()[1]);
			if(height(newNode.getChildren()[1])-height(newNode.getChildren()[0])==2)
				if(compare(newNode.getId(),root.getChildren()[1].getId())<0)
					root=rotateWithLeftChild(root);
			       else
			    	root=doubleWithLeftChild(root);
		}else;
		root.height=Math.max(height(root.getChildren()[0]), height(root.getChildren()[1]));
		return root;
		
	}
	
    
	
    //ɾ��
	@Override
	public Node delete(int id,Node newNode) {
		// TODO �Զ����ɵķ������
		if(newNode==null)
			return newNode;
		int compareRusult=compare(id,root.getId());
		if(compareRusult<0){
			root.getChildren()[0]=delete(root.getChildren()[0].getId(),root.getChildren()[0]);
			if(height(root.getChildren()[1])-height(root.getChildren()[0])==2){
				if(height(root.getChildren()[1].getChildren()[1])>=height(root.getChildren()[0].getChildren()[0])){
					root=rotateWithRightChild(root);
				}else{
					root=doubleWithRightChild(root);
				}
			}
		}else if(compareRusult>0){
			root.getChildren()[1]=delete(root.getChildren()[1].getId(),root.getChildren()[1]);
			if(height(root.getChildren()[0])-height(root.getChildren()[1])==2){
				if(root.getChildren()[0]!=null){
					if(height(root.getChildren()[0].getChildren()[0])>=height(root.getChildren()[0].getChildren()[1])){
						root=rotateWithLeftChild(root);
					}else{
						root=doubleWithLeftChild(root);
					}
				}
			}
		}
		return root;
     
	}
    
	
	//�����
	@Override
	public JTree printTree() {
		// TODO �Զ����ɵķ������
		Node Root = new Node();
        JTree tree = new JTree();
        JFrame frame = new JFrame("JTreeDemo");
        frame.add(tree);
        frame.setSize(300, 300);
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        Node[] childrenNode = root.getChildren()[0].getChildren();
        if(childrenNode[0] != null) {
            insert(childrenNode[0].getId(),Root);
        }
        if(childrenNode[1] != null) {
            insert(childrenNode[1].getId(),Root);
        }
        return tree;
		
	}
		
	
    //��˫��ת
	private Node doubleWithLeftChild(Node root3) {
		// TODO �Զ����ɵķ������
		root3.getChildren()[0]=rotateWithLeftChild(root3.getChildren()[0]);
		
		return rotateWithLeftChild(root3);
	}
	
	//��˫��ת
	private Node doubleWithRightChild(Node root3) {
		// TODO �Զ����ɵķ������
		root3.getChildren()[1]=rotateWithRightChild(root3.getChildren()[1]);
		
		return rotateWithRightChild(root3);
	}
	
    //����ת
	private Node rotateWithLeftChild(Node root2) {
		// TODO �Զ����ɵķ������
		Node root1=root2.getChildren()[0];
		root2.getChildren()[0]=root1.getChildren()[1];
		root1.getChildren()[1]=root2;
		root2.height=Math.max(height(root2.getChildren()[0]),height(root2.getChildren()[1]))+1;
		root1.height=Math.max(height(root1.getChildren()[0]),root2.height)+1;
		return root1;
	}
	
	//�ҵ���ת
	private Node rotateWithRightChild(Node root2) {
		// TODO �Զ����ɵķ������
		Node root1=root2.getChildren()[1];
		root2.getChildren()[1]=root1.getChildren()[0];
		root1.getChildren()[0]=root2;
		root2.height=Math.max(height(root2.getChildren()[0]),height(root2.getChildren()[1]))+1;
		root1.height=Math.max(height(root1.getChildren()[0]),root2.height)+1;
		return root1;
	}

	private int compare(int id, int i) {
		// TODO �Զ����ɵķ������
		if(id<i){
			return -1;
		}else
		return 1;
	}

}
