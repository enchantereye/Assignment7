import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class Test2014302580182 {

	public static void main(String[] args) {
		// TODO �Զ����ɵķ������
     AVLTree Testtree=new AVLTree();
     Node node = new Node();
   
	 Testtree.insert(1,node);
	}
	
	public String readFile(String path) throws IOException{
        File file=new File("C:\\Users\\xiaohao\\Desktop\\Assignment7\\tree_data.dat");
        if(!file.exists()||file.isDirectory())
            throw new FileNotFoundException();
        BufferedReader br=new BufferedReader(new FileReader(file));
        String temp=null;
        StringBuffer a=new StringBuffer();
        temp=br.readLine();
        while(temp!=null){
            a.append(temp+" ");
            temp=br.readLine();
            System.out.print(temp);
        }
        return a.toString();
    }

}
