
/**
 * Created by yangwen on 16/1/2.
 */

public class Node {
	private int id;
	private Object data;
	private Node parent;
	public int balanceFactor;
	private Node[] children = new Node[2];

	@Override
	public String toString() {
		if (this.getData() != null)
			return "id:" + String.valueOf(this.getId()) + " data:" + String.valueOf(this.getData());
		else
			return "id:" + String.valueOf(this.getId());
	}

	public void setBalanceFactor(int balanceFactor) {  //平衡因子
		this.balanceFactor = balanceFactor;
	}

	public int getBalanceFactor() {
		return balanceFactor;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getId() {
		return id;
	}

	public void setData(Object data) {
		this.data = data;
	}

	public void setChildren(Node[] children) {
		this.children = children;
	}

	public Object getData() {
		return data;
	}

	public void setChild(int id, Node child) {
		this.children[id] = child;
	}

	public Node getChildren(int id) {
		if (id == 0 || id == 1) {
			return children[id];
		} else {
			return null;
		}
	}

	public Node[] getChildren() {
		return children;
	}

	public void setParent(Node parent) {
		this.parent = parent;
	}

	public Node getParent() {
		return parent;
	}


	public void setLeft(Node left) { //左孩子，调用setChild函数
		setChild(0, left);
	}

	public Node getLeft() {
		return getChildren(0);
	}

	public void setRight(Node right) { //右孩子，调用setChild函数
		setChild(1, right);
	}

	public Node getRight() {
		return getChildren(1);
	}

}
