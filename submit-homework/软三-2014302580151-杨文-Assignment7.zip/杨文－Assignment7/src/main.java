/**
 * Created by yangwen on 16/1/3.
 */
import java.io.*;

public class main {
    public static void main(AVLTree2014302580151 avlTree) throws IOException {

        AVLTree2014302580151 avlTree2014302580151 = new AVLTree2014302580151();
        init2014302580151(avlTree);
        show2014302580151(avlTree);
    }

    public static void show2014302580151(AVLTree2014302580151 avlTree) {
        Frame2014302580151 frame = new Frame2014302580151(avlTree);
        frame.setVisible(true);
    }
    public static void init2014302580151(AVLTree2014302580151 avlTree) throws IOException {
        int id;
        String data;
        String temp;
        BufferedReader bufferedReader = null;
        bufferedReader = new BufferedReader(new InputStreamReader(new FileInputStream("data.dat")));

        if ((temp = bufferedReader.readLine()) != null) {
            Node node = new Node();
            String[] text = temp.split("\\#");
            id = Integer.parseInt(text[1]);
            data = text[0];
            node.setId(id);
            node.setData(data);
            avlTree.insert(node);
        } else {
            return;
        }
    }


}
