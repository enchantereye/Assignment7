/**
 * Created by yangwen on 16/1/2.
 */

import java.util.Vector;
import javax.swing.*;
import javax.swing.tree.DefaultMutableTreeNode;

public class AVLTree2014302580151 implements IAVLTree {

    private Node temp;
    private boolean unBalanced;
    private Node tempParent;
    private boolean tall;
    public Node root = null;

    public Node getRoot() {
        return root;
    }

    public int height2014302580151(Node node) {
        int l = 0;
        int r = 0;
        if (node == null) return 0;
        else {
            if (node.getLeft() != null) {
                l = height2014302580151(node.getLeft()) + 1;
            }
            if (node.getRight() != null) {
                r = height2014302580151(node.getRight()) + 1;
            }
            return (l > r) ? l : r;
        }
    }

    public int getBalance(Node node) {
        int b = height2014302580151(node.getLeft()) - height2014302580151(node.getRight());
        return b;
    }

    public void fixBalance2014302580151(Node node) {
        if (node != null) {
            node.setBalanceFactor(getBalance(node));
            fixBalance2014302580151(node.getLeft());
            fixBalance2014302580151(node.getRight());
        }
    }

    private void rotateRight2014302580151(Node n) {          //右旋算法

        if (n.getId() == root.getId()) {
            root = n.getRight();
            System.out.println("id" + root.getId());
        } else {
            if (n.getLeft().getBalanceFactor() == 1 || n.getLeft().getBalanceFactor() == 0) {
                Node no = n.getLeft();
                if (n.getParent() != null) {
                    if (n.getParent().getLeft() == n)
                        n.getParent().setLeft(n);
                    n.getParent().setRight(n);
                }
                if (n.getParent() != null) {
                    no.setParent(n.getParent());
                }
                n.setParent(n);
                if (no.getRight() != null) {
                    no.getRight().setParent(n);
                }
                n.setLeft(no.getRight());
                no.setRight(n);
                fixBalance2014302580151(root);
            } else if (n.getLeft().getBalanceFactor() == -1 || n.getLeft().getBalanceFactor() == 0) {
                Node no = n.getLeft();
                Node u = n.getRight();
                if (n.getParent() != null) {
                    if (n.getParent().getLeft() == n)
                        n.getParent().setLeft(u);
                    else if (n.getParent().getRight() == n)
                        n.getParent().setRight(u);
                }

                if (n.getParent() != null) {
                    u.setParent(n.getParent());
                }
                no.setParent(u);
                if (u.getLeft() != null) {
                    u.getLeft().setParent(no);
                }
                if (u.getRight() != null) {
                    u.getRight().setParent(n);
                }
                if (u.getLeft() != null) {
                    n.setRight(u.getLeft());
                }
                if (u.getRight() != null) {
                    n.setLeft(u.getRight());
                }
                u.setLeft(no);
                u.setRight(n);
                fixBalance2014302580151(root);
            }
        }
    }

    private Node rotateLeft2014302580151(Node root) {

        Node p;

        if (root == null)
            System.err.print("The root is empty.");
        else if (root.getLeft() == null)
            System.err.println("No left subtree to rotate.");
        else {
            p = root.getLeft();
            root.setLeft(p.getRight());
            p.setRight(root);
            root = p;
        }
        return root;
    }


    @Override
    public void insert(Node newNode) {
        tall = false;
        root = insert2014302580151(root, newNode);
    }

    public Node insert2014302580151(Node root, Node newNode) {

        System.out.println("Begin to insert.");

        if (root == null) {
            root = newNode;
            tall = true;
        } else if (newNode.getId() == root.getId())
            System.out.println("The node has been existed.");
        else if (newNode.getId() < root.getId()) {
            root.setLeft(insert2014302580151(root.getLeft(), newNode));
            if (tall)
                switch (root.getBalanceFactor()) {
                    case 1:
                        leftBalance(root);
                        tall = false;
                        break;
                    case 0:
                        root.setBalanceFactor(1);
                        tall = true;
                        break;
                    case -1:
                        root.setBalanceFactor(0);
                        tall = false;
                        break;
                }
            return root;
        } else {
            root.setRight(insert2014302580151(root.getRight(), newNode));
            if (tall)
                switch (root.getBalanceFactor()) {
                    case 1:
                        root.setBalanceFactor(0);
                        tall = false;
                        break;
                    case 0:
                        root.setBalanceFactor(-1);
                        tall = true;
                        break;
                    case -1:
                        rightBalance2014302580151(root);
                        tall = false;
                }
        }
        return null;
    }

    private boolean rightBalance2014302580151(Node node) {
        Node r = node.getRight();

        switch (r.getBalanceFactor()) {
            case 1: {
                Node rl = node.getLeft();
                switch (rl.getBalanceFactor()) {
                    case 1: {
                        node.setBalanceFactor(0);
                        r.setBalanceFactor(-1);
                        break;
                    }
                    case 0: {
                        node.setBalanceFactor(0);
                        r.setBalanceFactor(0);
                        break;
                    }
                    case -1: {
                        node.setBalanceFactor(1);
                        r.setBalanceFactor(0);
                        break;
                    }
                }
                rl.setBalanceFactor(0);
                rotateLeft2014302580151(r);
                rotateRight2014302580151(node);
                break;
            }
            case -1: {
                node.setBalanceFactor(0);
                r.setBalanceFactor(0);
                rotateRight2014302580151(node);
                break;
            }
            case 0: {
                r.setBalanceFactor(1);
                node.setBalanceFactor(-1);
                rotateRight2014302580151(node);
                return false;
            }
        }
        return true;
    }
    private boolean leftBalance(Node node) {
        Node l = node.getLeft();

        switch (l.getBalanceFactor()) {
            case 1: {
                node.setBalanceFactor(0);
                l.setBalanceFactor(0);
                rotateLeft2014302580151(node);
                break;
            }
            case -1: {
                Node lr = l.getRight();
                switch (lr.getBalanceFactor()) {
                    case 1: {
                        node.setBalanceFactor(-1);
                        l.setBalanceFactor(0);
                        break;
                    }
                    case 0: {
                        node.setBalanceFactor(0);
                        l.setBalanceFactor(0);
                        break;
                    }
                    case -1: {
                        node.setBalanceFactor(0);
                        l.setBalanceFactor(1);
                    }
                }
                lr.setBalanceFactor(0);
                rotateRight2014302580151(l);
                rotateLeft2014302580151(node);
                break;
            }
            case 0: {
                l.setBalanceFactor(-1);
                node.setBalanceFactor(1);
                rotateLeft2014302580151(node);
                return false;
            }
        }
        return true;
    }


    @Override
    public Node get(int id)
    {
        return search(root,id);
    }
    private Node search(Node node,int id)
    {
        if(node!=null)
        {
            if(node.getId()==id)
            {
                return node;
            }
            else if(node.getId()>id)
            {
                return search(node.getChildren(0),id);
            }
            else
            {
                return search(node.getChildren(1),id);
            }
        }
        else
        {
            return null;
        }
    }
    private void downToUp(Node initNode) {
        Node adjustNode = initNode.getParent();
        temp = adjustNode;
        while(temp.getParent()!=tempParent) {
            while(adjustNode.getParent()!=tempParent&&(adjustNode.getBalanceFactor()!=-2)&&(adjustNode.getBalanceFactor()!=2)) {
                adjustNode = adjustNode.getParent();
            }
            if(adjustNode.getParent()!=tempParent) {
                temp = adjustNode.getParent();
                unBalanced = true;
                rotateLeft2014302580151(adjustNode);
                rotateRight2014302580151(adjustNode);
                adjustNode=temp;
            }
            else{
                temp = adjustNode;
            }
        }
    }
    @Override
    public void delete(int id) {
        Node targetNode = get(id);
        if(targetNode==null) {
            throw new RuntimeException("id为"+id+"的结点空");
        }
        if(targetNode.getChildren()[0]!=null&&targetNode.getChildren()[1]!=null) {
            temp = targetNode.getChildren()[1];
            while(temp.getChildren()[0]!=null) {
                temp=temp.getChildren()[0];
            }
            targetNode.setId(temp.getId());
            targetNode.setData(temp.getData());
            targetNode = temp;
        }

        if(targetNode.getChildren()[0]==null && targetNode.getChildren()[1] == null) {

            if(targetNode.getParent()==tempParent) {
                root = null;
                tempParent.setChild(0,null);
                return;
            }
            else if(targetNode.getId()<targetNode.getParent().getId()) {
                targetNode.getParent().setChild(0,null);
                targetNode.getParent().setBalanceFactor(targetNode.getParent().getBalanceFactor()-1);
            }
            else{
                targetNode.getParent().setChild(1,null);
                targetNode.getParent().setBalanceFactor(targetNode.getParent().getBalanceFactor()+1);
            }
        }
        else if(targetNode.getChildren()[0]!=null && targetNode.getChildren()[1]==null) {

            if(targetNode.getParent()==tempParent) {
                targetNode.getChildren()[0].setParent(tempParent);
                tempParent.setChild(0,targetNode.getChildren(0));
            }
            else if(targetNode.getId()<targetNode.getParent().getId()) {
                targetNode.getChildren()[0].setParent(targetNode.getParent());
                targetNode.getParent().setChild(0,targetNode.getChildren(0));
            }
            else{
                targetNode.getChildren()[0].setParent(targetNode.getParent());
                targetNode.getParent().setChild(1,targetNode.getChildren(0));
            }
        }
        else if(targetNode.getChildren()[0]==null&&targetNode.getChildren()[1]!=null) {

            if(targetNode.getParent()==tempParent) {
                targetNode.getChildren()[1].setParent(tempParent);
                tempParent.setChild(0,targetNode.getChildren(1));
            }
            else if(targetNode.getId()<targetNode.getParent().getId()) {
                targetNode.getChildren()[1].setParent(targetNode.getParent());
                targetNode.getParent().setChild(0,targetNode.getChildren(1));
            }
            else{
                targetNode.getChildren()[1].setParent(targetNode.getParent());
                targetNode.getParent().setChild(1,targetNode.getChildren(0));
            }
        }
        downToUp(targetNode);
        }



    private void reBalance2014302580151(Node node) {

        Node parent = node.getParent();
        boolean heightLower = true;

        int LeftOrRight;
        while (heightLower = true && parent != null) {
            LeftOrRight = node.getId() - parent.getId();
            if (LeftOrRight<0) {
                parent.setBalanceFactor(parent.getBalanceFactor() - 1);
            } else {
                parent.setBalanceFactor(parent.getBalanceFactor() + 1);
            }

            switch (parent.getBalanceFactor()) {
                case 1: {
                    break;
                }
                case -1: {
                    break;
                }
                case 2: {
                    heightLower = leftBalance(parent);
                }
                case -2: {
                    heightLower = rightBalance2014302580151(parent);
                }
            }
            parent = parent.getParent();
        }
    }

    @Override
    public JTree printTree() {
        return new JTree(buildJTree(this.root));
    }

    private DefaultMutableTreeNode buildJTree(Node node){
        if(node==null){
            return null;
        }
        DefaultMutableTreeNode left=buildJTree(node.getLeft());
        DefaultMutableTreeNode right=buildJTree(node.getRight());
        DefaultMutableTreeNode treeNode=new DefaultMutableTreeNode(node.getData().toString()
                +"("+node.getId()+")");
        if(left!=null){
            treeNode.add(left);
        }
        if(right!=null){
            treeNode.add(right);
        }
        return treeNode;
    }

    }




