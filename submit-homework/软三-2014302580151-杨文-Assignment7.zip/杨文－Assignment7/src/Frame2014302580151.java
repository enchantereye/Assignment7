import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.Font;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JPanel;


/**
 * Created by Yangwen on 15/12/23.
 */
public class Frame2014302580151 extends JFrame {

    JTree tree;
    AVLTree2014302580151 avlTree;


    public Frame2014302580151(final AVLTree2014302580151 avlTree) {
        setTitle("AVLTree");
        this.avlTree = avlTree;


        this.tree = avlTree.printTree();
        addTree();
        setSize(700, 600);
        setLayout(null);
        setResizable(false);
        final JTextField jTextfield = new JTextField();
        jTextfield.setBounds(120, 400, 80, 40);
        add(jTextfield);

        JPanel panel = new ImagePanel2014302580151();
        getContentPane().add(panel);
        panel.setLayout(null);

        JLabel qLabel = new JLabel("查询的id: ");
        qLabel.setBounds(8, 400, 120, 40);
        add(qLabel);

        final JLabel rLabel = new JLabel();
        rLabel.setBounds(470, 500, 200, 50);
        add(rLabel);

        JButton qButton = new JButton("Enter");
        qButton.setBounds(300, 400, 80, 40);
        qButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    int id = Integer.parseInt(jTextfield.getText());
                    Node result = avlTree.get(id);
                    if (result == null) {
                        rLabel.setText("error");
                    } else {
                        rLabel.setText(result.toString());
                    }

                } catch (NumberFormatException err) {
                    JOptionPane.showMessageDialog(null, "输入数字", "wrong", JOptionPane.ERROR_MESSAGE);
                    err.printStackTrace();
                }
            }
        });
        add(qButton);


        final JTextField iTextField = new JTextField();
        iTextField.setBounds(180, 600, 80, 40);
        add(iTextField);

        JLabel iLabel = new JLabel("插入的节点id和data,id+data");
        iLabel.setBounds(180, 560, 200, 40);
        add(iLabel);

        JButton iButton = new JButton("Enter");
        iButton.setBounds(180, 680, 80, 40);


        JButton dButton = new JButton("Enter");
        dButton.setBounds(400, 700, 80, 40);
        final JTextField dTextField = new JTextField();
        dTextField.setBounds(400, 600, 80, 40);
        add(dTextField);

        JLabel dLabel = new JLabel("输入要删除的id: ");
        dLabel.setBounds(400, 580, 120, 40);
        add(dLabel);

        qLabel.setFont(new Font("",1,18));
        iLabel.setFont(new Font("",1,18));
        dLabel.setFont(new Font("",1,18));

        dButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    Frame2014302580151.this.avlTree.delete(Integer.parseInt(dTextField.getText()));
                    tree.setVisible(false);
                    remove(tree);
                    tree = Frame2014302580151.this.avlTree.printTree();
                    addTree();
                } catch (NumberFormatException error) {
                    JOptionPane.showMessageDialog(null, "输入数字", "wrong", JOptionPane.ERROR_MESSAGE);
                    dTextField.setText("");
                    error.printStackTrace();
                }

            }
        });
        add(dButton);
        iTextField.setBackground(Color.white);
        jTextfield.setBackground(Color.white);
        dTextField.setBackground(Color.white);

        qButton.setFont(new Font("",1,30));
        iButton.setFont(new Font("", 1, 30));
        dButton.setFont(new Font("", 1, 30));

        qButton.setBackground(Color.white);
        iButton.setBackground(Color.white);
        dButton.setBackground(Color.white);
        iButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                try {
                    String[] a = iTextField.getText().split("\\+");
                    if (a.length != 2) {
                        JOptionPane.showMessageDialog(null, "输入正确格式", "wrong", JOptionPane.ERROR_MESSAGE);
                    } else {
                        Node node = new Node();
                        int id = Integer.parseInt(a[0]);
                        tree.setVisible(false);
                        remove(tree);
                        String data = a[1];
                        node.setId(id);
                        node.setData(data);
                        Frame2014302580151.this.avlTree.insert(node);
                        tree = Frame2014302580151.this.avlTree.printTree();
                        addTree();
                    }

                } catch (NumberFormatException err) {
                    JOptionPane.showMessageDialog(null, "输入数字", "wrong", JOptionPane.ERROR_MESSAGE);
                    iTextField.setText("");
                    err.printStackTrace();
                }
            }
        });
        add(iButton);

    }

    private void addTree() {
        boolean isTrue = true;
        if (tree != null) {
            isTrue = true;
        }
        while (true) {
            tree.setVisible(true);
            tree.setBounds(100, 50, 600, 400);
            add(tree);
        }

    }
}
    class ImagePanel2014302580151 extends JPanel {

        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            ImageIcon icon = new ImageIcon("./src/view.png");
            g.drawImage(icon.getImage(), 0, 0, this.getWidth(), this.getHeight(), this);
        }


    }

