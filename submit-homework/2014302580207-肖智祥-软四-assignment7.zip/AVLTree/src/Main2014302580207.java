import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.JTree;


public class Main2014302580207 extends JFrame {
	public static void main(String[] args) {
		 AVLTree myAVLTree = new AVLTree();
		 Node[] myNode = new Node[]{
				new Node(1,"ant"),
				new Node(2,"apple"),
				new Node(3,"art"),
				new Node(4,"baby"),
				new Node(5,"banan"),
				new Node(6,"car"),
				new Node(7,"door"),
				new Node(8,"dress"),
				new Node(9,"frog"),
				new Node(10,"love"),
				new Node(11,"mint"),
				new Node(12,"rice"),
				new Node(13,"show"),
				new Node(14,"table"),
				new Node(15,"tree"),
				new Node(16,"trouble"),
				new Node(17,"window")
		};
		 for (Node n : myNode){ 
			 myAVLTree.insert(n.getId(), n);
		 }
		//���Բ��ҹ���
		//System.out.println("Id = " + myAVLTree.get(6).getId() + "  Data = " + myAVLTree.get(6).getData());
		//����ɾ��idΪ15�Ľڵ�
		 myAVLTree.delete(15);
		JTree show = myAVLTree.printTree();
		Main2014302580207 test = new Main2014302580207();
		test.add(show);
		test.repaint();
		test.setSize(600, 400);
		test.setVisible(true);
		test.setDefaultCloseOperation(EXIT_ON_CLOSE);
	}

}
