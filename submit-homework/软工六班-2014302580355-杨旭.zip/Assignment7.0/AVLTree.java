import javax.swing.JTree;


public class AVLTree implements IAVLTree {
             private Node root;
             public Node getRoot(){
            	 return root;
            			 }
			@Override
			public Node get(int id) {
				// TODO Auto-generated method stub
				return search (root,id);
			}
			private Node search(Node node,int id){
				if(node!=null)
				{
					if(node.getId()==id)
					{
						return node;
					}
					else if(node.getId()>id)
					{
						return search(node.getChildren(0),id);
					}
					else
					{
						return search(node.getChildren(1),id);
					}
				}
				else
				{
					return null;
				}
			}
			@Override
			public void insert(int id, Node newNode) {
				// TODO Auto-generated method stub
				if(root == null){
					root = newNode;
				}else{
					insert(id,newNode);
				}
			}
			  public boolean add(id ,data){  
			        Entry<E> t = root;  
			        if(t == null){  
			            root = new Entry<E>(element,null);  
			            size = 1;  
			            return true;  
			        }  
			        int cmp;  
			        Entry<E> parent;  //����t�ĸ��ڵ�  
			        Comparable<? super E> e = (Comparable<? super E>) element;  
			        //�Ӹ��ڵ������������ҵ�����λ��  
			        do {  
			            parent = t;       
			            cmp = e.compareTo(t.element);  
			            if(cmp < 0){  
			                t = t.left;  
			            }else if(cmp > 0){  
			                t = t.right;  
			            }else{  
			                return false;  
			            }  
			        } while (t!=null);  
			          
			        Node<E> child = new Entry(element,parent);  
			        if(cmp < 0){  
			            parent.left = child;  
			              
			        }else{  
			            parent.right = child;     
			        }  
			        //�������ϻ��ݣ����������ƽ��ڵ�  
			        while(parent!=null){  
			            cmp = e.compareTo(parent.element);  
			            if(cmp < 0){    //����ڵ���parent����������  
			                parent.balance++;  
			            }else{           //����ڵ���parent����������  
			                parent.balance--;  
			            }  
			            if(parent.balance == 0){    //�˽ڵ��balanceΪ0���������ϵ���BFֵ���Ҳ���Ҫ��ת  
			                break;  
			            }  
			            if(Math.abs(parent.balance) == 2){  //�ҵ���С��ƽ���������ڵ�  
			                fixAfterInsertion(parent);  
			                break;                  //���ü������ϻ���  
			            }  
			            parent = parent.parent;  
			        }  
			        size ++;  
			        return true;  
			    }  
			@Override
			public void delete(int id) {
				// TODO Auto-generated method stub
				
			}
			@Override
			public JTree printTree() {
				// TODO Auto-generated method stub
				return null;
			}

}
