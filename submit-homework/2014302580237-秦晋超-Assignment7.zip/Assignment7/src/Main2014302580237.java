

public class Main2014302580237 {

	
	public static void main(String [] args){
		
		AVLTree a = new AVLTree( );
		
	
		
		a.root= a.insert(1,a.root);
		a.root= a.insert(2,a.root);
		a.root= a.insert(3,a.root);
		a.root= a.insert(4,a.root);
		a.root= a.insert(5,a.root);
		a.root= a.insert(6,a.root);
		System.out.println("insert test:");
		a.printTree(a.root);
		System.out.println("====================");
		System.out.println("get test: (get(4):baby)");
		Node b = a.get(4);
		System.out.println(b.getData());
		System.out.println("====================");
		System.out.println("delete test:(delete apple)");
		a.delete(2);
		a.printTree(a.root);
	}
	
	
}
