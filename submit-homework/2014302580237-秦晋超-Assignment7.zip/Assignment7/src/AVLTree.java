import javax.swing.JTree;


public class AVLTree implements IAVLTree {
	
	 public Node root;
	 
	 AVLTree(){
		 root = null;
		    }
	 
	/**
	 * get the node by index
	 * @param id, the node id to get
	 * @return
	 */
	public Node get(int id){
		if (root == null) {
			System.out.println("Empty");
			return null;
		}else{
			Node a = root;
			while (a.getId()!= id) {
			 if (a.getId()<id) {
				 if (a.getrChild()!= null) {
					a =a.getrChild();
				}else{
					System.out.println("not find");
					return null;
					}
				
			} else {
				
					 if (a.getlChild()!= null) {
						a =a.getlChild();
					}else{
						System.out.println("not find");
						return null;
					}

				}
				
			}
			
			return a;
			
			
		}

	}
	/**
	 * insert the node by id
	 * @param id, the parent node id to insert
	 * @return 
	 */
	public Node insert(int id, Node newNode){
		
		if( newNode == null ){
            return new Node( id, null, null );
		}else{
       
        if( id < newNode.getId() )
        {
            newNode.setlChild(insert( id, newNode.getlChild() )); 
            if( height( newNode.getlChild() ) - height( newNode.getrChild() ) == 2 )
                if( id < newNode.getlChild().getId()  )
                	newNode = LL( newNode );
                else  
                	newNode= LR( newNode );
        }
        else if(  id > newNode.getId() )
        {
        	 newNode.setrChild(insert( id, newNode.getrChild() )); 
        	 if( height( newNode.getrChild() ) - height( newNode.getlChild() ) == 2 )
        		 if( id < newNode.getrChild().getId()  )
        			newNode = RR( newNode );
                else                           
                	newNode = RL( newNode );
        }
        else{
            System.out.println("�ظ����ݣ�"); 
        
        }
        if (newNode.getlChild()!= null && newNode.getrChild()!=null) {
			newNode.setHeight(Math.max( height( newNode.getlChild() ), height( newNode.getrChild() ) ) + 1); 
		}
        
        return newNode;
		}
	}
	/**
	 * the node id to delete
	 * @param id
	 */
	public void delete(int id) {
		
		Node a=root;
		Node b=root;
		boolean isLeft=false;
		while(a.getId()!=id){
			b=a;
				isLeft=false;
				
			if(a.getrChild()==null)
				System.out.println("δ�ҵ�");
			else 
				a=a.getrChild();
			
		}
		if(a.getlChild()==null&&a.getrChild()==null){
			if(a==root)
				root=null;
			else if(isLeft)
				b.setlChild(null);
			else
				b.setrChild(null);
			}
		else if(a.getrChild()==null){
			if(a==root)
				root=a.getlChild();
			else if(isLeft)
				b.setlChild(a.getlChild());
			else
				b.setrChild(a.getlChild());
		}
		else if(a.getlChild()==null){
			if(a==root)
				root=a.getrChild();
			else if(isLeft)
				b.setlChild(a.getrChild());
			else
				b.setrChild(a.getrChild());
		}
		else{
			Node next=getNext(a);
			if(a==root){
				root=next;
			}else if(isLeft){
				b.setlChild(next);
			}
			else
				b.setrChild(next);
			next.setlChild(a.getlChild());
		}
		System.out.println("Delete Success" );
		
	}

	/**
	 * print the whole tree
	 * @return a java swing Object JTree
	 */
	public JTree printTree( Node a) {
		
		   if( a!= null )
	        {
	            printTree(a.getlChild() );
	            System.out.println( a.getData());
	            printTree( a.getrChild() );
	        }
				
				
			return null;	
				
			
	}
	
	private Node getNext(Node t){
		Node NextParent=t;
		Node Next=t;
		Node current=t.getrChild();
		while(current!=null){
			NextParent=Next;
			Next=current;
			current=current.getlChild();
		}
		if(Next!=t.getrChild()){
			NextParent.setlChild(Next.getrChild());
			Next.setrChild(t.getrChild());
		}
		return Next;
	}
		private int height( Node node )
	    {
	        return node == null ? -1 : node.getHeight();
	    }
	   
	   private Node LL( Node a )
	    {
		   	Node b = a.getlChild();
		   	if (b!=null) {
			a.setlChild(b.getrChild());
	        b.setrChild(a);
	        a.setHeight(Math.max( height( a.getlChild() ), height( a.getrChild()) ) + 1); 
	        b.setHeight( Math.max( height( b.getlChild() ), a.getHeight()) + 1);
			}

	        return b;
	    }
	   
	    private Node RR( Node a )
	    {
	    	Node b = a.getrChild();
	    	if (b!=null) {
			a.setrChild(b.getlChild()); 
	        b.setlChild(a); 
	        a.setHeight(Math.max( height( a.getlChild() ), height( a.getrChild() ) ) + 1);
	        b.setHeight(Math.max( height( b.getrChild() ), a.getHeight() ) + 1);
			}
	       
	        return b;
	    }
	   
	    private Node LR(Node a )
	    {
	        a.setlChild(RR( a.getlChild() )); 
	        return RL( a );
	    }
	    
	    private Node RL( Node a )
	    {
	        a.setrChild(RL( a.getrChild() )); 
	        return RR( a );
	    }

		
}
