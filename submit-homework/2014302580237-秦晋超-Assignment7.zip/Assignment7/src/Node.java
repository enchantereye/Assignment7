
public class Node {
	private int id;
	private Object data;
	private Node parent;
	private Node lchild;
	private Node rchild;
	private int Height;
	private int balanceFactor;
	
	Node( int ID )
    {
        this( ID, null, null );
    }
	Node( int ID,Node lt, Node rt )
    {
        id= ID;
        lchild= lt;
        rchild= rt;
        Height= 0;
        switch (ID) {
		case 1:
			data ="ant";
			break;
		case 2:
			data ="apple";
			break;
		case 3:
			data ="art";
			break;
		case 4:
			data ="baby";
			break;
		case 5:
			data ="banan";
			break;
		case 6:
			data ="car";
			break;
		case 7:
			data ="door";
			break;
		case 8:
			data ="dress";
			break;
		case 9:
			data ="frog";
			break;
			
		default:
			break;
		}
    }
    
	public int getId() {
		return id;
	}
	public Object getData() {
		return data;
	}
	public void setData(Object data) {
		this.data = data;
	}
	public Node getParent() {
		return parent;
	}
	public void setParent(Node parent) {
		this.parent = parent;
	}
	public Node getrChild() {
		return rchild;
	}
	public void setrChild(Node child){
		this.rchild = child;
	}
	public Node getlChild() {
		return lchild;
	}
	public void setlChild(Node child){
		this.lchild = child;
	}
	public int getHeight() {
		//TODO calculate height
		return Height;
	}
	public void setHeight(int height) {
		//TODO calculate height
		this.Height = height;
	}

	public int getBalanceFactor() {
		//TODO calculate the balance factor
		return balanceFactor;
	}
	

}
