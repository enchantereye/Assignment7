package Tree;

public class Node {
	public int id;
	public String data;
	public Node lchild;
	public Node rchild;
	public int lSubTreeHeight;
	public int rSubTreeHeight;
	public int balanceFactor;
	
	public Node(int id,String data) {
		this.id=id;
		this.data=data;
		this.lchild=null;
		this.rchild=null;
		this.lSubTreeHeight=0;
		this.rSubTreeHeight=0;
		this.balanceFactor=0;
	}
	
	public int getId() {
		return id;
	}
	public String getData() {
		return data;
	}
	public void setData(String data) {
		this.data = data;
	}
	public Node getlChild() {
		return lchild;
	}
	public Node getrChild() {
		return rchild;
	}
	public void setlChild(Node lchild) {
		this.lchild = lchild;
	}
	public void setrChild(Node rchild) {
		this.rchild = rchild;
	}
	public int getHeight(Node node) {
		if(node==null) return 0;
		else {
			int hl=getHeight(node.lchild);
			int hr=getHeight(node.rchild);
			if(hl>hr) return hl+1;
			else return hr+1;
		}
	}
	public int getlSubTreeHeight() {
		//TODO calculate the left sub tree height
		lSubTreeHeight=getHeight(this.lchild);
		return lSubTreeHeight;
	}
	public int getrSubTreeHeight() {
		//TODO calculate the right sub tree height
		rSubTreeHeight=getHeight(this.rchild);
		return rSubTreeHeight;
	}
	public int getBalanceFactor() {
		//TODO calculate the balance factor
		balanceFactor=getlSubTreeHeight()-getrSubTreeHeight();
		return balanceFactor;
	}
	

}
