
public class Node {
	private int id;
	private Object data;
	private Node parent;
	private Node[] children = new Node[2];
	private int height;
	private int balanceFactor;
	
	public Node()
	{
		
	}
	
	public Node(int i,Object obj,Node node1,Node node2)
	{
		data=obj;
		id=i;
		parent=null;
		children[0]=node1;
		children[1]=node2;
        height=0;
        balanceFactor=0;
	}
	
	
	
	public int getId() {
		return id;
	}
	public void setId(int i){
		id=i;
	}
	public Object getData() {
		return data;
	}
	public void setData(Object data) {
		this.data = data;
	}
	public Node getParent() {
		return parent;
	}
	public void setParent(Node parent) {
		this.parent = parent;
	}
	public Node[] getChildren() {
		return children;
	}
	public Node getChildren(int id)
	{
		Node[] node=getChildren();
		return node[id];
	}
	public void setChildren(Node[] children) {
		this.children = children;
	}
	public void setChild(Node child, int id){
		this.children[id] = child;
	}
	public int getHeight() {
		//TODO calculate the left sub tree height
		return height;
	}
	public void setHeight(int i)
	{
		height=i;
	}
	public int getBalanceFactor() {
		//TODO calculate the balance factor
		int i1,i2;
		if(children[0]==null)
			i1=0;
		else
			i1=children[0].getHeight();
		if(children[1]==null)
			i2=0;
		else
			i2=children[1].getHeight();
		return i1-i2;
	}
	public void setBalanceFactor(int i) {
		// TODO Auto-generated method stub
		balanceFactor=i;
	}
}
