
import java.io.BufferedReader;
import java.io.FileReader;


public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AVLTree mytree=new AVLTree();
		try
		{
		FileReader fs = new FileReader("tree_data.dat");
		BufferedReader br = new BufferedReader(fs);
		String record = new String();
		while((record = br.readLine()) != null)
		{
			String[] str=record.split("#");
			Node myNode=new Node(Integer.parseInt(str[1]),str[0],null,null);
			mytree.insert(myNode);
		}
		}
		catch(Exception e)
		{
		e.printStackTrace();; 
		}
		mytree.insert(new Node(18,"leo",null,null));
		/*System.out.println("��������IDΪ14\nID:"+mytree.get(14).getId()+" Data:"+mytree.get(14).getData()+" height:"+mytree.get(14).getHeight()+" BalanceFactor:"+mytree.get(14).getBalanceFactor()
				            +" parent:"+mytree.get(14).getParent().getData());*/
		mytree.delete(2);
		mytree.printTree();
		
		
	}

}
