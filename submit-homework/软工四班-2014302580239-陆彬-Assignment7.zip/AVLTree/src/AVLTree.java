import java.awt.BorderLayout;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;

public class AVLTree implements IAVLTree
{
    private Node root;
    private int size=0;
	
    public AVLTree()
    {
    	
    }
    
	@Override
	public Node get(int id) {
		// TODO Auto-generated method stub
        return get(id,root);
	}

	public Node get(int id,Node node)
	{
		if(node==null)
			return null;
		else
		{
			if(node.getId()==id)
				return node;
			else
			{
				Node[] child=node.getChildren();
				if(get(id,child[0])!=null)
					return get(id,child[0]);
				else if(get(id,child[1])!=null)
					return get(id,child[1]);
				else
					return null;
			}
		}
	}
	
	private Node insert(Node newNode ,Node t){
		if(t == null)
			return newNode;		
		if(newNode.getId() < t.getId()){
			t.setChild(insert(newNode,t.getChildren(0)),0);
			newNode.setParent(t.getChildren(0));
			if(height(t.getChildren(0))-height(t.getChildren(1)) == 2){
				if(newNode.getId() < t.getChildren(0).getId())		//�������
					t = LLRotation(t);
				else									//�������
					t = LRRotation(t);
			}
		}else if(newNode.getId() > t.getId()){
			t.setChild(insert(newNode,t.getChildren(1)),1);
			newNode.setParent(t.getChildren(1));
			if(height(t.getChildren(1))-height(t.getChildren(0)) == 2){
				if(newNode.getId()<t.getChildren(1).getId())		//�������
					t = RLRotation(t);
				else										//�������
					t = RRRotation(t);
			}
		}		
		t.setHeight(Math.max(height(t.getChildren(0)), height(t.getChildren(1)))+1);
		return t;
	}	
	
	@Override
	public void insert(Node newNode) {
		// TODO Auto-generated method stub
		root=insert(newNode,root);
		size++;
	}

	private Node successor(Node e) {
        if(e == null) {
            return null;
        }
        else if(e.getChildren(1) != null) {
            Node p = e.getChildren(1);
            while (p.getChildren(0) != null) {
                p = p.getChildren(0);
            }
            return p;
        }
        else{
            Node p = e.getParent();
            Node c = e;
            while(p != null && c == p.getChildren(1)) {
                c = p;
                p = p.getParent();
            }
            return p;
        }
    }	
	
	protected void fixAfterDeletion(int id, Node ancestor) {

        boolean heightHasDecreased = true;
        while(ancestor != null && heightHasDecreased) 
        {
            int comp = id-ancestor.getId();
            if(comp >= 0) {
                if(ancestor.getBalanceFactor() == 0) 
                {
                    ancestor.setBalanceFactor(1);
                    heightHasDecreased = false;
                } 
                else if(ancestor.getBalanceFactor() ==-1) {
                    ancestor.setBalanceFactor(0);
                    ancestor = ancestor.getParent();
                }
                else if(ancestor.getBalanceFactor() == 1) {
                    // ancestor �����ӽڵ�ƽ������Ϊ '='
                    if(ancestor.getChildren(0).getBalanceFactor() == 0) {
                        ancestor.getChildren(0).setBalanceFactor(-1);
                        ancestor.setBalanceFactor(1);
                        RRRotation(ancestor);
                        heightHasDecreased = false;

                    }// ancestor �����ӽڵ�ƽ������Ϊ 'L' 
                    else if(ancestor.getChildren(0).getBalanceFactor()== 1) {
                        Node p = ancestor.getParent();
                        ancestor.setBalanceFactor(0);
                        ancestor.getChildren(0).setBalanceFactor(0);
                        RRRotation(ancestor);
                        ancestor = p;

                    } // ancestor �����ӽڵ�ƽ������Ϊ 'R'
                    else if(ancestor.getChildren(0).getBalanceFactor() == -1) {
                        Node p = ancestor.getParent();
                        // ancestor �����ӽڵ�����ӽڵ��ƽ������Ϊ 'L'
                        if(ancestor.getChildren(0).getChildren(1).getBalanceFactor() == 1) {
                            ancestor.setBalanceFactor(-1);
                            ancestor.getChildren(0).setBalanceFactor(0);

                        }// ancestor �����ӽڵ�����ӽڵ��ƽ������Ϊ 'R' 
                        else if(ancestor.getChildren(0).getChildren(1).getBalanceFactor() == -1) {
                            ancestor.setBalanceFactor(0);
                            ancestor.getChildren(0).setBalanceFactor(1);
                        }// ancestor �����ӽڵ�����ӽڵ��ƽ������Ϊ '=' 
                        else{
                            ancestor.setBalanceFactor(0);
                            ancestor.getChildren(0).setBalanceFactor(0);
                        }
                        ancestor.getChildren(0).getChildren(1).setBalanceFactor(0);
                        LLRotation(ancestor.getChildren(0));
                        RRRotation(ancestor);
                        ancestor = p;
                    }
                }

            }
            //��ancestor����������ɾ���ڵ�,�������ǶԳƵ�
            else if(comp < 0) {
                if(ancestor.getBalanceFactor() == 0) {

                    ancestor.setBalanceFactor(-1);
                    heightHasDecreased = false;
                } else if(ancestor.getBalanceFactor() == 1) {
                    ancestor.setBalanceFactor(0);
                    ancestor = ancestor.getParent();
                } else if(ancestor.getBalanceFactor() == -1) {
                    if(ancestor.getChildren(1).getBalanceFactor() == 0) {

                        ancestor.setBalanceFactor(-1);
                        ancestor.getChildren(1).setBalanceFactor(1);
                        LLRotation(ancestor);
                        heightHasDecreased = false;
                    } else if(ancestor.getChildren(1).getBalanceFactor() == -1) {
                        Node p = ancestor.getParent();
                        ancestor.setBalanceFactor(0);
                        ancestor.getChildren(1).setBalanceFactor(0);
                        LLRotation(ancestor);
                        ancestor = p;
                    } else if(ancestor.getChildren(1).getBalanceFactor() == 1) {
                        Node p = ancestor.getParent();
                        if(ancestor.getChildren(1).getChildren(0).getBalanceFactor() == -1) {
                            ancestor.setBalanceFactor(1);
                            ancestor.getChildren(1).setBalanceFactor(0);
                        } else if(ancestor.getChildren(1).getChildren(0).getBalanceFactor() == 1) {
                            ancestor.setBalanceFactor(0);
                            ancestor.getChildren(1).setBalanceFactor(-1);
                        } else{
                            ancestor.setBalanceFactor(0);
                            ancestor.getChildren(1).setBalanceFactor(0);
                        }
                        ancestor.getChildren(1).getChildren(0).setBalanceFactor(0);
                        RRRotation(ancestor.getChildren(1));
                        LLRotation(ancestor);
                        ancestor = p;

                    }
                }
            }
        }
    }

	
	@Override
	public void delete(int id) {
		// TODO Auto-generated method stub
		 Node node = get(id);
	     if(node != null)
	     {
	    	 if(node.getChildren(0) != null && node.getChildren(1) != null) {
	             Node s = successor(node);
	             node.setData(s.getData());
	             node.setId(s.getId());
	             node = s;
	         }
	         if( node.getChildren(0)== null && node.getChildren(1) == null) {

	             if(node.getParent() == null) {
	                 root = null;
	             } else if(node == node.getParent().getChildren(0)) {
	            	 node.getParent().setChild(null , 0);
	             }else{
	            	 node.getParent().setChild(null , 1);
	             }

	         } else{
	             Node rep=new Node();
	             if(node.getChildren(0) != null) {
	                 rep = node.getChildren(0);
	             } else{
	                 rep = node.getChildren(1);
	             }
	             rep.setParent(node.getParent());
	             if(node.getParent() == null) {
	                 root = rep;
	             } else if(node == node.getParent().getChildren(0)) {
	                 node.getParent().setChild(rep, 0);
	             } else{
	            	 node.getParent().setChild(rep, 1);
	             }
	         }
	         fixAfterDeletion(node.getId(), node.getParent());

	         node.setParent(null);
	         node.setChild(null, 0);
	         node.setChild(null, 1);

	         size--;
	     }
	     
	}
	
	private void addNode(DefaultMutableTreeNode d,Node node)
	{
		if((node.getChildren(0)!=null) && (node.getChildren(1)!=null))
		{
			DefaultMutableTreeNode lnode = new DefaultMutableTreeNode(node.getChildren(0).getData()+"#"+node.getChildren(0).getId());
			d.add(lnode);
			DefaultMutableTreeNode rnode = new DefaultMutableTreeNode(node.getChildren(1).getData()+"#"+node.getChildren(1).getId());
			d.add(lnode);
			d.add(rnode);
			addNode(lnode,node.getChildren(0));
			addNode(rnode,node.getChildren(1));
		}
		
		else if((node.getChildren(0)!=null)&&(node.getChildren(1)==null))
		{
			DefaultMutableTreeNode lnode = new DefaultMutableTreeNode(node.getChildren(0).getData()+"#"+node.getChildren(0).getId());
			d.add(lnode);
			addNode(lnode,node.getChildren(0));
		}
		
		else if((node.getChildren(1)!=null)&&(node.getChildren(0)==null))
		{
			DefaultMutableTreeNode rnode = new DefaultMutableTreeNode(node.getChildren(1).getData()+"#"+node.getChildren(1).getId());
			d.add(rnode);
			addNode(rnode,node.getChildren(1));
		}
	}
	
	@Override
	public JTree printTree() {
		// TODO Auto-generated method stub
		JTree tree=new JTree();
		if(root==null)
			tree=new JTree(new DefaultTreeModel(new DefaultMutableTreeNode("Empty tree")));
		else
			{
			DefaultMutableTreeNode top = new DefaultMutableTreeNode(root.getData()+"#"+root.getId());
			addNode(top,root);
			tree = new JTree(top);
			}
		JFrame frame=new JFrame("AVLTree");
		frame.setSize(500, 500);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		JPanel panel=new JPanel();
		panel.setLayout(new BorderLayout());
		panel.add(new JScrollPane(tree));
		frame.add(panel);
		frame.setVisible(true);
		return tree;
	}

	private int height(Node node)
	{
		return node == null ? -1 : node.getHeight();
	}
	
	private Node LLRotation(Node node2)
	{
		Node node1=node2.getChildren(0);
		node2.setChild(node1.getChildren(1),0);
		node1.setChild(node2, 1);
		node2.setHeight(Math.max(height(node2.getChildren(0)), height(node2.getChildren(1)))+1);
		node1.setHeight(Math.max(height(node1.getChildren(0)), height(node1.getChildren(1)))+1);	
		return node1;
	}
	
	private Node RRRotation(Node node2)
	{
		Node node1=node2.getChildren(1);
		node2.setChild(node1.getChildren(0),1);
		node1.setChild(node2, 0);
		node2.setHeight(Math.max(height(node2.getChildren(0)), height(node2.getChildren(1)))+1);
		node1.setHeight(Math.max(height(node1.getChildren(0)), height(node1.getChildren(1)))+1);	
		return node1;
	}
	
	private Node LRRotation(Node node3)
	{
		try
		{
			node3.setChild(RRRotation(node3.getChildren(0)), 0);
		}catch(NullPointerException e)
		{
			throw e;
		}
		return LLRotation(node3);
	}
	
	private Node RLRotation(Node node3)
	{
		try
		{
			node3.setChild(RRRotation(node3.getChildren(1)), 1);
		}catch(NullPointerException e)
		{
			throw e;
		}
		return RRRotation(node3);
	}
	
	public Node getRoot() {
		return root;
	}

	public void setRoot(Node root) {
		this.root = root;
	}

	public int getSize() {
		return size;
	}

	public void setSize(int size) {
		this.size = size;
	}

}
