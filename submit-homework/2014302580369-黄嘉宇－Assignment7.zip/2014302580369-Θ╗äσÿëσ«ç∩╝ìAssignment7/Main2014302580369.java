import javax.swing.*;

public class Main2014302580369
{
	
	public static void main(String[] args)
	{
		AVLTree tree=new AVLTree();
		//初始化节点
		Node a=new Node();
		a.setId(1);
		
		Node b=new Node();
		b.setId(2);	
		b.setData("2014302580369-黄嘉宇－Assignment7");
		Node c=new Node();
		c.setId(0);
		Node d=new Node();
		d.setId(6);
		Node e=new Node();
		e.setId(7);
		Node f=new Node();
		f.setId(8);
		Node g=new Node();
		g.setId(-3);		
		Node h=new Node();
		h.setId(-4);

		tree.insert(a);
		tree.insert(b);
		tree.insert(c);
		tree.insert(d);
		tree.insert(e);
		tree.insert(f);
		tree.insert(g);
		tree.insert(h);
		
		//get操作
		System.out.println(tree.get(2));		
		tree.delete(7);
				
	}
}


